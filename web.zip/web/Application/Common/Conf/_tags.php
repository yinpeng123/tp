<?php
if (!IS_CLI) {
    if ( !APP_DEBUG ) { // 线上环境
        return [
            'app_begin'  => [
//                'Common\\Behavior\\profileLogHeadBehavior',
//                'Common\\Behavior\\preventRefreshBehavior',
            ],
            'app_end'    => [
//                'Common\\Behavior\\updateRefreshCacheBehavior',
//                'Common\\Behavior\\profileLogTailBehavior',
            ]
        ];
    } else { // 测试环境
        return [
            'app_begin'  => [
//                'Common\\Behavior\\profileLogHeadBehavior',
//                'Common\\Behavior\\preventRefreshBehavior',
            ],
            'app_end'    => [
//                'Common\\Behavior\\updateRefreshCacheBehavior',
//                'Common\\Behavior\\profileLogTailBehavior',
            ]
        ];
    }
}else{
//    return [
//        'app_begin'  => [
//            'Common\\Behavior\\profileLogHeadBehavior',
//        ],
//        'app_end'    => [
//            'Common\\Behavior\\profileLogTailBehavior',
//        ]
//    ];
}
?>
