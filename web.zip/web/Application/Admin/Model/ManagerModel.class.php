<?php
namespace Admin\Model;

use Basic\Model\BasicModel;

/**
 * Created by PhpStorm.
 * User: edward
 * Date: 2017/6/13
 * Time: 下午2:27
 */
class ManagerModel extends BasicModel {

    private $__manager_model = NULL;

//    public function __construct() {
//        $this->__manager_model = M('admin_manager');
//        $this->__manager_model->setPk('manager_id');
//    }

    /**
     * 构造函数, 缺省为连接主库并不使用缓存!
     *
     * @param string     $db_type 指定主、从数据库, 值分别为: master/slave
     * @param bool|FALSE $enable_cache 是否启用缓存
     */
    public function __construct($db_type = 'master', $enable_cache = FALSE) {
        parent::__construct('admin_manager', \Basic\Cnsts\CACHE_PREFIX::ADMIN_MANAGER, $db_type);
        $this->_enable_cache = $enable_cache;

        $this->__manager_model = $this->_model;
        $this->__manager_model->setPk('manager_id');
    }

    /**
     * 根据id获取管理员信息
     * @param int $manager_id
     * @param string $fields
     */
    public function getManagerById($manager_id, $fields = NULL) {
        $mkey = 'admin_manager_'.$manager_id;
        if ( $mvalue = S($mkey) ) {
            return $mvalue;
        }

        if ( !$fields ) $fields = '*';
        $res = $this->__manager_model->field($fields)->where(['manager_id' => $manager_id])->find();

        if ( $fields == '*' ) {
            S($mkey, $res);
        }

        return $res;
    }

    /**
     * 根据username获取管理员信息
     * @param string $username
     */
    public function getManagerByUsername($username) {
        $manager = $this->__manager_model->where("username='%s' AND is_delete='N'", $username)->find();
        if ( !$manager ) { // 设置缓存
            S('admin_manager_'.$manager['manager_id'], $manager);
        }
        return $manager;
    }

    /**
     * 根据work_sn获取管理员信息
     * @param string $work_sn
     */
    public function getManagerByWorksn($work_sn) {
        $manager = $this->__manager_model->where("work_sn='%d' AND is_delete='N'", $work_sn)->find();
        if ( !$manager ) { // 设置缓存
            S('admin_manager_'.$manager['manager_id'], $manager);
        }
        return $manager;
    }

    // 获取全部管理员列表
    public function getAllManagerList($where=null, $fields = NULL) {
        if ( $fields)
            $this->__manager_model->where($where)->field($fields);
        return $this->__manager_model->select();
    }

    /**
     * 添加管理员
     */
    public function addManager($info) {
        return $this->__manager_model->add($info);
    }

    // 更新manager数据
    public function updateManagerById($manager_id, $info) {
        $this->__manager_model->where(['manager_id' => $manager_id])->save($info);
        S('admin_manager_'.$manager_id, NULL);
    }

    /**
     * 批量更新管理员信息
     * @param $ids
     * @param $info
     */
    public function updateManagers($ids, $info) {
        $this->__manager_model->where(['manager_id' => array('in', $ids)])->save($info);

        foreach ( $ids as $id ) {
            S('admin_manager_'.$id);
        }
    }


    /**
     * 搜索管理员
     * @param array $cond 搜索条件
     * @param int   $page_no 页码
     * @param int   $per_page 每页记录数
     *
     * @return array
     */
    public function searchManager($cond, $page_no, $per_page) {
        $where = ['is_delete' => 'N'];
        if (isset($cond['select_agent_id']) && $cond['select_agent_id']) {
            $where['agent_id'] = $cond['select_agent_id'];
        }
        if ( isset($cond['search_agent_id']) && $cond['search_agent_id'] ) {
            $where['agent_id'] = $cond['search_agent_id'];
        }

        if ( isset($cond['search_realname']) && $cond['search_realname'] ) {
            $where['realname'] = array('like', '%'.$cond['search_realname'].'%');
        }

        if ( isset($cond['search_from_day']) && $cond['search_from_day'] ) {
            $where['ctime'] = array('egt', $cond['search_from_day'].' 00:00:00');
        }

        if ( isset($cond['search_to_day']) && $cond['search_to_day'] ) {
            $where['ctime'] = array('elt', $cond['search_to_day'].' 23:59:59');
        }

        $page_no = max($page_no, 1);
        $data = $this->__manager_model->field('SQL_CALC_FOUND_ROWS *')->where($where)->order('manager_id DESC')
                ->page($page_no, $per_page)->select();
        $res = $this->__manager_model->field("FOUND_ROWS() as total")->find();
        $count = $res['total'];
        $page_number = ceil($count/$per_page);  // 总页数

        if ( $page_number > 0 && $page_no > $page_number ) { // 超出记录集, 返回最后一页的数据
            return $this->searchManager($cond, $page_number, $per_page);
        }

        return array('count' => $count, 'page_number' => $page_number, 'page_no' => $page_no, 'data' => $data);
    }

    //根据渠道ID获取管理员
    public function getList($where) {
        return $this->__manager_model->where($where)->select();
    }

}