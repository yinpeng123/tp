<?php
namespace Admin\Model;


use Basic\Cnsts\CACHE_PREFIX;
use Basic\Model\BasicModel;

class RoleModel extends BasicModel
{

    private $__role_model = NULL;

//    public function __construct() {
//        $this->__role_model = M('admin_role');
//    }

    /**
     * 构造函数, 缺省为连接主库并不使用缓存!
     *
     * @param string     $db_type 指定主、从数据库, 值分别为: master/slave
     * @param bool|FALSE $enable_cache 是否启用缓存
     */
    public function __construct($db_type = 'master', $enable_cache = FALSE) {
        parent::__construct('admin_role', CACHE_PREFIX::ADMIN_ROLE, $db_type);
        $this->_enable_cache = $enable_cache;

        $this->__role_model = $this->_model;
    }

    /**
     * 根据id获取角色信息
     * @param int $manager_id
     * @param string $fields
     */
    public function get($role_id, $fields = NULL) {
        $mkey = 'admin_role_'.$role_id;
        if ( $mvalue = S($mkey) ) {
            return $mvalue;
        }

        if ( !$fields ) $fields = '*';
        $res = $this->__role_model->field($fields)->where(['id' => $role_id])->find();

        if ( $fields == '*' ) {
            S($mkey, $res);
        }

        return $res;
    }

    /**
     * 获取指定agent_id的角色列表
     * @param int $agent_id
     */
    public function getListByAgentId($agent_id = 0) {
        return $this->__role_model->where(['agent_id' => $agent_id])->select();
    }

    /**
     * 添加角色
     */
    public function add($info) {
        return $this->__role_model->add($info);
    }

    /**
     * 更新角色信息
     */
    public function update($role_id, $info) {
        $this->__role_model->where(['id' => $role_id])->save($info);
        S('admin_role_'.$role_id, NULL);
    }

    /**
     * 角色列表
     * @param $cond
     * @param $page_no
     * @param $per_page
     *
     * @return array
     */
    public function searchRoleList($cond, $page_no, $per_page) {
        $page_no = max($page_no, 1);
        $data = $this->__role_model->field('SQL_CALC_FOUND_ROWS *')->where($cond)->order('id DESC')->page($page_no, $per_page)->select();
        $res = $this->__role_model->field("FOUND_ROWS() as total")->find();
        $count = $res['total'];
        $page_number = ceil($count/$per_page);  // 总页数

        if ( $page_number > 0 && $page_no > $page_number ) { // 超出记录集, 返回最后一页的数据
            return $this->searchRoleList($cond, $page_number, $per_page);
        }

        return array('count' => $count, 'page_number' => $page_number, 'page_no' => $page_no, 'data' => $data);
    }

}