<?php
namespace Admin\Controller;

use Admin\Service\ManagerService;
use Basic\Cnsts\CS_WORK_SHEET;
use Basic\Cnsts\DICT;
use Basic\Cnsts\PAY;
use Basic\Cnsts\USER_FINANCE;
use Basic\Model\GasOrderModel;
use Admin\Service\PageService;
use Basic\Model\OilCardLostOrderModel;
use Basic\Model\OilCardModel;
use Basic\Model\OilCardOrderLogModel;
use Basic\Model\OilCardOrderModel;
use Basic\Model\OilCardRechargeOrderModel;
use Basic\Model\OilCardRefundOrderModel;
use Basic\Model\UserModel;
use Basic\Model\UserOilCardModel;
use Basic\Service\CityService;
use Basic\Service\OilCardLostOrderService;
use Basic\Service\OilCardOrderLogService;
use Basic\Service\OilCardOrderService;
use Basic\Service\OilCardRechargeOrderService;
use Basic\Service\OilCardRefundOrderService;
use Basic\Service\OilCardService;
use Basic\Service\SmsService;
use Basic\Service\UserOilCardService;
use Common\Utils\SimpleHttp;
use Gas\Service\GasOrderLinkService;
use Gas\Service\GasOrderService;
use Common\Cnsts\ERRNO;

class OilCardController extends AdminSessionController
{

    const FIX_NUM = 2;  // 控制油卡账户展示条数

    public function __construct()
    {
        parent::__construct();

    }

    /**
     * 订单状态
     */

    const ORDER_STATUS_PAYED       = 20;
    const ORDER_STATUS_ACCEPTED    = 30;
    const ORDER_STATUS_MAILING     = 40;
    const ORDER_STATUS_DONE        = 50;

    const ORDER_STATUS_NAME = [
        self::ORDER_STATUS_PAYED       => '待受理',
        self::ORDER_STATUS_ACCEPTED    => '待邮寄',
        self::ORDER_STATUS_MAILING     => '已邮寄',
        self::ORDER_STATUS_DONE        => '已完成',

    ];

    /**
     * 充值状态
     */
    const RECHARGE_NOT_PAY = 10;
    const RECHARGE_APPLY = 20;
    const RECHARGE_DONE = 50;

    const RECHARGE_STATUS_ARR = [
//        self::RECHARGE_NOT_PAY       => '未支付',
        self::RECHARGE_APPLY    => '待处理',
        self::RECHARGE_DONE     => '已完成',
    ];

    /**
     * 支付方式
     */
    const OP_TYPE_ARR = [
        '10' => '支付宝',
        '12' => '微信',
//        '20' => '余额',
    ];

    const PURCHASE_TYPE = [
        '1' => '线上',
        '2' => '线下',
    ];

    // 订单类型
    const RECHARGE = 2;


    public function demolist() {
        $this->assignAll(array(
            'title' => '油卡销售列表',
            'express_list' => DICT::EXPRESS_COMPANY_LIST,
        ));
        $this->display('oil_demo_index');
    }

    public function demoadd() {
        $this->assignAll(array(
            'title' => '添加油卡销售订单',
        ));
        $this->display('oil_demo_info');
    }

    public function demolist2() {
        $this->assignAll(array(
            'title' => '油卡批销列表',
            'express_list' => DICT::EXPRESS_COMPANY_LIST,
        ));
        $this->display('oil_demo_index2');
    }

    public function demoadd2() {
        $this->assignAll(array(
            'title' => '添加油卡批售订单',
        ));
        $this->display('oil_demo_info2');
    }


    public function index() {
        $status_arr = $this->getStatus();
        array_shift($status_arr);

        $pay_time = I('pay_time');
        $gas_id = I('gas_id');
        $telephone = I('telephone');
        $status = I('status');
        $car_num = I('car_num');
        $phone = I('phone');
        $express_no = I('express_no');

        $cond = [];
        $cond['gas_order.status'] = ['gt', 100];
        $cond['gas_order.is_delete'] = ['eq', 0];
        $cond['gas_order_link.is_delete'] = ['eq', 0];

        if (!empty($pay_time)) {
            $cond['gas_order.pay_time'] = [['egt', $pay_time. ' 00:00:00'], ['elt', $pay_time . ' 23:59:59']];
        }
        if (!empty($gas_id)) {
            $cond['gas_order.id'] = ['eq', $gas_id];
        }
        if (!empty($telephone)) {
            $cond['gas_user.telephone'] = ['eq', $telephone];
        }
        if (!empty($status)) {
            if ($status == 100) {
                $cond['gas_order.status'] = ['gt', 100];
            } else{
                $cond['gas_order.status'] = ['eq', $status];
            }

        }
        if (!empty($car_num)) {
//            $cond['gas_order_link.car_num'] = ['eq', $car_num];
            $map['gas_order_link.car_num'] = ['eq', $car_num];
            /** @var GasOrderLinkService $gas_order_link_service */
            $gas_order_link_service = D('Gas/GasOrderLink', 'Service');
            $gas_link_list = $gas_order_link_service->getListBy($map, $fields = '', $order = '', $curpage = 0, $perpage = 0);
            $ids = [];
            foreach ($gas_link_list as $v) {
                $ids[] = $v['gas_oid'];
            }
            $cond['gas_order.id'] = ['in', array_unique($ids)];
        }
        if (!empty($phone)) {
            $cond['gas_order.phone'] = ['eq', $phone];
        }
        if (!empty($express_no)) {
            $cond['gas_order.express_no'] = ['eq', $express_no];
        }


//p($cond);die;
        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        /** @var GasOrderModel $gas_model */
        $gas_model = D('Gas/GasOrder', 'Model');
        $ret = $gas_model->searchList($cond, $curr_page, $per_page);

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav = $page_service->show();

        /** @var CityService $city_service */
        $city_service = D('Basic/City', 'Service');
        foreach ($ret['data'] as &$v) {
            foreach ($v as &$vv) {
                $vv['status_text'] = \Gas\Cnsts\GAS_ORDER::STATUS_LIST[$vv['status']];
                for ($i=0; $i<self::FIX_NUM; $i++) {
                    $vv['gas_card_no_list'] .= t_json_decode($vv['gas_card_no'])[$i].'<br>';
                }
                $vv['to_code_text'] = $city_service->getAreaFullName($vv['to_code'], $sep = '');
                $vv['pay_type_text'] = USER_FINANCE::PAY_TYPE_ARR[$vv['op_type']];
            }
        }
        // 获取统计数据
        $text = $this->_getTotalFee($ret['data']);
        $search_param = [
            'pay_time' => $pay_time,
            'gas_id' => $gas_id,
            'telephone' => $telephone,
            'status' => $status,
            'car_num' => $car_num,
            'phone' => $phone,
            'express_no' => $express_no,
        ];
//        p($page_nav);die;
        $this->assignAll(array(
            'title' => '油卡销售列表',
            'status_arr' => $status_arr,
            'page_nav' => $page_nav,
            'list' => $ret['data'],
            'express_list' => DICT::EXPRESS_COMPANY_LIST,
            'search_param' => $search_param,
            'fix_num' => self::FIX_NUM,
            'text' => $text,
        ));
        $this->display('oil_index');
    }

    private function _getTotalFee($data) {
        $op_type = [];
        foreach ($data as $v) {
            foreach ($v as $vv) {
                $op_type[] = $vv['pay_type_text'];
            }
        }
        $op_type_list = array_unique($op_type);
        $list = [];
        foreach ($op_type_list as $k=>$v) {
            foreach($data as &$vv) {
                $vv['total'] = $vv[0]['total_fee'];
                $vv['pay_type_text'] = $vv[0]['pay_type_text'];
                if ($vv['pay_type_text'] == $v) {
                    $list[$k]['type'] = $v;
                    $list[$k]['total'] += $vv['total'];
                }
                unset($vv['total']);
                unset($vv['pay_type_text']);
            }
        }
        $total_money = 0;
        $fen = '';
        foreach ($list as &$v) {
            $total_money += $v['total'];
            $fen .= '其中' . $v['type'] . '：' . sprintf("%.2f", $v['total']) . '元。';
        }
        $text_total = '总油费收入：'. sprintf("%.2f", $total_money);
        $text = $text_total . $fen;
        return $text;
    }

    // 寄送
    public function ajaxSend() {
        $gas_id = I('gas_id/d');
        if (!$gas_id) {
            $this->ajaxResponse(ERRNO::DATA_NOT_EXISTS, ERRNO::e(ERRNO::DATA_NOT_EXISTS),[]);
        }

        $up_data = [
            'express_no' => (int)I('express_no_input'),
            'express_company' => I('express_company'),
            'status' => \Gas\Cnsts\GAS_ORDER::MAILED,
        ];

        // 修改gas_order表
        /** @var GasOrderService $gas_order_service */
        $gas_order_service = D('Gas/GasOrder', 'Service');
        $res = $gas_order_service->updateById($gas_id, $up_data);

        // 修改gas_order_link表
        /** @var GasOrderLinkService $gas_order_link_service */
        $gas_order_link_service = D('Gas/GasOrderLink', 'Service');
        $res1 = $gas_order_link_service->updateLinkByGasId($gas_id, I('')['data']);
        if ($res && $res1)
            $this->ajaxResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), []);
        $this->ajaxResponse(ERRNO::SQL_UPDATE_ERRNO, '修改失败',[]);
    }

    public function ajaxGetGasOrderInfo() {
        $gas_order_id = I('gas_id/d');
        $amount = I('card_amount');

        if (!$gas_order_id) {
            $this->ajaxResponse(-1, '油卡订单号不正确！！！');
        }

        $where = [
            'gas_oid' => $gas_order_id,
            'id' => $amount,
        ];
        /** @var GasOrderLinkService $gas_order_link_service */
        $gas_order_link_service = D('Gas/GasOrderLink', 'Service');
        $info = $gas_order_link_service->getByWhere($where);
        $info['gas_card_no'] = implode(',', t_json_decode($info['gas_card_no']));
        $this->ajaxResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), $info);
    }

    protected function getStatus()
    {
        $status_arr  = [];
        $status_list = \Gas\Cnsts\GAS_ORDER::STATUS_LIST;
        $status_keys = array_keys($status_list);
        foreach ($status_keys as $i => &$r) {
            $status_arr[] = ['id' => $r, 'text' => $status_list[$r]];
        }

        return $status_arr;
    }

    /**
     * 油卡库存列表
     */
    public function stockIndex() {
        $card_no = trim(I('card_no'));
        $telephone = trim(I('telephone'));
        $status = trim(I('status/d'));
        $cond = [];
        if (!empty($card_no)) {
            $cond['card_no'] = ['eq', $card_no];
        }
        if (!empty($telephone)) {
            $cond['telephone'] = ['eq', $telephone];
        }
        if (!empty($status)) {
            if ($status == 50) {
                $cond['agent'] = ['exp', 'is not null'];
            } else {
                $cond['status'] = ['eq', $status];
                $cond['agent'] = ['exp', 'is null'];
            }
        }

        $per_page  = C('TABLE_PER_PAGE');
        $page_no = I('path.2/d', 1);
        /** @var OilCardModel $oil_card_model */
        $oil_card_model = D('Basic/OilCard', 'Model');
        $ret = $oil_card_model->oilCardsList($cond, $page_no, $per_page);

        $data = $this->_formatInfo($ret['data']);

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();

        $search_param = [
            'card_no' => $card_no,
            'telephone' => $telephone,
            'status' => $status,
        ];

        $status_arr = [
            '10'=> '可用',
            '20'=> '使用中',
            '30'=> '已挂失',
            '40'=> '已退款',
            '50'=> '批售',
        ];
        $this->assignAll(array(
            'title' => '油卡库存列表',
            'list' => $data,
            'count' => $this->_getNum(),
            'status_arr' => $status_arr,
            'search_param' => $search_param,
            'page_nav' => $page_nav,
        ));
        $this->display('oil_stock_index');
    }

    private function _getNum() {
        /** @var OilCardModel $oil_card_model */
        $oil_card_model = D('Basic/OilCard', 'Model');
        $rem = $oil_card_model->getByCond(['agent' => ['exp','is null']], $lock = FALSE);

        $available = 0;
        $asstinged = 0;
        $losted = 0;
        $refunded = 0;

        foreach ($rem as $v) {
            switch ($v['status'])
            {
                case OilCardService::CARD_STATUS_AVAILABLE;
                    $available +=1;
                    break;
                case OilCardService::CARD_STATUS_ASSIGNED;
                    $asstinged +=1;
                    break;
                case OilCardService::CARD_STATUS_LOSTED;
                    $losted +=1;
                    break;
                case OilCardService::CARD_STATUS_REFUNDED;
                    $refunded +=1;
                    break;
                default;
                    $available = 0;
                    $asstinged = 0;
                    $losted = 0;
                    $refunded = 0;
            }

        }

        $batch_list = $oil_card_model->getByCond(['agent' => ['exp', 'is not null']], $lock = FALSE);
        $batch = count($batch_list);
        $count = [
            'total_count' => count($rem) + $batch,
            'available' => $available ,
            'asstinged' => $asstinged ,
            'losted' => $losted ,
            'refunded' => $refunded ,
            'batch' => $batch ,
        ];

        return $count;
    }

    public function editCard() {
        $card_id = I('card_id');
        /** @var OilCardModel $card_model */
        $card_model = D('Basic/OilCard', 'Model');
        $card_info = $card_model->getById($card_id, $lock = FALSE);
        $data = [$card_info];
        $info = $this->_formatInfo($data);
        $this->assignAll(array(
            'title' => '编辑油卡',
            'card_info' => $info[0],
            'refer' => $this->_refer,
            'form_action' => '/OilCard/doEdit',
        ));
        $this->display('oil_card_edit');
    }

    public function doEdit() {
        $card_pass = I('card_pass');
        $card_id = I('card_id');
        $data = [
            'card_pass' => $card_pass,
        ];
        /** @var OilCardModel $card_model */
        $card_model = D('Basic/OilCard', 'Model');
        $res = $card_model->updateById($card_id, $data);
        if ($res) {
            $this->ajaxResponse(0, '修改成功');
        } else {
            $this->ajaxResponse(1, '修改失败');
        }
    }

    private function _formatInfo($data) {
        /** @var UserModel $user_model */
        $user_model = D('Basic/User', 'Model');
        /** @var OilCardOrderModel $oil_order_model */
        $oil_order_model = D('Basic/OilCardOrder', 'Model');
//        p($data);die;
        foreach ($data as &$v) {
            $v['status_text'] = OilCardService::CARD_STATUS_NAME[$v['status']];

            if (!empty($v['agent'])) {
                $v['status_text'] = '批售';
            }
            if (empty($v['telephone'])) {
//                $v['status'] = '可用';
            } else {
                // 根据手机号获取购买人账号
                $info = $user_model->getBy(['telephone' => $v['telephone']], ['account', 'id']);
                $v['account'] = $info['account'];
                $v['uid'] = $info['id'];
//                $v['status'] = '已售';

                // 获取下单时间
                $order_id = $this->_getOrderIdByCardNo($v['card_no']);
                /** @var OilCardOrderModel $order_model */
                $order_model = D('Basic/OilCardOrder', 'Model');
                $order_info = $order_model->getById($order_id, $lock = FALSE);
                $v['order_ctime'] = $order_info['ctime'];
//                $list = $oil_order_model->getListBy(['telephone' => $v['telephone']], ['telephone', 'card_list', 'ctime'], $order = '', 0, 0);
//                foreach ($list as &$vv) {
//                    $vv['card_list'] = t_json_decode($vv['card_list']);
//                    foreach ($vv['card_list'] as $vvv) {
//                        $vv['card_no_list'][] = $vvv['card_no'];
//                    }
//                    if (in_array($v['card_no'], $vv['card_no_list'])) {
//                        $v['order_ctime'] = $vv['ctime'];
//                    }
//                }
            }
//            $v['card_company_text'] = $v['card_company'] == 1 ? '北京' : '山西';

        }
        return $data;
    }

    public function uploadFile() {
        $key = key($_FILES);
        $file_types = explode ( ".", $_FILES [$key] ['name'] );
        $file_type = $file_types [count ( $file_types ) - 1];
        /*判别是不是.xls文件，判别是不是excel文件*/
        if (strtolower ( $file_type ) != "xls"){
            $this->ajaxResponse(-1, '不是Excel文件，重新上传');
        }
        $root_dir   = C('OIL_FILE_PATH')['oil_file'];
        $sub_dir    = day();
        $file_info = $_FILES[$key];
        list($errcode, $errmsg, $res) = uploadFile($key, $root_dir, $sub_dir, $file_info, $key);

        $fullpath = $root_dir  . $sub_dir . "/" . $file_info['name'];
        //获取上传的excel表格的数据，形成数组
        list($errno, $errmsg, $ret) = $this->actionRead($fullpath,'utf-8');
        $this->ajaxResponse($errno, $errmsg, $ret);
    }

    public function actionRead($file_name,$encode='utf-8'){
        $service = new \Vendor\ImportExcel\ExcelParser();
        $origin_data = $service->getData($file_name);
        $data = $this->_formateData($origin_data);
        /** @var OilCardService $oil_service */
        $oil_service = D('Basic/OilCard', 'Service');
        list($errno, $errmsg, $ret) = $oil_service->oilLeading($data);
        return [$errno, $errmsg, $ret];
    }

    /**
     * 导入批售油卡
     */
    public function uploadFileBatch() {
        $key = key($_FILES);
        $file_types = explode ( ".", $_FILES [$key] ['name'] );
        $file_type = $file_types [count ( $file_types ) - 1];
        /*判别是不是.xls文件，判别是不是excel文件*/
        if (strtolower ( $file_type ) != "xls"){
            $this->ajaxResponse(-1, '不是Excel文件，重新上传');
        }
        $root_dir   = C('OIL_FILE_PATH')['oil_file'];
        $sub_dir    = day();
        $file_info = $_FILES[$key];
        list($errcode, $errmsg, $res) = uploadFile($key, $root_dir, $sub_dir, $file_info, $key);

        $fullpath = $root_dir  . $sub_dir . "/" . $file_info['name'];
        //获取上传的excel表格的数据，形成数组
        list($errno, $errmsg, $ret) = $this->actionBatchRead($fullpath,'utf-8');
        $this->ajaxResponse($errno, $errmsg, $ret);
    }

    public function actionBatchRead($file_name,$encode='utf-8'){
        $service = new \Vendor\ImportExcel\ExcelParser();
        $origin_data = $service->getData($file_name);
        $data = $this->_formateData($origin_data);
        /** @var OilCardService $oil_service */
        $oil_service = D('Basic/OilCard', 'Service');
        list($errno, $errmsg, $ret) = $oil_service->oilBatchLeading($data);
        return [$errno, $errmsg, $ret];
    }

    public function _formateData($data) {
        array_shift($data);
        $arr = array_merge($data);
        $for_data = [];
        for ($i=0; $i<count($arr); $i++) {
            if (!empty($arr[$i][0])) {
                $for_data[$i] = $arr[$i];
            }
        }
        return $for_data;
    }

    public function offLineAdd() {
        $order_id = I('oil_order_id/d');
        $certain_type = I('certain_type', 1);
        $certain_id = I('certain_id', '');
        $express_list = DICT::EXPRESS_COMPANY_LIST;

        $url = $_SERVER['HTTP_REFERER'];
        $arr = explode('/', $url);
        if ($arr[count($arr)-1] == 'doAdd') {
            $arr[count($arr)-1] = 'oilOrderIndex';
            $url = implode('/', $arr);

        }
        if ($order_id > 0) {
            $this->_orderDetail($order_id);
        } else {
            $this->_offLineAdd($certain_id);
        }
        $this->assignAll(array(
            'certain_type' => $certain_type,
            'express_list' => $express_list,
            'oil_order_id' => $order_id,
            'refer' => $url,
            'form_action' => '/OilCard/doAdd',
        ));
        $this->display('oil_offLine_add');
    }

    // 订单详情
    private function _orderDetail($order_id) {
        /** @var OilCardOrderService $oil_order_service */
        $oil_order_service = D('Basic/OilCardOrder', 'Service');
        $order_info = $oil_order_service->getOrderInfo($order_id);
//p($order_info);die;
        $card = t_json_decode($order_info['card_list']);
//        p($card);die;
        /** @var OilCardRechargeOrderService $oil_card_recharge_service */
        $oil_card_recharge_service = D('Basic/OilCardRechargeOrder', 'Service');

        for ($i = 0; $i<count($card); $i++) {
            $card[$i]['s_price'] = $order_info['purchase_type'] == 2 ? $card[$i]['selling_price'] : $card[$i]['price'] * $card[$i]['discount'] / 100;
            $card[$i]['fee'] = $order_info['purchase_type'] == 2 ? $card[$i]['in_fee'] : $card[$i]['s_price'] + $card[$i]['extra_fee'];

            // 根据油卡对应的充值订单状态判断该油卡是否可以编辑
            $card[$i]['status'] = $oil_card_recharge_service->getOrderByCardNo($card[$i]['card_no'])[0];
            $card[$i]['recharge_id'] = $oil_card_recharge_service->getOrderByCardNo($card[$i]['card_no'])[1];
        }
        $order_info['card_list'] = t_json_encode($card);
        // 新用户的邮寄地址
        $res = D('Basic/User', 'Model')->getBy(['telephone' => $order_info['telephone']], $fields = '');
        if (!$res) {
//            $mail_info = D('Basic/MailInfo', 'Model') -> getByNewTelephone($order_info['telephone']);
            $mail_info = D('Basic/MailInfo', 'Model') -> getMailInfoById($order_info['mail_id']);
            /** @var CityService $city_service */
            $city_service = D('Basic/City', 'Service');
            $order_info['pcd'] = $province_city_dis = $city_service->getAreaFullName($mail_info['district'], $sep = '-');
            $order_info['addr'] = $mail_info['addr'];
            $order_info['user_name'] = $mail_info['user_name'];
            $order_info['telephone'] = $mail_info['telephone'];
        }
//        p($order_info);die;
        if ($order_info['pay_time'] == '0000-00-00 00:00:00') {
            $order_info['pay_time'] = '';
        }
        $this->assignAll(array(
            'title' => '订单详情',
            'order' => $order_info,
            'certain_id' => $order_info['telephone'],
            'act' => 'edit',
            'charging_list' => $order_info['purchase_type'] == 1 ? USER_FINANCE::PAY_TYPE_ARR : CS_WORK_SHEET::WS_CHARGING_ARR,
            'op_charging_type' => $order_info['purchase_type'] == 1 ? $order_info['op_type'] : $order_info['charging'],
            'fee' => $order_info['purchase_type'] == 1 ? $order_info['total_fee'] : $order_info['total_fee'],
        ));

        // 添加操作记录
        if ($order_info['status'] == self::ORDER_STATUS_PAYED ) {
            /** @var OilCardOrderLogService $oil_card_log_service */
            $oil_card_log_service = D('Basic/OilCardOrderLog', 'Service');
            $oil_card_log_service->addCardAcceptLog($order_info['id'], $this->_manager_id);
            /** @var OilCardOrderModel $oil_card_order_model */
            $oil_card_order_model = D('Basic/OilCardOrder', 'Model');
            $oil_card_order_model->updateById($order_id, ['status' => self::ORDER_STATUS_ACCEPTED, 'manager_id' => $this->_manager_id]);
        }
    }

    // 添加线下油卡销售记录
    private function _offLineAdd($certain_id) {
        /** @var OilCardModel $oil_card_model */
        $oil_card_model = D('Basic/OilCard', 'Model');
        $res = $oil_card_model->getAvaliableCards(1);
        if (!$res) {
            $this->admin_warn('油卡库存不足，请补充后再次添加订单！！！');
            exit();
        }
        $this->assignAll(array(
            'title' => '添加油卡销售记录',
            'certain_id' => $certain_id,
            'act' => 'add',
            'order' => ['id' => 0, 'card_list' => [], 'purchase_type' => 2, 'pay_time' => date('Y-m-d')],
            'charging_list' => CS_WORK_SHEET::WS_CHARGING_ARR,
        ));
    }

    /**
     * 获取订单对应的油卡详情
     */
    public function getOrderCards($id) {
        /** @var OilCardOrderService $oil_order_service */
        $oil_order_service = D('Basic/OilCardOrder', 'Service');
        $card_list = $oil_order_service->getOrderCards($id);
        return $card_list;
    }

    public function doAdd() {
        /** @var OilCardOrderService $oil_card_order_service */
        $oil_card_order_service = D('Basic/OilCardOrder', 'Service');
        $_POST['manager_id'] = $this->_manager_id;
        $url_arr = explode('/', $_POST['refer']);
        list($errno, $errmsg, $res) = $oil_card_order_service->offLineAdd($_POST);
        if ($errno == ERRNO::SUCCESS) {
            if (empty(end($url_arr))) {
                redirect(U('oilCard/oilOrderIndex'));
            } else {
                redirect(U('oilCard/oilOrderIndex') . '/' . end($url_arr));
            }
        } else {
            $this->admin_warn($errmsg, $_POST['refer']);
        }
    }

    /**
     * 油卡销售列表
     */
    public function oilOrderIndex() {
        $status_arr = self::ORDER_STATUS_NAME;
        $purchase_type_arr = self::PURCHASE_TYPE;
        $pay_time = trim(I('pay_time'));
        $pay_time_to = trim(I('pay_time_to'));
        $oil_order_id = trim(I('oil_order_id'));
        $telephone = trim(I('telephone'));
        $status = trim(I('status'));
        $purchase_type = trim(I('purchase_type'));
        $car_num = trim(I('car_num'));
        $phone = trim(I('phone'));
        $express_no = trim(I('express_no'));
        $card_no = trim(I('card_no'));

        $cond = [];

        if (!empty($card_no)) {
            $order_id = $this->_getOrderIdByCardNo($card_no);
            $cond['oil_card_order.id'] = ['eq', $order_id];
        }
        $cond['oil_card_order.status'] = ['gt', 10];
        if (!empty($pay_time)) {
            $cond['oil_card_order.ctime'] = ['egt', $pay_time. ' 00:00:00'];
        }
        if (!empty($pay_time_to)) {
            $cond['oil_card_order.ctime'] = ['elt', $pay_time_to. ' 23:59:59'];
        }
        if (!empty($pay_time) && !empty($pay_time_to)) {
            $cond['oil_card_order.ctime'] = [['egt', $pay_time. ' 00:00:00'], ['elt', $pay_time_to. ' 23:59:59']];
        }
        if (!empty($oil_order_id)) {
            $cond['oil_card_order.id'] = ['eq', $oil_order_id];
        }
        if (!empty($telephone)) {
            $cond['oil_card_order.telephone'] = ['eq', $telephone];
//            $map['user.account'] = ['eq', $telephone];
//            $map['user.net_no'] = ['eq', $telephone];
//            $map['user.telephone'] = ['eq', $telephone];
//            $map['_logic'] = 'OR';
//            $cond['_complex'] = $map;
        }
        if (!empty($status)) {
            if ($status == 10) {
                $cond['oil_card_order.status'] = ['gt', 10];
            } else {
                $cond['oil_card_order.status'] = ['eq', $status];
            }
        }
        if (!empty($car_num)) {
            $cond['oil_card_order.card_list'] = ['like', '%' . $car_num . '%'];
        }
        if (!empty($phone)) {
            $cond['mail_info.telephone'] = ['eq', $phone];
        }
        if (!empty($express_no)) {
            $cond['oil_card_order.express_no'] = ['eq', $express_no];
        }
        if (!empty($purchase_type)) {
            $cond['oil_card_order.purchase_type'] = ['eq', $purchase_type];
        }

        $search_param = [
            'pay_time' => $pay_time,
            'oil_order_id' => $oil_order_id,
            'telephone' => $telephone,
            'status' => $status,
            'purchase_type' => $purchase_type,
            'car_num' => $car_num,
            'phone' => $phone,
            'express_no' => $express_no,
            'card_no' => $card_no,
        ];

        $cond['oil_card_order.is_delete'] = ['eq', 0]; // 正常订单，未删除
        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);

        /** @var OilCardOrderModel $oil_card_order_model */
        $oil_card_order_model = D('Basic/OilCardOrder', 'Model');
        $ret = $oil_card_order_model->oilCardOrderList($cond, $curr_page, $per_page);
        // 转化展示信息
        $this->_formateList($ret['data']);
//p($ret['data']);die;
        $page_service = new PageService($ret['count'], $per_page);
        $page_nav = $page_service->show();

        $this->assignAll(array(
            'title' => '油卡销售列表',
            'order_list' => $ret['data'],
            'search_param' => $search_param,
            'status_arr' => $status_arr,
            'purchase_type_arr' => $purchase_type_arr,
            'page_nav' => $page_nav,
        ));
        $this->display('oil_order_index');
    }

    /**
     * @param $card_no 根据卡号获取对应订单号
     *
     * @return int|string 订单号
     */
    public function _getOrderIdByCardNo($card_no) {
        /** @var OilCardOrderModel $oil_card_order_model */
        $oil_card_order_model = D('Basic/OilCardOrder', 'Model');
        $list = $oil_card_order_model->getByCond(['is_delete' => 0], $lock = FALSE);
//        p($list);die;
        $arr = [];
        foreach ($list as &$v) {
            $v['card_list'] = t_json_decode($v['card_list']);
        }
        for ($i=0; $i<count($list); $i++) {
            for ($j=0; $j<count($list[$i]['card_list']); $j++) {
                $arr[$list[$i]['id']][$j] = $list[$i]['card_list'][$j]['card_no'];
            }
        }
//        p($arr);die;
        $order_id = 0;
        foreach ($arr as $k=>$v) {
            if (in_array($card_no, $v)) {
                $order_id = $k;
            }
        }
        return $order_id;
    }

    private function _formateList(&$data) {
        /** @var CityService $city_service */
        $city_service = D('Basic/City', 'Service');
        /** @var OilCardOrderService $oil_order_service */
        $oil_order_service = D('Basic/OilCardOrder', 'Service');
        foreach ($data as &$v) {
            $card = t_json_decode($v['card_list']);
            /** @var UserOilCardModel $user_oil_card_model */
            $user_oil_card_model = D('Basic/UserOilCard', 'Model');
            for ($i = 0; $i<count($card); $i++) {
                $card[$i]['s_price'] = $v['purchase_type'] == 2 ? $card[$i]['selling_price'] : $card[$i]['price'] * $card[$i]['discount'] / 100;
                $card[$i]['fee'] = $v['purchase_type'] == 2 ? $card[$i]['in_fee'] : $card[$i]['s_price'] + $card[$i]['extra_fee'];
                $info = $user_oil_card_model->getByCond(['card_no' => $card[$i]['card_no']], $fields = [], $order = 'id desc', $count = 0);
                $card[$i]['activation_time'] = $info[0]['activation_time'];
            }
            $v['card_list'] = $card;

            $v['address'] = $city_service->getAreaFullName($v['district'] == 0 ? $v['city'] : $v['district'], $sep = '');
            $v['status_text'] = self::ORDER_STATUS_NAME[$v['status']];
            $v['purchase_type_text'] = $v['purchase_type'] == 1 ? '线上' : '线下';
            $v['express_company_text'] = DICT::EXPRESS_COMPANY_LIST[$v['express_company']] == '请选择' ? '' : DICT::EXPRESS_COMPANY_LIST[$v['express_company']];
            if ($v['purchase_type'] == 1) {
                $type_text = USER_FINANCE::PAY_TYPE_ARR[$v['op_type']];
            } else {
                $type_text = CS_WORK_SHEET::WS_CHARGING_ARR[$v['charging']];
            }
            $v['op_type_text'] = $type_text;
//            $info = $this->getManager($v['id']);
//            $v['manager'] = $info['username'];
//            if (empty($v['manager'])) {
//                $v['up_mtime'] = '';
//            } else {
//                $v['up_mtime'] = $info['mtime'];
//            }
            /** @var ManagerService $manager_service */
            $manager_service = D('Admin/Manager', 'Service');
            $info = $manager_service->get($v['manager_id'], ['username']);
            $v['manager'] = $info['username'];
            $v['up_mtime'] = $v['mtime'];
            $v['payment_id'] = $v['payment_id'] == 0 ? '' : $v['payment_id'];
        }
        return $data;
    }

    public function getManager($order_id) {
        /** @var OilCardOrderLogModel $order_log_model */
        $order_log_model = D('Basic/OilCardOrderLog', 'Model');
        $res = $order_log_model->getByOrder($order_id, 1);
        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');
        $info = $manager_service->get(end($res)['manager_id'], ['username']);
        $info['mtime'] = end($res)['mtime'];
        return $info;
    }


    /**
     * 油卡充值列表页
     */
    public function oilCardRecharge() {
        $per_page  = C('TABLE_PER_PAGE');
        $page_no = I('path.2/d', 1);

        $search_ftime_from = I('search_ftime_from');
        $search_ftime_to = I('search_ftime_to');
        $recharge_id = I('recharge_id');
        $account = I('account');
        $status = I('status');
        $card_no = I('card_no');
        $op_type = I('op_type');

        $cond = [];
        if (!empty($search_ftime_from) && !empty($search_ftime_to)) {
            $cond['oil_card_recharge_order.ctime'] = [['egt', $search_ftime_from . ' 00:00:00'], ['elt', $search_ftime_to . ' 23:59:59']];
        } elseif (!empty($search_ftime_from)) {
            $cond['oil_card_recharge_order.ctime'] = ['egt', $search_ftime_from . ' 00:00:00'];
        } elseif (!empty($search_ftime_to)) {
            $cond['oil_card_recharge_order.ctime'] = ['elt', $search_ftime_to . ' 23:59:59'];
        }
        if (!empty($recharge_id)) {
            $cond['oil_card_recharge_order.recharge_id'] = ['eq', $recharge_id];
        }
        if (!empty($account)) {
            $cond['oil_card_recharge_order.telephone'] = ['eq', $account];
        }
        if (!empty($status)) {
            $cond['oil_card_recharge_order.status'] = ['eq', $status];
        } else {
            $cond['oil_card_recharge_order.status'] = ['egt', self::RECHARGE_APPLY];
        }
        if (!empty($card_no)) {
            $cond['oil_card_recharge_order.card_no'] = ['eq', $card_no];
        }
        if (!empty($op_type)) {
            $cond['oil_card_recharge_order.op_type'] = ['eq', $op_type];
        }

//
        /** @var OilCardRechargeOrderModel $oil_card_recharge_model */
        $oil_card_recharge_model = D('Basic/OilCardRechargeOrder', 'Model');
        $ret = $oil_card_recharge_model->oilCardRechargeList($cond, $page_no, $per_page);
//p($ret['data']);die;
        // 获取操作人员与操作时间
        foreach ($ret['data'] as &$v) {
            $info = $this->_getManagerAndMtime($v['id']);
            $v['user_name'] = $info['user_name'];
            $v['manager_mtime'] = $info['mtime'];
        }
        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();

        $search_param = [
            'ctime' => I('search_from_day'),
            'recharge_id' => I('recharge_id'),
            'account' => I('account'),
            'status' => I('status'),
            'card_no' => I('card_no'),
            'op_type' => I('op_type'),
            'search_ftime_from' => I('search_ftime_from'),
            'search_ftime_to' => I('search_ftime_to'),
        ];
        $this->assignAll(array(
            'title' => '油卡充值管理',
            'status_arr' => self::RECHARGE_STATUS_ARR,
            'op_type_arr' => self::OP_TYPE_ARR,
            'search_param' => $search_param,
            'list' => $ret['data'],
            'page_nav' => $page_nav,
        ));
        $this->display('oil_card_recharge_index');
    }

    /**
     * @param $id 充值订单id
     *
     * @return array
     */
    public function _getManagerAndMtime($id) {
        $oil_order_log_model = D('Basic/OilCardOrderLog', 'Model');
        $log_list = $oil_order_log_model->getByOrder($id, 2);
        $manager_id = 0;
        $mtime = '';
        foreach ($log_list as $v) {
            if ($v['log_type'] == 5) {
                $manager_id = $v['manager_id'];
                $mtime = $v['mtime'];
            }
        }

        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');
        $m = $manager_service->get($manager_id, ['username']);
        return ['user_name' => $m['username'], 'mtime' => $mtime];
    }

    /**
     * 充值
     */
    public function doRecharge() {
        $data = [
            'id' => I('id'),
            'telephone' => I('telephone'),
            'amount' => I('amount'),
            'card_no' => substr(I('card_no'), -4),
        ];
        // 修改订单状态
        /** @var OilCardRechargeOrderModel $oil_card_recharge_model */
        $oil_card_recharge_model = D('Basic/OilCardRechargeOrder', 'Model');
        $oil_card_recharge_model->updateById($data['id'], ['status' => self::RECHARGE_DONE]);

        // 写日志
        /** @var OilCardOrderLogService $oil_order_log_service */
        $oil_order_log_service = D('Basic/OilCardOrderLog', 'Service');
//        $oil_order_log_service->addLog($data['id'], self::RECHARGE, 4, $this->_manager_id);
        $oil_order_log_service->addRechargeDoneLog($data['id'], $this->_manager_id);
        // 发送充值短信
        /** @var SmsService $sms_service */
        $sms_service = D('Basic/Sms', 'Service');
        $sms_service->setMode($type='second');
        $sms_service->sendOilCardRecharge($data);

        $this->ajaxResponse(0, '充值成功！');

    }

    /**
     * ajax 同步获取快递信息
     *
     * 异步浏览器拦截新页面
     */
    public function getExpressInfo() {
        $express_company = I('express_company');
        $express_no = I('express_no');
        /** @var OilCardOrderLogService $oil_card_log_service */
        $oil_card_log_service = D('Basic/OilCardOrderLog', 'Service');
        $arr = $oil_card_log_service->getExpressUrl($express_company, $express_no);
//        p($arr);die;
        $res = SimpleHttp::get($arr['url'], []);
        if ($res) {
            $this->ajaxResponse(0, '', ['url' => $arr['url'], 'script' => $arr['script']]);
        } else {
            $this->ajaxResponse(-1);
        }
    }

    /**
     * 油卡挂失、退卡页面
     */
    public function reportAndBackIndex() {
        $this->assignAll(array(
            'title' => '挂失、退卡列表',
            'type' => I('type') == 'report' ? 'report' : 'back',
        ));

        if (I('type') == 'back') {
            $this->_backList();
            $this->display('oil_back_index');
        } else {
            $this->_reportList();
            $this->display('oil_report_index');
        }
    }

    /**
     * 订单状态
     */

    const ORDER_STATUS_APPLIED     = 10;
    const ORDER_STATUS_DONES        = 50;
    const ORDER_STATUS_REFUSED     = 60;

    const ORDER_STATUS_TEXT = [
        self::ORDER_STATUS_APPLIED     => '已申请',
        self::ORDER_STATUS_DONE        => '已完成',
        self::ORDER_STATUS_REFUSED     => '已拒绝',

    ];

    /**
     * 退卡页
     */
    private function _backList() {
        $search_ftime_from = trim(I('search_ftime_from'));
        $search_ftime_to = trim(I('search_ftime_to'));
        $refund_id = trim(I('refund_id'));
        $search_telephone = trim(I('search_telephone'));
        $status = trim(I('status'));
        $card_no = trim(I('card_no'));

        $cond = [];
        if (!empty($search_ftime_from)) {
            $cond['oil_card_refund_order.ctime'] = ['egt', $search_ftime_from];
        } elseif (!empty($search_ftime_to)) {
            $cond['oil_card_refund_order.ctime'] = ['elt', $search_ftime_to];
        } elseif (!empty($search_ftime_from) && !empty($search_ftime_to)) {
            $cond['oil_card_refund_order.ctime'] = [['egt', $search_ftime_from], ['elt', $search_ftime_to]];
        }

        if (!empty($refund_id)) {
            $cond['oil_card_refund_order.id'] = ['eq', $refund_id];
        }

        if (!empty($search_telephone)) {
            $cond['user.telephone'] = ['eq', $search_telephone];
        }

        if (!empty($status)) {
            $cond['oil_card_refund_order.status'] = ['eq', $status];
        }

        if (!empty($card_no)) {
            $cond['oil_card_refund_order.card_no'] = ['eq', $card_no];
        }

        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        /** @var OilCardRefundOrderModel $oil_card_refund_model */
        $oil_card_refund_model = D('Basic/OilCardRefundOrder', 'Model');
        $ret       = $oil_card_refund_model->searchRefundList($cond, $curr_page, $per_page);

        $this->_formatData($ret['data']);

        $search_param = [
            'search_ftime_from' => $search_ftime_from,
            'search_ftime_to' => $search_ftime_to,
            'refund_id' => $refund_id,
            'search_telephone' => $search_telephone,
            'status' => $status,
            'card_no' => $card_no,
            'type' => 'back',
        ];

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav = $page_service->show();

        $this->assignAll(array(
            'status_arr' => self::ORDER_STATUS_TEXT,
            'list' => $ret['data'],
            'charging_list' => PAY::PAY_TYPE,
            'search_param' => $search_param,
            'page_nav' => $page_nav,
            'refer' => $this->_refer,
            'form_action' => '/OilCard/reportAndBackIndex',
        ));
    }

    private function _formatData(&$data) {
        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');
        foreach ($data as &$v) {
            $info = $manager_service->get($v['manager_id'], 'username');
            $v['manager_name'] = $info['username'];
            $v['status_text'] = self::ORDER_STATUS_TEXT[$v['status']];
            $v['charging_text'] = PAY::PAY_TYPE[$v['charging']];
        }
        return $data;
    }

    // 拒绝退卡
    public function denyRefund() {
        $order_id = I('refund_id');
        $refuse_reason = trim(I('content'));
        $manager_id = $this->_manager_id;

        /** @var OilCardRefundOrderService $oil_card_refund_service */
        $oil_card_refund_service = D('Basic/OilCardRefundOrder', 'Service');
        list($errno, $errmsg, $data) = $oil_card_refund_service->refuse($order_id, $refuse_reason, $manager_id);
        if ($errno == ERRNO::SUCCESS) {
            redirect(U('oilCard/reportAndBackIndex') . '?' . 'type=' . 'back');
        } else {
            $this->admin_error('拒绝退卡失败---' . $errmsg);
        }
    }

    // 确认退卡
    public function refundDone() {
        $order_id = trim(I('back_id'));
        $amount = trim(I('back_amount'));
        $extra_fee = trim(I('back_extra_fee'));
        $charging = trim(I('back_charging'));
        $recycle = trim(I('back_status')) == 1 ? 1 : '';
        $refund_time = datetime();
        $manager_id = $this->_manager_id;

        /** @var OilCardRefundOrderService $oil_card_refund_service */
        $oil_card_refund_service = D('Basic/OilCardRefundOrder', 'Service');

        list($errno, $errmsg, $data) = $oil_card_refund_service->confirmRefund($order_id, $amount, $extra_fee, $charging, $recycle, $refund_time, $manager_id);
        if ($errno == ERRNO::SUCCESS) {
            redirect(U('oilCard/reportAndBackIndex') . '?' . 'type=' . 'back');
        } else {
            $this->admin_error('确认退卡失败---' . $errmsg);
        }
    }

    const ORDER_STATUS_PAYEDL       = 20;
    const ORDER_STATUS_MAILED      = 30;
    const ORDER_STATUS_DONEL        = 50;
    const ORDER_STATUS_REFUSEDL     = 60;

    const ORDER_STATUS_NAMEL = [
        self::ORDER_STATUS_PAYED       => '已申请',
        self::ORDER_STATUS_MAILED      => '已寄送',
        self::ORDER_STATUS_DONE        => '已完成',
        self::ORDER_STATUS_REFUSED     => '已拒绝'

    ];

    /**
     * 挂失页
     */
    private function _reportList() {
        $search_ftime_from = trim(I('search_ftime_from'));
        $search_ftime_to = trim(I('search_ftime_to'));
        $report_id = trim(I('report_id'));
        $search_telephone = trim(I('search_telephone'));
        $search_status = trim(I('search_status'));
        $card_no = trim(I('card_no'));

        $cond = [];
        if (!empty($search_ftime_from)) {
            $cond['oil_card_lost_order.ctime'] = ['egt', $search_ftime_from];
        } elseif (!empty($search_ftime_to)) {
            $cond['oil_card_lost_order.ctime'] = ['elt', $search_ftime_to];
        } elseif (!empty($search_ftime_from) && !empty($search_ftime_to)) {
            $cond['oil_card_lost_order.ctime'] = [['egt', $search_ftime_from], ['elt', $search_ftime_to]];
        }

        if (!empty($report_id)) {
            $cond['oil_card_lost_order.id'] = ['eq', $report_id];
        }

        if (!empty($search_telephone)) {
            $cond['user.telephone'] = ['eq', $search_telephone];
        }

        if (!empty($search_status)) {
            $cond['oil_card_lost_order.status'] = ['eq', $search_status];
        }

        if (!empty($card_no)) {
            $cond['oil_card_lost_order.card_no'] = ['eq', $card_no];
        }

        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        /** @var OilCardLostOrderModel $oil_card_lost_model */
        $oil_card_lost_model = D('Basic/OilCardLostOrder', 'Model');
        $ret       = $oil_card_lost_model->searchReportList($cond, $curr_page, $per_page);
//p($ret);die;

        $this->_transData($ret['data']);
        $search_param = [
            'search_ftime_from' => $search_ftime_from,
            'search_ftime_to' => $search_ftime_to,
            'report_id' => $report_id,
            'search_telephone' => $search_telephone,
            'search_status' => $search_status,
            'card_no' => $card_no,
            'type' => 'report',
        ];

        $status_arr = self::ORDER_STATUS_NAMEL;
        $express_company_list = DICT::EXPRESS_COMPANY_LIST;

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav = $page_service->show();

        $this->assignAll(array(
            'express_company_list' => $express_company_list,
            'search_param' => $search_param,
            'status_arr' => $status_arr,
            'list' => $ret['data'],
            'action_time' => date('Y-m-d'),
            'page_nav' => $page_nav,
            'refer' => $this->_refer,
            'form_action' => '/OilCard/reportAndBackIndex?type=report'
        ));
    }

    private function _transData(&$data) {
        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');
        foreach ($data as &$v) {
            $info = $manager_service->get($v['manager_id'], 'username');
            $v['manager_name'] = $info['username'];
            $v['status_text'] = OilCardLostOrderService::ORDER_STATUS_NAME[$v['status']];
            $v['express_company'] = DICT::EXPRESS_COMPANY_LIST[$v['express_company']];
            $v['pay_text'] = '¥' . $v['total_fee'] . "\n" . PAY::PAY_TYPE[$v['op_type']] . "\n" . $v['payment_id'];
        }
        return $data;
    }

    // 线下添加挂失
    public function addReport() {
        $this->assignAll(array(
            'title' => '添加挂失',
            'status' => 0,
        ));
        $this->display('oil_report_add');
    }

    public function doAddReport() {
        $data = [
            'uid' => trim(I('user_id')),
            'user_card_id' => trim(I('user_card_id')),
            'card_id' => trim(I('card_id')),
            'card_no' => trim(I('card_no')),
            'balance' => trim(I('balance')),
            'need_new' => trim(I('status')),
            'mail_id' => trim(I('mail_id')),
            'purchase_type' => OilCardLostOrderService::PURCHASE_TYPE_OFFLINE,
            'manager_id' => $this->_manager_id,
        ];

        /** @var OilCardLostOrderService $oil_card_lost_service */
        $oil_card_lost_service = D('Basic/OilCardLostOrder', 'Service');
        list($errno, $errmsg, $data) = $oil_card_lost_service->addReport($data);

        if ($errno == ERRNO::SUCCESS) {
            redirect(U('oilCard/reportAndBackIndex') . '?' . 'type=' . 'report');
        } else {
            $this->admin_error('添加失败---' . $errmsg);
        }

    }

    /**
     * 确定邮寄
     */
    public function expressDone() {
        /** @var OilCardLostOrderService $oil_card_lost_order_service */
        $oil_card_lost_order_service = D('Basic/OilCardLostOrder', 'Service');
        list($errno, $errmsg, $data) = $oil_card_lost_order_service->addMail(trim(I('express_id')), trim(I('new_card_no')), trim(I('new_card_pass')), trim(I('card_company')), trim(I('parent_card_no')), trim(I('express_company')), trim(I('express_no')), trim(I('card_value')), $this->_manager_id, trim(I('telephone')));
        if ($errno == ERRNO::SUCCESS) {
            redirect(U('oilCard/reportAndBackIndex') . '?' . 'type=' . 'report');
        } else {
            $this->admin_error('邮寄失败--' . $errmsg);
        }
    }

    /**
     * 拒绝挂失
     */
    public function denyReport() {
        $id = I('deny_id/d');
        $refuse_reason = trim(I('content'));

        /** @var OilCardLostOrderService $oil_card_lost_order_service */
        $oil_card_lost_order_service = D('Basic/OilCardLostOrder', 'Service');
        list($errno, $errmsg, $data) = $oil_card_lost_order_service->refuse($id, $refuse_reason, $this->_manager_id);
        if ($errno == ERRNO::SUCCESS) {
            redirect(U('oilCard/reportAndBackIndex') . '?' . 'type=' . 'report');
        } else {
            $this->admin_error('拒绝失败--' . $errmsg);
        }
    }

    /**
     * 完成挂失
     */
    public function doneReport() {
        $order_id = I('done_id/d');
        /** @var OilCardLostOrderService $oil_card_lost_order_service */
        $oil_card_lost_order_service = D('Basic/OilCardLostOrder', 'Service');
        list($errno, $errmsg, $data) = $oil_card_lost_order_service->addFinsh($order_id, $this->_manager_id);
        if ($errno == ERRNO::SUCCESS) {
            redirect(U('oilCard/reportAndBackIndex') . '?' . 'type=' . 'report');
        } else {
            $this->admin_error('完成失败--' . $errmsg);
        }
    }

    // 线下添加退卡
    public function addBack() {
        $this->assignAll(array(
            'title' => '添加退卡',
        ));
        $this->display('oil_back_add');
    }

    public function doAddBack() {
        $card_no = trim(I('card_no'));
        $reason = trim(I('content'));

        // 获取卡用户相关信息
        /** @var UserOilCardService $user_oil_card_service */
        $user_oil_card_service = D('Basic/UserOilCard', 'Service');
        $res = $user_oil_card_service->getUserByCardNo($card_no);

        $uid = $res['uid'];
        $card_id = $res['card_id'];
        $manager_id = $this->_manager_id;

        /** @var OilCardRefundOrderService $oil_card_refundOrder_service */
        $oil_card_refundOrder_service = D('Basic/OilCardRefundOrder', 'Service');
        list($errno, $errmsg, $data) = $oil_card_refundOrder_service->addOrder($uid, $card_id, $reason, $manager_id);
        if ($errno == ERRNO::SUCCESS) {
            redirect(U('oilCard/reportAndBackIndex') . '?' . 'type=' . 'back');
        } else {
            $this->admin_error('添加退卡失败--' . $errmsg);
        }
    }

    /**
     * ajax 获取用户信息
     */
    public function ajaxGetInfo() {
        $card_no = I('card_no');
        // 在oil_cards表中获取该卡状态
        /** @var OilCardModel $oil_card_model */
        $oil_card_model = D('Basic/OilCard', 'Model');
        $info = $oil_card_model->getByCardNo($card_no, $lock = FALSE);

        /** @var UserOilCardService $user_oil_card_service */
        $user_oil_card_service = D('Basic/UserOilCard', 'Service');
        $res = $user_oil_card_service->getUserByCardNo($card_no);
        $res['card_status'] = $info['status'];
        $this->ajaxResponse(0, '', $res);

    }

    public function ajaxGetCardInfo() {
        $card_no = trim(I('card_no'));
        // 在oil_cards表中获取该卡状态
        /** @var OilCardModel $oil_card_model */
        $oil_card_model = D('Basic/OilCard', 'Model');
        $info = $oil_card_model->getByCardNo($card_no, $lock = FALSE);

        $this->ajaxResponse(0, '', $info);
    }

    /**
     * 油卡用户列表
     */
    public function oilUserIndex() {
        $telephone = I('telephone');
        $account = I('account');
        $card_num = I('card_num');

        $cond = [];
        if (!empty($telephone)) {
            $cond['user_oil_card.telephone'] = ['eq', $telephone];
        }
        if (!empty($account)) {
            $cond['user.account'] = ['eq', $account];
        }
        if (!empty($card_num)) {
            $cond['user.card_num'] = ['eq', $card_num];
        }

        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        /** @var UserOilCardModel $user_oil_card_model */
        $user_oil_card_model = D('Basic/UserOilCard', 'Model');
        $res = $user_oil_card_model->userOilList($cond, $curr_page, $per_page);
//p($res['data']);die;
        $list = $this->_getOilCardInfo($res['data']);
        $search_param = [
            'telephone' => $telephone,
            'account' => $account,
            'card_num' => $card_num,
        ];
//        p($list);die;
        $page_service = new PageService($res['count'], $per_page);
        $page_nav = $page_service->show();
//p($list);die;
        $this->assignAll(array(
            'order_list' => $list,
            'title' => '油卡用户列表',
            'search_param' => $search_param,
            'page_nav' => $page_nav,
        ));
        $this->display('oil_user_index');
    }

    private function _getOilCardInfo($data) {
        /** @var UserOilCardModel $user_oil_card_model */
        $user_oil_card_model = D('Basic/UserOilCard', 'Model');
        /** @var OilCardRechargeOrderService $oil_card_recharge_service */
        $oil_card_recharge_service = D('Basic/OilCardRechargeOrder', 'Service');

        foreach ($data as &$v) {
            $info = $user_oil_card_model->getListByTelephone($v['telephone']);
//            p($info);die;

            $v['total_num'] = count($info);

            // 计算各个状态的油卡数量
            for ($i=0; $i<count($info); $i++) {
                if ($info[$i]['status'] == UserOilCardService::USER_CARD_STATUS_ACTIVE) {
                    $v['active'] += 1;
                } else if ($info[$i]['status'] == UserOilCardService::USER_CARD_STATUS_PAUSE) {
                    $v['pause'] += 1;
                } else if ($info[$i]['status'] == UserOilCardService::USER_CARD_STATUS_DELETE) {
                    $v['delete'] += 1;
                } else if ($info[$i]['status'] == UserOilCardService::USER_CARD_STATUS_CHARGING) {
                    $v['charging'] += 1;
                } else if ($info[$i]['status'] == UserOilCardService::USER_CARD_STATUS_LOSTING) {
                    $v['losting'] += 1;
                } else if ($info[$i]['status'] == UserOilCardService::USER_CARD_STATUS_LOSTED) {
                    $v['losted'] += 1;
                } else if ($info[$i]['status'] == UserOilCardService::USER_CARD_STATUS_REFUNDING) {
                    $v['refunding'] += 1;
                } else if ($info[$i]['status'] == UserOilCardService::USER_CARD_STATUS_REFUNDED) {
                    $v['refunded'] +=1;
                } else {

                }
                $info[$i]['status_text'] = UserOilCardService::USER_CARD_STATUS[$info[$i]['status']];
            }
            $v['card_list'] = $info;

            $v['last_info'] = $oil_card_recharge_service->getLastConsume($v['telephone']);

        }
        return $data;
    }

}