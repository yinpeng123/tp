<?php
namespace Admin\Model;

use Basic\Model\BasicModel;

class MenuModel extends BasicModel {

    private $__menu_model = NULL;

//    public function __construct() {
//        $this->__menu_model = M('admin_menu');
//    }

    /**
     * 构造函数, 缺省为连接主库并不使用缓存!
     *
     * @param string     $db_type 指定主、从数据库, 值分别为: master/slave
     * @param bool|FALSE $enable_cache 是否启用缓存
     */
    public function __construct($db_type = 'master', $enable_cache = FALSE) {
        parent::__construct('admin_menu', \Basic\Cnsts\CACHE_PREFIX::ADMIN_MENU, $db_type);
        $this->_enable_cache = $enable_cache;

        $this->__menu_model = $this->_model;
    }

    /**
     * 搜索菜单
     * @param array $cond 搜索条件
     */
    public function searchMenu($cond = array()) {
        $where = ['is_delete' => 0];
        if ( isset($cond['pid']) ) {
            $where['pid'] = (int)$cond['pid'];
        }
        if ( isset($cond['search_pid']) ) {
            $where['pid'] = (int)$cond['search_pid'];
        }
        if ( isset($cond['id_list']) ) {
            $where['id'] = array('in', $cond['id_list']);
        }
        return $this->__menu_model->where($where)->order('list')->select();
    }

    /**
     * 生成菜单结构的数组
     */
    public function genMenuSelectArray() {
        // 一级菜单
        $where =[
            'is_delete'=>0,
            'pid'=>0,
        ];
        $res = $this->__menu_model->where($where)->order('list')->select();

        $menu_arr = array();
        foreach ( $res as $r ) {
            $menu_arr[] = array('id' => $r['id'], 'text' => $r['name']);

            // 二级菜单
            $where =[
                'is_delete'=>0,
                'pid'=>$r[id],
            ];
            $res2 = $this->__menu_model->where($where)->order('list')->select();
            foreach ( $res2 as $r2 ) {
                $menu_arr[] = array('id' => $r2['id'], 'text' => '|-----'.$r2['name']);
            }
        }
        return $menu_arr;
    }

    public function getAllMenu() {
        return $this->__menu_model->order('list')->select();
    }

    /**
     * 获取父级菜单的id数组, 返回排重后的集合
     */
    public function getDistinctPidList($ids) {
        $where = array('id' => array('in', $ids));
        return $this->__menu_model->distinct(TRUE)->field('pid')->where($where)->order('list')->getField('pid', TRUE);
    }

    /**
     * 获取当前最大的序号
     */
    public function getMaxList() {
        return $this->__menu_model->max('list');
    }

    /**
     * 根据id获取菜单信息
     * @param int $menu_id
     * @param string $fields
     */
    public function getMenu($id, $fields = NULL) {
        $mkey = 'admin_menu_'.$id;
        if ( $mvalue = S($mkey) ) {
            return $mvalue;
        }

        if ( !$fields ) $fields = '*';

        $res = $this->__menu_model->field($fields)->where('id='.$id)->find();

        if ( $fields == '*' ) {
            S($mkey, $res);
        }

        return $res;
    }

    /**
     * 添加菜单
     */
    public function addMenu($menu) {
        return $this->__menu_model->add($menu);
    }

    /**
     * 更新菜单信息
     */
    public function updateMenu($id, $menu) {
        $this->__menu_model->where(['id' => $id])->save($menu);
        S('admin_menu_'.$id, NULL);
    }

    /**
     * 删除菜单
     */
    public function deleteMenu($ids) {
        if ( is_array($ids) ) {
            //$this->__menu_model->where(['id' => array('in', $ids)])->delete();
            $this->__menu_model->where(['id' => array('in', $ids)])->save(['is_delete' => 1]);
            $id_arr = $ids;
        } else {
            //$this->__menu_model->where(['id' => $ids])->delete();
            $this->__menu_model->where(['id' => $ids])->save(['is_delete' => 1]);
            $id_arr = array($ids);
        }

        foreach ($id_arr as $id) {
            S('admin_menu_'.$id, NULL);
        }
    }
}