<?php
namespace Admin\Cnsts;


class MANAGER {

    const DEPARTMENT_ARR = [
        1      => '客服部',
        2      => '核算部',
        3      => '财务部',
        4      => '风控部',
        5      => '运营',
        10     => '渠道商',
    ];
}