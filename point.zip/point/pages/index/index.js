var openid = 6;
var type = getUrlParam('type');
var room_id;
var hasTeam = false;

switch (type) {
    case "1":
        $('#toutu').attr('src', '/asserts/img/tiaozhanshai7.png');
        break;
    case "2":
        $('#toutu').attr('src', '/asserts/img/tiaozhanshai21.png');
        break;
    default:
        type = 1;
        $('#toutu').attr('src', '/asserts/img/tiaozhanshai7.png');
        break;
}


//关闭我的队伍弹框
function hideTeamPopBox() {
    document.getElementById('team-popBox').style.display = 'none';
}


//好吧
function hideWarningPopBox() {
    $('.warning-popBox').css('display', 'none');
}

//我选“no”
$('.popBox-button-no').click(function () {
    $('#joinTeam-popBox').css('display', 'none');
});

//我选yes
$('.popBox-button-yes').click(function () {
    window.location.href = '../makingplan/makingplan.html?room_id=' + room_id + '&type=' + type + '&openid=' + openid;
})

function showJoinTeamPopBox(groupid) {
    document.getElementById('joinTeam-popBox').style.display = 'block';
}


// 跳转创建队伍页面
$('.create-team').click(function () {
    window.location.href = "../createteam/createteam.html?type=" + type + "&openid=" + openid;
})

function refresh() {
    var myGroupPopBox = document.getElementById('team-popBox');
    layer.msg('已刷新排名！', { time: 1000 });
}

function insertGroups(data) {
    $('.challenge-groups').empty();
    var grouphtml =
        '<div class="group-left">' +
        '<div class="group-name">我是挑战组的名称哈哈</div>' +
        '<div class="group-players-avatar">' +
        '</div>' +
        '</div>' +
        '<div class="group-right">' +
        '<p class="group-tableNumber-text">桌号</p>' +
        '<p class="group-tableNumber">45</p>' +
        '<p class="group-startTime-text">开始日期</p>' +
        '<p class="group-startTime">2018.11.30</p>' +
        '</div>';
    var info = data.info;
    var groupLength = info.length;
    for (let i = 0; i < groupLength; i++) {
        $('.challenge-groups').append('<div class="group" id="group' + i + '">' + grouphtml + '</div>');
        $('#group' + i + ' .group-tableNumber').text(info[i].room_id);
        $('#group' + i + ' .group-startTime').text(info[i].start_time.replace(/-/g, '.'));
        $('#group' + i + ' .group-name').text(info[i].room_name);
        $('#group' + i + ' .group-players-avatar').attr('id', 'group-players-avatar' + i);
        let playerLength = info[i].headimg.length;
        let emptyLength = info[i].room_people_num - playerLength;
        for (let j = 0; j < playerLength; j++) {
            $('#group-players-avatar' + i).append('<div class="avatar avatar-noEmpty" id="player' + i + j +
                '"></div>');
            $('#player' + i + j).css('background-image', 'url(' + info[i].headimg[j] + ')');
            setColor($('#player' + i + j));
        }
        for (let j = 0; j < emptyLength; j++) {
            $('#group-players-avatar' + i).append('<div class="avatar avatar-empty"' + 'room_id=' + info[i].room_id + '></div>');
        };
    }
    $('.avatar-empty').click(function () {
        if (data.complaint === 1) {
            $('#comp-warning-popBox').css('display', 'block');
        } else if (hasTeam) {
            $('#hasTeam-warning-popBox').css('display', 'block');
        } else {
            $('#joinTeam-popBox').css('display', 'block');
            room_id = $(this).attr('room_id');
        }

    })
}

function setColor(target) {
    let browm = '#b28c4f';
    let orange = '#f77b31';
    let yellow = '#facc16';
    let purple = '#5c50cc';
    let blue = '#42ae70';
    let gray = '#cccccc';
    var random_number = Math.ceil(Math.random() * 6);
    switch (random_number) {
        case 1:
            target.css('border-color', browm);
            break;
        case 2:
            target.css('border-color', orange);
            break;
        case 3:
            target.css('border-color', yellow);
            break;
        case 4:
            target.css('border-color', purple);
            break;
        case 5:
            target.css('border-color', blue);
            break;
        case 6:
            target.css('border-color', gray);
            break;
        default:
            break;
    }
}


// 搜索
$('.search-button').click(function () {
    let telephone = $('.search-input').val();
    $.ajax({
        url: 'http://www.htown.xyz/Home/index/challenge',
        type: 'POST',
        data: {
            telephone: telephone,
            type: type
        },
        success: function (data) {
            insertGroups(data)
        },
        error: function () {
            console.error();
        }
    });
})

$(document).ready(function () {
    $.ajax({
        url: 'http://www.htown.xyz/Home/index/challenge',
        type: 'POST',
        data: {
            openid: openid,
            type: type
        },
        success: function (data) {
            insertGroups(data);
            if (data.status === 1 || data.status === 2) {
                $('.team-popBox').css('display', 'block');
                $('.button-area').css('display', 'none');
                if (data.status === 1) {
                    $('.team-popBox-bottom').css('display', 'block');
                }
                hasTeam = true;
                $('.team-popBox .myGroup-name').text(data.myroom.room_name);
                $('.team-popBox .myGroup-startTime').text(data.myroom.start_time.replace(/-/g, '.'));

                var playerLength = data.myroom.headimg.length;
                var emptyLength = data.myroom.room_people_num - playerLength;
                for (let i = 0; i < playerLength; i++) {
                    $('#myGroup-players-avatar').append('<div class="myGroup-avatar myGroup-avatar-noEmpty" id="myGroup_player' + i +
                        '"></div>');
                    $('#myGroup_player' + i).css('background-image', 'url(' + data.myroom.headimg[i] + ')');
                }

                for (let i = 0; i < emptyLength; i++) {
                    $('#myGroup-players-avatar').append('<div class="myGroup-avatar myGroup-avatar-empty"></div>');
                };
            }
        },
        error: function () {
            //
            console.error();
        }
    })
})