<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Cnsts\MANAGER;

class ProfileController extends AdminSessionController {

    private $__manager_model = NULL;
    private $__profile_service = NULL;

    public function __construct() {
        parent::__construct();

        $this->__manager_model = D('Manager');
        $this->__profile_service = D('Profile', 'Service');
    }

    public function index() {
        $this->edit();
    }

    /**
     * 编辑个人信息
     */
    public function edit() {
        $manager = $this->__manager_model->getManagerById($this->_manager_id);
        if ( !$manager ) {
            $this->admin_error('管理员不存在！');
            return;
        }

        // 渠道商列表
        $agent_model = D('Basic/Agent');
        $agent_list = $agent_model->getAllAgentList('id,name');
        $this->assign('agent_list', $agent_list);

        $this->assignAll(array(
            'act'     => 'edit',
            'title'   => '编辑个人信息',
            'manager' => $manager,
            'department_arr'    => MANAGER::DEPARTMENT_ARR,
        ));
        $this->display('profile_info');
    }

    /**
     * 保存个人信息
     */
    public function doEdit() {
        // 验证令牌
        $this->checkFormToken();

        $realname = I('realname');
        $cn_len = cnstrlen($realname);
        if ( $cn_len < 4 ) {
            $this->admin_error('真实姓名格式不正确！');
            return;
        }

        $department = I('department/d');

        $phone = I('phone');
        if ( !empty($phone) && !is_mobile($phone) ) {
            $this->admin_error('手机号格式不正确！');
            return;
        }

        $identity = I('identity');
        if ( !empty($identity) && !is_identity_number($identity) ) {
            $this->admin_error('身份证号格式不正确！');
            return;
        }

        $email = I('email');
        if ( !empty($email) && !is_email($email) ) {
            $this->admin_error('email格式不正确');
            return;
        }

        $this->__manager_model->updateManagerById($this->_manager_id, array(
            'realname'    => $realname,
            'department'  => $department,
            'phone'       => $phone,
            'identity'    => $identity,
            'email'       => $email,
            'mtime'       => datetime(),
        ));

        // 添加操作日志
        $this->__profile_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => $this->_manager_id,
            'action'        => 'edit',
            'desc'          => "编辑个人信息：".$this->_manager['username'],
        ));

        $this->admin_success('编辑个人信息成功！');
    }

    /**
     * 修改密码
     * @param string $manager_id
     */
    public function editPassword() {
        $this->assignAll(array(
            'act'     => 'edit_password',
            'title'   => '编辑个人信息',
        ));
        $this->display('profile_password');
    }

    /**
     * 提交修改个人密码
     */
    public function doEditPassword() {
        // 验证令牌
        $this->checkFormToken();

        $password = I('password');
        $cn_len = cnstrlen($password);
        if ( $cn_len < 6 ) {
            $this->admin_error('密码格式不正确！');
            return;
        }

        $password2 = I('password2');
        if ( $password2 != $password ) {
            $this->admin_error('两次输入密码不一致！');
            return;
        }

        $password_encrypted = password_hash($password, PASSWORD_DEFAULT);
        $this->__manager_model->updateManagerById($this->_manager_id, array(
            'password'    => $password_encrypted,
            'mtime'       => datetime(),
        ));

        // 添加操作日志
        $this->__profile_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => $this->_manager_id,
            'action'        => 'edit',
            'desc'          => "编辑个人密码：".$this->_manager['username'],
        ));

        $this->admin_success('修改个人密码成功！');
    }


}