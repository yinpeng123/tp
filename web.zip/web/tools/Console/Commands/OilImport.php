<?php

namespace Artisan\Console\Commands;

use Illuminate\Console\Command;

class OilImport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'oil:import';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '导入油卡历史数据';

    /**
     * 原始数据
     * @var array
     */
    private $data = [];

    /**
     * 当前行
     * @var integer
     */
    private $cur_row = 0;

    /**
     * 未导入数据
     * @var array
     */
    private $unimport_data = [];

    private $oil_cards_model = null;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        ini_set('memory_limit', -1);
        parent::__construct();
        $this->readData();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $model = M();
        while ($row = $this->getRow()) {
            var_dump($row[0]);
            $model->startTrans();
            $data = $this->formatRow($row);
            if ($data['code']) {
                $this->addFailRow($data['data']['row'], $data['msg']);
                $model->rollback();
                continue;
            }
            /**
             * 添加油卡
             * @var [type]
             */
            $card_id = $this->checkCard($data['data']['card']['card_no']);
            if (!$card_id) {
                $card_id = $this->addCard($data['data']['card']);
            }
            if (!$card_id) {
                $this->addFailRow($data['data']['row'], '添加油卡失败');
                $model->rollback();
                continue;
            }
            if ($data['data']['order_type'] == 'card') {

                /**
                 * 添加订单
                 */
                $data['data']['card_order']['card_list'][0]['card_id'] = $card_id;
                $data['data']['card_order']['card_list'] = json_encode($data['data']['card_order']['card_list']);
                $order_id = $this->addCardOrder($data['data']['card_order']);
                if (!$order_id) {
                    $this->addFailRow($data['data']['row'], '添加订单失败');
                    $model->rollback();
                    continue;
                }

                /**
                 * 添加订单日志
                 */
                $data['data']['c_order_log']['order_id'] = $order_id;
                $log_id = $this->addOrderLog($data['data']['c_order_log']);

                /**
                 * 添加用户油卡
                 */
                $user_card = $this->checkUserCard($data['data']['user_card']['card_no'], $data['data']['user_card']['uid']);
                if ($user_card == 'used-by-others') {
                    $this->addFailRow($data['data']['row'], '该卡正在被他人使用');
                    $model->rollback();
                    continue;
                } elseif ($user_card == 'no-usercard') {
                    /**
                     * 添加用户油卡
                     */
                    $data['data']['user_card']['card_id'] = $card_id;
                    $data['data']['user_card']['card_order_id'] = $order_id;
                    $user_card_id = $this->addUserCard($data['data']['user_card']);
                    if (!$user_card_id) {
                        $this->addFailRow($data['data']['row'], '添加用户油卡失败');
                        $model->rollback();
                        continue;
                    }
                }
            } else {
                $user_card = $this->checkUserCard($data['data']['user_card']['card_no'], $data['data']['user_card']['uid']);
                if ($user_card == 'used-by-others') {
                    $this->addFailRow($data['data']['row'], '该卡正在被他人使用');
                    $model->rollback();
                    continue;
                } elseif ($user_card == 'no-usercard') {

                    /**
                     * 添加用户油卡
                     */
                    $data['data']['user_card']['card_id'] = $card_id;
                    $data['data']['user_card']['card_order_id'] = $order_id;
                    $user_card_id = $this->addUserCard($data['data']['user_card']);
                    if (!$user_card_id) {
                        $this->addFailRow($data['data']['row'], '添加用户油卡失败');
                        $model->rollback();
                        continue;
                    }
                }

                /**
                 * 添加订单
                 */
                $data['data']['recharge_order']['card_id']= $card_id;
                $order_id = $this->addRechargeOrder($data['data']['recharge_order']);
                if (!$order_id) {
                    $this->addFailRow($data['data']['row'], '添加订单失败');
                    $model->rollback();
                    continue;
                }

                /**
                 * 添加订单日志
                 */
                $data['data']['r_order_log']['order_id'] = $order_id;
                $this->addOrderLog($data['data']['r_order_log']);
            }
            $model->commit();
        }
        $this->saveFailData();
    }

    /**
     * 获取卡ID
     * @param  [type] $card_no [description]
     * @return [type]          [description]
     */
    public function checkCard($card_no){
        if (!$this->oil_cards_model) {
            $this->oil_cards_model = M('oil_cards');
        }
        $card = $this->oil_cards_model->where(['card_no' => $card_no])->field('id')->find();
        return $card['id'];
    }

    /**
     * 添加油卡
     * @param [type] $data [description]
     */
    public function addCard($data){
        if (!$this->oil_cards_model) {
            $this->oil_cards_model = M('oil_cards');
        }
        $card_id =  $this->oil_cards_model->add($data);
        $data['id'] = $card_id;
        $this->oil_cards[] = array_values($data);
        return $card_id;
    }

    /**
     * 添加油卡订单
     * @param [type] $data [description]
     */
    public function addCardOrder($data){
        if (!$this->oil_card_order_model) {
            $this->oil_card_order_model = M('oil_card_order');
        }
        $order_id = $this->oil_card_order_model->add($data);
        $data['id'] = $order_id;
        $this->card_order[]  = array_values($data);
        return $order_id;
    }

    /**
     * 添加充值订单
     * @param [type] $data [description]
     */
    public function addRechargeOrder($data){
        if (!$this->oil_card_recharge_order_model) {
            $this->oil_card_recharge_order_model = M('oil_card_recharge_order');
        }
        $recharge_order_id = $this->oil_card_recharge_order_model->add($data);
        $data['id'] = $recharge_order_id;
        $this->recharge_order[] = array_values($data);
        return $recharge_order_id;
    }

    /**
     * 检查用户油卡状态
     * @param  [type] $card_no [description]
     * @param  [type] $uid     [description]
     * @return [type]          [description]
     */
    public function checkUserCard($card_no, $uid){
        if (!$this->user_oil_card_model) {
            $this->user_oil_card_model = M('user_oil_card');
        }
        $data = $this->user_oil_card_model->where(['card_no' => $card_no])->field('uid')->find();
        if (!$data) {
            return 'no-usercard';
        }
        if ($data['uid'] == $uid) {
            return 'ok';
        }
        if ($data['uid'] && $data['uid'] != $uid) {
            return 'used-by-others';
        }
    }

    /**
     * 添加用户油卡
     * @param [type] $data [description]
     */
    public function addUserCard($data){
        if (!$this->user_oil_card_model) {
            $this->user_oil_card_model = M('user_oil_card');
        }
        $user_card_id      = $this->user_oil_card_model->add($data);
        $data['id']        = $user_card_id;
        $this->user_card[] = array_values($data);
        return $user_card_id;
    }

    /**
     * 订单日志
     * @param [type] $data [description]
     */
    public function addOrderLog($data){
        if (!$this->oil_card_order_log_model) {
            $this->oil_card_order_log_model = M('oil_card_order_log');
        }
        $log_id = $this->oil_card_order_log_model->add($data);
        $data['id'] = $log_id;
        $this->order_log[] = array_values($data);
        return $log_id;
    }

    /**
     * 读取数据
     * @return [type] [description]
     */
    public function readData(){
        $data = json_decode(file_get_contents(__DIR__.'/../../data/oilimport.json'), true);
        $this->data = $data[0]['data'];
    }

    /**
     * 获取一行数据
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function getRow(){
        $row = $this->data[$this->cur_row++];
        list($checked, $result) = $this->checkRow($row);
        while (!$checked && $row) {
            $this->addFailRow($row, $result);
            $row = $this->data[$this->cur_row++];
            list($checked, $result) = $this->checkRow($row);
        }
        return $row;
    }

    /**
     * 检查数据
     * @param  [type] $row [description]
     * @return [type]      [description]
     */
    public function checkRow($row){
        if ($row[2] != '使用中') {
            return [false, '未导入。不在使用中'];
        }
        if (!$row[3]) {
            return [false, '未导入。无卡号'];
        }
        if (!in_array($row[9], ['新','续'])) {
            return [false, '未导入。非新、续'];
        }
        if (!is_integer($row[6]) && !trim($row[24], '无')) {
            return [false, '未导入。无网号，手机号无效'];
        }
        return [true, 'ok'];
    }

    /**
     * 格式化数据
     * @param string $value [description]
     */
    public function formatRow($row){
        $ori_row = $row;
        if (is_integer($row[1])) {
            $row[1] = date('Y/m/d H:i:s', ($row[1] - 25569) * 24*60*60);
        }
        if (is_integer($row[17])) {
            $row[17] = date('Y/m/d H:i:s', ($row[17]+$row[18] - 25569) * 24*60*60);
        }
        if (is_integer($row[22])) {
            $row[22] = date('Y/m/d H:i:s', ($row[22] - 25569) * 24*60*60);
        }
        if (is_integer($row[29])) {
            $row[29] = date('Y/m/d H:i:s', ($row[29] - 25569) * 24*60*60);
        }
        if (is_integer($row[30])) {
            $row[30] = date('Y/m/d H:i:s', ($row[30] - 25569) * 24*60*60);
        }
        if ($row[9] == '新') {
            $order_type = 'card';
        }
        if ($row[9] == '续') {
            $order_type = 'recharge';
        }
        if (!$this->user_model_s) {
            $this->user_model_s = D('Basic/User');
        }
        if (is_integer($row[6])) {
            $user_info = $this->user_model_s->getBy(['net_no' => $row[6]], ['id']);
            $uid = $user_info['id'];
        }
        if ($row[24] && !$uid) {
            $user_info = $this->user_model_s->getBy(['telephone' => $row[24]], ['id']);
            $uid = $user_info['id'];
            if (!$uid) {
                if (!$this->us) {
                    $this->us = D('Basic/User', 'Service');
                }
                list($errno, $errmsg, $uid) = $this->us->wxRegister(strval($row[24]), null);
            }
        }
        
        if (!$uid) {
            return [
                'code'  => 1,
                'msg'   => '获取UID失败'.$errno.$errmsg.$row[24],
                'data'  => [
                    'row' => $ori_row
                ],
                
            ];
        }
        $card = [
            'card_no'         => $row[3],
            'card_pass'       => '致电客服',
            'card_value'      => $this->getFloat($row[10]),
            'card_company'    => $row[8],
            'telephone'       => $row[24],
        ];
        $user_card = [
            'uid'             => $uid,
            'telephone'       => $row[24],
            'card_id'         => '',
            'card_no'         => $row[3],
            'card_order_id'   => '',
            'extra_fee'       => $this->getFloat($row[14]),
            'total_amount'    => $this->getFloat($row[10]),
            'status'          => 20,
            'activation_time' => $row[30] ?: date('Y-m-d H:i:s'),
        ];
        if ($order_type == 'card') {
            $card_order = [
                'uid'             => $uid,
                'telephone'       => $row[24],
                'card_list'       => [[
                    'car_no'         => '',
                    'price'          => $this->getFloat($row[10]),
                    'count'          => 1,
                    'card_no'        => $row[3],
                    'card_id'        => '',
                    'discount'       => intval($row[11] * 100),
                    'extra_fee'      => $this->getFloat($row[14]),
                    'selling_price'  => $this->getFloat($row[12]),
                    'in_fee'         => $this->getFloat($row[15]),
                ]],
                'extra_fee'       => $this->getFloat($row[14]),
                'total_amount'    => $this->getFloat($row[10]),
                'total_fee'       => $this->getFloat($row[15]),
                'payment_id'      => 0,
                'op_type'         => 0,
                'pay_time'        => $row[17] ?: date('Y-m-d H:i:s'),
                'status'          => 50,
                'seller'          => $row[4].$row[5],
                'purchase_type'   => 2,
                'order_source'    => 'Import',
                'charging'        => $row[16],
                'mail_id'         => -1,
                'cards_assigned'  => 1,
                'express_company' => $row[28] ? 10 : '',
                'express_no'      => $row[28] ? : '',
            ];
            $c_order_log = [
                'order_id'    => '',
                'order_type'  => 1,
                'log_type'    => 5,
                'ctime'       => $row[30] ?: date('Y-m-d H:i:s'), 
            ];
        } else {
            $recharge_order = [
                'uid'             => $uid,
                'telephone'       => $row[24],
                'card_id'         => '',
                'card_no'         => $row[3],
                'amount'          => $this->getFloat($row[10]),
                'discount'        => intval($row[11] * 100),
                'total_fee'       => $this->getFloat($row[15]),
                'payment_id'      => 0,
                'op_type'         => 0,
                'pay_time'        => $row[17] ?: date('Y-m-d H:i:s'),
                'status'          => 50,
                'order_source'    => 'Import',
            ];
            $r_order_log = [
                [
                    'order_id'    => '',
                    'order_type'  => 2,
                    'log_type'    => 5,
                    'ctime'       => $row[30] ?: date('Y-m-d H:i:s'),
                ]
            ];
        }
        return [
            'code' => 0,
            'data' => [
                'order_type'     => $order_type,
                'card'           => $card, 
                'card_order'     => $card_order,
                'c_order_log'    => $c_order_log,
                'recharge_order' => $recharge_order,
                'r_order_log'    => $r_order_log,
                'user_card'      => $user_card,
                'row'            => $ori_row
            ]
        ];
    }

    /**
     * 浮点数
     * @param  [type] $value [description]
     * @return [type]        [description]
     */
    public function getFloat($value){
        return round($value, 2);
    }

    /**
     * 添加失败行
     * @param [type] $row [description]
     */
    public function addFailRow($row, $result){
        for ($i=0; $i < 33; $i++) { 
            $row[$i] = $row[$i] ?: '';
        }
        $row[33] = $result;
        $this->unimport_data[] = $row;
    }

    /**
     * 保存失败数据
     * @return [type] [description]
     */
    public function saveFailData(){
        $data = [
            [
                'name' => '导入油卡',
                'data' => $this->oil_cards
            ],[
                'name' => '导入用户油卡',
                'data' => $this->user_card
            ],[
                'name' => '导入购卡订单',
                'data' => $this->card_order
            ],[
                'name' => '导入充值订单',
                'data' => $this->recharge_order
            ],[
                'name' => '导入订单log',
                'data' => $this->order_log
            ],[
                'name' => '未导入数据',
                'data' => $this->unimport_data
            ],
        ];
        return file_put_contents(__DIR__.'/../../data/oilimportfail.json', json_encode($data));
    }

}
