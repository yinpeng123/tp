<?php
namespace Admin\Behavior;

use Think\Behavior;
use Think\Log;

class profileLogTailBehavior extends Behavior
{
    // 行为扩展的执行入口必须是run
    public function run(&$params)
    {
        $ext_msg = session('PROFILE_LOG');
        $manager = session('manager');
        $log_content = [
            round(microtime($get_as_float = true) - I('server.REQUEST_TIME_FLOAT'), 4),
            'manager_id=' . $manager['manager_id'],
            'role_id=' . $manager['role_id'],
            'agent_id=' . $manager['agent_id'],
            'ip=' . I('server.REMOTE_ADDR'),
            str_replace(' ', '', I('server.HTTP_X_FORWARDED_FOR')),
            PATH_INFO,
            'post=' . json_encode(I('post.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
            'get=' . json_encode(I('get.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
            'refer=' . I('server.HTTP_REFERER', '', 'url'),
            'ua=\'' . I('server.HTTP_USER_AGENT') . '\'',
            'cookie=' . json_encode($_COOKIE) ,
            'sid=' . session_id(),
            'rid=' . $_REQUEST['request_id'],
            'ext_msg=' . json_encode($ext_msg, JSON_UNESCAPED_UNICODE),
        ];
        Log::write(implode(' ', $log_content), 'PROFILE_TAIL');
        if ($ext_msg) {
            session('PROFILE_LOG', null);
        }
    }
}

