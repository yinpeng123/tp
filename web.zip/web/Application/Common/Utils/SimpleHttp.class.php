<?php
namespace Common\Utils;


/**
 * HTTP接口请求工具类
 * @author
 * @version
 */
class SimpleHttp {

    // 支持的method有: get/post/post_json
    public static function request($url, $params = array(), $method = 'post') {
        if ($method == 'post') {
            $request_url = $url;
            $params_str = http_build_query($params);
            $post_string = $params_str;
        } elseif ($method == 'post_json') {
            $request_url = $url;
            $post_string = $params;
        } else {
            $params_str = http_build_query($params);
            $request_url = $url . "?{$params_str}";
            $post_string = ''; // for debug code
        }

        // curl配置
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_URL, $request_url);
        curl_setopt($ch, CURLOPT_HEADER, false);  // 输出数据中不包含header信息
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        if ($method == 'post') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string);
//      curl_setopt($ch, CURLOPT_HTTPHEADER, array(
//              'Content-Type: application/x-www-form-urlencoded; charset=utf-8',
//              'Content-Length: ' . strlen($post_string))
//      );
        } elseif ($method == 'post_json') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json; charset=utf-8',
                    'Content-Length: ' . strlen($post_string))
            );
        }
        $response = curl_exec($ch);
        $curl_info = curl_getinfo($ch);
        $errno = curl_errno($ch);
        curl_close($ch);

        if ( APP_DEBUG ) {
            \Think\Log::write('request url: ' . $method . ' ' . $request_url . $post_string, 'DEBUG');
            \Think\Log::write('sms result: ' . $response, 'DEBUG');
// 		echo '<br>:'.$response.'-----<br>';
//         dump($response);
        }

        return $response;
    }


    public static function get($url, $params) {
        return self::request($url, $params, 'get');
    }

    public static function post($url, $params) {
        return self::request($url, $params, 'post');
    }

    /**
     * POST请求接口
     *
     * @param string $url 请求地址
     * @param array  $param 请求参数
     *
     * @return $response
     */
    public static function postJson($url, $param = array()) {
// 		$post_json = self::sign_params($url,$param);
        //print_r($post_json)."\n";
        return self::request($url, json_encode($param), 'post_json');
    }

}