<?php

namespace Admin\Controller;

use Admin\Cnsts\USER;
use Admin\Model\BindMemachineLogModel;
use Admin\Model\UserModel;
use Admin\Service\ManagerService;
use Admin\Service\ProductStatusLogService;
use Admin\Service\TblOnlineService;
use Admin\Service\UserService;
use Basic\Cnsts\DICT;
use Basic\Model\ProductModel;
use Basic\Model\TruckModel;
use Basic\Service\AddressService;
use Basic\Service\AgentService;
use Basic\Service\CardCheckService;
use Basic\Service\CityService;
use Basic\Service\CSWorkSheetService;
use Basic\Service\GrabService;
use Basic\Service\OrderService;
use Basic\Service\SendNoticeService;
use Basic\Service\SmsService;
use Basic\Service\TicketInfoService;
use Basic\Service\TruckService;
use Basic\Service\UserLogService;
use Basic\Service\WLSendService;
use Client\Service\LoginService;
use Common\Cnsts\ERRNO;
use Admin\Service\PageService;
use Basic\Cnsts\CS_WORK_SHEET;
use Think\Exception;
use Basic\Service\SignService;
use Basic\ModelU\CenterModel;

class UserController extends AdminSessionController
{


    public function __construct()
    {
        parent::__construct();

    }

    /**
     *平台用户列表
     */
    public function index()
    {

        $curr_page = I('path.2/d', 1);
        $model = new CenterModel('u_user');
        $name = I("name");
        $where = [];
        if ($name) {
            $where ['name'] = $name;
            $key = "%" . $name . "%";
            $where['name'] = array('like', $key);
        }
        $list = $model->getListBy($where, "*", "utime desc", $curr_page, 15);
        $total = $model->getListTotal($where);
        $page_service = new PageService($total, 15);
        $page_nav = $page_service->show();
        foreach ($list as $key => $val) {
            $list[$key]['id'] = sprintf("%06d", $val['id']);
        }
        $this->assignAll(array(
            'title' => '用户列表',
            'list' => $list,
            'page_nav' => $page_nav
        ));

        $this->display('index');
    }

    public function edit($id)
    {
        $list = [];
        $user = (new CenterModel("u_user"))->get($id);
        $bbs = (new CenterModel("u_bbs"))->getListBy(['uid' => $id]);
        $plans = (new CenterModel("u_plan"))->getListBy(['uid' => $id]);
        $model = new CenterModel("u_plan_info");
        foreach ($plans as $key => $val) {
            $plans[$key]['info'] = $model->getListBy(['pid' => $val['id']], "title");
        }
        $pointLog = (new CenterModel("u_mall_order"))->getListBy(['uid' => $id]);
        foreach ($pointLog as $key => $val) {
            $pointLog[$key]['info'] = (new CenterModel("u_mall"))->get($val['good_id']);
        }
        $target = (new CenterModel("u_target"))->getListBy(['uid' => $id]);
        $where = "{$user['plan_total']}<= point or {$user['point']}<=point";
        $medals = (new CenterModel("u_medal"))->getListBy($where);
        $medal = [];
        foreach ($medals as $key => $val) {
            if ($val['type'] == 1) {
                $medal['point'][] = $val['pic'];
            } else {
                $medal['jianc'][] = $val['pic'];
            }
        }
        $finance = (new CenterModel("u_finance_log"))->getListBy(['uid' => $id, 'status' => 1],
            "id,uid,type,status,amount,ctime");
        $schedule = (new CenterModel("u_schedule"))->getBy(['uid' => $id], "content");
        $schedule = t_json_decode($schedule);
        $list = [
            'user' => $user,
            'bbs' => $bbs,
            'plans' => $plans,
            'target' => $target,
            'pointLog' => $pointLog,
            'medal' => $medal,
            'finance' => $finance,
            'schedule' => t_json_decode($schedule['content']),

        ];
        $this->assignAll(array(
            'title' => '用户信息',
            'list' => $list,

        ));

        $this->display('edit');
    }

    //禁用启用用户
    public function opUser()
    {
        $model = new CenterModel("u_user");
        $ids = I("ids");
        $url = I("url");
        $ac = I("ac");
        if ($ac == 'rest') {
            if (is_array($ids)) {
                $where = 'id in(' . implode(',', $ids) . ')';
                $info = $model->getListBy($where, "openid,name,avatar");
                foreach($ids as $key){
                    $model->delete($key);
                }
                foreach($info as $key){
                    $model->add($key);
                }



            } else {
                $info = $model->get($ids, "openid,name,avatar");
                $model->delete($ids);
                $model->add($info);
            }

            $this->admin_success("ok");
            exit;
        }
        if (is_array($ids)) {
            $where = 'id in(' . implode(',', $ids) . ')';
            $param = [
                'status' => 0,
            ];
            $model->updateBy($where, $param);
        } else {
            $where = 'id=' . $ids;
            $info = $model->get($ids);
            $model->update($ids, ['status' => $info['status'] == 0 ? 1 : 0]);

        }
        $this->admin_success("ok");
    }

    //vip列表

    public function vipList()
    {
        $curr_page = I('path.2/d', 1);
        $model = new CenterModel('u_user');
        $name = I("name");
        $where = [
            'is_vip' => 'Y'
        ];
        if ($name) {
            $where ['name'] = $name;
            $key = "%" . $name . "%";
            $where['name'] = array('like', $key);
        }
        $list = $model->getListBy($where, "*", "utime desc", $curr_page, 15);
        $total = $model->getListTotal($where);
        $page_service = new PageService($total, 15);
        $page_nav = $page_service->show();
        foreach ($list as $key => $val) {
            $list[$key]['id'] = sprintf("%06d", $val['id']);
        }
        $totalDay= $model->getListTotal(['vip_stime'=>['gt',day()]]);
        $this->assignAll(array(
            'title' => 'VIP列表',
            'list' => $list,
            'page_nav' => $page_nav,
           'totalDay'=>$totalDay,
        ));

        $this->display('viplist');
    }


    //会员列表
    public function memberList()
    {
        $curr_page = I('path.2/d', 1);
        $model = new CenterModel('u_user');
        $name = I("name");
        $where = [
            'is_member' => 'Y'
        ];
        if ($name) {
            $where ['name'] = $name;
            $key = "%" . $name . "%";
            $where['name'] = array('like', $key);
        }
        $list = $model->getListBy($where, "*", "utime desc", $curr_page, 15);
        $total = $model->getListTotal($where);
        $page_service = new PageService($total, 15);
        $page_nav = $page_service->show();
        foreach ($list as $key => $val) {
            $list[$key]['id'] = sprintf("%06d", $val['id']);
        }
        $totalDay= $model->getListTotal(['member_stime'=>['gt',day()]]);
        $this->assignAll(array(
            'title' => '会员列表',
            'list' => $list,
            'page_nav' => $page_nav,
            'totalDay'=>$totalDay,
        ));

        $this->display('memberlist');
    }


}