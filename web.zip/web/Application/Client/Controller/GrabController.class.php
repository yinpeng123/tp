<?php
namespace Client\Controller;

use Basic\Service\AuthService;
use Basic\Service\GrabService;
use Basic\Service\OrderMiddleService;
use Basic\Service\OrderService;
use Common\Controller\SessionController;
use Common\Cnsts\ERRNO;
use Basic\Cnsts\DICT;

class GrabController extends  SessionController {

    protected $_grab_info;

    public function __construct() {
        parent::__construct();
    }

    protected function _setGrabInfo( $grab_info ) {
        $this->_grab_info = $grab_info;
    }

    public function _getGrabInfo() {
        return $this->_grab_info;
    }

    /**
     * 我要报价页面
     * 重新报价(grab_id>0)
     */
    public function grabPage() {
        $order_id = $this->req['order_id'];
        $grab_id = $this->req['grab_id'];
        if ($grab_id) {
            /** @var GrabService $grab_service */
            $grab_service = D('Basic/Grab','Service');
            $grab_info = $grab_service->getGrabById($grab_id);
            if ( $grab_info['user_id'] != $this->user_id ) {
                return $this->doResponse(ERRNO::NO_AUTH, '数据不存在', []);
            }
        } else {
            $grab_info = [];
        }
        $data = [
            'order_id' => $order_id,
            'grab_id' => $grab_id ? : 0,
            'grab_price' => $grab_info['grab_price'] ? : 0,
            'fee_list' => [],
            'link_phone' => !empty($grab_info['link_phone']) ? $grab_info['link_phone'] :[],
            'car_num' => !empty($grab_info['car_num']) ? $grab_info['car_num'] : '',
            'driver_name' => !empty($grab_info['driver_name']) ? $grab_info['driver_name'] : '',
            'driver_phone' => !empty($grab_info['driver_phone']) ? $grab_info['driver_phone'] : '',
            'extra_info' => !empty($grab_info['info']) ? $grab_info['info'] : '',
        ];
        return $this->doResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), $data);
    }

    /**
     * 提交报价 Or 重新报价
     *
     */
    public function grabOrder() {
        $this->req['user_id'] = $this->req['_user_id'];
        $this->req['info'] = $this->req['extra_info'];
        /** @var AuthService $auth_service */
        $auth_service = D('Basic/Auth', 'Service');
        $auth = $auth_service->isAuth($this->req['_user_id'], 'grab_order');
        if ( $auth['permission'] == 0 ) {
            return $this->doResponse(ERRNO::OP_NOT_ALLOW, $auth['alert']);
        }
        /** @var GrabService $grab_service */
        $grab_service = D('Basic/Grab', 'Service');
        list($errno, $errmsg, $check_data) = $grab_service->checkGrabParam($this->req);
        if ($errno != ERRNO::SUCCESS) {
            return $this->doResponse($errno, $errmsg, []);
        }
        $this->req['grab_status'] = DICT::GRAB_ING;
        list($errno, $errmsg, $data) = $grab_service->grabOrder($this->req);
        if ($errno == ERRNO::SUCCESS && $this->req['grab_id']) {
            $up_data = [
                'grab_status' => DICT::GRAB_CANCEL,
                'grab_count' => 2,
            ];
            list($up_err, $up_errmsg) = $grab_service->updateGrabById($this->req['grab_id'],$up_data);
            if ( $up_err != ERRNO::SUCCESS ) {
                cmm_log2(json_decode($this->req, JSON_UNESCAPED_UNICODE));
            }
        } else if ($errno == ERRNO::SUCCESS) {
            $cond = [
                'order_id' => $this->req['order_id'],
                'user_id' => $this->req['user_id'],
                'grab_status' => ['neq', DICT::GRAB_ING]
            ];
            $cancel_grab_list = $grab_service->getGrabList($cond);
            if ($cancel_grab_list) {
                $up_cg_data = [
                    'grab_count' => 2,
                ];
                foreach ($cancel_grab_list as $cg){
                    $grab_service->updateGrabById($cg['id'],$up_cg_data);
                }
            }
        }
        return $this->doResponse($errno, $errmsg, $data);
    }

    /**
     * 报价列表
     */
    public function grabList() {
        $this->req['user_id'] = $this->req['_user_id'];
        $cond = $this->_getCond($this->req);
        /** @var GrabService $grab_service */
        $grab_service = D('Basic/Grab', 'Service');
        $where = $this->_getGrabListwhere($cond);
        $page_service = new \Basic\Service\PageService($cond);
        $limit = $page_service->getLimit();
        $order = 'id desc';
        $grab_list = $grab_service->getGrabMergeCoList($where, $order, $limit);
        $grab_service->formatGrabList($grab_list); //转换报价列表

        foreach ($grab_list as &$grab_info) {
            $grab_info['detail_view'] = [
                'permission' => 1,
                'alert' => '',
            ];
            $grab_info['telephone_view'] = [
                'permission' => 1,
                'alert' => '',
            ];
        }

        $ret_total = (int)count($grab_list);
        if ($ret_total == $page_service->page_size) {
            $total = ($page_service->page_num+1) * $page_service->page_size;
        } else {
            $total = ($page_service->page_num -1) * $page_service->page_size + $ret_total;
        }
        $ret_data = [
            'total' => (int) $total,
            'page_size' => (int) $page_service->page_size,
            'page_num' => (int) $page_service->page_num,
            'ret_count' => $ret_total,
            'list' => $grab_list,
        ];
        return $this->doResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), $ret_data);
    }

    //获取运单查询条件
    protected function _getGrabListwhere($cond) {
        $where = [];
        $user_id = (int)$cond['user_id'];

        if ($user_id) {
            $where['grab_order.user_id'] = $user_id;
        }

        //@todo 拼装条件
        if ( $cond['grab_status'] ) {
            if ( $cond['grab_status'] == DICT::GRAB_CANCEL ) {
                $where['grab_order.grab_status'] = ['in', [DICT::CANCEL_ORDER_GRAB_FAIL, DICT::GRAB_CANCEL]];
            } else {
                $where['grab_order.grab_status'] = $cond['grab_status'];
            }
        }
        /** @var OrderService $order_service */
        $order_service = D('Basic/Order', 'Service');
        $start = $order_service->getSearchStart($cond);
        $to = $order_service->getSearchTo($cond);
        if ( !empty($start) ) {
            $where['co_order.start_code'] = ['like',"$start%"];
        }

        if ( !empty($to) ) {
            $where['co_order.to_code'] = ['like',"$to%"];
        }
        $where['grab_order.status'] = 1;
        return $where ?: [];
    }

    /**
     * @param $req
     */
    protected function _getCond($req) {
        $cond = [
            'user_id' => $req['user_id'],
            'page_num' => $req['page_num'],
            'page_size' => $req['page_size'],
            'grab_status' => $req['query']['grab_status'],
            'start_province' => $req['query']['start_province'],
            'start_city' => $req['query']['start_city'],
            'start_district' => $req['query']['start_district'],
            'to_province' => $req['query']['to_province'],
            'to_city' => $req['query']['to_city'],
            'to_district' => $req['query']['to_district'],
        ];
        return $cond;
    }


    /**
     * 报价详情
     */
    public function grabOrderDetail() {
        $grab_id = $this->req['grab_id'];
        if (empty($grab_id)) {
            return $this->doResponse(ERRNO::INPUT_PARAM_ERRNO, ERRNO::e(ERRNO::INPUT_PARAM_ERRNO), []);
        }
        /** @var GrabService $grab_service */
        $grab_service = D('Basic/Grab', 'Service');
        $grab_detail = $grab_service->grabOrderDetail($grab_id);
        if ($grab_detail['grab_info']['user_id'] != $this->req['_user_id']) {
            //非本人不能查看
            return $this->doResponse(ERRNO::OP_NOT_ALLOW, '数据不存在！');
        }
        return $this->doResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), $grab_detail);
    }

    /**
     * 取消报价
     */

    public function cancelGrab() {
        $data = $this->req;
        $grab_id = $data['grab_id'];
        /** @var Grabservice $grab_service */
        $grab_service = D('Basic/Grab', 'Service');
        //验证是否可以取消,抢单成功的不可取消
        list($errno, $errmsg) = $grab_service->checkCancelGrab($grab_id, $this->req['_user_id']);
        if ($errno != ERRNO::SUCCESS) {
            return $this->doResponse($errno, $errmsg, null);
        }
        /** @var OrderService $order_service */
        $order_service = D('Basic/Order', 'Service');
        $grab_info = $grab_service->getGrabById($grab_id);
        $order_id = $grab_info['order_id'];
        $order_info = $order_service->getCoOrderById($order_id);

        $new_grab_num = $order_info['grab_num'] -1;
        $up_data = [
            'grab_status' => DICT::GRAB_CANCEL,
        ];
        list($errno,$errmsg, $up_res) = $grab_service->updateGrabById($grab_id,$up_data);
        $co_up_data = [
           'grab_num' => $new_grab_num,
        ];
        if ( $new_grab_num == 0 ) {
            $co_up_data['query_status'] = DICT::UN_QUERY;
        }
        list ($co_err, $co_msg,$co_up_res) = $order_service->upCoOrderByOrderId($order_id, $co_up_data);
        return $this->doResponse($errno, $errmsg, []);
    }


    /**
     * 确认接单
     */
    public function receive() {
        $grab_id = $this->req['grab_id'];
        if ( !$this->_isSelf($grab_id) ) {
            return $this->doResponse(ERRNO::OP_NOT_ALLOW, '数据不存在！', null);
        }

        $grab_info = $this->_getGrabInfo();
        if ( $grab_info['grab_status'] != DICT::GRAB_WAIT_CON ) {
            return $this->doResponse(ERRNO::OP_NOT_ALLOW, '不允许当前操作，请刷新后重试！', null);
        }
        /** @var OrderMiddleService $omid_service */
        $omid_service = D('Basic/OrderMiddle', 'Service');
        list($errno, $errmsg, $ret_data) = $omid_service->sureOrder($grab_id);
        return $this->doResponse($errno, $errmsg, $ret_data);
    }

    /**
     * @param $grab_id
     *
     * @return bool
     * 判断是否是本人操作
     * 不符合单一职责原则//@todo 修改
     */
    protected function _isSelf($grab_id) {
        /** @var GrabService $grab_service */
        $grab_service = D('Basic/Grab', 'Service');
        $grab_info = $grab_service->getGrabById($grab_id);
        $this->_setGrabInfo($grab_info);
        $g_uid = $grab_info['user_id'];
        return $g_uid == $grab_info['user_id'];
    }


    /**
     * 拒绝接单
     */
    public function refuse(){
        $grab_id = $this->req['grab_id'];
        $user_id = $this->req['_user_id'];
        if ( !$this->_isSelf($grab_id) ) {
            return $this->doResponse(ERRNO::OP_NOT_ALLOW, '数据不存在！', null);
        }
        $grab_info = $this->_getGrabInfo();
        if ( $grab_info['grab_status'] != DICT::GRAB_WAIT_CON ) {
            return $this->doResponse(ERRNO::OP_NOT_ALLOW, '不允许当前操作，请刷新后重试！', null);
        }
        /** @var OrderMiddleService $omid_service */
        $omid_service = D('Basic/OrderMiddle', 'Service');
        $ret_res = $omid_service->closeGrabOrder($grab_info['order_id'], $grab_id, $user_id);
        if ( $ret_res ) {
            return $this->doResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), null);
        } else {
            return $this->doResponse(ERRNO::SQL_UPDATE_ERRNO, '操作失败！', null);

        }
    }

    /**
     * 修改抢单信息 司机和车辆
     * @todo 调Mid接口
     */

    public function editGrab() {
        $data = $this->req;
        $data['user_id'] = $this->req['_user_id'];

        if ( !$this->_isSelf($data['grab_id']) ) {
            return $this->doResponse(ERRNO::OP_NOT_ALLOW, '数据不存在！', null);
        }
        /** @var Grabservice $grab_service */
        $grab_service = D('Basic/Grab', 'Service');
        list($errno, $errmsg, $edit_res) = $grab_service->editGrab($data);
        return $this->doResponse($errno, $errmsg);
    }

}