<?php
namespace Client\Controller;

use Basic\Service\InsurService;
use Basic\Service\ShippingOrderService;
use Common\Cnsts\ERRNO;
use Common\Controller\SessionController;
use Basic\Model\InsurModel;
use Basic\Cnsts\INSUR;

class InsuranceController extends SessionController  {

    public function __construct() {
        parent::__construct();
    }

    // @lxf_todo
    public function commonData() {

        $ship_id = $this->req['ship_id'];
        $ship_info = $this->getDefaultShipInfo();
        if ( !empty($ship_id) ) {
            /** @var ShippingOrderService $ship_service */
            $ship_service = D('Basic/ShippingOrder', 'Service');
            $ship_info = $ship_service->getShipMergeOrderByShipId($ship_id);
            /** @var InsurService $insur_service */
            $insur_service = D('Basic/Insur', 'Service');
            list($errno, $errmsg, $check_data) = $insur_service->checkCanInsur($ship_info, $this->user_id);
            if ( $errno != ERRNO::SUCCESS ) {
                return $this->doResponse($errno, $errmsg, null);
            }
            $ship_info = $insur_service->getFmtShipInfoForInsur($ship_info, $this->user_id);
        }
        $data = [
            'pay_valid_time' => InsurModel::WYLJ_PAY_VALID_TIME,    // 有效描述
            'all_good_type' => INSUR::getCargoTypeDict(),
            'ship_info' => $ship_info,
        ];

        return $this->doResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), $data);
    }

    protected function getDefaultShipInfo() {
        $fmt_ship_info = [
            'ship_id' => 0,
            'order_id' => 0,
            'policy_holder' => '',
            'mobile' => '',
            'departure' => '',
            'terminal' => '',
            'insurance_from' => '',
            'truck_no' => '',
        ];
        return $fmt_ship_info;
    }

    public function notice() {
        $url= U( 'Client/Insurance/noticeUrl',  '',  true,  true);
        return $this->doResponse(0, "须知URL", ['url'=>$url]);
    }
    public function clause(){
        $url= U( 'Client/Insurance/clauseUrl',  '',  true,  true);
        return $this->doResponse(0, "条款URL", ['url'=>$url]);
    }
    /**
     * 创建保单
     * @doc http://wiki.chemanman.com/pages/viewpage.action?pageId=16777683
     * @version 1.1.0
     *  cargos 字段兼容标准json.list格式
     * @version 1.0.0
     * @return json
     */
    public function create() {
        /** @var InsurService $srv */
        $srv = D('Basic/Insur', 'Service');
        if ( $this->req['ship_id']> 0 ) {
            /** @var ShippingOrderService $ship_service */
            $ship_service = D('Basic/ShippingOrder', 'Service');
            $ship_info = $ship_service->getShipMergeOrderByShipId($this->req['ship_id']);
            list($errno ,$errmsg, $check_data) = $srv->checkCanInsur($ship_info, $this->user_id);
            if ( $errno != ERRNO::SUCCESS ) {
                return $this->doResponse($errno, $errmsg, $check_data);
            }
        }
        $insur_id = $srv->createInsur($this->_getDataArray());
        $data = ['id' => $insur_id];
        if (false === $insur_id) {
            list($errno, $errmsg) = [100, $errmsg = $srv::$errmsg];
        } else {
            list($errno, $errmsg) = [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS)];
        }
        return $this->doResponse($errno, $errmsg, $data);
    }

    protected function _getDataArray() {
        $data_array = [
            'uid' => $this->req['_user_id'],
            'so_id' => $this->req['ship_id'],
            'policy_holder' => $this->req['policy_holder'],
            'mobile' => $this->req['mobile'],
            'departure' => $this->req['departure'],
            'terminal' => $this->req['terminal'],
            'insurance_from' => $this->req['insurance_from'],
            'truck_no' => $this->req['truck_no'],
            'cargos' => is_string($this->req['cargos']) ? $this->req['cargos']
                : t_json_encode($this->req['cargos']),
            'count' => $this->req['count'],
        ];
        return $data_array;
    }

    /**
     * 修改保单
     * @doc http://wiki.chemanman.com/pages/viewpage.action?pageId=16777683
     * @version 1.0.0
     * @return json
     */
    public function modify() {
        $errno = 0;
        $errmsg = '';
        $data_array = [
            'uid' => $this->req['_user_id'],
            'so_id' => $this->req['ship_id'],
            'policy_holder' => $this->req['policy_holder'],
            'mobile' => $this->req['mobile'],
            'departure' => $this->req['departure'],
            'terminal' => $this->req['terminal'],
            'insurance_from' => $this->req['insurance_from'],
            'truck_no' => $this->req['truck_no'],
            'cargos' => is_string($this->req['cargos']) ? $this->req['cargos']
                : t_json_encode($this->req['cargos']),
            'count' => $this->req['count'],
        ];
        $id = $this->req['id'];
        /** @var InsurService $srv */
        $srv = D('Basic/Insur', 'Service');
        if ( $this->req['ship_id']> 0 ) {
            /** @var ShippingOrderService $ship_service */
            $ship_service = D('Basic/ShippingOrder', 'Service');
            $ship_info = $ship_service->getShipMergeOrderByShipId($this->req['ship_id']);
            list($errno ,$errmsg, $check_data) = $srv->checkCanInsur($ship_info, $this->user_id);
            if ( $errno != ERRNO::SUCCESS ) {
                return $this->doResponse($errno, $errmsg, $check_data);
            }
        }
        if ($id) {
            $insur_info = $srv->getFormattedDetail($id);
            $data_array['so_id'] = $insur_info['so_id'];
        }

        $ret = $srv->modifyInsur($id, $data_array);
        $data = ['id' => $id];
        if (false === $ret) {
            $errno = 100;
            $errmsg = $srv::$errmsg;
        }
        return $this->doResponse($errno, $errmsg, $data ?: (object)[]);
    }

    /**
     * 确认保单
     *
     * @href http://wiki.chemanman.com/pages/viewpage.action?pageId=16777683
     * @version 1.0.0
     * @return json
     */
    public function confirm(){
        $errno = 0; 
        $errmsg = '';
        $data = [];
        $id = $this->req['id'];
        /** @var InsurService $srv */
        $srv = D('Basic/Insur', 'Service');
        $res = $srv->confirm($id);
        $errmsg = $srv::$errmsg;
        if (false === $res) {
            $errno = 1000;
        } else {
            $data = ['pay_url' => $res['pay_url_app']];
        }
        return $this->doResponse($errno, $errmsg, $data?:(object)[]);
    }

    public function insuranceList() {
        $errno = 0;
        $errmsg = '';
        /** @var InsurService $srv */
        $srv = D('Basic/Insur', 'Service');
        list($where, $order, $limit) = $this->parseFilter();
        $res = $srv->getFormattedList($where, $order, $limit);
        $data = ['list' => $res];
        return $this->doResponse($errno, $errmsg, $data);
    }

    /**
     * 解析我的保单筛选条件
     * @lxf_todo
     *
     * @param [type] $filter
     * @return void
     */
    private function parseFilter() {
        $where = [
            'uid' => $this->req['_user_id'],
        ];
        $filter_status = $this->req['filter']['status'];
        if (InsurModel::INSUR_STATUS_CANCEL == $filter_status) { // 已取消
            $where[] = [
                'insur_status' => ['in', [InsurModel::INSUR_STATUS_CREATE, InsurModel::INSUR_STATUS_CONFIRM]],
                'ctime' => ['elt', date('Y-m-d H:i:s', time()-InsurModel::WYLJ_PAY_VALID_TIME)],
            ];
        } else if (InsurModel::INSUR_STATUS_EXPIRED == $filter_status) { // 已过期
            $where[] = [
                'insur_status' => InsurModel::INSUR_STATUS_PAID,
                'insurance_to' => ['lt', date('Y-m-d H:i:s')],
            ];
        } else if (InsurModel::INSUR_STATUS_CONFIRM == $filter_status) { // 待支付
            $where[] = [
                'insur_status' => ['in', [InsurModel::INSUR_STATUS_CREATE, InsurModel::INSUR_STATUS_CONFIRM]],
                'ctime' => ['gt', date('Y-m-d H:i:s', time()-InsurModel::WYLJ_PAY_VALID_TIME)],
            ];
        } else if (InsurModel::INSUR_STATUS_PAID == $filter_status) { // 已投保
            $where[] = [
                'insur_status' => InsurModel::INSUR_STATUS_PAID,
                'insurance_to' => ['egt', date('Y-m-d H:i:s')],
            ];
        } else {
        }
        $start_time = $this->req['filter']['start_time'] ?: date('Y-m-01');
        $end_time = $this->req['filter']['end_time'] ?: date('Y-m-01', strtotime('+1 month'));
        $where['ctime'] = ['between', [$start_time, $end_time]];
        $order = 'ctime desc';
        $page_index = $this->req['page_index'] ?: 1;
        $page_size = $this->req['page_size'] ?: 10;
        $limit = sprintf('%s,%s', $page_index-1, $page_size);
        return [$where, $order, $limit];
    }

    public function detail() {
        $errno = 0;
        $errmsg = '';
        $id = $this->req['id'];
        /** @var InsurService $srv */
        $srv = D('Basic/Insur', 'Service');
        $detail = $srv->getFormattedDetail($id);
        if ( $detail['uid'] != $this->user_id ) {
            return $this->doResponse(ERRNO::DATA_NOT_EXISTS, '数据不存在！', []);
        }
        $detail['ship_id'] = $detail['so_id'] ? : 0;
        return $this->doResponse($errno, $errmsg, $detail);
    }


    /**
     * @note :重构了生成电子保单方法(@wanghongjie)
     * @param  :int id 保单ID
     * @return : file
     */
    public function downloadPdf(){
        $id=I('id');
        /** @var InsurService $srv */
        $srv = D('Basic/Insur', 'Service');
        list($code,$message,$path)=$srv->makePolicy($id);
        if($code){
            echo $message;
            return false;
        }
        $filename = $id.'.pdf';
        header("Content-type:application/pdf");
    //    header("Content-Disposition:attachment;filename=".$filename);
        echo file_get_contents($path);
    }
    public function download(){
        $id = $this->req['id'];
        $url= U( 'Client/Insurance/downloadPdf?id='.$id,  '',  true,  true);
        $this->doResponse(0, "保单下载URL", ['url'=>$url]);
    }
    public function noticeUrl() {
        $this->display(T('Web@Insurance:insurance_001'));
    }
    public function clauseUrl(){
        $this->display(T('Web@Insurance:insurance_002'));
    }

}