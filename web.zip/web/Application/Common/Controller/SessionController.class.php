<?php
namespace Common\Controller;

use Basic\Service\UserService;
use Common\Controller\CommonController;
use Common\Cnsts\ERRNO;
use Common\Service\CommonService;

/**
 * 需要验证用户登录状态的controller基类
 */
class SessionController extends CommonController {

    // 用户id
    protected $user_id = null;
    // 用户信息
    protected $user_info = null;

    public function __construct() {
        parent::__construct();

        // 登录判断
        if ( empty(session('user_id')) ) {
            $this->doResponse(ERRNO::SYS_NOT_LOGIN, ERRNO::e(ERRNO::SYS_NOT_LOGIN));
            cmm_exit();
        }

        // 更新最近访问时间
        $this->updateActiveTime();
        // 统计用户在线时长
        $this->statsOnlineTime();

        $this->user_id = session('user_id');
        $this->user_info = session('user_info');

        if ( !empty($this->user_info['relogin']) && $this->user_info['relogin'] == 1 ) {
            session_destroy();
            $this->doResponse(ERRNO::SYS_RELOGIN, ERRNO::e(ERRNO::SYS_RELOGIN));
            cmm_exit();
        }

        // 为了方便service中获取当前用户的信息
        $this->req['_user_id'] = session('user_id');
        $this->req['_user_info'] = session('user_info');
        /** @var CommonService $common_service */
        $common_service = D('Common/Common','Service');
        if ( $this->app_info ) {
            if ( empty($this->app_info['memachine_no']) && !APP_DEBUG ) {
                $this->doResponse(ERRNO::MEMACHINE_NO_NOT_EQ, '未获取到您的设备号，请到权限设置修改，信任此应用！');
                cmm_exit();
            }
            if ( !$common_service->checkAppMemachineNo($this->user_id, $this->app_info) ) {
                $this->doResponse(ERRNO::MEMACHINE_NO_NOT_EQ, '每个账号只允许在一台设备上登录，更换设备请联系客服！');
                cmm_exit();
            }
        }

    }

    // 更新最近访问时间, 缓存数据以减少更新数据库的次数 && 新增更新版本号
    protected function updateActiveTime() {
        $user_id = session('user_id');
        if ( !$user_id )
            return FALSE;

        $now = time();
        $flag = TRUE; // 是否更新数据
        $active_time = session('user_info.app_active_time');
        if ( $active_time && $now - strtotime($active_time) < C('MAX_IDLE_TIME') ) {
            $flag = FALSE;
        }

        // 更新数据库、session
        if ( $flag ) {
            /** @var UserService $user_service */
            $user_service = D('Basic/User', 'Service');
            $up_data = [
                'app_active_time' => datetime($now),
            ];
            $user_service->updateUserById($user_id, $up_data);
            session('user_info.app_active_time', datetime($now));
        }
    }

    // 统计用户的在线时长
    protected function statsOnlineTime() {
        $user_id = session('user_id');
        if ( !$user_id )
            return;

        // 本次请求与上一次请求之间的时间间隔超过5分钟即被视为新一次的访问(在线)
        $offline_time = 5*60;
        // 当本次访问时长达到1分钟即需要累计到数据表中
        $min_inc_duration = 60;

        // 当前时间
        $now = time();
        $curr_time = datetime();
        $curr_day = substr($curr_time, 0, 10);

        // 本次访问(在线)的开始、结束时间, 两者之差即是本次访问的时长(未累计到数据表中的值)
        $visit_begin_time = S('online_visit_begin_time_'.$user_id) ?: $curr_time;
        $visit_end_time = S('online_visit_end_time_'.$user_id) ?: $curr_time;
        $visit_begin_day = substr($visit_begin_time, 0, 10);
        $visit_end_day = substr($visit_end_time, 0, 10);
        \Think\Log::write(sprintf("[before] visit_begin_time:%s, visit_end_time:%s", $visit_begin_time, $visit_end_time), 'INFO');

        // 时间是否跨天
        $is_new_day = $visit_begin_day != $curr_day ? TRUE : FALSE;
        if ( $is_new_day ) { // 跨天
            // 将截止24点的时长累计到数据表中
            if ( $visit_end_day != $curr_day ) {
                $visit_duration = strtotime($visit_end_time) - strtotime($visit_begin_time);
            } else {
                $visit_duration = strtotime($curr_day." 00:00:00") - strtotime($visit_begin_time);
            }
            $this->_incOnlineTime($user_id, $visit_begin_day, $visit_duration, $curr_time);

            $visit_begin_time = $curr_day." 00:00:00";
            $visit_begin_day = $curr_day;
            $visit_end_time = max($visit_begin_time, $visit_end_time);
            $visit_end_day = substr($visit_end_time, 0, 10);
        }

        if ( $now - strtotime($visit_end_time) <= $offline_time ) { // 进行中的访问
            $visit_end_time = $curr_time;

            // 如果本次访问的时长超过1分钟, 则累加到在线时长并将开始、结束时间前移至当前时间
            $visit_duration = strtotime($visit_end_time) - strtotime($visit_begin_time);
            if ( $visit_duration >= $min_inc_duration ) {
                // 累加时长
                $this->_incOnlineTime($user_id, $visit_begin_day, $visit_duration, $curr_time);

                // 开始新一次访问
                $visit_begin_time = $visit_end_time = $curr_time;
            }
        } else { // 新一次的访问
            // 首先, 将之前访问的时长累计到数据表中
            $visit_duration = strtotime($visit_end_time) - strtotime($visit_begin_time);
            $this->_incOnlineTime($user_id, $visit_begin_day, $visit_duration, $curr_time);

            // 然后, 将开始、结束时间前移至当前时间
            $visit_begin_time = $visit_end_time = $curr_time;
        }

        S('online_visit_begin_time_'.$user_id, $visit_begin_time);
        S('online_visit_end_time_'.$user_id, $visit_end_time);
        \Think\Log::write(sprintf("[after] visit_begin_time:%s, visit_end_time:%s", $visit_begin_time, $visit_end_time), 'INFO');
    }

    /**
     * 更新用户在线时长数据表中的时长值
     * @param $uid
     * @param $day
     * @param int    $seconds 增加的秒数
     * @param string $curr_time 当前时间, 防止重复统计访问时长
     *
     * @return int
     * @throws \Think\Exception
     */
    private function _incOnlineTime($uid, $day, $seconds, $curr_time) {
        if ( !$uid || !$day || $seconds <= 0 )
            return -1;

        $online_model = new \Basic\Model\UserOnlineLogModel();
        $online_model->startTrans();
        $row = $online_model->getRow($uid, $day, TRUE);
        if ( empty($row) ) {
            $online_model->add(['uid' => $uid, 'day' => $day, 'online_time' => $seconds]);
            $online_model->commit();
            // 增加登录分
            D('Basic/UserCredit', 'Service')->addLogin($uid);
            return 1;

        } else {
            // 检查记录是否已经在当前时刻更新过, 防止并发访问导致重复累计时长
            if ( $curr_time <= $row['mtime'] ) {
                $online_model->rollback();
                return 0;
            }

            $online_model->incOnlineTime($row['id'], $seconds);
            $online_model->commit();
            return 1;
        }
    }
}