<?php
define('BASE_PATH', __DIR__.'/../');
//for test
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 'On');
date_default_timezone_set('Asia/Shanghai');

define('SERVER_SCRIPT_MODE', true);
// 定义应用目录
define('APP_PATH',BASE_PATH.'/Application/');
define('MODULE_NAME', 'Crontab');
// 定义运行时目录
define('RUNTIME_PATH','/tmp/Runtime/');
// 开启调试模式
define('APP_DEBUG',True);

// 更名框架目录名称，并载入框架入口文件
require BASE_PATH.'/ThinkPHP/ThinkPHP.php';

C('DB_TYPE', 'mysqli');
C('DB_PREFIX', '');

if (!IS_CLI) {
    die('Only Avaliable On CLI-Mode');
}