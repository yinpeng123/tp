<?php
namespace Admin\Service;

class ProfileService {

    /**
     * 添加操作日志
     */
    public function addOperLog($info) {
        $log_model = D('OperLog');
        $oper_info = array(
            'manager_id'    => $info['manager_id'],
            'module'        => '个人信息',
            'resource'      => '个人',
            'object_id'     => $info['object_id'],
            'action'        => $info['action'],
            'desc'          => $info['desc'],
            'ctime'         => datetime(),
        );
        $log_model->add($oper_info);
    }

}