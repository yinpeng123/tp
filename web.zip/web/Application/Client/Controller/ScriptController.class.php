<?php
namespace Client\Controller;

use Think\Controller;

class ScriptController extends Controller {

    public function __construct()
    {
        if (APOLLO_ENV_STAGE == 'prod' && !IS_CLI)

            exit();
        parent::__construct();
    }

    public function completeTicket() {
        $ticket_m = M('ticket');
        $go_on = true;
        $page_num = 0;
        $page_size = 1000;
        $search_time = date('Y-m-d H:i:s',strtotime("-10 days"));
        dump($search_time);
        die();
        while( $go_on ) {
            $where = [

            ];
        }
    }

    /**
     * app 用的地址插件
     */
    public function cityText() {
        $cities = M('city')->where(['id'=> ['gt',0]])->select();
        $str = '';
        $str .= "id parent_id address level is_last_level\r\n";
        $parent_ids = [];
        $num = 0;
        foreach ($cities as $value) {
            if ($value['level']>= 3) {
                $is_last_level = 1;
            } else {
                $is_last_level = 0;
            }
//            if (!in_array($value['parent_id'],$parent_ids) && $value['level']>1) {
//                $parent_ids[]= $value['parent_id'];
//                $num = 0;
//                $str .= "{$num} {$value['parent_id']} 全部 {$value['level']} {$is_last_level}\r\n";
//            }
            if ($value['parent_id'] == -1) {
                $value['parent_id'] = 0;
            }
            $str .= "{$value['id']} {$value['parent_id']} {$value['alias']} {$value['level']} {$is_last_level}\r\n";
        }

        $filename = '搜索.txt';
        header("Content-type: text/plain");
        header("Accept-Ranges: bytes");
        header("Content-Disposition: attachment; filename=".$filename);
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0" );
        header("Pragma: no-cache" );
        header("Expires: 0" );
        echo $str;
    }
}