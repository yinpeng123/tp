<?php

if ( !APP_DEBUG ) {
    $root_path = '/data/static/';
} else {
    $root_path = '/data/static_t/';
}

if ( !APP_DEBUG ) {
    $sub_path = 'certficate/';
} else {
    $sub_path = 'certficate/';
}

return [
    // 最大图片上传的大小
    'MAX_IMAGE_UPLOAD_SIZE' => 5*1024*1024,
    'IMAGE_HOST'=>"https://plan.upxiaoqu.com/basic/image/view/certificate/",
    'IMAGE_PATH' => [
        'certificate'    => $root_path . 'certficate/',
    ],

    'FILE_PATH' => [
        'crm_file'        => $root_path.$sub_path,
    ],



    'DOWNLOAD_PATH' => [
        'download'        => $root_path.'download',
    ],

];