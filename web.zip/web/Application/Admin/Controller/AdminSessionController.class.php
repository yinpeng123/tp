<?php
namespace Admin\Controller;

use Admin\Controller\AdminCommonController;

class AdminSessionController extends AdminCommonController {

    // 管理员信息
    protected $_manager_id = null;
    protected $_manager = null;

    public function __construct() {
        parent::__construct();

        $this->checkLogin();

        $this->_manager_id = session('manager_id');
        $this->_manager = session('manager');
        $this->setNavMenuStatus();
        $this->genNavMenu();

        $this->assign('socket_uid', 'crm_'.$this->_manager_id);
        $this->assign('socket_url', C('WSS')[0]['fe']['socket_url']);
        // 访问权限检查移到具体的功能controller中进行
        // +2017-08-10 zhongying
//        if ( !$this->checkManagerPrivilege() ) {
//            //$this->error('你无权访问该页面！', base_url('auth/login').'?refer='.urlencode('/home/index'));
//            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
//            exit;
//        }

        if ( IS_GET ) {
            $this->assign('admin', session('manager'));
        }
    }

    /**
     * 检查用户是否已登录，未登录则跳转到登录页
     */
    protected function checkLogin() {
        $refer = I('request.refer/s');
        $backurl = $refer ?: I('server.REQUEST_URI');
        if ( empty(session('manager_id')) || empty(session('manager')) ) {
            //$this->input->set_cookie('xsy_referer', base_url(uri_string()), 0); // session cookie
            redirect(U('auth/login', '', '').'?refer='.urlencode($backurl));
        }
        $_manager = session('manager');
        $manager_model = D('Manager');
        $row = $manager_model->getManagerById($_manager['manager_id'], 'password, relogin');
        if ($row['relogin'] > 0 || $_manager['password'] != $row['password']) {
            session_destroy();  // 先销毁当前session
            redirect(U('auth/login', '', '').'?refer='.urlencode($backurl));
        }

        //$this->assign('admin', $_manager);
    }


    /**
     * 将左侧菜单导航栏设置成最近访问的状态
     */
    protected function setNavMenuStatus() {
        $navcol = cookie('navcol');
        //\Think\Log::write('[AdminSessionController::setNavMenuStatus] cookie.navcol:'.$navcol, \Think\Log::DEBUG);
        if ($navcol == 'nav-md' || $navcol == 'nav-sm' )
            $this->assign('navcol', $navcol);
        else
            $this->assign('navcol', 'nav-md');
    }


    /**
     * 生成左侧导航菜单
     */
    protected function genNavMenu() {
        $menu_model = D('Menu');
        $url_key = I('path.0') ?: 'home'; // 缺省为home
        $url_key2 = I('path.1') ?: 'index';

        // 获取当前管理员能访问的菜单列表
        if ( !empty(session('menu_list')) ) { // 先从session中获取数据
            $menu_list = session('menu_list');
        } else {
//            $menu_ids = array();
//            if ( $this->_manager_id != 1 ) {
//                $menu_arr = array();
//                if ( strlen($this->_manager['menu_ids']) > 1 ) {
//                    $menu_arr = json_decode($this->_manager['menu_ids'], true);
//                }
//
//                foreach ($menu_arr as $id1 => $id2_arr) {
//                    $menu_ids[] = $id1;
//                    foreach ( $id2_arr as $id2 => $id3_arr) {
//                        $menu_ids[] = $id2;
//
//                        if ( !empty($id3_arr) ) {
//                            foreach ($id3_arr as $id3 => $val) {
//                                $menu_ids[] = $id3;
//                            }
//                        }
//                    }
//                }
//            }
//            //print_r($menu_ids);
//
//            if ( $this->_manager_id == 1 ) {
//                $menu_list = $menu_model->searchMenu();
//            } else {
//                if ( !empty($menu_ids) ) {
//                    $menu_list = $menu_model->searchMenu(array('id_list' => $menu_ids));
//                } else {
//                    $menu_list = array();
//                }
//            }
            //print_r($res);exit;
            $menu_list = $this->_getMenuList();
            // 保存到session数据中
            session('menu_list', $menu_list);
        }


        // 将menu数据按层级关系组织, 并设置菜单的显示状态
        $nav_menu_list = array();
        foreach ( $menu_list as $r ) {
            // 过滤掉末尾的参数部分
            $_p = strpos($r['url'], '?');
            $_url = $_p ? substr($r['url'], 0, $_p) : $r['url'];
            $url_segments = explode('/', $_url);

            if ( $r['pid'] == 0 ) { // 一级菜单
                $nav_menu_list[$r['id']] = $r;
                $nav_menu_list[$r['id']]['is_active'] = 0;
                $nav_menu_list[$r['id']]['sub_menu'] = array();
            } else { // 二级菜单
                if ( strcasecmp($url_key, $url_segments[0]) == 0
                    && strcasecmp($url_key2, $url_segments[1]) == 0 ) {
                //if ( 0 == strncasecmp($url_key, $r['url'], strlen($url_key))
                //    /* && $this->input->cookie("navcol") != 'nav-sm' */ ) {
                    $r['is_active'] = 1;
                    $nav_menu_list[$r['pid']]['is_active'] = 1;
                } else {
                    $r['is_active'] = 0;
                }
                $nav_menu_list[$r['pid']]['sub_menu'][] = $r;
            }
        }
        //print_r($nav_menu_list);exit;
        $this->assign("nav_menu_list", $nav_menu_list);
    }

    // 获取当前用户能访问的菜单列表
    protected function _getMenuList() {
        $role_model = D('Role');

        $menu_ids = array();
        if ( $this->_manager_id != 1 && $this->_manager['role_id'] ) {
            // 获取角色的权限
            $role_info = $role_model->get($this->_manager['role_id']);

            $privilege_arr = array();
            if ( strlen($role_info['privileges']) > 2 ) {
                $privilege_arr = json_decode($role_info['privileges'], true);
            }
            // 获取权限对应访问的菜单
          //  $priv_service = D('Privilege', 'Service');
           // $menu_ids = $priv_service->getPrivilegeMenuIdList($privilege_arr);
        }
        $menu_ids=$privilege_arr;
        $menu_model = D('Menu');
        if ( $this->_manager_id == 1 ) { // 返回所有菜单
            $menu_list = $menu_model->searchMenu();
        } else {
            if ( !empty($menu_ids) ) {
                $menu_list = $menu_model->searchMenu(array('id_list' => $menu_ids));
            } else {
                $menu_list = array();
            }
        }
        //$menu_list = $menu_model->searchMenu();
        return $menu_list;
    }

    /**
     * 检查管理员的访问权限
     */
    protected function checkManagerPrivilege() {
        if ( $this->_manager_id == 1 )
            return true;

        $url_key = I('path.0').'/';
        if ( $url_key == 'index/' ) // 默认允许访问index页
            return true;

        if ( empty(session('menu_list')) )
            return false;

        foreach ( session('menu_list') as $r ) {
            if ( 0 == strncasecmp($url_key, $r['url'], strlen($url_key)) )
                return true;
        }
        return false;
    }

}