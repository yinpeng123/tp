<?php
namespace Admin\Controller;

use Admin\Model\MailInfoModel;
use Admin\Model\TicketModel;
use Admin\Controller\AdminSessionController;
use Admin\Service\PageService;
use Admin\Service\TicketService;
use Basic\Cnsts\CS_WORK_SHEET;
use Basic\Cnsts\DICT;
use Admin\Service\ManagerService;
use Basic\Model\AgentInvoiceModel;
use Basic\Model\CSWorkSheetModel;
use Basic\Service\AddressService;
use Basic\Service\AgentService;
use Basic\Service\CityService;
use Basic\Service\CSWorkSheetService;
use Basic\Service\MailInfoService;
use Basic\Service\SendNoticeService;
use Basic\Service\ShippingOrderService;
use Basic\Service\TicketInfoService;
use Basic\Service\UserService;
use Admin\Service\TableConfigService;
use Admin\Service\TableService;
use Common\Cnsts\ERRNO;

class TicketController extends AdminSessionController {

    private $__ticket_model = NULL;
    private $__manager_model = NULL;
    private $__user_model = NULL;
    private $__ticket_info_model = NULL;
    private $__mail_info_model = NULL;
    private $__manager_service = NULL;
    private $__agent_model = NULL;

    public function __construct() {
        parent::__construct();
        $this->__ticket_model = D('Ticket');
        $this->__manager_model = D('Manager');
        $this->__user_model = D('User');
        $this->__ticket_info_model = D('Ticket');
        $this->__mail_info_model = D('MailInfo');
        $this->__manager_service = D('Manager', 'Service');
        $this->__agent_model            = D('Basic/Agent');
        // 权限检查
        if (!\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id,
            \Admin\Cnsts\PRIVILEGE::AGENT_INVOICE)
        ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }
    }

    /**
     * 获取返回列表的链接
     */
    protected function _backToListUrl($refer='') {
        if (!empty($refer) && 0 === stripos($refer, U('Ticket/index', '', '', TRUE))) {
            return $refer;
        } else {
            return U('Ticket/index', '', '', TRUE);
        }
    }

    /**
     * 开票管理页面
     */
    public function index() {
        $ticket_config = TableConfigService::$ticket_config;
        $filters_fields = $ticket_config['filter'];
        $cond = $this->prepareSearchCond(array_keys($filters_fields));
        if (session('manager')['agent_id'] == 0) {
            $cond['channel_id'] = I('search_agent_id');
        } else {
            $cond['channel_id'] = session('manager')['agent_id'];
        }

        $where = $this->_getTicketWhere($cond);
        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        /** @var TicketService $ticket_service */
        $ticket_service = D('Admin/Ticket', 'Service');
        $field = $this->_getTicketField();
        $join = $this->_getTicketJoin();
        $order = $this->_getTicketOrder();
        $limit = ($curr_page-1) * $per_page.','.$per_page;
        $list = $ticket_service->getTicketList($field, $join, $where, $order, $limit);
//        p($list);die;
        $ticket_service->formatTicketList($list);
//        p($list);die;
        $total = $ticket_service->getTicketListTotal($where, $join);
        $page_service = new PageService($total, $per_page);
        $page_nav = $page_service->show();
        $table_service = new \Admin\Service\TableService($ticket_config);
        $table_content = $table_service->getTableContent($list);
        $filters = $table_service->getFilterContent($cond);
        $this->_assignEnum();
        $ticket = [
            'express_type'  => DICT::EXPRESS_DF,
            'express_company' => DICT::EXPRESS_SF,
        ];
        /** @var AgentService $agent_service */
        $agent_service = D('Basic/Agent', 'Service');
        $agent_list = $agent_service->getFormatAgent();

        $agent_info = $this->__agent_model->getAgentById(session('manager')['agent_id']);

        $this->assignAll(array(
            'title'               => '开票管理',
            'filters'             => $filters,
            'table_content'       => $table_content,
            'page_nav'            => $page_nav,
            'billing_time'        => date('Y-m-d'),
            'send_time'           => date('Y-m-d'),
            'ticket'               => $ticket,
            'agent_list' => $agent_list,
            'search_agent_id_owner' => session('manager')['agent_id'],
            'search_agent_id_name' => $agent_info['name'],
            'search_agent_id' => I('search_agent_id'),
        ));
        $this->display('ticket_list');
    }

    //发票相关的枚举类型
    protected function _assignEnum() {
        $this->assignAll(
            array(
                'fee_type_arr' => DICT::FEE_TYPE_LIST,
                'ticket_status_arr' => DICT::TICKET_STATUS_CRM,
                'express_type_arr'    => $this->__getExpressTypeArr(),
                'express_company_arr' => $this->__getExpressCompanyArr(),
                'back_to_list_url' => $this->_backToListUrl($this->_refer),
                'owner_company' => DICT::OWNER_COMPANY_LIST,
            )
        );
    }

    //快递公司 顺风，中通，申通，韵达
    private function __getExpressCompanyArr() {
        $express_list = DICT::EXPRESS_COMPANY_LIST;
        $express_keys = array_keys($express_list);
        foreach ($express_keys as $i => &$r) {
            $express_arr[] = array('id' => $r, 'text' => $express_list[$r]);
        }
        return $express_arr;
    }

    //快递类型 到付 寄付
    private function __getExpressTypeArr() {
        $express_list = DICT::EXPRESS_TYPE_LIST;
        $express_keys = array_keys($express_list);
        foreach ($express_keys as $i => &$r) {
            $express_arr[] = array('id' => $r, 'text' => $express_list[$r]);
        }
        return $express_arr;
    }

    //获取筛选列表的数据
    protected function _getTicketWhere($cond) {
//        $where = $cond;
        $where = [];
        if ( $cond['confirm_time'][0] ) {
            $where['ticket.confirm_time'][] = ['egt',$cond['confirm_time'][0]];
        }
        if ( $cond['confirm_time'][1] ) {
            $where['ticket.confirm_time'][] = ['elt',$cond['confirm_time'][1]. '23:59:59'];
        }
//        if ( $cond['confirm_time'][0] && $cond['confirm_time'][1]) {
//            $where['confirm_time'] = ['between',$cond['confirm_time']];
//        } else if ( $cond['confirm_time'][0] ) {
//            $where['confirm_time'] = ['egt',$cond['confirm_time'][0]];
//        } else if ($cond['confirm_time'][1]) {
//            $where['confirm_time'] = ['elt',$cond['confirm_time'][1]. '23:59:59'];
//        } else {
//            unset($where['confirm_time']);
//        }

        if ( $cond['ticket_status'] ) {
            $where['ticket.ticket_status'] = $cond['ticket_status'];
        }

        //@todo 增加公司搜索
        $company_name = trim($cond['company_name']);
        if ( $company_name ) {
            /** @var UserService $user_service */
            $user_service = D('Basic/User','Service');
            $user_where = [
                'company_name' => ['like',"%$company_name%"],
            ];
            $users = $user_service->getListBy($user_where);
            if ( $users ) {
                $where['ticket.user_id'] = ['in',array_column($users,'id')];
            } else {
                $where['ticket.user_id'] = -99;
            }
        }
        $username = trim($cond['username']);
        if ( $username ) {
            /** @var UserService $user_service */
            $user_service = D('Basic/User','Service');
            $user_net_account_where['account'] = ['like',"%$username%"];
            $user_net_account_where['net_no'] = ['like', "%$username%"];
            $user_net_account_where['_logic'] = 'OR';
            $user_where['_complex'] = $user_net_account_where;

            $users = $user_service->getListBy($user_where);
            if ( $users ) {
                $where['ticket.user_id'] = ['in',array_column($users,'id')];
            } else {
                $where['ticket.user_id'] = -99;
            }
        }
        $phone = trim($cond['phone']);
        if ( $phone ) {
            /** @var UserService $user_service */
            $user_service = D('Basic/User','Service');
            $user_where['telephone'] = ['eq', $phone];

            $users = $user_service->getListBy($user_where);
            if ( $users ) {
                $where['ticket.user_id'] = ['in',array_column($users,'id')];
            } else {
                $where['ticket.user_id'] = -99;
            }
        }
        if ($cond['ticket_id']) {
            $where['id'] = $cond['ticket_id'];
            unset($where['ticket_id']);
        }
        if ($cond['fee_type']) {
            $where['fee_type'] = $cond['fee_type'];
        }
        if ($cond['owner_company']) {
            $where['owner_company'] = $cond['owner_company'];
        }
        if ($cond['express_type']) {
            $where['express_type'] = $cond['express_type'];
        }
        if ($cond['channel_id']) {
            $where['user.channel_id'] = $cond['channel_id'];
        }
        return $where;
    }
    protected function _getTicketField() {
        $fields = [
            'SQL_CALC_FOUND_ROWS ticket.*',
            'ticket_info.company_name',
            'user.channel_id'
        ];
        return $fields;
    }

    protected function _getTicketJoin() {
        $join = "left join ticket_info on ticket.ticket_info_id = ticket_info.id left join user on ticket.user_id = user.id";
        return $join;
    }

    protected function _getTicketOrder() {
        return 'id desc';
    }

    //编辑,新增发票
//    public function editTicketV2() {
//        $ticket_id = I('ticket_id', 0, 'int');
//        if ( empty($ticket_id) ) {
//            //新增工单类型发票
//            $page_data = $this->_getAddCsTicketPageData();
//            $title = '编辑开票';
//        } else {
//            //
//            $ticket = [];//获取发票信息
//            if ($ticket['ticket_type'] == 1 ) { //@todo 更改成常量
//
//            } else {
//                //判断工单的类型 根据是渠道工单还是用户 工单分开处理
//            }
//            $title = '新增开票';
//        }
//
//        if ( $page_data['errno'] != ERRNO::SUCCESS ) {
//            $this->admin_error($page_data['errmsg']);
//            return;
//        }
//        $this->_assignEnum();
////        dump($page_data['ticket']);
////        die();
//        $this->assignAll(
//            array(
//                'title' => $title,
//                'ticket' => $page_data['ticket'],
//                'mail_info' => $page_data['mail_info'],
//                'ticket_info' => $page_data['ticket_info'],
//                'table_content' => $page_data['table_content'],
//                'log_list' => $page_data['log_list'],
//            )
//        );
//        $this->display('ticket_editv2');
//    }

//    protected function _getAddCsTicketPageData() {
//        $ticket_add_config = TableConfigService::$ticket_edit_config;
//        $table_service = new \Admin\Service\TableService($ticket_add_config);
//        $table_content = $table_service->getTableContent([]);
//        $data = [
//            'errno' => ERRNO::SUCCESS,
//            'errmsg' => ERRNO::e(ERRNO::SUCCESS),
//            'ticket' => [
//                'ticket_id'       => 0,
//                'ticket_status'   => DICT::TICKET_STATUS_PAYED,
//                'fee_type'        => DICT::TECHNICAL_SERVICE,
//                'ticket_amount'   => 0,
//                'create_time'     => datetime(),
//                'confirm_time'    => '',
//                'express_no'      => '',
//                'mail_fee'        => DICT::MAIL_FEE,
//                'username'        => '',
//                'phone'           => '',
//                'express_company' => '',
//                'express_type' => '',
//                'work_no' => '',
//                'invoice_no' => '',
//                'content' => '',
////                'send_info' => '',
//            ],
//            'mail_info' => [
//
//            ],
//            'ticket_info' => [
//
//            ],
//            'table_content' => $table_content,
//            'log_list' => [
//
//            ],
//        ];
//        return $data;
//    }

//    protected function _getEditTickePagetData($ticket_id) {
//        $data = [];
//        return $data;
//    }


    /**
     * 新增开票页面 checked
     */
    public function addIndex() {
        $filters['fee_type'] = DICT::TECHNICAL_SERVICE;// 技术服务费
        $filters['ticket_status'] = DICT::TICKET_STATUS_PAYED;// 已申请
        $filters['owner_company'] = DICT::OWNER_COMPANY_LIST; // 开票公司
        $filters['create_time'] = date("Y-m-d H:i:s");// 创建日期
        $ticket_add_config = TableConfigService::$ticket_edit_config;
        $table_service = new \Admin\Service\TableService($ticket_add_config);
        $table_content = $table_service->getTableContent([]);
        $filters = $table_service->getFilterContent($filters);
//        p($filters);die;
        // 默认选择快递公司和寄送方式
        $ticket = [
            'express_type'  => DICT::EXPRESS_DF,
            'express_company' => DICT::EXPRESS_SF,
        ];

        $this->assignAll(array(
            'title'               => '新增开票',
            'ticket_type'         => 0,
            'filters'             => $filters,
            'table_content'       => $table_content,
            'ticket' => $ticket,
            'rebilling_ticket_arr' => DICT::REBILLING_TICKET_LIST,
            'mail_info' => json_encode(['act' => 'add'], JSON_UNESCAPED_UNICODE),
            'ticket_info' => json_encode(['act' => 'add'], JSON_UNESCAPED_UNICODE),
            'act' => 'add',
        ));
        $this->_assignEnum();
        $this->display('ticket_edit');
    }

    /*
     * 新增编辑(工单)开票
     * ticket_type 0 用户工单开票 2 渠道工单开票
     */
    public function editTicket() {
        $ticket_id = I('ticket_id/d');
        $invoice_no = I('invoice_no');
        $work_no = trim(I('work_no'));
        $mail_id = I('mail_id');
        $ticket_info_id = I('ticket_info_id');
        $content = I('content');
        $phone = I('phone');
        $username = I('username');
        // 查询条件框
        $ticket_edit_config = TableConfigService::$ticket_edit_config;
        $filters_fields = $ticket_edit_config['filter'];
        $cond = $this->prepareSearchCond(array_keys($filters_fields));

        /** @var \Basic\Service\TicketService $ticket_service */
        $ticket_service = D('Basic/Ticket', 'Service');
        $ticket =$ticket_service->getTicketById($ticket_id);
//        p($ticket);die;
        // 获取邮寄信息的地址全称
        /** @var CityService $city_service */
        $city_service = D('Basic/City', 'Service');
        if (!empty($ticket['ext'])) {
            $ticket['ext']['mail_info'][2]['city_full_name'] = $city_service->getAreaFullName($ticket['ext']['mail_info'][2]['district'], $sep = '');
        }

        if ($work_no) {
            $work_no_arr = explode(',', $work_no);
        } else {
            if ( empty($work_no_arr) &&  $ticket_id) {
                $work_no_arr = $ticket['order_ids'];
            } else {
                $work_no_arr = [];
            }
        }
        $cond['create_time'] = $ticket['create_time'] ? : datetime();
        $cond['confirm_time'] = $ticket['confirm_time'] ? substr($ticket['confirm_time'], 0, 10): '';
        $cond['ticket_status'] = $ticket['ticket_status'] ? : DICT::TICKET_STATUS_PAYED;
        $cond['express_no'] = $ticket['express_no'];
        $cond['mail_fee'] = $ticket['mail_fee'] ? : DICT::MAIL_FEE;
        $cond['fee_type'] = $ticket['fee_type'];
        list ( $errno, $errmsg, $ret_data) = $this->_checkAndGetWorkInfo($work_no_arr,$ticket['order_ids']);
//        p($ret_data);die;
        // 处理收款来源
        self::_dopaymentsource($ret_data);
        if ( $errno != ERRNO::SUCCESS ) {
            $this->admin_error($errmsg);
            return;
        }
        $work_list = $ret_data['work_list'];
        $ticket_amount = $ret_data['ticket_amount'];
        $uid = $ret_data['uid'];
        /** @var UserService $user_service */
        $user_service = D('Basic/User', 'Service');
        $user_info = $user_service->getUserInfo($uid);
        // 工单列表
        $cond['ticket_amount'] = $ticket_amount;
        $cond['phone'] = $phone ? : $user_info['telephone'];
        $cond['username'] = $username ? : $user_info['user_name'];
        $account = !empty($user_info['account']) ? $user_info['account'] : '';
        $net_no = !empty($user_info['net_no']) ? $user_info['net_no'] : '';
        $cond['account']= $account.'/'.$net_no;
        $table_service = new \Admin\Service\TableService($ticket_edit_config);
        $table_content = $table_service->getTableContent($work_list);
        $filters = $table_service->getFilterContent($cond);

//        $work_type = 0;
        // 历史记录
        if ( $ticket_id ) {
            $title = '编辑开票';
            $this->_assignTickeLog($ticket_id);
        } else {
            $title = '新增开票';
        }

        if ( $ret_data['ticket_type'] == 0 ) {
            $this->_assignMailTicketInfo($uid);
        } else {
            $this->_assignAgentMailTicketInfo($uid);
        }
        $this->_assignEnum();

        $new_data = [
            'mail_id'=> $mail_id ? : $ticket['mail_id'],
            'ticket_info_id'=> $ticket_info_id ? : $ticket['ticket_info_id'],
            'invoice_no'=> $invoice_no ? : $ticket['invoice_no'],
            'content'=> $content ? : $ticket['content'],
        ];
        $ticket = array_merge($ticket,$new_data);
        if (substr($ticket['mail_time'], 0, 1) == 0) {
            $mail_time = '';
        } else {
            $mail_time = substr($ticket['mail_time'], 0, 10);
        }
        $ticket['confirm_time'] = substr($ticket['confirm_time'], 0, 10);
        $ticket['express_company'] = DICT::EXPRESS_SF;
        $ticket['express_type'] = DICT::EXPRESS_DF;
        $this->assignAll(array(
            'title'            => $title,
            'ticket_id'        => $ticket_id,
            'ticket_type'      => $ret_data['ticket_type'],
            'invoice_no'       => $invoice_no,
            'work_no'          => implode(',',$work_no_arr),
            'ticket' => $ticket,
            'filters'          => $filters,
            'table_content'    => $table_content,
            'mail_time' => $mail_time,
            'ticket_time' => substr($ticket['confirm_time'], 0, 10),
            'uid' => $uid,
            'cs_sheet_style' => 1,
            'rebilling_ticket_arr' => DICT::REBILLING_TICKET_LIST,
            'mail_info' => json_encode($ticket['ext']['mail_info'][2], JSON_UNESCAPED_UNICODE),
            'ticket_info' => json_encode($ticket['ext']['ticket_info'], JSON_UNESCAPED_UNICODE),
        ));
        $this->display('ticket_edit');
    }

    /**
     * 处理收款来源
     * @param $data 工单数据
     */
    private function _dopaymentsource($data) {
        $is_extra_open = 0;
        foreach ( $data['work_list'] as &$v) {
            $v['charging_list'] = json_decode($v['charging'], TRUE);
            foreach ($v['charging_list'] as &$vv) {
                 $vv['source_text'] = CS_WORK_SHEET::WS_CHARGING_ARR[$vv['source']];
                 $vv['amount'] = sprintf("%.2f",$vv['amount']);
            }
            if ($v['finish_day_real'] == substr(datetime(), 0, 10)) {
                $is_extra_open = DICT::RE_NOT;
            } else {
                $is_extra_open = DICT::RE_YES;
            }
        }
        $this->assign('is_extra_open_status', $is_extra_open);
        $this->assign('cs_list', $data['work_list']);
    }


    //编辑运单开票 @todo
    public function editIndex() {
        $ticket_id = (int)I('ticket_id');
        if ( empty($ticket_id) ) {
            $this->admin_error('请选择正确的发票号');
            return;
        }
        /** @var \Basic\Service\TicketService $ticket_service */
        $ticket_service = D('Basic/Ticket', 'Service');
        $ticket =$ticket_service->getTicketById($ticket_id);
        $ext = $ticket['ext'];
        $ticket_info = $ext['ticket_info'];
        $mail_info = $ext['mail_info'];
        $ticket['send_info'] = $mail_info['addr'].' '.$mail_info['user_name'].' '.$mail_info['telephone'];
        $ticket['ticket_info'] = $ticket_info['company_name'].' '.$ticket_info['tax_no'].' '.$ticket_info['credit_no'].' '.$ticket_info['addr'].' '.$ticket_info['open_bank'].' '.$ticket_info['bank_card'];
        $work_no = implode(',',$ticket['order_ids']);
        if ( $ticket['ticket_type'] == 1 ) {
            if ($ticket['order_ids']) {
                $ship_where = [
                    'order_id' => ['in', $ticket['order_ids']],
                ];
            } else {
                $ship_where = [
                    'order_id' => ['in', [-99]],
                ];
            }

            /** @var ShippingOrderService $ship_service */
            $ship_service = D('Basic/ShippingOrder', 'Service');
            $list = $ship_service->getListBy($ship_where);
            foreach ($list as &$r) {
                $r['price_real'] = $r['grab_price'];
                $r['id'] = $r['order_id'];
                $r['type'] = DICT::FEE_TYPE_LIST[$ticket['fee_type']];
            }
            unset($r);
        } else {
            $this->admin_error('非运单发票');
            return;
        }
        $ticket_add_config = TableConfigService::$ticket_edit_config;
        $table_service = new \Admin\Service\TableService($ticket_add_config);
        $table_content = $table_service->getTableContent($list);
        //        $filters['ticket_id'] = $ticket_id;// 开票单号
        $ticket_status = $ticket['ticket_status'];
        $filters['ticket_status'] = $ticket_status;
        $filters['ticket_id'] = $ticket['id'];
        $filters['fee_type'] = $ticket['fee_type'];// 技术服务费
        $filters['ticket_amount'] = $ticket['ticket_amount'];// 技术服务费
        $filters['create_time'] = $ticket['create_time'];
        $filters['confirm_time'] = substr($ticket['confirm_time'], 0, 10);
        $filters['username'] = $ticket['username'] ?: '';// 开票申请人
        $filters['phone'] = $ticket['phone'] ? : '';// 申请人电话
        $filters['express_no'] = $ticket['express_no'];// 快递单号
        $filters['mail_fee'] = $ticket['mail_fee'];// 邮寄费
        $filters = $table_service->getFilterContent($filters);
        $this->_assignMailTicketInfo($ticket['user_id']);
        $this->_assignTickeLog($ticket_id);
//p($ticket);die;
        $this->assignAll(array(
            'title'               => '编辑开票',
//            'ticket_status'       => $ticket_status,
            'ticket_id'           => $ticket_id,
            'ticket_type'         => $ticket['ticket_type'],
//            'invoice_no'          => $ticket['invoice_no'],
            'work_no'             => $work_no,
//            'send_info'           => $ticket['mail_id'],
//            'ticket_info'         => $ticket['ticket_info_id'],
            'filters'             => $filters,
            'mail_time'           => substr($ticket['mail_time'], 0, 10),
            'ticket'               => $ticket,
            'ticket_time'         => substr($ticket['confirm_time'], 0, 10),
            'table_content'       => $table_content,
            'express_company'     => $ticket['express_company'],
            'express_type'        => $ticket['express_type'],
            'act' => 'add',
            'mail_info' => json_encode($ticket['ext']['mail_info'][2], JSON_UNESCAPED_UNICODE),
            'ticket_info' => json_encode($ticket['ext']['ticket_info'], JSON_UNESCAPED_UNICODE),
        ));
        $this->_assignEnum();
        $this->display('ticket_edit');
    }

    protected function _checkAndGetWorkInfo( $work_no_arr ,$except_ids = []) {
//        $work_no_arr = explode(',', $work_no);
        $wk_count = count($work_no_arr);
        $wk_count_unique = count(array_unique($work_no_arr));
        if ( !$wk_count ) {
            return [ERRNO::INPUT_PARAM_ERRNO, '请选中工单号', []];
        }
        if ( $wk_count != $wk_count_unique) {
            return [ERRNO::INPUT_PARAM_ERRNO, '你选择的存在有重复的工单号', []];
        }
        if ( $work_no_arr ) {
            //获取工单列表
            $work_where = [
                'id' => ['in', $work_no_arr],
            ];
        } else {
            //获取工单列表
            $work_where = [
                'id' => ['in', [-99]],
            ];
        }
        /** @var CSWorkSheetModel $cs_work_m */
        $cs_work_m = D('Basic/CSWorkSheet', 'Model');
        $work_list = $cs_work_m->getWsList($work_where);
        $work_list_count = count($work_list);
        if ( !$work_list_count || ($work_list_count != $wk_count) ) {
            return [ERRNO::INPUT_PARAM_ERRNO, '你填写的有无效的工单', []];
        }

        //判断是否都为有效的工单
        $ticket_amount = 0;
        $agent_cs = [];
        $user_cs = [];
        foreach ( $work_list as &$cs_work ) {
            if ( $cs_work['status'] != 'finish' ) {
                return [ERRNO::INPUT_PARAM_ERRNO, '工单'.$cs_work['id'].'的状态不是已完成,请重新填写工单号!', []];
            }
            if ( $cs_work['finance_ticket_id'] != 0 && !in_array($cs_work['id'],$except_ids) ) {
                return [ERRNO::INPUT_PARAM_ERRNO, '工单'.$cs_work['id'].'已开票,请重新填写工单号!', []];
            }
            if ( $cs_work['type'] == 7 ) {
                $agent_cs[] = $cs_work['id'];
            } else {
                $user_cs[] = $cs_work['id'];
            }
            $cs_work['type'] = \Basic\Cnsts\CS_WORK_SHEET::WS_TYPE_ARR[$cs_work['type']];
            $ticket_amount += $cs_work['price_real'];
        }
        if ( $agent_cs && $user_cs ) {
            return [ERRNO::INPUT_PARAM_ERRNO, '工单'.implode(',',$agent_cs).'是渠道工单,'.implode(',',$user_cs)
                .'是用户工单,请重新填写同类型的工单!',
            []];
        }
        $ticket_type = $user_cs ? 0 : 2;

        //判断工单是否同属一个人
        if ( $ticket_type == 0 ) {
            $uids = array_column($work_list, 'uid'); //用户工单
        } else {
            $uids = array_column($work_list, 'agent_id'); //渠道工单
        }
        $uid_unique_count = array_unique($uids);
        if ( count($uid_unique_count) != 1) {
            return [ERRNO::INPUT_PARAM_ERRNO, '你填写工单不同属一个用户', []];
        }
        $uid = $uids[0];
        $ret_data = [
            'uid' => $uid,
            'work_list' => $work_list,
            'ticket_amount' => $ticket_amount,
            'work_no_arr' => $work_no_arr,
            'ticket_type' => $ticket_type,
        ];
        return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), $ret_data];
    }

    protected function _assignTickeLog($ticket_id) {
        $ticket_log_list = [];
        /** @var TicketModel $ticket_m */
        $ticket_m = D('Admin/Ticket', 'Model');
        if ($ticket_id) {
            $ticket_log_list = $ticket_m->searchTicketLog($ticket_id);
            foreach ($ticket_log_list as $i => &$r) {
                $remark = $r['remark'];
                if (!$remark) {
                    $remark = '无';
                }
                $r['info'] = $r['create_time'].' 【'.$r['op_content'].'】 操作人：'.$r['op_user'].' 备注：'.$remark;
            }
        }
        $num = count($ticket_log_list);
        $this->assign('log_list', $ticket_log_list);
        $this->assign('num', $num);
    }

    // 用户开票信息,邮寄信息
    protected function _assignMailTicketInfo($uid) {
        /** @var MailInfoModel $mail_info_m */
        $mail_info_m = D('Admin/MailInfo','Model');
        $mail_where = [
            'user_id' => $uid,
            'status' => 1,
        ];
        $send_info_arr = $mail_info_m->getMailList($mail_where);
        foreach ($send_info_arr as $i => &$r) {
            $r['text'] = $r['addr'].' '.$r['user_name'].' '.$r['telephone'];
        }
        $send_info_arr = array_merge([['id' => 0,'text' => '请选择']], $send_info_arr);

        /** @var TicketInfoService $ticket_info_service */
        $ticket_info_service = D('Basic/TicketInfo', 'Service');
        $ticket_info_where = [
            'user_id' => $uid,
            'status' => 1,
        ];
        $ticket_info_arr = $ticket_info_service->getTicketList($ticket_info_where);

        foreach ($ticket_info_arr as $i => &$r) {
            $r['text'] = $r['company_name'].' '.$r['tax_no'].' '.$r['credit_no'].' '.$r['addr'].' '.$r['open_bank'].' '.$r['bank_card'];
        }
        $ticket_info_arr = array_merge([['id' => 0,'text' => '请选择']], $ticket_info_arr);
        $this->assign(array(
            'send_info_arr'    => $send_info_arr,
            'ticket_info_arr'  => $ticket_info_arr,
        ));
    }

    //assign 渠道发票邮寄信息
    protected function _assignAgentMailTicketInfo($agent_id) {
        $mail_where = [
            'agent_id' => $agent_id,
            'status' => 1,
        ];
        /** @var AddressService $mail_service */
        $mail_service = D('Basic/Address', 'Service');
        $send_info_arr = $mail_service->getListByCond($mail_where,[],['is_default desc,id desc']);
        foreach ($send_info_arr as $i => &$r) {
            $r['text'] = $r['addr'].' '.$r['user_name'].' '.$r['telephone'];
        }

        $ticket_info_where = [
            'agent_id' => $agent_id,
        ];
        /** @var AgentInvoiceModel $agent_invoice_m */
        $agent_invoice_m = D('Basic/AgentInvoice','Model');
        $ticket_info_arr = $agent_invoice_m->getInvoiceList($ticket_info_where);
        $send_info_arr = array_merge([['id' => 0,'text' => '请选择']], $send_info_arr);

        foreach ($ticket_info_arr as $i => &$r) {
            $r['text'] = $r['company_name'].' '.$r['taxer_no'].' '.$r['credit_no'].' '.$r['address'].' '.$r['bank_name'].' '.$r['bank_passport'];
        }

        $ticket_info_arr = array_merge([['id' => 0,'text' => '请选择']], $ticket_info_arr);
        $this->assign(array(
            'send_info_arr'    => $send_info_arr,
            'ticket_info_arr'  => $ticket_info_arr,
        ));
    }

    /**
     * 动态读取发票信息api接口
     * @param $tid 发票信息的id（ticket_info表id）
     * @param $uid 用户id
     */
    public function ajaxGetInfo($tid, $uid) {
        /** @var MailInfoModel $mail_info_m */
        $mail_info_m = D('Admin/MailInfo','Model');
        $mail_where = [
            'user_id' => $tid,
            'status' => 1,
        ];
        $send_info_arr = $mail_info_m->getMailList($mail_where);
        foreach ($send_info_arr as $i => &$r) {
            $r['text'] = $r['addr'].' '.$r['user_name'].' '.$r['telephone'];
        }
        $send_info_arr = array_merge([['id' => 0,'text' => '请选择']], $send_info_arr);

        /** @var TicketInfoService $ticket_info_service */
        $ticket_info_service = D('Basic/TicketInfo', 'Service');
        $ticket_info_where = [
            'user_id' => $tid,
            'status' => 1,
        ];
        $ticket_info_arr = $ticket_info_service->getTicketList($ticket_info_where);

        foreach ($ticket_info_arr as $i => &$r) {
            $r['text'] = $r['company_name'].' '.$r['tax_no'].' '.$r['credit_no'].' '.$r['addr'].' '.$r['open_bank'].' '.$r['bank_card'];
        }
        $ticket_info_arr = array_merge([['id' => 0,'text' => '请选择']], $ticket_info_arr);

        $ticket_info = [];
        for ($i=0; $i<count($ticket_info_arr); $i++) {
            if ($ticket_info_arr[$i]['id'] == $uid) {
                $ticket_info = $ticket_info_arr[$i];
            }
        }

        $this->doResponse(0, '成功', $ticket_info);
    }

    /**
     * 动态获取邮寄信息api
     * @param $uid 用户id
     * @param $mid 邮寄信息id
     */
    public function ajaxGetMailInfo($uid, $mid) {
        /** @var MailInfoModel $mail_info_m */
        $mail_info_m = D('Admin/MailInfo','Model');
        $mail_where = [
            'user_id' => $uid,
            'status' => 1,
        ];
        $send_info_arr = $mail_info_m->getMailList($mail_where);

        /** @var CityService $city_service */
        $city_service = D('Basic/City', 'Service');
        foreach ($send_info_arr as $i => &$r) {
            $r['text'] = $r['addr'].' '.$r['user_name'].' '.$r['telephone'];
            $name = $city_service->getAreaFullName($r['district'], $sep = '');
            if (!empty($name)) {
                $r['city_full_name'] = $name;
            } else {
                $r['city_full_name'] = '';
            }
        }
        $send_info_arr = array_merge([['id' => 0,'text' => '请选择']], $send_info_arr);

        $mail_info = [];
        for ($i=0; $i<count($send_info_arr); $i++) {
            if ($send_info_arr[$i]['id'] == $mid) {
                $mail_info = $send_info_arr[$i];
            }
        }
        $this->doResponse(0, '成功', $mail_info);
    }

    public function saveTicketV2() {
        $data = $_GET;
        $data['order_ids'] = explode(',', $data['work_no']);
        $ticket_id = I('ticket_id');
        //@todo 工单完成同步
        // 确定该发票是否是补开发票
        if ( strlen(current($data['order_ids']))<18 ) {
            $data = $this->_setaddticketType($data);
        }

        if ( $ticket_id ) {
            $this->_saveTicket($data);
        } else {
            //新增发票
            $this->_addTicket($data);
        }

    }

    /**
     * 确定是否补发开票
     * @param $data 带转换数据
     *
     * @return mixed 转换后数据
     */
    private function _setaddticketType($data) {
        /** @var CSWorkSheetService $cs_work_service */
        $cs_work_service = D('Basic/CSWorkSheet','Service');
        $work_sheet_info = $cs_work_service->getWorkSheetInfo($data['work_no']);
        if ($work_sheet_info['finish_day_real'] != substr(datetime(), 0, 10)) {
            $data['is_extra_open'] = DICT::RE_YES;
        } else {
            $data['is_extra_open'] = DICT::RE_NOT;
        }
        return $data;
    }

    protected function _saveTicket($data) {
        /** @var TicketModel $ticket_m */
        $ticket_m = D('Admin/Ticket', 'Model');
        $ticket = $ticket_m->getTicketById($data['ticket_id']);
        $up_data = $this->_getUpTicketData($data,$ticket);
        switch($data['ticket_type']) {
            case 0 :
            case 2 :
                $new_add_cs = [];
                $del_cs = [];
                break;
            case 1 :
                $new_add_cs = [];
                $del_cs = [];
                break;
            default :
                $new_add_cs = [];
                $del_cs = [];
                break;
        }
        //更新ticket 内容
        $format_up_data = $this->_formatUpdata($up_data);
        $up_res = $ticket_m->upTicketById($data['ticket_id'], $format_up_data);
        if ( $up_res == false ) {
            $this->admin_error('更新发票信息失败');
            return;
        }
        /** @var CSWorkSheetModel $cs_work_m */
        $cs_work_m = D('Basic/CSWorkSheet', 'Model');
        if ($new_add_cs) {
            $add_cs_where = [
                'id' => ['in', $new_add_cs],
            ];
            $add_cs_data = [
                'finance_ticket_id' => $data['ticket_id'],
            ];
            $new_add_res = $cs_work_m->updateWorkByWhere($add_cs_where, $add_cs_data);
        }
        if ($del_cs) {
            $del_cs_where = [
                'id' => ['in', $del_cs],
            ];
            $del_cs_data = [
                'finance_ticket_id' => 0,
            ];
            $del_cs_res = $cs_work_m->updateWorkByWhere($del_cs_where, $del_cs_data);
        }
        $remark = '';
        $check_change_f = [
            'ticket_amount' => '发票金额',
//            'mail_fee' => '邮寄费用',
            'username' => '联系人',
            'phone' => '联系电话',
            'express_company' => '快递公司',
            'express_type' => '付费类型',
            'invoice_no' => '发票号',
            'mail_id' => '邮寄信息',
            'ticket_info_id' => '发票信息',
            'content' => '备注',
        ];
        foreach ($check_change_f as $f => $t ) {
            if ( $up_data[$f] != $ticket[$f]) {
                $remark .= $t.'、';
            }
        }
        if (number_format($up_data['mail_fee'],2) != number_format($ticket['mail_fee'],2)) {
            $remark .= '邮寄费用';
        }
        if ( $remark ) {
            $remark  = '修改内容:'.$remark;
        }
        //@todo 工单更新工单的信息
        $this->__saveTicketLog($data['ticket_id'],$format_up_data['ticket_status'],$remark);
        //记录日志
        if ( $up_data['ticket_status'] == DICT::TICKET_STATUS_PAYED ) {
            $this->admin_success('保存成功','/Ticket/index');
        } else {
            $this->admin_success('保存成功');
        }
    }

    //获取发票更新的数据
    protected function _getUpTicketData($data, $ticket) {
        $up_data = [
            'ticket_amount' => $data['ticket_amount'],
            'express_no' => $data['express_no'],
            'username' => $data['username'],
            'mail_fee' => $data['mail_fee'],
            'phone' => $data['phone'],
            'express_company' => $data['express_company'],
            'express_type' => $data['express_type'],
            'invoice_no' => $data['invoice_no'],
            'mail_id' => $data['mail_id'],
            'ticket_info_id' => $data['ticket_info_id'],
            'content' => $data['content'],
            'ticket_status' => $ticket['ticket_status'],
            'order_ids' => $data['order_ids'],
            'mail_time' => $data['send_time'],
            'confirm_time' => $data['confirm_time'],
            'update_time' => datetime(),
        ];
        $this->_fmtTicketStatus($up_data, $ticket);
        $ext = json_decode($ticket['ext'],JSON_UNESCAPED_UNICODE);
        if ( $data['mail_id'] != $ticket['mail_id']) {
            /** @var MailInfoService $mail_info_service */
            $mail_info_service = D('Basic/MailInfo', 'Service');
            list($errno,$errmsg,$ext['mail_info']) = $mail_info_service->getMailInfoById($data['mail_id']);
        }
        switch( $data['ticket_type'] ) {
            case 0 :
            case 1 :
                if ( $data['ticket_info_id'] != $ticket['ticket_info_id']) {
                    /** @var TicketInfoService $ticket_info_service */
                    $ticket_info_service = D('Basic/TicketInfo', 'Service');
                    $ext['ticket_info'] = $ticket_info_service->getTicketInfoById($ticket['ticket_info_id']);
                }
                break;
            case 2 :
                /** @var AgentInvoiceModel $agent_invoice */
                $agent_invoice = D('Basic/AgentInvoice', 'Model');
                if ( $data['ticket_info_id'] != $ticket['ticket_info_id']) {
                    $ext['ticket_info'] = $agent_invoice->getInvoiceById($ticket['ticket_info_id']);
                }
                break;
            default :
                break;
        }

        if ( $data['ticket_type'] == 0 || $data['ticket_type'] == 2 ) {
            $except_ids = $ticket['order_ids'] ? json_decode($ticket['order_ids'],JSON_UNESCAPED_UNICODE) : [];
            list($errno ,$errmsg, $ret_data) = $this->_checkAndGetWorkInfo($data['order_ids'],$except_ids);
            if ( $errno != ERRNO::SUCCESS ) {
                $this->admin_error($errmsg);
                exit();
            }
        }
        $up_data['ext'] = $ext;
        return $up_data;
    }

    //转换发票状态和更新时间
    protected function _fmtTicketStatus(&$up_data, $ticket) {

        if ( ($ticket['ticket_status'] == DICT::TICKET_STATUS_PAYED || $ticket['ticket_status'] ==
            DICT::TICKET_STATUS_OPENED ) && $up_data['invoice_no'] ) {
            $up_data['ticket_status'] = DICT::TICKET_STATUS_OPENED;
            $up_data['confirm_time'] = $up_data['confirm_time'];
        }
        if ( $up_data['express_no'] && $up_data['express_company'] && $up_data['mail_id'] && $up_data['ticket_info_id'] &&
            $ticket['ticket_status'] == DICT::TICKET_STATUS_OPENED ) {
            $up_data['ticket_status'] = DICT::TICKET_STATUS_MAILING;
            $up_data['mail_time'] = $up_data['mail_time'];
        }
    }

    protected function _formatUpdata($up_data) {
        $format_updata = $up_data;
        $format_updata['ext'] = json_encode($up_data['ext'], JSON_UNESCAPED_UNICODE);
        $format_updata['order_ids'] = json_encode($up_data['order_ids'],JSON_UNESCAPED_UNICODE);
        return $format_updata;
    }

    protected function _addTicket($data) {
        $add_data = $this->_getAddTicketData($data);
        /** @var TicketModel $ticket_m */
        $ticket_m = D('Admin/Ticket', 'Model');
        $ticket_id = $ticket_m->addTicket($add_data);
        if ( !$ticket_id ) {
            $this->admin_error('添加发票信息失败');
            return;
        }
//        $work_no_arr = $work_no_arr = explode(',', $data['work_no']);
        $up_work_where = [
            'id' => ['in', $data['order_ids']],
        ];
        $up_work_data = [
            'finance_ticket_id' => $ticket_id,
        ];
        /** @var CSWorkSheetModel $cs_work_m */
        $cs_work_m = D('Basic/CSWorkSheet', 'Model');
        //2.更新工单表
        $cs_up_res = $cs_work_m->updateWorkByWhere($up_work_where, $up_work_data);
        if ( $cs_up_res != false ) {
            //3.记录添加日志
            $this->__saveTicketLog($ticket_id, $add_data['ticket_status'], $data['content']);
            if ( $add_data['ticket_status'] == DICT::TICKET_STATUS_PAYED ) {
                $this->admin_success('保存成功','/Ticket/index');
            } else {
                $this->admin_success('保存成功');
            }
        } else {
            $this->admin_error('保存失败');
        }
        return;
    }

    protected function _getAddTicketData( $data ) {
        list($errno ,$errmsg, $ret_data) = $this->_checkAndGetWorkInfo($data['order_ids']);
        if ( $errno != ERRNO::SUCCESS ) {
            $this->admin_error($errmsg);
            exit();
        }
        if ( $data['ticket_type'] != $data['ticket_type'] ) {
            //@todo 报错
        }

        $uid  = $ret_data['uid'];
        /** @var MailInfoService $mail_info_service */
        $mail_info_service = D('Basic/MailInfo', 'Service');
        list($err,$msg,$mail_info) = $mail_info_service->getMailInfoById($data['mail_id']);
        if ( $data['ticket_type'] == 2 ) {
            //渠道的信息
        } else {
            //用户的信息
            /** @var TicketInfoService $ticket_info_service */
            $ticket_info_service = D('Basic/TicketInfo', 'Service');
            $ticket_info = $ticket_info_service->getTicketInfoById($data['ticket_info_id']);
        }
        /** @var TicketService $ticket_service */
        $ticket_service = D('Admin/Ticket', 'Service');
        $fee_type_list = $ticket_service->getCsWorkFormatTicketFee($data['ticket_amount']);
        $ext = [
            'mail_info' => $mail_info,
            'ticket_info' => $ticket_info,
            'fee_type_list' => $fee_type_list,
        ];

        $ticket_status = $this->_getAddTicketStatus($data);
        $confirm_time = $this->_getAddTicketConTime($data);
        $add_data = [
            'user_id' => $uid,
            'ticket_status' => $ticket_status,
            'fee_type' => \Basic\Cnsts\DICT::TECHNICAL_SERVICE,
            'ticket_amount' => $data['ticket_amount'], //@todo 重新计算
            'create_time' => $data['create_time'],
            'confirm_time' => $confirm_time,
            'mail_fee' => \Basic\Cnsts\DICT::MAIL_FEE,
            'username' => $data['username'],
            'phone' => $data['phone'],
            'order_ids' => json_encode($data['order_ids'],JSON_UNESCAPED_UNICODE),
            'ticket_type' => 0,
            'invoice_no' => $data['invoice_no'] ? : '',
            'mail_id' => $data['mail_id'] ? : 0,
            'ticket_info_id' => $data['ticket_info_id'] ? : 0,
            'ext' => json_encode($ext, JSON_UNESCAPED_UNICODE),
            'content' => $data['content'],
            'express_company' => $data['express_company'],
            'express_type' => $data['express_type'],
            'owner_company' => $data['owner_company'],
            'is_extra_open' => $data['is_extra_open_status'],
        ];
        return $add_data;
    }

    protected function _getAddTicketStatus( $data ) {
        $ticket_status = DICT::TICKET_STATUS_PAYED;
        if ( $data['invoice_no']) {
            $ticket_status = DICT::TICKET_STATUS_OPENED;
        }
        return $ticket_status;
    }

    //
    protected function _getAddTicketConTime( $data, $old_invoice_no = '') {
        $confirm_time = null;
        if ( $old_invoice_no ) {
            $confirm_time = ($old_invoice_no != $data['invoice_no']) ? datetime() : $data['confirm_time'];
        } else if ($data['invoice_no']) {
            $confirm_time = datetime();
        } else {

        }
        return $confirm_time;
    }
//    /**
//     * 保存开票
//     */
//    public function saveTicket() {
//        $ticket_id = I('ticket_id');
//        $work_no = I('work_no');
//        $mail_id = I('send_info');
//        $ticket_info_id = I('ticket_info');
//        $invoice_no = I('invoice_no');
//        $express_company = I('express_company');
//        $express_type = I('express_type');
//        $ticket_edit_config = TableConfigService::$ticket_edit_config;
//        $filters_fields = $ticket_edit_config['filter'];
//        $cond = $this->prepareSearchCond(array_keys($filters_fields));
//        /** @var TicketModel $ticket_m */
//        $cond['content'] = I('content');
//        $ticket_m = D('Admin/Ticket', 'Model');
//        if ( $ticket_id ) {
//            $ticket = $ticket_m->getTicketById($ticket_id);
//            $ticket['ticket_id'] = $ticket['id'];
//        }
//
//        $cond['invoice_no'] = $invoice_no;
//        if ($ticket['ticket_status'] == DICT::TICKET_STATUS_PAYED  &&  $cond['invoice_no'] ) {
//            $cond['ticket_status'] = DICT::TICKET_STATUS_OPENED;
//            if ($ticket['invoice_no'] != $cond['invoice_no']) {
//                $cond['confirm_time'] = datetime();
//            }
//        } else if ( $cond['invoice_no'] ) {
//            $cond['confirm_time'] = datetime();
//        }
//        if ( $cond['express_no'] && $cond['express_company'] && $cond['mail_id'] && $cond['ticket_info_id'] &&
//            $ticket['ticket_status'] == DICT::TICKET_STATUS_OPENED) {
//            $cond['ticket_status'] = DICT::TICKET_STATUS_MAILING;
//        }
//
//        $ticket_type = $ticket['ticket_type'] ? : 0;//默认是工单
//        if ( $ticket_type == 0 || $ticket_type == 2 ) {
//            $except_ids = $ticket['order_ids'] ? json_decode($ticket['order_ids'],JSON_UNESCAPED_UNICODE) : [];
//
//            list($errno ,$errmsg, $ret_data) = $this->_checkAndGetWorkInfo($work_no,$except_ids);
//            if ( $errno != ERRNO::SUCCESS ) {
//                $this->admin_error($errmsg);
//                return;
//            }
//            if (empty($ticket['ticket_status']) && empty($cond['ticket_status'])) {
//                $cond['ticket_status'] = DICT::TICKET_STATUS_PAYED;
//            }
//            $cond['order_ids'] = json_encode($ret_data['work_no_arr'], JSON_UNESCAPED_UNICODE);
//            $cond['user_id'] = $ret_data['uid'];
//        } else if ( $ticket_type == 1 ) {
//            //运单不改变状态
//        }
//        $cond['ticket_info_id'] = $ticket_info_id;
//        $cond['mail_id'] = $mail_id;
//
//        /** @var TicketService $ticket_service */
//        $ticket_service = D('Admin/Ticket', 'Service');
//
//        /** @var MailInfoService $mail_info_service */
//        $mail_info_service = D('Basic/MailInfo', 'Service');
//        $mail_info = $mail_info_service->getMailInfoById($mail_id);
//        /** @var TicketInfoService $ticket_info_service */
//        $ticket_info_service = D('Basic/TicketInfo', 'Service');
//        $ticket_info = $ticket_info_service->getTicketInfoById($ticket_info_id);
//        if ( $ticket_id ) {
//            $ext = json_decode($ticket['ext'],JSON_UNESCAPED_UNICODE);
//            $ext['mail_info'] = $mail_info;
//            $ext['ticket_info'] = $ticket_info;
//            if ( $ticket_info['ticket_type'] == 0 ) {
//                $ext['fee_type_list'] = $ticket_service->getCsWorkFormatTicketFee($cond['ticket_amount']);
//            }
//        } else {
//            $fee_type_list = $ticket_service->getCsWorkFormatTicketFee($cond['ticket_amount']);
//            $ext = [
//                'mail_info' => $mail_info,
//                'ticket_info' => $ticket_info,
//                'fee_type_list' => $fee_type_list,
//            ];
//        }
//        $cond['ext'] = json_encode($ext,JSON_UNESCAPED_UNICODE);
//        if ( $ticket_id ) {
//            $cond['express_company'] = $express_company;
//            $cond['express_type'] = $express_type;
//            $ticket_where['id'] = $ticket_id;
//            $ticket_m->upTicketById($ticket_id, $cond);
//            $remark = '';
//            foreach ( $ticket_edit_config['filter'] as $field => $value ) {
//                if ($cond[$field] != $ticket[$field]) {
//                    $remark .= $value['title'].',';
//                }
//            }
//
//            if ( $remark ) {
//                $remark = '修改内容'.$remark;
//            }
//        } else {
//            //新增
//            $cond['manager_id'] = $this->_manager_id;
//            $remark = '新增开票';
//            $ticket_id = $ticket_m->addTicket($cond);
//        }
//        $work_no_arr = $ret_data['work_no_arr'];
//        $up_work_where = [
//            'id' => ['in', $work_no_arr],
//        ];
//        $up_work_data = [
//            'finance_ticket_id' => $ticket_id,
//        ];
//        /** @var CSWorkSheetModel $cs_work_m */
//        $cs_work_m = D('Basic/CSWorkSheet', 'Model');
//        $cs_up_res = $cs_work_m->updateWorkByWhere($up_work_where, $up_work_data);
//        if ( $cs_up_res !== false ) {
//            $this->__saveTicketLog($ticket_id, $cond['ticket_status'], $remark);
//            if ( $ticket['ticket_status'] == DICT::TICKET_STATUS_PAYED || $cond['ticket_status'] ==
//                DICT::TICKET_STATUS_PAYED ) {
//                $this->admin_success('保存成功','/Ticket/index');
//            } else {
//                $this->admin_success('保存成功');
//            }
//        } else {
//            $this->admin_error('保存失败');
//        }
//    }

    /**
     * 取消开票
     */
    public function cancelTicket() {

        $ticket_id = I('ticket_id');
        $cancel_reason = I('cancel_reason');
        if ( empty($ticket_id) ) {
            $this->admin_error('请选择开票号');
            return;
        }
        if ( empty($cancel_reason) ) {
            $this->admin_error('请输入取消原因');
            return;
        }

        $this->_ticketOp($ticket_id, DICT::TICKET_STATUS_CANCEL);
    }

    /**
     * 开票
     */
    public function billing() {
        // 取值
        $id = (int)I('ticket_id');
        $ticket_status = (int)I('ticket_status');
        $invoice_no = I('invoice_no');
        if (!$invoice_no) {
            $this->admin_error('发票号不能为空!');
            return;
        }

        /** @var TicketService $ticket_service */
        $ticket_service = D('Admin/Ticket', 'Service');
        $ticket = $ticket_service->getTicketById($id);

        $up_data = [
            'invoice_no' => $invoice_no,
//            'confirm_time' => date("Y-m-d H:i:s"),
            'confirm_time' => I('billing_time'),
            'ticket_status' => DICT::TICKET_STATUS_OPENED,
        ];
        if ( $ticket['ticket_status'] != DICT::TICKET_STATUS_PAYED) {
            $this->admin_error('当前状态不支持开票!');
            return;
        }
        list($errno, $errmsg,$up_res) = $ticket_service->upTicketById($id, $up_data);
        if ($errno == 0) {
            //记录操作日志
            $this->__saveTicketLog($id, $ticket_status, '');
            $this->admin_success('操作成功!');
        } else {
            $this->admin_error('操作失败!');
        }
    }

    /**
     * 重新开票
     */
    public function restBilling() {
        $ticket_id = I('ticket_id');
        $remark = I('cancel_reason');
        if ( empty($ticket_id) ) {
            $this->admin_error('请选择开票号');
            return;
        }

        if ( empty($remark) ) {
            $this->admin_error('请填写重新开票原因');
            return;
        }
        $this->_ticketOp($ticket_id, DICT::TICKET_STATUS_AGAIN);
        return;
    }

    protected function _ticketOp($ticket_id, $ticket_status) {
        $close_reason = I('close_reason');
        $cancel_reason = I('cancel_reason');
        /** @var \Basic\Service\TicketService $ticket_service */
        $ticket_service = D('Basic/Ticket', 'Service');
        $ticket = $ticket_service->getTicketById($ticket_id);
        $order_ids = $ticket['order_ids'];
        /** @var \Basic\Service\TicketService $ticket_service */
        $ticket_service = D('Basic/Ticket','Service');
        $up_ticket_data = [
            'ticket_status' => $ticket_status,
            'mender' => $this->_manager_id,
        ];
        if ($cancel_reason) {
            $up_ticket_data['content'] = $cancel_reason;
        }
        list($errno, $errmsg, $up_res) = $ticket_service->upTicketById($ticket_id,$up_ticket_data);
        if ( $errno != ERRNO::SUCCESS) {
            $this->admin_error($errmsg);
            return;
        }
        if ( $ticket['ticket_type']== 0 ) {
            //把所有的工单号更改成未开票
            $up_cs_data = [
                'finance_ticket_id' => 0
            ];
            $up_cs_where = [
                'id' => ['in',$order_ids]
            ];
            /** @var CSWorkSheetModel $cs_work_m */
            $cs_work_m = D('Basic/CSWorkSheet', 'Model');
            $up_link_res = $cs_work_m->updateWorkByWhere($up_cs_where,$up_cs_data);

        } else if ( $ticket['ticket_type'] == 1 ) {
            //把所有的运单的开票状态标记为未开票
            $up_order_data = [
                'ticket_id' => 0
            ];
            $up_order_where = [
                'order_id' => ['in',$order_ids]
            ];
            /** @var ShippingOrderService $ship_service */
            $ship_service = D('Basic/ShippingOrder', 'Service');
            $up_link_res = $ship_service->upShipByWhere($up_order_where,$up_order_data);
        } else {
            $this->admin_error('你选择的发票号不合法');
            return;
        }
        /** @var SendNoticeService $send_notice_service */
        $send_notice_service = D('Basic/SendNotice', 'Service');
        $ticket['ticket_cancel_reason'] = $close_reason ? $close_reason : '系统管理员操作';
        $send_notice_service->addNotice($ticket['user_id'],\Basic\Cnsts\NOTICE::NOTICE_TYPE_TICKET_CANCEL,
            $ticket);
        $this->__saveTicketLog($ticket['ticket_id'],$up_ticket_data['ticket_status'],'重新开票原因：'.$cancel_reason);
        $this->admin_success('成功');
    }
    /**
     * 寄送
     */
    public function sendTicket() {
        // 取值
        $ticket_id = (int)I('ticket_id');
        $ticket_status = (int)I('ticket_status');
        $express_company = I('express_company');
        $express_type = I('express_type');
        $express_no = I('express_no');
        if (!$express_no) {
            $this->admin_error('快递单号不能为空!');
            return;
        }
        // 更新状态 邮寄状态
        $up_data = [
            'express_company' => $express_company,
            'express_type' => $express_type,
            'express_no' => $express_no,
            'mail_time' => I('send_time'),
            'ticket_status' => DICT::TICKET_STATUS_MAILING,
        ];
        /** @var \Basic\Service\TicketService $ticket_service */
        $ticket_service = D('Basic/Ticket','Service');
        $ticket = $ticket_service->getTicketById($ticket_id);
        list($errno, $errmsg, $up_res ) = $ticket_service->upTicketById($ticket_id,$up_data);

        // 保存流水
        if ( $errno == ERRNO::SUCCESS ) {
            $this->__saveTicketLog($ticket_id, $ticket_status, '');
            /** @var SendNoticeService $send_notice_service */
            $send_notice_service = D('Basic/SendNotice', 'Service');
            $ticket['ticket_status_desc'] = '已邮寄';
            $send_notice_service->addNotice($ticket['user_id'],\Basic\Cnsts\NOTICE::NOTICE_TYPE_TICKET_STATUS_CHANGE,
                $ticket);
            $this->admin_success('操作成功!');
        } else {
            $this->admin_error($errmsg);
        }
    }

    public function completeTicket() {
        // 取值
        $id = (int)I('ticket_id');
        $ticket_status = (int)I('ticket_status');

        /** @var TicketService $ticket_service */
        $ticket_service = D('Admin/Ticket', 'Service');
        $ticket = $ticket_service->getTicketById($id);

        $up_data = [
            'complete_time' => date("Y-m-d H:i:s"),
            'ticket_status' => DICT::TICKET_STATUS_COMPLETE,
        ];
        if ( $ticket['ticket_status'] != DICT::TICKET_STATUS_MAILING) {
            $this->admin_error('当前状态不支持开票!');
            return;
        }
        list($errno, $errmsg,$up_res) = $ticket_service->upTicketById($id, $up_data);
        if ($errno == 0) {
            //记录操作日志
            $this->__saveTicketLog($id, $ticket_status,'');
            $this->admin_success('操作成功!');
        } else {
            $this->admin_error('操作失败!');
        }
    }


    /**
     * 开票详情
     */
    public function ticketInfo($id) {
        $ticket_id = $id;
        if (!$id) {
            $id = (int)I('ticket_id');
        }
        /** @var \Basic\Service\TicketService $ticket_service */
        $ticket_service = D('Basic/Ticket', 'Service');
        $ticket =$ticket_service->getTicketById($ticket_id);


        $ticket['work_no'] = implode(',',$ticket['order_ids']);
        $ticket_type = 0;
        if ( $ticket['ticket_type'] == 1 ) {
            $ticket_type = 1;
            if ($ticket['order_ids']) {
                $ship_where = [
                    'order_id' => ['in', $ticket['order_ids']],
                ];
            } else {
                $ship_where = [
                    'order_id' => -99,
                ];
            }

            /** @var ShippingOrderService $ship_service */
            $ship_service = D('Basic/ShippingOrder', 'Service');
            $list = $ship_service->getListBy($ship_where);
            foreach ($list as &$r) {
                $r['price_real'] = $r['grab_price'];
                $r['id'] = $r['order_id'];
                $r['type'] = DICT::FEE_TYPE_LIST[$ticket['fee_type']];
            }

        } else {
            if ( $ticket['order_ids'] ) {
                $work_where = [
                    'id' => ['in', $ticket['order_ids']],
                ];
            } else {
                $work_where = [
                    'id' => -99,
                ];
            }
            /** @var CSWorkSheetModel $cs_work_m */
            $cs_work_m = D('Basic/CSWorkSheet', 'Model');
            $list = $cs_work_m->getWsList($work_where);
            $cs_type = $list[0]['type'];
            if ( $cs_type == 7 ) {
                $ticket_type = 2;
            } else {
                $ticket_type = 0;
            }
            foreach($list as &$v) {
                $v['type'] = \Basic\Cnsts\CS_WORK_SHEET::WS_TYPE_ARR[$v['type']];
            }
        }
        $ext = $ticket['ext'];
        $ticket_info = $ext['ticket_info'];
        $mail_info = $ext['mail_info'];
        $ticket['send_info'] = $mail_info['addr'].' '.$mail_info['user_name'].' '.$mail_info['telephone'];
        if ( $ticket_type == 0 ) { //工单开票
            $ticket['ticket_info'] = $ticket_info['company_name'].' '.$ticket_info['tax_no'].' '.$ticket_info['credit_no'].' '.$ticket_info['addr'].' '.$ticket_info['open_bank'].' '.$ticket_info['bank_card'];
        } else if ( $ticket_type == 1 ) {
            $ticket['ticket_info'] = $ticket_info['company_name'].' '.$ticket_info['tax_no'].' '.$ticket_info['credit_no'].' '.$ticket_info['addr'].' '.$ticket_info['open_bank'].' '.$ticket_info['bank_card'];
        } else {
            $ticket['ticket_info'] = $ticket_info['company'].' '.$ticket_info['taxer_no'].' '.$ticket_info['credit_no'].' '.$ticket_info['address'].' '.$ticket_info['bank_name'].' '.$ticket_info['bank_passport'];
        }

        $ticket['ticket_id'] = $ticket['id'];
        $ticket_add_config = TableConfigService::$ticket_edit_config;
        $table_service = new \Admin\Service\TableService($ticket_add_config);
        $table_content = $table_service->getTableContent($list);
        $filters = $table_service->getFilterContent($ticket);

        $this->assignAll(array(
            'title'               => '开票详情',
            'ticket'              => $ticket,
            'filters'             => $filters,
            'table_content'       => $table_content,
            'express_company'     => $ticket['express_company'],
            'express_type'        => $ticket['express_type'],
            'express_type_arr'    => $this->__getExpressTypeArr(),
            'express_company_arr' => $this->__getExpressCompanyArr(),
            'back_to_list_url'    => $this->_backToListUrl($this->_refer),
        ));
        $this->_assignTickeLog($ticket_id);
        $this->display('ticket_info');
    }

    private function __saveTicketLog($id, $ticket_status, $remark) {
        $manager = $this->__manager_model->getManagerById($this->_manager_id);
        $ticket_log['ticket_id'] = $id;
        $ticket_log['op_content'] = DICT::getDictValue($ticket_status, 'ticket_status_crm') ? : '';
        $ticket_log['op_user'] = $manager['realname'];
        $ticket_log['remark'] = $remark;
        $ticket_log['create_time'] = date("Y-m-d H:i:s");
        $this->__ticket_model->saveTicketLog($ticket_log);
    }


}