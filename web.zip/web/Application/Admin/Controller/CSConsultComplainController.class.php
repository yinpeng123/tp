<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\UserService;
use Basic\Cnsts\AGENT_CHARGE;
use Admin\Service\PageService;
use Basic\Cnsts\DICT;
use Basic\Service\AgentChargeService;

class CSConsultComplainController extends AdminSessionController
{

    private $__cs_consult_complain_model = null;
    private $__charge_call_model = null;
    private $__cs_consult_complain_log_model = null;
    private $__manager_model = null;

    public function __construct()
    {
        parent::__construct();
        $this->__cs_consult_complain_model     = D('Basic/CSConsultComplain');
        $this->__charge_call_model             = D('Basic/CSChargeCall');
        $this->__cs_consult_complain_log_model = D('Basic/CSConsultComplainLog');
        $this->__manager_model                 = D('Manager');

        // 权限检查
        if (!\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id,
            \Admin\Cnsts\PRIVILEGE::CS_CONSULT_COMPLAIN)
        ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }
    }

    public function index()
    {
        $type_arr       = $this->getType();
        $status_arr     = $this->getStatus();
        $cc_content_arr = $this->getCcContent();

        $id              = I('id');
        $status          = I('status');
        $type            = I('type');
        $username        = I('username');
        $phone           = I('phone');
        $creator         = I('creator');
        $account         = I('account');
        $net_no          = I('net_no');
        $consult_type    = I('consult_type');
        $search_from_day = I('search_from_day');
        $search_to_day   = I('search_to_day');

        $cond = [];
        if (!empty($status)) {
            $cond['cs_consult_complain.status'] = ['eq', $status];
        }
        if (!empty($id)) {
            $cond['cs_consult_complain.id'] = ['eq', $id];
        }
        if (!empty($type)) {
            $cond['cs_consult_complain.type'] = ['eq', $type];
        }
        if (!empty($username)) {
            $cond['cs_consult_complain.username'] = ['eq', $username];
        }
        if (!empty($phone)) {
            $cond['cs_consult_complain.phone'] = ['eq', $phone];
        }
        if (!empty($creator)) {
            $cond['cs_consult_complain.creator'] = ['eq', $creator];
        }
        if (!empty($consult_type)) {
            $cond['cs_consult_complain.consult_type'] = ['like', '%' . $consult_type . '%'];
        }
        if (!empty($search_from_day) && !empty($search_to_day)) {
            $cond['cs_consult_complain.ctime'] = [['egt', $search_from_day], ['elt', $search_to_day]];
        }
        if (!empty($search_from_day)) {
            $cond['cs_consult_complain.ctime'] = ['egt', $search_from_day];
        }
        if (!empty($search_to_day)) {
            $cond['cs_consult_complain.ctime'] = ['elt', $search_to_day];
        }
        if (!empty($account)) {
            $cond['user.account'] = ['eq', $account];
        }
        if (!empty($net_no)) {
            $cond['user.net_no'] = ['eq', $net_no];
        }

        //分页
        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        $ret       = $this->__cs_consult_complain_model->searchConsultComplainList($cond, $curr_page, $per_page);
//p($ret['data']);die;
        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();

        //获取创建人姓名
        for ($i = 0; $i < count($ret['data']); $i++) {
            $manager_model                   = D('Manager');
            $manager_list                    = $manager_model->getManagerById($ret['data'][$i]['creator']);
            $ret['data'][$i]['creator_name'] = $manager_list['username'];
        }

        //获取来电人信息
        /** @var UserService $user_service */
        $user_service = D('User', 'Service');
//        p($ret['data']);die;
        for ($i = 0; $i < count($ret['data']); $i++) {
            list($errno, , $userInfo)                     = $user_service->searchUserProfile($ret['data'][$i]['phone']);
            if ($errno == 1) {
                $ret['data'][$i]['net_no']    = $userInfo['net_no'];
                $ret['data'][$i]['account']   = $userInfo['account'];
                $ret['data'][$i]['telephone'] = $userInfo['telephone'];
            } elseif($errno > 1) {
                // @todo 产品确认一个手机号对应多个账号怎么展示
            }

        }

        //咨询内容处理
        for ($i = 0; $i < count($ret['data']); $i++) {
            $type       = explode(',', $ret['data'][$i]['consult_type']);
            $cc_content = '';
            for ($j = 0; $j < count($type); $j++) {
                $cc_content .= DICT::CONSULT_TYPE_LIST[$type[$j]] . '/';
            }
            $ret['data'][$i]['cc_content'] = $cc_content;
        }

        // 管理员列表
        $manager_model = D('Manager');
        $manager_list  = $manager_model->getAllManagerList('manager_id, realname');
//p($manager_list);die;
        $this->assignAll([
            'list'            => $ret['data'],
            'manager_list'    => $manager_list,
            'status_arr'      => $status_arr,
            'type_arr'        => $type_arr,
            'cc_content_arr'  => $cc_content_arr,
            'status'          => $status,
            'type'            => I('type'),
            'account'         => $account,
            'net_no'          => $net_no,
            'username'        => $username,
            'phone'           => $phone,
            'creator'         => $creator,
            'consult_type'    => $consult_type,
            'search_from_day' => $search_from_day,
            'search_to_day'   => $search_to_day,
            'page_nav'        => $page_nav,
            'code_id'         => $id,
        ]);
        $this->display('CC_index');
    }

    public function add()
    {
        $cs_telephone = I('cs_telephone');
        $_manager = session('manager');
//        p($_manager);
        //咨询内容
        $consult_type_arr = $this->getConsultType();
        //投诉类型
        $complain_type_arr = $this->getComplainType();
        //投诉部门
        $complain_department_type_arr = $this->getComplainDepartmentType();

        //类型
        $type_arr = $this->getType();
        $this->assignAll([
            'title'                        => '新建咨询投诉',
            'manager'                      => $_manager['username'],
            'act'                          => 'add',
            'status'                       => 'new',
            'creator'                      => $_manager['manager_id'],
            'type_arr'                     => $type_arr,
            'username'                     => $_manager['username'],
            'consult_type_arr'             => $consult_type_arr,
            'complain_type_arr'            => $complain_type_arr,
            'complain_department_type_arr' => $complain_department_type_arr,
            'cs_telephone'                  => $cs_telephone,
            'form_action'                  => '/CSConsultComplain/doAdd',
        ]);
        $this->display('CC_add');
    }

    public function doAdd()
    {
        $data = I('');
//        p($data);die;
        $fields   = [
            'creator'                  => $data['creator'],
            'status'                   => $data['status'],
            'type'                     => $data['cc_type'],
            'ctime'                    => $data['ctime'],
            'uid'                      => $data['uid'],
            'username'                 => $data['username'],
            'phone'                    => $data['phone'],
            'complain_to'              => $data['complain_to'],
            'complain_to_no'           => $data['complain_to_no'],
            'complain_content'         => $data['complain_content'],
            'consult_type_other'       => $data['consult_type_other'],
            'remark'                   => $data['remark'],
            'consult_type'             => implode(',', $data['consult_type']),
            'complain_type'            => $data['complain_type'],
            'complain_department_type' => $data['complain_department_type'],
        ];
        $_manager = session('manager');
        $cc_id    = $this->__cs_consult_complain_model->addConsultComplain($fields);

        $action  = '新建';
        $logData = [
            'cc_id'   => $cc_id,
            'mender'  => $_manager['manager_id'],
            'content' => "【" . $action . "】" . "操作人：" . $_manager['username'] . "。处理方案：" . $data['remark'],
            'ctime'   => date("Y-m-d H:i:s"),
        ];
        $this->__cs_consult_complain_log_model->addConsultComplainLog($logData);

        $this->admin_success('新建成功', U('CSConsultComplain/index', '', ''));
    }

    public function edit()
    {
        $data = I('');
        //咨询内容
        $consult_type_arr      = $this->getConsultType();
        $type_arr              = $this->getType();
        $consult_complain_info = $this->__cs_consult_complain_model->getConsultComplainInfo($data['0']);
//        p($consult_complain_info['consult_type']);die;
        $cc_checked = explode(',', $consult_complain_info['consult_type']);
//        p($cc_checked);die;

        $consult_complain_info['cc_content'] = DICT::ACTION_LIST[$consult_complain_info['status']];
        //读取相应的操作记录
        $cc_log_list      = $this->__cs_consult_complain_log_model->getConsultComplainListById($data[0]);
        $cc_log_list_less = $this->__cs_consult_complain_log_model->getConsultComplainListById($data[0], 5);
        $num              = count($cc_log_list);

        //创建人姓名
        $manager_model = D('Manager');
        $manager_list  = $manager_model->getManagerById($consult_complain_info['creator']);
        //被指派人姓名
        $manager_model = D('Manager');
        $worker_info   = $manager_model->getManagerById($consult_complain_info['worker']);
//p($worker_info);
        //投诉部门
        $complain_department_type_arr = $this->getComplainDepartmentType();
        //投诉类型
        $complain_type_arr = $this->getComplainType();

        $this->assignAll([
            'act'                          => 'edit',
            'cc_checked'                   => $cc_checked,
            'status'                       => $consult_complain_info['status'],
            'title'                        => '编辑咨询投诉',
            'creator_name'                 => $manager_list['username'],
            'worker'                       => $worker_info['username'],
            'worker_id'                    => $worker_info['manager_id'],
            'cc_info'                      => $consult_complain_info,
            'consult_type_arr'             => $consult_type_arr,
            'complain_type_arr'            => $complain_type_arr,
            'type_arr'                     => $type_arr,
            'cc_log_list'                  => $cc_log_list,
            'cc_log_list_less'             => $cc_log_list_less,
            'num'                          => $num,
            'complain_department_type_arr' => $complain_department_type_arr,
            'form_action'                  => '/CSConsultComplain/doEdit',
        ]);
        $this->display('CC_add');
    }

    public function doEdit()
    {
        $data = I('');
//        p($data);die;
        $notApprove = $data['notApprove'];
        $id         = $data['id'];
        $btn_act    = $data['btn_act'];
        if ($id) {
            $old_cc = $this->__cs_consult_complain_model->getConsultComplainInfo($id);
        } else {
            $old_cc = [];
        }
        if ($notApprove == 'not_save') {
            $status = 'doing';
        } elseif ($notApprove == 'not_finish') {
            $status = 'approve_not';
        } else {
            $status = $this->_getNewStatus($id, $btn_act, $old_cc);
        }


        //当修改时取消其他，则置空所填内容
        if (!in_array(8, $data['consult_type'])) {
            $data['consult_type_other'] = '';
        }
        $fields = [
            'type'                     => $data['type'],
            'mtime'                    => date("Y-m-d H:i:s"),
            'username'                 => $data['username'],
            'phone'                    => $data['phone'],
            'complain_to'              => $data['complain_to'],
            'complain_to_no'           => $data['complain_to_no'],
            'complain_content'         => $data['complain_content'],
            'consult_type'             => implode(',', $data['consult_type']),
            'consult_type_other'       => $data['consult_type_other'],
            'complain_type'            => $data['complain_type'],
            'complain_department_type' => $data['complain_department_type'],
            'remark'                   => $data['remark'],
            'worker'                   => $data['worker'],
            'status'                   => $status,
            'mender'                   => $this->_manager_id,
            'reason_back'              => $data['reason_back'],
        ];

        $this->__cs_consult_complain_model->updateById($id, $fields);
        $this->addLog($id, $status, $data['remark']);
        if ($data['btn_act'] === 'finish') {
            $this->admin_success('操作成功！', U('CSConsultComplain/index', '', ''));
        }
        $this->admin_success('编辑成功');
    }


    //指派
    public function doAssign()
    {
        $data   = I('');
        $id     = $data['id'];
        $worker = $data['worker'];

        if (!$id || !$worker) {
            $this->admin_error('参数不正确！');

            return;
        }

        $fields = [
            'status' => 'doing',
            'mender' => $this->_manager_id,
            'worker' => $worker,
            'mtime'  => datetime(),
        ];
        //print_r($fields);
        $this->__cs_consult_complain_model->updateById($id, $fields);

        $this->addLog($id, 'assign', I('remark', ''), $worker);

        $this->admin_success('指派工单成功！');
    }


    //日志操作
    protected function addLog($id, $status, $remark, $worker = null)
    {
        if ($status == 'assign') {
            $manager_model = D('Manager');
            $manager_list  = $manager_model->getManagerById($worker);
            $action        = '指派';
            $content       = "【" . $action . "】" . $this->_manager['username'] . "指派给" . $manager_list['username'] . "。" . "操作人：" . $this->_manager['username'] . "、创建时间：" . date("Y-m-d H:i:s") . "、处理方案：" . $remark;

        } else {
            $action  = DICT::ACTION_LIST[$status];
            $content = "【" . $action . "】" . "操作人：" . $this->_manager['realname'] . "、创建时间：" . date("Y-m-d H:i:s") . "、处理方案：" . $remark;
        }

        $logData = [
            'cc_id'   => $id,
            'mender'  => $this->_manager_id,
            'content' => $content,
            'ctime'   => date("Y-m-d H:i:s"),
        ];
        $this->__cs_consult_complain_log_model->addConsultComplainLog($logData);
    }


    // 新状态
    protected function _getNewStatus($id, $btn_act = '', $old_cc = [])
    {
        if ($id == 0) {
            return 'new';
        }

        if ($btn_act == 'save') { // 待回访、否单状态下的工单，点击保存，不改变工单状态
            if ($old_cc['status'] == 'wait_review' || $old_cc['status'] == 'deny') {
                return $old_cc['status'];
            }
        }
        if ($btn_act == 'finish') {
            return 'wait_review';
        }
        if ($btn_act == 'deny') {
            return 'deny';
        }
        if ($btn_act == 'approve') {
            return 'finish';
        }
        if ($btn_act == 'close') // 权限检查
        {
            if (!\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id,
                \Admin\Cnsts\PRIVILEGE::CS_CONSULT_COMPLAIN_EXAM)
            ) {
                $this->admin_error('你无权操作！', U('index/index', '', ''));
                exit;
            } else {
                return 'close';
            }
        }

        return 'doing';
    }

    /**
     * 回电操作
     */
    public function callBack()
    {
        $data = I('');
//        p($data);die;
        $call_id = $data['id'];

        $csc_info = $this->__cs_consult_complain_model->getConsultComplainInfo($call_id);


        if ($csc_info['uid'] == 0) {
            $fields = [
                'style'         => 'call_back',
                'status'        => 'new',
                'cc_id'         => $call_id,
                'ctime'         => date('Y-m-d H:i:s'),
                'not_telephone' => $data['phone'],
            ];
        } else {
            $fields = [
                'uid'    => $csc_info['uid'],
                'style'  => 'call_back',
                'status' => 'new',
                'cc_id'  => $call_id,
                'ctime'  => date('Y-m-d H:i:s'),
            ];
        }


        $cs_id = $this->__charge_call_model->insertInto($fields);

        //更改回电状态
        $fields = [
            'is_call_back' => 1,
        ];
        $this->__cs_consult_complain_model->updateById($call_id, $fields);

        $this->admin_success('回电成功！', U('CSConsultComplain/index', '', ''));
    }


    protected function getConsultType()
    {
        $consult_type_arr  = [];
        $consult_type_list = DICT::CONSULT_TYPE_LIST;
        $consult_type_keys = array_keys($consult_type_list);
        foreach ($consult_type_keys as $i => &$r) {
            $consult_type_arr[] = ['id' => $r, 'text' => $consult_type_list[$r]];
        }

        return $consult_type_arr;
    }

    protected function getComplainType()
    {
        $consult_type_arr  = [];
        $consult_type_list = DICT::COMPLAIN_LIST;
        $consult_type_keys = array_keys($consult_type_list);
        foreach ($consult_type_keys as $i => &$r) {
            $consult_type_arr[] = ['id' => $r, 'text' => $consult_type_list[$r]];
        }

        return $consult_type_arr;
    }

    protected function getComplainDepartmentType()
    {
        $consult_department_type_arr  = [];
        $consult_department_type_list = DICT::COMPLAIN_DEPARTMENT_TYPE;
        $consult_department_type_keys = array_keys($consult_department_type_list);
        foreach ($consult_department_type_keys as $i => &$r) {
            $consult_department_type_arr[] = ['id' => $r, 'text' => $consult_department_type_list[$r]];
        }

        return $consult_department_type_arr;
    }

    protected function getStatus()
    {
        $status_arr  = [];
        $status_list = DICT::ACTION_LIST;
        $status_keys = array_keys($status_list);
        foreach ($status_keys as $i => &$r) {
            $status_arr[] = ['id' => $r, 'text' => $status_list[$r]];
        }

        return $status_arr;
    }

    protected function getCcContent()
    {
        $cc_content_arr  = [];
        $cc_content_list = DICT::CONSULT_TYPE_LIST;
        $cc_content_keys = array_keys($cc_content_list);
        foreach ($cc_content_keys as $i => &$r) {
            $cc_content_arr[] = ['id' => $r, 'text' => $cc_content_list[$r]];
        }

        return $cc_content_arr;
    }

    protected function getType()
    {
        $type_arr  = [];
        $type_list = DICT::TYPE_LIST;
        $type_keys = array_keys($type_list);
        foreach ($type_keys as $i => &$r) {
            $type_arr[] = ['id' => $r, 'text' => $type_list[$r]];
        }

        return $type_arr;
    }
}