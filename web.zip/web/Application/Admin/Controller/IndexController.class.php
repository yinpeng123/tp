<?php
namespace Admin\Controller;

use Admin\Service\UserService;
use Basic\ModelU\CenterModel;
use Common\Cnsts\ERRNO;
use Basic\Cnsts\DICT;
use Admin\Controller\AdminSessionController;

class IndexController extends AdminSessionController {

    private $__agent_model = null;

    public function __construct() {
        parent::__construct();

        $this->__agent_model   = D('Basic/Agent');
    }

    public function isHasCertAuth() {

        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::TRUCK_OWNER_VERIFY) ) {
            if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::GOODS_OWNER_VERIFY) ) {
                return ['cert_privilege' => 0, 'company_cert_privilege' => 0];
            } else {
                return ['cert_privilege' => 0, 'company_cert_privilege' => 1];
            }
        } else {
            if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::GOODS_OWNER_VERIFY) ) {
                return ['cert_privilege' => 1, 'company_cert_privilege' => 0];
            } else {
                return ['cert_privilege' => 1, 'company_cert_privilege' => 1];
            }
        }
    }

    public function home() {
        //获取渠道信息
        $agent_info = $this->__agent_model->getAgentById(session('manager')['agent_id']);
        if(session('manager')['agent_id'] == 0) {
            $agent_name = '全国网';
        } else {
            $agent_name = $agent_info['name'];
        }

        /** @var UserService $admin_user_service */
        $admin_user_service = D('Admin/User', 'Service');
        $cert_list = $admin_user_service->getUserCertList(['is_delete' => 0, 'status' => 1, 'cert_status' => DICT::VERIFY_ING]);

        $company_cert_list = $admin_user_service->getUserCertList(['is_delete' => 0, 'status' => 1, 'company_cert_status' => DICT::VERIFY_ING]);

        // 根据权限展示
        $privilege = $this->isHasCertAuth();
        $model= new CenterModel("u_user");
        $smodel=new CenterModel("u_school");
        $jmodel= new CenterModel("u_trainer");
        $pmodel= new CenterModel("u_mall_order");
        $info=[
            'allUser'=>$model->getListTotal(),
            'newUser'=>$model->getListTotal(['ctime'=>['egt',day()]]),
            'vipUser'=>$model->getListTotal(['is_vip'=>'Y']),
            'memberUser'=>$model->getListTotal(['is_member'=>'Y']),
            'school'=>$smodel->getListTotal(),
            'nopic'=>$smodel->getListTotal(['pic'=>""]),
            'juser'=>$jmodel->getListTotal(),
            'nopass'=>$pmodel->getListTotal(['remark'=>['exp','is null']]),
        ];
        $this->assignAll(array(
            'agent_name' => $agent_name,
            'username' => session('manager')['username'],
            'uncheck' => ['cert' => count($cert_list), 'company_cert' => count($company_cert_list)],
            'privilege' => $privilege,
            'title'   => '首页',
            'info'=>$info,
        ));
        $this->display('home');
    }

    public function index() {
        $this->home();
    }

    public function uiDemo() {
        // 渠道商列表
        $agent_model = D('Basic/Agent');
        $agent_list = $agent_model->getAllAgentList('id,name');
        //print_r($agent_list);exit;
        $this->assign('agent_list', $agent_list);
        // 设置初始值
        $this->assign('agent_id', 118);

        // 管理员列表
        $manager_model = D('Manager');
        $manager_list = $manager_model->getAllManagerList('manager_id, realname');
        //print_r($manager_list);exit;
        $this->assign('manager_list', $manager_list);

        // 一级地区列表
        $city_model = D('Basic/City');
        $province_list = $city_model->getCityList(-1);
        $this->assign('province_list', $province_list);

        // 地区初始数据显示
        $area_arr = [
            ['province' => 1107, 'city' => 1170, 'district' => 1173],
            ['province' => 1889, 'city' => 1911, 'district' => 1913],
        ];
        $this->assign('area_arr', $area_arr);

        // 多图上传初始图片数据
        $url_prefix = 'http://w-alpha-1001.chemanman.com:9111/basic/image/view/certificate/2017-07-06/';
        $photos = [
            'initialPreview' => [ $url_prefix.'certificate_595dd233c1890.jpg', $url_prefix.'certificate_595dd2a4f1348.jpg' ],
            'initialPreviewConfig' => [
                [
                    'type'      => 'image',
                    'caption'   => 'certificate_595dd233c1890.jpg',
                    'size'      => 35978,
                    'url'       => '/api/ajaxDeleteImage',
                    'key'       => 1,
                ],

                [
                    'type'      => 'image',
                    'caption'   => 'certificate_595dd2a4f1348.jpg',
                    'size'      => 43936,
                    'url'       => '/api/ajaxDeleteImage',
                    'key'       => 2,
                ],
            ]
        ];
        $this->assign('photos', $photos);
        $this->assign('photos1', $photos);

        // 产品功能列表
        $product_model = D('Basic/Product');
        $product_list = $product_model->getAllProductList();
        //print_r($product_list);
        $product_checked = array(1,4,5,6,7); // 选中的功能
        $this->assign('product_list', $product_list);
        $this->assign('product_checked', $product_checked);

        //var_dump(session_id());
        $this->assignAll(array(
            'title'   => '首页',
        ));
        $this->display('ui_demo');
    }

    // 异步多图上传demo
    public function uploadDemo() {

        $this->assignAll(array(
            'title'   => '多图ajax上传演示',
        ));
        $this->display('upload_demo');
    }

    public function doUploadDemo() {
        //p(I('uploadedFile'));exit;
        p($_POST);

        // 排序以便重置索引
        $photo2_arr = S(I('photo2_upload_key'));
        //$photo2_arr = array_values($photo2_arr);
        print_r($photo2_arr);

        exit;
    }

    // 变态版上传demo
    public function uploadDemo2() {
        // 多图上传初始图片数据
        $url_prefix = 'http://w-alpha-1001.chemanman.com:9111/basic/image/view/certificate/2017-07-06/';
        $photos = [
            'initialPreview' => [ $url_prefix.'certificate_595dd233c1890.jpg', $url_prefix.'certificate_595dd2a4f1348.jpg' ],
            'initialPreviewConfig' => [
                [
                    'type'      => 'image',
                    'caption'   => 'certificate_595dd233c1890.jpg',
                    'size'      => 35978,
                    'url'       => '/api/ajaxDeleteImage',
                    'key'       => 0,
                ],

                [
                    'type'      => 'image',
                    'caption'   => 'certificate_595dd2a4f1348.jpg',
                    'size'      => 43936,
                    'url'       => '/api/ajaxDeleteImage',
                    'key'       => 1,
                ],
            ]
        ];
        //$this->assign('photos', $photos);

        // ajax多图2
        $photo2_upload_key = uniqid('photo2_');
        $this->assign('photo2_upload_key', $photo2_upload_key); // 图片上传key,用于添加记录时需要临时保存上传的文件
        //$this->assign('photos2', $photos);

        // ajax单图上传
        $photo_ajax_single = [
            'initialPreview' => [ $url_prefix.'certificate_595dd233c1890.jpg' ],
            'initialPreviewConfig' => [
                [
                    'type'      => 'image',
                    'caption'   => 'certificate_595dd233c1890.jpg',
                    'size'      => 35978,
                    'url'       => '/api/ajaxDeleteImage',
                    'key'       => 1,
                ],
            ]
        ];
        //$this->assign('photo_ajax_single', $photo_ajax_single);

        $this->assignAll(array(
            'rid'       => 0, // 模拟新建记录时的图片上传
            'title'     => '图片上传演示',
        ));
        $this->display('upload_demo_2');
    }

    // 使用新的上传组件以兼容低版本IE浏览器
    public function uploadDemo3() {
        // 多图上传初始图片数据
        $photos = [
            ['name' => 'image1[]', 'url' => 'http://w-alpha-1001.chemanman.com:9111/basic/image/view/certificate/2017-07-06/certificate_595dd233c1890.jpg'],
            ['name' => 'image1[]', 'url' => 'http://w-alpha-1001.chemanman.com:9111/basic/image/view/certificate/2017-07-06/certificate_595dd2a4f1348.jpg'],
        ];
        //$this->assign('photos', $photos);

        $this->assignAll(array(
            'rid'       => 0, // 模拟新建记录时的图片上传
            'title'     => '图片上传演示',
        ));
        $this->display('upload_demo_3');
    }


    // ajax单图, 选中后自动上传
    public function uploadDemo4() {
        // 多图上传初始图片数据
        $url_prefix = 'http://w-alpha-1001.chemanman.com:9111/basic/image/view/certificate/2017-07-06/';

        // ajax单图上传
        $photo_ajax_single = [
            'initialPreview' => [ $url_prefix.'certificate_595dd233c1890.jpg' ],
            'initialPreviewConfig' => [
                [
                    'type'      => 'image',
                    'caption'   => 'certificate_595dd233c1890.jpg',
                    'size'      => 35978,
                    'url'       => '/api/ajaxDeleteImage',
                    'key'       => 1,
                ],
            ]
        ];
        $this->assign('photo_ajax_single', $photo_ajax_single);

        $this->assignAll(array(
            'rid'       => 0, // 模拟新建记录时的图片上传
            'title'     => '图片上传演示',
        ));
        $this->display('upload_demo_4');
    }


    // ajax上传图片接口
    public function ajaxUploadImage() {
        header("Content-Type: application/json; charset=utf-8");

        $key = key($_FILES);
        if ( empty($_FILES[$key]) || $_FILES[$key]['size'] == 0 ) {
            die("{}");
        }

        $root_dir = C('IMAGE_PATH')['certificate'];
        $sub_dir = day();
        $image_info = array();
        list($errcode, $errmsg) = uploadImage($key, $root_dir, $sub_dir, $image_info, 'certificate');
        if ( $errcode != ERRNO::SUCCESS ) {
            echo json_encode(['error' => $errmsg]);
            exit;
        }

        $res = [
            'initialPreview' => [ imageUrl($image_info) ],
            'initialPreviewConfig' => [
                [
                    'type'      => 'image',
                    'caption'   => $image_info['name'],
                    'size'      => $_FILES[$key]['size'],
                    'url'       => '/index/ajaxDeleteImage',
                    'key'       => null,
                    'extra'     => null,
                ],
            ]
        ];

        $id = I('id/d', 0);
        if ( !$id ) { // 新增记录
            $field = I('field');
            $upload_key = I('upload_key');
            if ( !$field || !$upload_key ) {
                die(json_encode(['error' => '参数 field 和 upload_key 不能为空！']));
            }

            // 从缓存中获取临时保存的上传图片信息
            $image_arr = S($upload_key);
            if ( !$image_arr ) {
                $image_arr = [$image_info];
            } else {
                $image_arr[] = $image_info;
            }

            // 更新缓存
            S($upload_key, $image_arr, 1800);

            $res['initialPreviewConfig'][0]['key'] = count($image_arr) - 1;
            $res['initialPreviewConfig'][0]['extra'] = ['field' => $field, 'upload_key' => $upload_key];

        } else { // 编辑记录

        }

        echo json_encode($res);
        exit;
    }

    // ajax上传图片接口2, 不处理数据存储
    public function ajaxUploadImage2() {
        $key = key($_FILES);
        if ( empty($_FILES[$key]) || $_FILES[$key]['size'] == 0 ) {
            die("{}");
        }

        $root_dir = C('IMAGE_PATH')['certificate'];
        $sub_dir = day();
        $image_info = array();
        list($errcode, $errmsg) = uploadImage($key, $root_dir, $sub_dir, $image_info, 'certificate');
        if ( $errcode != ERRNO::SUCCESS ) {
            echo json_encode(['error' => $errmsg]);
            exit;
        }

        $res = [
            'initialPreview' => [ imageUrl($image_info) ],
            'initialPreviewConfig' => [
                [
                    'type'      => 'image',
                    'caption'   => $image_info['name'],
                    'size'      => $_FILES[$key]['size'],
                    'url'       => '/index/ajaxDeleteImage',
                    'key'       => $key,
                    'extra'     => null,
                ],
            ]
        ];

        echo json_encode($res);
    }

    // ajax上传图片接口
    public function ajaxUploadImage3() {
        //header("Content-Type: application/json; charset=utf-8");
        header("Content-Type: application/javascript; charset=utf-8");

        $key = key($_FILES);
        if ( empty($_FILES[$key]) || $_FILES[$key]['size'] == 0 ) {
            die("{}");
        }

        $root_dir = C('IMAGE_PATH')['certificate'];
        $sub_dir = day();
        $image_info = array();
        list($errcode, $errmsg) = uploadImage($key, $root_dir, $sub_dir, $image_info, 'certificate');
        if ( $errcode != ERRNO::SUCCESS ) {
            echo json_encode(['error' => $errmsg]);
            exit;
        }

        $name = I('get.name'); // 字段名
        $res = [
            'name'      => $name, // input hidden 元素的name属性值
            'url'       => imageUrl($image_info), // 图片链接
        ];

        //
        //echo json_encode($res);
        $uploadbtn1 = 'uploadbtn1';
        header('Content-Type:text/html;charset=utf-8');
        echo '<script>parent.addImgtoForm('.json_encode($res).',"uploadbtn1")</script>';
        exit;
    }


    /**
     * 删除图片
     */
    public function ajaxDeleteImage() {
        $id = I('id/d', 0);
        if ( !$id ) { // 新增记录
            $field = I('field');
            $upload_key = I('upload_key');
            if ( !$field || !$upload_key ) {
                die(json_encode(['error' => '参数 field 和 upload_key 不能为空！']));
            }

            // 从缓存中获取临时保存的上传图片信息
            $image_arr = S($upload_key);
            if ( !$image_arr ) {
                die('{}');
            }

            // 从记录中删除图片
            $key = I('key/d', 0);
            unset($image_arr[$key]);

            // 更新缓存
            S($upload_key, $image_arr, 1800);

        } else { // 编辑记录

        }

        die('{}');
    }

    // 国志版文件上传控件
    public function imgUploadDemo() {
        // 多图上传初始图片数据
        $pics = [
            ['name' => 'certificate_5a66dde861c77.jpg', 'extension' => 'jpg', 'url' => 'http://w-alpha-1001.chemanman.com:9111/basic/image/view/certificate/2018-01-23/certificate_5a66dde861c77.jpg'],
            ['name' => 'certificate_5a66ddf41d6fb.zip', 'extension' => 'zip', 'url' => 'http://w-alpha-1001.chemanman.com:9111/basic/image/view/certificate/2018-01-23/certificate_5a66ddf41d6fb.zip'],
            ['name' => 'certificate_5a66f1f338988.jpg', 'extension' => 'jpg', 'url' => 'http://w-alpha-1001.chemanman.com:9111/basic/image/view/certificate/2018-01-23/certificate_5a66f1f338988.jpg'],
        ];
        $this->assign('pic_arr', $pics);

        $this->assignAll(array(
            'title'     => '国志版图片上传演示',
        ));
        $this->display('img_upload_demo');
    }

    // 国志版文件上传控件, 处理表单提交
    public function doImgUploadDemo() {
        p($_POST);

        // 将url地址解析成上传文件的信息
        if ( !empty($_POST['pic1']) ) {
            p(imageUrlToArray($_POST['pic1']));
        }

        if ( !empty($_POST['pic2']) ) {
            foreach ( $_POST['pic2'] as $i ) {
                p(imageUrlToArray($i));
            }
        }
    }

    public function formsubmit() {
        // 多图上传
//        print_r($_FILES);die;
        $root_dir = C('IMAGE_PATH')['certificate'];
        $sub_dir = day();
        $input_name = 'photo';
        if ( !empty($_FILES[$input_name]) && $_FILES[$input_name]['size'][0] > 0 ) {
            $photo_info = array(); // 保存图片信息
            list($errcode, $errmsg) = uploadImageMulti($input_name, $root_dir, $sub_dir, $photo_info, 'certificate');
            if ( $errcode != ERRNO::SUCCESS ) {
                $this->admin_error('图片上传失败！'.$errmsg);
                return;
            }

            print_r($photo_info);
            exit;
        }

        // 动态增减表单元素
        print_r($_POST);

        echo "ok!";
    }

    // 穿梭框演示
    public function transferDemo() {
        $this->assignAll(array(
            'title'   => '穿梭框演示',
        ));
        $this->display('transfer_demo');
    }

    // 穿梭框演示 - 表单提交
    public function doTransferDemo() {
        p($_POST);
    }

    // ECharts 演示
    public function echartsDemo() {
        $this->assignAll(array(
            'title'   => 'Echarts - 柱状图演示',
        ));
        $this->display('echarts_bar_demo');
    }
    public function checkPassword($pwd) {
        echo "checkPassword() called! $pwd\n";
        return preg_match('/^\w{6,}$/', $pwd) ? TRUE : FALSE;
    }

    /**
     * 添加新用户, 供测试数据验证使用 @todo 废弃 demo
     */
    public function addUser($req) {
        $user_model = new \Basic\Model\UserModel();

        // 模拟请求数据
        $req = array(
            'user_name'   => 'a1234',
            'card_num'    => '510123190001011000', // 身份证号
            'member_type' => '2', // 会员类型
            'password'    => 'xxxxxxx', // 密码
            'password2'   => 'xxxxxxx', // 确认密码
        );

        $rules = array(
            //array('user_name', 'require', '用户名格式不正确！', \Think\Model::MUST_VALIDATE ), // 必须有值
            //array('user_name', '4,128', '用户名格式不正确！', \Think\Model::MUST_VALIDATE, 'length'), // 验证长度
            array('user_name', '/^[^\d_][\w_]{3,}$/', '用户名格式不正确！', \Think\Model::MUST_VALIDATE, 'regex'), // 正则表达式

            array('card_num', '/^(\d{18,18}|\d{15,15}|\d{17,17}x)$/', '身份证号格式不正确！', \Think\Model::VALUE_VALIDATE, 'regex'), // 有值的时候验证

            array('member_type', array(1, 2, 3), '会员类型不正确！', \Think\Model::MUST_VALIDATE, 'in'), // 必须有值

            //array('password', '__check_password', '密码格式不正确！', \Think\Model::MUST_VALIDATE, 'function'), // 自定义函数验证密码格式
            array('password', array(&$this, 'checkPassword'), '密码格式不正确！', \Think\Model::MUST_VALIDATE, 'function'), // 自定义当前类的方法来验证

            array('password2', 'password', '两次输入密码不一致', \Think\Model::MUST_VALIDATE, 'confirm'), // 验证两个字段是否相同
        );

        $ret = $user_model->validate($rules, $req);
        if ($ret !== NULL) { // 验证未通过
            return [ERRNO::INPUT_PARAM_ERRNO, ERRNO::e(ERRNO::INPUT_PARAM_ERRNO).': '.$ret, []];
        }

        // 验证通过, 执行添加用户的操作

        // 返回数据
        return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), []];
    }
}