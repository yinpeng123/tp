var popBox = document.querySelector('#popBox');
var imgurl;

var openid = getUrlParam('openid');

function uploadImg() {
    popBox.style.display = 'block';
    $('.img').css('background-image', 'url(' + imgurl + ')');
}

function reUpload() {
    popBox.style.display = 'none';
}

function upload() {
    let uploading = false;
    if (uploading) {
        layer.msg('图片正在上传，请稍后');
        return false;
    }
    var formData = new FormData();
    var image = $('#picfile')[0].files[0];
    formData.append('file', image);
    formData.append('openid', openid);
    var fileSize = image.size;
    if (parseInt(fileSize) >= 5242880) {
        layer.msg('上传的图片不能大于5M');
        return false;
    }
    $.ajax({
        url: 'http://www.htown.xyz/Home/index/clock_record',
        type: 'POST',
        processData: false,
        contentType: false,
        data: formData,
        beforeSend: function () {
            uploading = true;
        },
        success: function (data) {
            console.log(data)
            uploading = false;
            if (data.msg == "打卡完成") {
                window.location.href = '../share/share.html?openid=' + openid;
            }
        }
    })
}

$('.addimg-icon').click(function () {
    $('.file-input').click();
})

function changepic() {
    var reads = new FileReader;
    f = document.getElementById('picfile').files[0];
    reads.readAsDataURL(f);
    reads.onload = function (e) {
        imgurl = this.result;
        $('.addimg-icon').css('background-image', 'url(' + imgurl + ')');
        $('.addimg-icon').css('width', '5.12rem');
        $('.addimg-icon').css('height', '5.12rem');
    }
}




