<?php
namespace Admin\Service;

use Admin\Cnsts\INNER_NOTICE;
use Admin\Model\InnerNoticeModel;
use Common\Cnsts\ERRNO;

class InnerNoticeService {

    //添加系统消息
    public function addInnerNotice($data) {
        /** @var InnerNoticeModel $inner_notice_model */
        $inner_notice_model = D('Admin/InnerNotice', 'Model');
        $inner_notice_id = $inner_notice_model->addInnerNotice($data);
        if ($inner_notice_id !== false) {
            return [ERRNO::SUCCESS,ERRNO::e(ERRNO::SUCCESS),['inner_notice_id' => $inner_notice_id]];
        } else {
            return [ERRNO::SQL_UPDATE_ERRNO,ERRNO::e(ERRNO::SQL_UPDATE_ERRNO),['inner_notice_id' => $inner_notice_id]];
        }
    }

    //添加系统消息
    public function mulitiAddLink($data) {
        /** @var InnerNoticeModel $inner_notice_model */
        $inner_notice_model = D('Admin/InnerNotice', 'Model');
        $add_link_res = $inner_notice_model->mulitiAddLink($data);
        if ($add_link_res !== false) {
            return [ERRNO::SUCCESS,ERRNO::e(ERRNO::SUCCESS),[]];
        } else {
            return [ERRNO::SQL_UPDATE_ERRNO,ERRNO::e(ERRNO::SQL_UPDATE_ERRNO),[]];
        }
    }

    //获取消息列表
    public function getInnerNoticeList($where,$fields,$order_by,$limit,$join=[]) {
        /** @var InnerNoticeModel $inner_notice_model */
        $inner_notice_model = D('Admin/InnerNotice', 'Model');
        $inner_notice_list = $inner_notice_model->getInnerNoticeList($where,$fields,$limit,$order_by,$join);
        return $inner_notice_list ? :[];
    }


    public function getInnerNoticeLinks($where) {
        /** @var InnerNoticeModel $inner_notice_model */
        $inner_notice_model = D('Admin/InnerNotice', 'Model');
        $link_list = $inner_notice_model->getInnerNoticeLinks($where);
        return $link_list ? :[];
    }

    public function getTableOp($data) {
        $std_str = '';
        $std_str .= '<td class="last column-width-90">
            <a href="/InnerNotice/addInnerNotice?inner_notice_id='.$data['inner_notice_id'].'" class="op_edit" 
            op_data_id='
            .$data['inner_notice_id'].'>复制</a>
            <a href="/InnerNotice/addInnerNotice?inner_notice_id='.$data['inner_notice_id'].'&act=view" class="op_view" 
            op_data_id='
            .$data['inner_notice_id'].'>查看</a>
            <a href="/InnerNotice/delete?inner_notice_id='.$data['inner_notice_id'].'" class="op_del" op_data_id='
            .$data['inner_notice_id'].'>删除</a>
        </td>';
        return $std_str;
    }

    //获取消息详情
    public function getInnerNoticeById($id) {
        /** @var InnerNoticeModel $inner_notice_model */
        $inner_notice_model = D('Admin/InnerNotice', 'Model');
        $notice = $inner_notice_model->getInnerNoticeById($id);
        return $notice ? :[];
    }

//    //获取总条数
    public function getSqlFoundRows($where,$join=[]) {
        /** @var InnerNoticeModel $inner_notice_model */
        $inner_notice_model = D('Admin/InnerNotice', 'Model');
        $total = $inner_notice_model->getSqlFoundRows($where,$join);
        return $total;
    }

    public function upNoticeLink($where,$data) {
        /** @var InnerNoticeModel $inner_notice_model */
        $inner_notice_model = D('Admin/InnerNotice', 'Model');
        $up_res = $inner_notice_model->updateInnerLink($where,$data);
        if ($up_res !== false) {
            return [ERRNO::SUCCESS,ERRNO::e(ERRNO::SUCCESS),[]];
        } else {
            return [ERRNO::SQL_UPDATE_ERRNO,ERRNO::e(ERRNO::SQL_UPDATE_ERRNO),[]];
        }
    }

    public function upInnerByWhere($where,$data) {
        /** @var InnerNoticeModel $inner_notice_model */
        $inner_notice_model = D('Admin/InnerNotice', 'Model');
        $up_res = $inner_notice_model->updateInner($where,$data);
        if ($up_res !== false) {
            return [ERRNO::SUCCESS,ERRNO::e(ERRNO::SUCCESS),[]];
        } else {
            return [ERRNO::SQL_UPDATE_ERRNO,ERRNO::e(ERRNO::SQL_UPDATE_ERRNO),[]];
        }
    }

}