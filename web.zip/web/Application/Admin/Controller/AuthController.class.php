<?php
namespace Admin\Controller;

use Admin\Controller\AdminCommonController;
use Admin\Service\AuthService;
use  Qcloud\Sms\SmsSingleSender;
use Qcloud\Cos\Client;
use Qcloud_cos\Auth;
use Qcloud_cos\Cosapi;
use Qcloud_cos\CosDb;

class AuthController extends AdminCommonController {

    public function _empty($action){
        //将所有错误的操作方法指向login
        $this->login();
    }

    public function index() {
        redirect(U('auth/login', '', '', TRUE));
    }

    /**
     * 登录页
     */
    public function login() {
        $this->assign('title', '用户登录');
        $this->display('login');
    }

    /**
     * 用户登录
     */
    public function doLogin() {
        // 验证令牌
        //$this->checkFormToken();

        // 密码登录
        $auth_service = D('Admin/Auth', 'Service');
        list($code, $message, $manager) = $auth_service->doLoginPassword(I('username'), I('password'));
        if ( $code < 0 ) {
            return $this->ajaxResponseToken($code, $message);
        }

        $manager_model = D('Admin/Manager', 'Model');
        $info = array('last_login_ip' => get_client_ip(), 'last_login_time' => datetime(), 'relogin' => 0);
        $manager_model->updateManagerById($manager['manager_id'], $info);

        // 设置会话数据
        session('manager', $manager);
        session('manager_id', $manager['manager_id']);
        session('menu_list', NULL);

        $this->ajaxResponse(0, '登录成功！');
    }

    /**
     * 登出
     */
    public function logout() {
        session_destroy();
        redirect(U('auth/login', '', ''));
    }


    public function test(){

        $appid="1400165675";
        $appkey="f2130492ca44f1c6b09540f03455d3d9";
        $ssender = new SmsSingleSender($appid, $appkey);
        $result = $ssender->send(0, "86", "15801350170",
            "【UPplan】1818为您的登录验证码，请于2分钟内填写。如非本人操作，请忽略本短信。", "", "");
        $rsp = json_decode($result);
       echo $result;die;


//创建文件夹
        Cosapi::setTimeout(180);
        $bucketName = 'upxiaoqu-1253793121';
        $srcPath = "/home/web/Application/Admin/Controller/AuthController.class.php";

        $dstPath = '/test/test.log';
        $dstFolder = '/UP-PLAN/';
        $createFolderRet = Cosapi::createFolder($bucketName, $dstFolder);
       //p($createFolderRet);die;

        //上传文件
        $bizAttr = "";
        $insertOnly = 0;
        $sliceSize = 3 * 1024 * 1024;
        $uploadRet = Cosapi::upload($bucketName, $srcPath, $dstPath,$bizAttr,$sliceSize, $insertOnly);
        p($uploadRet);

    }
}