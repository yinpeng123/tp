<?php
namespace Admin\Cnsts;

class USER {
    const USER_SEARCH_FIELD = [
        'telephone' => ['type' => 'like',],
        'account' => ['type' => 'like'],
        'net_no' => ['type' => 'like'],
        'card_num' => ['type' => 'like'],
        'member_type' => ['type' => 'eq'],
        'channel_id' => ['type' => 'eq'],
//        'cert_status' => ['type' => 'eq'],
        'user_name' => ['type' => 'like'],
    ];

    const CERT_FAIL_REASON = [
        '身份证正面照片有误、过期或模糊',
        '身份证背面照片有误、过期或模糊',
        '驾驶证照片有误、过期或模糊',
        '行驶证照片有误、过期或模糊',
        '准驾证照片有误、过期或模糊',
    ];

    const COMPANY_CERT_FAIL_REASON = [
        '身份证正面照片有误、过期或模糊',
        '身份证背面照片有误、过期或模糊',
        '营业执照正面照片有误、过期或模糊',
        '营业执照背面照片有误、过期或模糊',
        '公司名称、注册号与营业执照不符',
    ];
    const ADD_USER_FIELD = [
        //基础信息部分
        'account'               => ['type' => 'text','default' => '','require' => '1' ],
        'member_type'             => ['type' =>'select'],
        'channel_id'             => ['type' => 'text'],
        'avatar'                 => ['type' => 'photo'],
        'net_no'                 => ['type' => 'text'],
        'cert_status'          => ['type' => 'select'],
        'active_area'          => ['type' => 'checkbox_select'],
        'province_city_area'  => ['type' => 'text'],//区域
        'addr'                 => ['type' => 'text'],
        'card_num'            => ['type' => 'text'],
        'user_name'           => ['type' => 'text'],
        'telephone'           => ['type' => 'text'],
        'phone1'              => '',
        'phone2'              => '',
        'phone3'              => '',
        'remark'              => '',
        'email'              => ['type' => 'text'],
        'register_num'      => '',
        'company_cert_status'   => 0,
        'member_start_time'  => '',
        'member_end_time'   => '',
        'cert_time'         => '',
    ];






}