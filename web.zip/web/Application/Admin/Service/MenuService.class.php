<?php
namespace Admin\Service;


class MenuService {

    /**
     * 添加操作日志
     */
    public function addOperLog($info) {
        $log_model = D('OperLog');
        $oper_info = array(
            'manager_id'     => $info['manager_id'],
            'module'  => '菜单管理',
            'resource'=> '菜单',
            'object_id' => $info['object_id'],
            'action'  => $info['action'],
            'desc'    => $info['desc'],
            'ctime'   => datetime(),
        );
        $log_model->add($oper_info);
    }

}