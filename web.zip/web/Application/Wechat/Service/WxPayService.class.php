<?php
namespace Wechat\Service;

use Basic\Cnsts\USER_FINANCE;
use Think\Log;
use Common\Service\CommonService;
use Common\Cnsts\ERRNO;
use Basic\Cnsts\WECHAT;


class WxPayService extends CommonService {

    public function __construct() {
        parent::__construct();

        Vendor('WxMpPayAPI.lib.WxPay#Api');
        Vendor('WxMpPayAPI.example.WxPay#JsApiPay');
    }

    /**
     * 生成微信支付订单
     * @param  int    $uid        [description]
     * @param  string $openid     [description]
     * @param  int    $order_type [description]
     * @param  int    $certain_id [description]
     * @return [type]             [description]
     */
    public function createOrder(int $uid, string $openid, int $order_type, int $certain_id) {
        /* @var \Basic\Service\PaymentService $payment_service */
        $payment_service = D('Basic/Payment', 'Service');
        list($errno, $errmsg, $res) = $payment_service->getPaymentAmount($uid, $order_type, USER_FINANCE::PAY_TYPE_WXPAY, $certain_id);
        if ( $errno != ERRNO::SUCCESS ) { // 出错
            return [$errno, $errmsg, $res];
        }

        $total_fee = $res['amount'];
        if ( $total_fee == 0 ) { // 支付金额为0
            return $payment_service->payZeroAmount($uid, $order_type, $certain_id);
        }

        if ( APP_DEBUG ) // 测试
            $total_fee = 0.01;

        // 到期时间
        $time_expire = time() + C('alipay')['timeout'] * 60;

        $data                   = C('alipay')['data_tpl_wx'];
        $data['out_trade_no']   = C('alipay')['out_trade_no'];
        $data['total_fee']      = $total_fee;
        $data['openid']         = $openid;
        $data['body']           .= $data['out_trade_no'];
        $data['time_expire']    = date("YmdHis", $time_expire);
        $data['notify_url']     = C('alipay')['notify_host'] . '/Wechat/PayCallback/wxpayConfirm';

        $wxpay_request = $this->buildRequest($data);
        if (!$wxpay_request) {
            return [ERRNO::CREATE_PAYMENT_ERROR, ERRNO::e(ERRNO::CREATE_PAYMENT_ERROR), ['error' => 'UnifiedOrderFail' ]];
        }
        // 添加订单记录
        $fields = $data;
        $fields['partner']      = \WxPayConfig::APPID;
        $fields['seller_id']    = \WxPayConfig::MCHID;
        $fields['op_type']      = USER_FINANCE::PAY_TYPE_WXPAY;
        $fields['uid']          = $uid;
        $fields['status']       = 10; // 10:已通知, 20:已确认
        $fields['order_type']   = $order_type;
        $fields['certain_id']   = $certain_id;
        $fields['expire_time']  = datetime($time_expire);
        $fields['device']       = I('server.HTTP_USER_AGENT'); // 用户使用的设备信息
        $fields['remark']       = !empty($res['money_arr']) ? json_encode($res['money_arr']) : NULL;
        $payment_id = $payment_service->addPayment($fields);
        if ( $payment_id < 0 ) {
            return [ERRNO::CREATE_PAYMENT_ERROR, ERRNO::e(ERRNO::CREATE_PAYMENT_ERROR), ['error' => $payment_id]];
        }

        return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), $wxpay_request];
    }

    /**
     * 生成签名后的订单信息
     * @param array $wxpay_data
     * @param null $from
     *
     * @return array
     */
    public function buildRequest($data) {
        $input = new \WxPayUnifiedOrder();
        $input->SetBody($data['body']);
        $input->SetAttach($data['body']);
        $input->SetOut_trade_no($data['out_trade_no']);
        $input->SetTotal_fee($data['total_fee']*100);
        $input->SetTime_start(date("YmdHis"));
        $input->SetTime_expire($data['time_expire']);
        $input->SetGoods_tag("");
        $input->SetNotify_url($data['notify_url']);
        $input->SetTrade_type("JSAPI");
        $input->SetOpenid($data['openid']);
        try {
            $result = \WxPayApi::unifiedOrder($input);
            Log::write('[WxPayService::buildRequest] result: '.print_r($result, TRUE), Log::INFO);
        } catch (Exception $e) {
            Log::write('[WxPayService::buildRequest] create unified order FAIL!', Log::ERR);
            return NULL;
        } 
        if ( $result['return_code'] != 'SUCCESS' || $result['result_code'] != 'SUCCESS'
            || empty($result['prepay_id']) ) {
            Log::write('[WxPayService::buildRequest] create unified order FAIL!', Log::ERR);
            return NULL;
        }
        $tools = new \JsApiPay();
        try {
            return json_decode($tools->GetJsApiParameters($result), true);
        } catch (Exception $e) {
            return FALSE;
        }
        
    }


    // 处理微信的异步通知数据
    public function confirmOrder($data) {
        // 验证数据
        $out_trade_no = $data['out_trade_no'];
        if ( !$out_trade_no ) {
            Log::write('[WxPayService::confirmOrder] empty out_trade_no!', Log::ERR);
            return FALSE;
        }

        /* @var \Basic\Model\PaymentModel $payment_model */
        $payment_model = D('Basic/Payment');
        $payment_model->startTrans();
        $rec = $payment_model->getByOutTradeNo($out_trade_no, TRUE);
        if ( empty($rec) ) {
            $payment_model->rollback();
            Log::write('[WxPayService::confirmOrder] payment order not exist! out_trade_no:'.$out_trade_no, Log::ERR);
            return FALSE;
        }

        if ( floatval($data['total_fee']/100) != $rec['total_fee'] ) {
            $payment_model->rollback();
            Log::write('[WxPayService::confirmOrder] parameter not match!', Log::ERR);
            return FALSE;
        }

        if ( $rec['status'] == 20 ) { // 订单已经确认
            $payment_model->rollback();
            return TRUE;
        }

        // 更新数据库记录
        $update_data = [
            'trade_no'      => $data['transaction_id'],
            'openid'        => $data['openid'],
            'status'        => 20,
            'bank_type'     => $data['bank_type'], // 付款银行
            'pay_time'      => datetime(strtotime($data['time_end'])),
        ];
        $payment_model->updateByOutTradeNo($out_trade_no, $update_data);
        $payment_model->commit();

        /* @var \Basic\Service\PaymentService $payment_service */
        $payment_service = D('Basic/Payment', 'Service');
        $payment_service->paySuccess($rec);

        return TRUE;
    }


    /**
     * 微信退款接口, 移动支付、PC网站支付通用
     * https://pay.weixin.qq.com/wiki/doc/api/native.php?chapter=9_4
     *
     * @param int   $payment_id 支付记录id
     *
     * @return int
     * -1   参数不正确
     * -2   支付订单信息不正确
     * -3   已退款
     * -4   订单还未完成支付
     * -10  退款失败
     * >=0  实际退款的金额
     */
    public function refundOrder($payment) {
        if ( empty($payment) ){
            return -1;
        }
        if ( $payment['op_type'] != USER_FINANCE::PAY_TYPE_WXPAY ){
            return -2;
        }
        if ( $payment['status'] == USER_FINANCE::PAY_STATUS_REFUNDED ){ // 已退款
            return -3;
        }
        if ( $payment['status'] != USER_FINANCE::PAY_STATUS_CONFIRMED ){// 未支付
            return -4;
        }
        $input = new \WxPayRefund();
        $input->SetOut_trade_no($payment['out_trade_no']);
        $input->SetTotal_fee($payment['total_fee']*100);
        $input->SetRefund_fee($payment['total_fee']*100);
        $input->SetOut_refund_no('refund_'.$payment['out_trade_no']);
        $input->SetOp_user_id(\WxPayConfig::MCHID);
        $response = \WxPayApi::refund($input);
        Log::write('[WxPayService::refundOrder] '.print_r($response, TRUE), Log::INFO);

        if ( $response["return_code"] == "SUCCESS" && $response["result_code"] == "SUCCESS") {
            /* @var \Basic\Model\PaymentModel $payment_model */
            $payment_model = D('Basic/Payment');
            $payment_model->updateById($payment['id'], ['status' => USER_FINANCE::PAY_STATUS_REFUNDED, 'refund_time' => datetime()]);
            return floatval($response['refund_fee']/100);
        } else { // 退款失败
            return -10;
        }
    }


}