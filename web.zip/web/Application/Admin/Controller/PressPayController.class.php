<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Model\ManagerModel;
use Admin\Model\RoleModel;
use Admin\Service\ManagerService;
use Admin\Service\RoleService;
use Admin\Service\UserService;
use Basic\Cnsts\AGENT_CHARGE;
use Admin\Service\PageService;
use Basic\Cnsts\DICT;
use Admin\Cnsts\MANAGER;
use Basic\Model\AgentModel;
use Basic\Model\ChargeCallAssignModel;
use Basic\Model\ChargeCallLogModel;
use Basic\Model\ChargeCallModel;
use Basic\Model\CSChargeCallLogModel;
use Basic\Model\CSChargeCallModel;
use Basic\Model\UserModel;
use Basic\Service\AgentChargeService;
use Basic\Service\AgentService;
use Basic\Service\ChargeCallService;
use Common\Cnsts\ERRNO;

class PressPayController extends AdminSessionController
{
    private $_pageSize = null;

    public function __construct()
    {
        parent::__construct();
        $this->_pageSize = 5;

        // 权限检查
        if (!\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id,
            \Admin\Cnsts\PRIVILEGE::CS_CHARGE_CALL)
        ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }

        // 分配任务权限
        $res = $this->_getManagerPrivilege();
        $this->assign('privilege', $res);
    }

    public function index() {

        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);

        /** @var ChargeCallAssignModel $charge_call_assign_model */
        $charge_call_assign_model = D('Basic/ChargeCallAssign', 'Model');

        // 会员属性获取
        $type = $this->_getMemberType();

        // 根据渠道获取管理员
        $manager_list = $this->_getManagerList();

        $search_expire_time = '';

        if (I('act') != 'delete') {
            $search_pc_type = I('search_pc_type');
            $search_app_type = I('search_app_type');

            $cond = [];

            // 默认时间（当月）
            $expire_time = substr(datetime(), 0, 7);
            $search_expire_time = I('search_expire_time');

            if (empty($search_expire_time)) {
                $search_expire_time = $expire_time;
            }

            $map['member_end_time'] = [['egt', $search_expire_time . '-01 00:00:00'], ['elt', $search_expire_time . '-30 23:59:59']];
            $map['pc_member_end_time'] = [['egt', $search_expire_time . '-01 00:00:00'], ['elt', $search_expire_time . '-30 23:59:59']];
            $map['_logic'] = 'OR';
            $cond['_complex'] = $map;
//        p($cond);
            switch ($search_pc_type) {
                case 0 :
                    $search_pc_type = '';
                    break;
                case 1 :
                    $search_pc_type = 1;
                    break;
                case 2 :
                    $search_pc_type = 0;
                    break;
            }

            if (!empty($search_pc_type)) {
                $cond['pc_is_inner'] = ['eq', $search_pc_type];
            }

            switch ($search_app_type) {
                case 0 :
                    $search_app_type = '';
                    break;
                case 1 :
                    $search_app_type = 1;
                    break;
                case 2 :
                    $search_app_type = 0;
                    break;
            }

            if (!empty($search_app_type)) {
                $cond['is_inner'] = ['eq', $search_app_type];
            }

            /** @var UserModel $user_model */
            $user_model = D('Basic/User', 'Model');
//            $ret = $user_model->searchUserList($cond, $curr_page, $per_page);

            // 把查询结果写入分配中间表
            $add_data = [];
            $rand = rand(100000, 999999);
            $total_data = $user_model->searchAllList($cond);
//            p($total_data);die;

            // 符合查询时间的用户id (array)
            $id_array = [];
            foreach ($total_data as $k=>$v) {
                $id_array[] = $v['id'];
            }

            // 在催缴表中获取已有数据的用户id
            $charge_id_array = [];
            /** @var ChargeCallModel $charge_call_model */
            $charge_call_model = D('Basic/ChargeCall', 'Model');
            $rule['charge_call.member_end_time'] = [['egt', $search_expire_time . '-01 00:00:00'], ['elt', $search_expire_time . '-30 23:59:59']];
            $rule['charge_call.pc_member_end_time'] = [['egt', $search_expire_time . '-01 00:00:00'], ['elt', $search_expire_time . '-30 23:59:59']];
            $rule['_logic'] = 'OR';
            $where['_complex'] = $rule;
            $where['charge_call.status'] = ['IN', ['doing', 'send_account', 'cs_work', 'done'] ];
            $charge_call_list = $charge_call_model->searchAllList($where);
            foreach ($charge_call_list as $k=>$v) {
                $charge_id_array[] = $v['uid'];
            }

            $last_uid = array_diff($id_array, $charge_id_array);

            // 最终获得用户数据（过滤掉已经被处理的部分）
            $user_info = [];
            for ($i=0; $i<count($total_data); $i++) {
                if (in_array($total_data[$i]['id'], array_merge($last_uid))) {
                    $user_info[] = $total_data[$i];
                }
            }

            for ($i=0; $i<count($user_info); $i++) {
                $add_data[$i]['manager_id'] = session('manager')['manager_id'];
                $add_data[$i]['session_id'] = session_id().$rand;
                $add_data[$i]['uid'] = $user_info[$i]['id'];
                $add_data[$i]['user_name'] = $user_info[$i]['user_name'];
                $add_data[$i]['telephone'] = $user_info[$i]['telephone'];
                $add_data[$i]['net_no'] = $user_info[$i]['net_no'];
                $add_data[$i]['member_end_time'] = $user_info[$i]['member_end_time'];
                $add_data[$i]['pc_member_end_time'] = $user_info[$i]['pc_member_end_time'];
                $add_data[$i]['search_expire_time'] = $search_expire_time;
                $add_data[$i]['is_inner'] = $user_info[$i]['is_inner'];
                $add_data[$i]['pc_is_inner'] = $user_info[$i]['pc_is_inner'];
            }
//        p($add_data);die;
            $charge_call_assign_model->addAll($add_data);

            // 读取中间表数据
            $search_where = [
                'session_id' => session_id().$rand,
            ];
            $ret = $charge_call_assign_model->searchAssignList($search_where, $curr_page, $per_page);
//p($ret);die;
            // 标记到期日期
            foreach ($ret['data'] as &$v) {
                if (($v['member_end_time'] > $search_expire_time.'-01 00:00:00') && ($v['member_end_time'] < $search_expire_time.'-30 23:59:59')) {
                    $v['member_type'] = 1;
                }
                if (($v['pc_member_end_time'] > $search_expire_time.'-01 00:00:00') && ($v['pc_member_end_time'] < $search_expire_time.'-30 23:59:59')) {
                    $v['pc_member_type'] = 1;
                }
            }
            $this->assign('session_rand', session_id().$rand);
        } else {
            // 读取中间表数据
            $search_where = [
                'session_id' => I('session_id'),
            ];
            $ret = $charge_call_assign_model->searchAssignList($search_where, $curr_page, $per_page);
//p($ret);die;

            // 标记到期日期
            foreach ($ret['data'] as &$v) {
                if (($v['member_end_time'] > $v['search_expire_time'].'-01 00:00:00') && ($v['member_end_time'] < $v['search_expire_time'].'-30 23:59:59')) {
                    $v['member_type'] = 1;
                }
                if (($v['pc_member_end_time'] > $v['search_expire_time'].'-01 00:00:00') && ($v['pc_member_end_time'] < $v['search_expire_time'].'-30 23:59:59')) {
                    $v['pc_member_type'] = 1;
                }
            }
            $search_expire_time = $ret['data'][0]['search_expire_time'];
            $this->assign('session_rand', I('session_id'));
        }

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();

        $this->assign(array(
           'title' => '分配',
           'type' => $type,
           'list' => $ret['data'],
           'manager_list' => $manager_list,
           'page_nav'         => $page_nav,
           'search_pc_type' => I('search_pc_type'),
           'search_app_type' => I('search_app_type'),
           'search_expire_time' => $search_expire_time,
        ));
        $this->display('allot_search');
    }

    // 分配页面结果移除
    public function delete() {
//        p(I(''));die;
        $page = explode('/', I('url'));
//        p(end($page));die;
        $act = I('act');
        $url = '';
        if (end($page) == 'index') {
            $url = '?session_id='.I('session_id') . '&act=' . $act;
        } else {
            if (strlen(end($page))>4) {
                $url = '/'.current(explode('?', end($page))).'?session_id='.I('session_id') . '&act=' . $act;
            } else {
                $url = '/'.end($page).'?session_id='.I('session_id') . '&act=' . $act;
            }
        }
        $id = I('id/d');

        if (!$id) {
            $this->admin_error('ID不正确！');

            return;
        }
        /** @var ChargeCallAssignModel $charge_call_assign_model */
        $charge_call_assign_model = D('Basic/ChargeCallAssign', 'Model');
        $charge_call_assign_model->delete($id);
// . '?session_id='.I('session_id') . '&act=' . $act
        redirect(U('admin/pressPay/index').$url);
    }

    /**
     * 分配任务
     */
    public function assignManager() {
//        p(I('ids'));die;
        /** @var ChargeCallAssignModel $charge_call_assign_model */
        $charge_call_assign_model = D('Basic/ChargeCallAssign', 'Model');
        $assign_list = $charge_call_assign_model->searchAllList(['session_id' => I('session_rand')]);
//p($assign_list);die;
        if (count($assign_list) < count(I('ids'))) {
            for ($i=0; $i<count($assign_list); $i++) {
                $fields = [
                    'worker' => I('ids')[$i],
                ];
                $charge_call_assign_model->update($assign_list[$i]['id'], $fields);
            }
        } else {
            for ($i=0; $i<count($assign_list); $i++) {
                $fields = [];
                for ($j=0; $j<count(I('ids')); $j++) {
                    if ($i % count(I('ids')) == $j) {
                        $fields = [
                            'worker' => I('ids')[$j],
                        ];
                    }
                }
                $charge_call_assign_model->update($assign_list[$i]['id'], $fields);
            }
        }

        $ids = implode(',', I('ids'));
//        p($ids);die;
        redirect(U('admin/pressPay/assignResult') . '?session_id='.I('session_rand') . '&ids=' . $ids);
    }

    // 分配结果接口
    public function assignResult() {
        // 根据渠道获取管理员
        $manager_list = $this->_getManagerList();
//p($manager_list);die;
        $assign_manager = [];
        for ($i=0; $i<count($manager_list); $i++) {
            if (in_array($manager_list[$i]['manager_id'], explode(',', I('ids')))) {
                $assign_manager[$i]['manager_id'] = $manager_list[$i]['manager_id'];
                $assign_manager[$i]['work_sn'] = $manager_list[$i]['work_sn'];
                $assign_manager[$i]['username'] = $manager_list[$i]['username'];
            }
        }
        $assign_manager = array_merge($assign_manager);

        /** @var ChargeCallAssignModel $charge_call_assign_model */
        $charge_call_assign_model = D('Basic/ChargeCallAssign', 'Model');
        for ($i=0; $i<count($assign_manager); $i++) {
            $where = [
                'session_id' => I('session_id'),
                'worker' => $assign_manager[$i]['manager_id'],
            ];
            $assign_manager[$i]['assign_count'] = $charge_call_assign_model->getAssignCount($where);
        }
//p($assign_manager);die;
        // 临时分配结果
        $cond = [
            'session_id' => I('session_id'),
        ];
        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);

        $ret = $charge_call_assign_model->searchAssignList($cond, $curr_page, $per_page);

        // 获取被分配人员姓名
        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');
        foreach ($ret['data'] as &$v) {
            $v['worker_name'] = $manager_service->get($v['worker'], $fields=null)['username'];
            if ($v['prev_worker'] == 0) {
                $v['prev_worker_name'] = '-';
            }
        }

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();
//        p($ret['data']);die;
        $this->assignAll(array(
            'title' => '分配结果',
            'manager_list' => $assign_manager,
            'assign_list' => $ret['data'],
            'page_nav'    => $page_nav,
            'ids' => I('ids'),
            'session_rand' => I('session_id'),
        ));
        $this->display('assign_result');
    }

    // 分配临时结果移除
    public function deleteAssign($id) {
        $id = (int)$id;
        if (!$id) {
            $this->admin_error('ID不正确！');

            return;
        }
        /** @var ChargeCallAssignModel $charge_call_assign_model */
        $charge_call_assign_model = D('Basic/ChargeCallAssign', 'Model');
        $charge_call_assign_model->delete($id);

        $this->admin_success('删除结果成功！');
    }

    // 取消分配结果
    public function cancelAssign($sid) {
        /** @var ChargeCallAssignModel $charge_call_assign_model */
        $charge_call_assign_model = D('Basic/ChargeCallAssign', 'Model');
        $where = [
            'session_id' => $sid,
        ];
        $charge_call_assign_model->updateInfo($where, ['worker' => 0]);

        redirect(U('admin/pressPay/chargeCallIndex'));
    }

    // 确定分配结果
    public function confirmAssign($sid) {
        /** @var ChargeCallAssignModel $charge_call_assign_model */
        $charge_call_assign_model = D('Basic/ChargeCallAssign', 'Model');
        $charge_call_list = $charge_call_assign_model->searchAllList(['session_id' => $sid]);
//        p($charge_call_list);die;

        // 将分配结果写入催缴表

        /** @var UserModel $user_model */
        $user_model = D('Basic/User', 'Model');


        $add_data = [];
        for ($i=0; $i<count($charge_call_list); $i++) {
            $add_data[$i]['uid'] = $charge_call_list[$i]['uid'];
            $user_info = $user_model->getUserInfoById($charge_call_list[$i]['uid'], $force_db = FALSE);
            $add_data[$i]['net_no'] = $user_info['net_no'];
            $add_data[$i]['user_name'] = $user_info['user_name'];
            $add_data[$i]['telephone'] = $user_info['telephone'];
            $add_data[$i]['agent_id'] = $user_info['channel_id'];
            $add_data[$i]['member_end_time'] = $charge_call_list[$i]['member_end_time'];
            $add_data[$i]['pc_member_end_time'] = $charge_call_list[$i]['pc_member_end_time'];
            $add_data[$i]['is_inner'] = $charge_call_list[$i]['is_inner'];
            $add_data[$i]['pc_is_inner'] = $charge_call_list[$i]['pc_is_inner'];
            $add_data[$i]['status'] = 'doing';
            $add_data[$i]['ac_name'] = '-'; // 上次套餐名称
            $add_data[$i]['worker'] = $charge_call_list[$i]['worker'];
            $add_data[$i]['assign_time'] = $charge_call_list[$i]['search_expire_time'].'-00 00:00:00';
            $add_data[$i]['allot_to_time'] = $charge_call_list[$i]['ctime'];
        }
        /** @var ChargeCallModel $charge_call_model */
        $charge_call_model = D('Basic/ChargeCall', 'Model');
        $charge_call_model->addAll($add_data);

        redirect(U('admin/pressPay/chargeCallIndex'));
    }

    // 催缴管理首页
    public function chargeCallIndex() {
        $search_net_no = I('net_no');
        $search_status = I('status');
        $search_expire_time = I('search_expire_time');

        if ( empty($search_status)) {
            $search_status = 'all';
        }
        // 权限控制
        $privilege = $this->_getManagerPrivilege();
//        p(session('manager'));die;
        $cond = $this->_getWhere('', $privilege, session('manager')['agent_id'], session('manager')['manager_id']);
//        p($cond);die;
//p($search_status);
        if (!empty($search_net_no)) {
            $cond['user.net_no'] = ['eq', $search_net_no];
        }
        if ($search_status != 'all') {
            $cond['charge_call.status'] = ['eq', $search_status];
        }
        if (!empty($search_expire_time)) {
            $map['charge_call.member_end_time'] = [['egt', $search_expire_time . '-01 00:00:00'], ['elt', $search_expire_time . '-30 23:59:59']];
            $map['charge_call.pc_member_end_time'] = [['egt', $search_expire_time . '-01 00:00:00'], ['elt', $search_expire_time . '-30 23:59:59']];
            $map['_logic'] = 'OR';
            $cond['_complex'] = $map;
        }

        // 获取催缴数据
        /** @var ChargeCallModel $charge_call_model */
        $charge_call_model = D('Basic/ChargeCall', 'Model');

//        p($cond);die;
        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        $ret = $charge_call_model->searchAssignList($cond, $curr_page, $per_page);
        $data = $charge_call_model->searchAllList($cond);

//        p($res);
        // 获取显示数据
        /** @var \Basic\Service\UserService $user_service */
        $user_service = D('Basic/User', 'Service');

        /** @var AgentService $agent_service */
        $agent_service = D('Basic/Agent', 'Service');

        /** @var ChargeCallService $charge_call_service */
        $charge_call_service = D('Basic/ChargeCall', 'Service');

        /** @var ChargeCallLogModel $charge_call_log_model */
        $charge_call_log_model = D('Basic/ChargeCallLog', 'Model');
//        p($ret['data']);die;
        foreach ($ret['data'] as &$v) {
            // 获取用户信息
            $user_info = $user_service->getUserInfo($v['uid'], $show_password = false );
            // 获取渠道名称
            $agent_info = $agent_service->getAgentById($user_info['channel_id']);
//            p($agent_info);die;
            $v['agent_name'] = $agent_info['name'];
            $v['status_name'] = $this->_getStatus()[$v['status']];

            // 获取记录、时间
            $where = [
                'cc_id' => $v['id'],
            ];
            $res = $charge_call_log_model->getNewLog($where);
//            p($res);die;
            if (strlen(current($res)['content']) < 15) {
                $str_content = current($res)['content'];
            } else {
                $str_content = substr(current($res)['content'], 0, 15).'...';
            }
            $v['call_content'] = $str_content;
            $v['call_time'] = current($res)['ctime'];

            // 获取套餐名称 (pc/app分开获取)
            $v['ac_name'] = $charge_call_service->getAcName ($v['uid'])['ac_name'];
            $v['ac_app_name'] = $charge_call_service->getAcName ($v['uid'])['ac_app_name'];

            // 标记到期日期
            if (($v['member_end_time'] > substr($v['assign_time'], 0, 7).'-01 00:00:00') && ($v['member_end_time'] < substr($v['assign_time'], 0, 7).'-30 23:59:59')) {
                $v['member_type'] = 1;
            }
            if (($v['pc_member_end_time'] > substr($v['assign_time'], 0, 7).'-01 00:00:00') && ($v['pc_member_end_time'] < substr($v['assign_time'], 0, 7).'-30 23:59:59')) {
                $v['pc_member_type'] = 1;
            }

            // 确定开单类型
            if ($v['member_type'] == 1 && $v['pc_member_type'] != 1) {
                $v['ws_type'] = 2;
            }
            if ($v['member_type'] != 1 && $v['pc_member_type'] == 1) {
                $v['ws_type'] = 4;
            }

            // 确定开单的优先条件
            $v['certain_id'] = $this->_getUserInfoToWs($v);
        }

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();

        // 获取催缴状态
        $status_list = $this->_getStatus();

        // 数量统计
        $this->_getCount($data);

//        p($ret['data']);die;
        $this->assignAll(array(
            'title' => '催缴管理',
            'net_no' => $search_net_no,
            'status' => $search_status,
            'search_expire_time' => $search_expire_time,
            'list' => $ret['data'],
            'status_list' => $status_list,
            'page_nav' => $page_nav,
        ));
        $this->display('charge_call');
    }

    // 详情
    public function detail($id) {
        C('TOKEN_ON', false);
        // 获取状态
        $status_arr = $this->_getStatus();
        // 不缴费原因
        $no_charge_arr = $this->_getNoChargeReason();
//        p($no_charge_arr);die;

        /** @var ChargeCallModel $charge_model */
        $charge_model = D('Basic/ChargeCall', 'Model');
        $charge_call_info = $charge_model->get($id, $fields = '');
//        p($charge_call_info);die;
        /** @var \Basic\Service\UserService $user_service */
        $user_service = D('Basic/User', 'Service');
        $user = $user_service->getUserInfo($charge_call_info['uid'], $show_password = false );
//        p($user['phone1']);die;
        // 拼接用户联系方式
        $tele_phone = [];

        if (!empty($user['telephone'])) {
            $tele_phone['telephone'] = $user['telephone'];
        }
        if (!empty($user['phone1'])) {
            $tele_phone['phone1'] = $user['phone1'];
        }
        if (!empty($user['phone2'])) {
            $tele_phone['phone2'] = $user['phone2'];
        }
        if (!empty($user['phone3'])) {
            $tele_phone['phone3'] = $user['phone3'];
        }
//p($tele_phone);die;
        $link_phone = $this->_getPhone($user);
//p($charge_call_info);die;
        if ($charge_call_info['call_status'] != 'not_user_telephone') {
            $charge_call_info['call_telephone'] = '';
        }
//        p($charge_call_info);die;
        $this->assignAll(array(
            'title' => '催缴详情',
            'cid' => $id,
            'user' => $user,
            'link_phone' => $link_phone,
            'status' => $charge_call_info['status'],
            'tele_phone' => $tele_phone,
            'status_arr' => $status_arr,
            'charge_call_info' => $charge_call_info,
            'no_charge_arr' => $no_charge_arr,
            'back_to_list_url' => $this->_refer,
        ));
        $this->display('detail');
    }

    public function doChargeCall() {
        C('TOKEN_ON', false);
//        p(I(''));die;
        //  修改催缴状态
        /** @var ChargeCallModel $charge_call_model */
        $charge_call_model = D('Basic/ChargeCall', 'Model');
        $charge_call_info = $charge_call_model->get(I('cid'), $fields = '');

        /** @var UserModel $user_model */
        $user_model = D('Basic/User', 'Model');
        $user_info = $user_model->getUserInfoById($charge_call_info['uid'], $force_db = FALSE);

        // 确定电话号码
        if (I('tele_phone') == 'not_user_telephone') {
            $call_phone = I('not_user_telephone');
        } else {
            $call_phone = $user_info[I('tele_phone')];
        }

        $data = [
            'status' => I('status'),
            'call_status' => I('tele_phone'),
            'call_content' => I('content'),
            'deny_reason' => I('no_charge'),
            'call_telephone' => empty($call_phone) ? 0 : $call_phone,
            'call_time' => datetime(),
        ];
        $charge_call_model->update(I('cid'), $data);

        /** @var ChargeCallLogModel $charge_call_log_model */
        $charge_call_log_model = D('Basic/ChargeCallLog', 'Model');

        // 查询最新一条记录，如果内容没有发生改变则本次不执行添加操作
        $log_info = $charge_call_log_model->getNewLog(['cc_id' => I('cid')]);
//        p($log_info);die;
        if ($log_info[0]['content'] != I('content') || $log_info[0]['telephone'] != $call_phone) {
            $fields = [
                'cc_id' => I('cid'),
                'manager_id' => session('manager')['manager_id'],
                'telephone' => empty($call_phone) ? 0 : $call_phone,
                'worker' => $charge_call_info['worker'],
                'content' => I('content'),
            ];
            $charge_call_log_model->add($fields);
        }

        redirect(U('admin/pressPay/chargeCallIndex'));
    }

    // 重新分配
    public function assignAgain() {
        // 确定当前页
        if (is_numeric(current(explode('?', end(explode('/', I('page_num'))))))) {
            $page_num = '/'.current(explode('?', end(explode('/', I('page_num')))));
        } else {
            $page_num = '/'.'1';
        }
        /** @var ChargeCallAssignModel $charge_call_assign_model */
        $charge_call_assign_model = D('Basic/ChargeCallAssign', 'Model');
        $where = [
            'id' => I('assign_id'),
            'session_id' => I('session_rand'),
        ];
        $info = [
            'worker' => I('id_s'),
        ];
        $charge_call_assign_model->updateInfo($where, $info);
        redirect(U('admin/pressPay/assignResult') .$page_num. '?session_id='.I('session_rand') . '&ids=' . I('ids'));
    }

    // 操作历史记录
    public function logList() {
        $cid = I('cid');
        $edit_page_key = I('edit_page_key/d', 1);
        $edit_page_key = $edit_page_key <= 1 ? 0 : $edit_page_key - 1;
        /** @var ChargeCallLogModel $charge_call_log_model */
        $charge_call_log_model = D('Basic/ChargeCallLog', 'Model');
        $cond = [
            'cc_id' => $cid,
        ];
        $log_list_total = $charge_call_log_model->getLogListCount($cond); // 总条数
        $page_total = ceil($log_list_total / $this->_pageSize); // 总页数
        $limit = $edit_page_key * $this->_pageSize . "," . $this->_pageSize;
        $join = 'left join admin_manager on charge_call_log.manager_id = admin_manager.manager_id';
        $log_list = $charge_call_log_model->getLogList($cond, $join, 'charge_call_log.id,charge_call_log.manager_id,charge_call_log.telephone,charge_call_log.content,charge_call_log.ctime, admin_manager.username', NULL, $limit);

        foreach ($log_list as &$v) {
            if ($v['telephone'] == 0) {
                $v['telephone'] = '-';
            }
        }
        return $this->ajaxResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), ['log_list' => $log_list, 'edit_page_key' => $edit_page_key + 1, 'page_total' => $page_total, ]);

    }

    // 全部催缴任务
    public function chargeCallAllIndex() {
        $search_net_no = I('net_no');
        $search_status = I('status');
        $search_expire_time = I('search_expire_time');
        $search_worker = I('worker');

        if ( empty($search_status)) {
            $search_status = 'all';
        }
        // 权限控制
        $privilege = $this->_getManagerPrivilege();
        $cond = $this->_getWhere('', $privilege, session('manager')['agent_id'], session('manager')['manager_id']);
//p($search_status);
        if (!empty($search_worker)) {
            $cond['charge_call.worker'] = ['eq', $search_worker];
        }
        if (!empty($search_net_no)) {
            $cond['user.net_no'] = ['eq', $search_net_no];
        }
        if ($search_status != 'all') {
            $cond['charge_call.status'] = ['eq', $search_status];
        }
        if (!empty($search_expire_time)) {
            $map['charge_call.member_end_time'] = [['egt', $search_expire_time . '-01 00:00:00'], ['elt', $search_expire_time . '-30 23:59:59']];
            $map['charge_call.pc_member_end_time'] = [['egt', $search_expire_time . '-01 00:00:00'], ['elt', $search_expire_time . '-30 23:59:59']];
            $map['_logic'] = 'OR';
            $cond['_complex'] = $map;
        }

        // 获取催缴数据
        /** @var ChargeCallModel $charge_call_model */
        $charge_call_model = D('Basic/ChargeCall', 'Model');

//        p($cond);
        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        $ret = $charge_call_model->searchAssignList($cond, $curr_page, $per_page);
        $data = $charge_call_model->searchAllList($cond);

        // 获取管理员
        $format_manager_list = [];
        $manager_list = $this->_getManagerList();
        for ($i=0; $i<count($manager_list); $i++) {
            $format_manager_list[$manager_list[$i]['manager_id']] = $manager_list[$i]['username'];
        }

//        p($res);
        // 获取显示数据
        /** @var \Basic\Service\UserService $user_service */
        $user_service = D('Basic/User', 'Service');

        /** @var AgentService $agent_service */
        $agent_service = D('Basic/Agent', 'Service');

        /** @var ChargeCallService $charge_call_service */
        $charge_call_service = D('Basic/ChargeCall', 'Service');

        foreach ($ret['data'] as &$v) {
            // 获取用户信息
            $user_info = $user_service->getUserInfo($v['uid'], $show_password = false );
            // 获取渠道名称
            $agent_info = $agent_service->getAgentById($user_info['channel_id']);
//            p($agent_info);die;
            $v['agent_name'] = $agent_info['name'];
            $v['status_name'] = $this->_getStatus()[$v['status']];
            $v['worker_name'] = $format_manager_list[$v['worker']];

            // 获取套餐名称
            $v['ac_name'] = $charge_call_service->getAcName ($v['uid'])['ac_name'];
            $v['ac_app_name'] = $charge_call_service->getAcName ($v['uid'])['ac_app_name'];

            // 标记到期日期
            if (($v['member_end_time'] > substr($v['assign_time'], 0, 7).'-01 00:00:00') && ($v['member_end_time'] < substr($v['assign_time'], 0, 7).'-30 23:59:59')) {
                $v['member_type'] = 1;
            }
            if (($v['pc_member_end_time'] > substr($v['assign_time'], 0, 7).'-01 00:00:00') && ($v['pc_member_end_time'] < substr($v['assign_time'], 0, 7).'-30 23:59:59')) {
                $v['pc_member_type'] = 1;
            }
        }

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();


        // 获取催缴状态
        $status_list = $this->_getStatus();

        // 数量统计
        $this->_getCount($data);

        $this->assignAll(array(
            'title' => '全部催缴任务',
            'net_no' => $search_net_no,
            'status' => $search_status,
            'worker' => $search_worker,
            'format_manager_list' => $format_manager_list,
            'search_expire_time' => $search_expire_time,
            'list' => $ret['data'],
            'status_list' => $status_list,
            'page_nav' => $page_nav,
        ));
        $this->display('charge_call_all');
    }


    public function _getPhone($user) {
        $link_phone = '';
        $telephone = !empty($user['telephone']) ?$user['telephone'].'/':$user['telephone'];
        $phone1 = !empty($user['phone1']) ?$user['phone1'].'/':$user['phone1'];
        $phone2 = !empty($user['phone2']) ?$user['phone2'].'/':$user['phone2'];
        $phone3 = !empty($user['phone3']) ?$user['phone3'].'/':$user['phone3'];

        $link_phone = $telephone.$phone1.$phone2.$phone3;
        return $link_phone;
    }

    // 催缴数据统计
    public function _getCount($data) {
        $total_num = count($data); // 总数
        $doing_num = 0;
        $send_account_num = 0;
        $cs_work_num = 0;
        $no_charge_num = 0;
        $done_num = 0;
        for ($i=0; $i<$total_num; $i++) {
            switch ($data[$i]['status']) {
                case 'doing':
                    $doing_num ++;
                    break;
                case 'send_account' :
                    $send_account_num ++;
                    break;
                case 'cs_work' :
                    $cs_work_num ++;
                    break;
                case 'deny_charge':
                    $no_charge_num ++;
                    break;
                case 'done':
                    $done_num ++;
                    break;
            }
        }

        $this->assignAll(array(
            'total_num' => $total_num,
            'doing_num' => $doing_num,
            'send_account_num' => $send_account_num,
            'cs_work_num' => $cs_work_num,
            'no_charge_num' => $no_charge_num,
            'done_num' => $done_num,
        ));

    }


    protected function _getWhere($str, $privilege, $agent_id = null, $worker = null) {
        if (!empty($str)) {
            if ($privilege == 'YES') {
                if ($agent_id == 0) {
                    $where = [
                        'charge_call.status' => $str,
                    ];
                } else {
                    $where = [
//                        'user.channel_id' => $agent_id,
                        'charge_call.worker' => $worker,
                        'charge_call.status' => $str,
                    ];
                }
            } else {
                if ($agent_id == 0) {
                    $where = [
                        'charge_call.worker' => $worker,
                        'charge_call.status' => $str,
                    ];
                } else {
                    $where = [
//                        'user.channel_id' => $agent_id,
                        'charge_call.worker' => $worker,
                        'charge_call.status' => $str,
                    ];
                }
            }
        } else {
            if ($privilege == 'YES') {
                if ($agent_id == 0) {
                    $where = [];
                } else {
                    $where = [
//                        'user.channel_id' => $agent_id,
                        'charge_call.worker' => $worker,
                    ];
                }
            } else {
                if ($agent_id == 0) {
                    $where = [
                        'charge_call.worker' => $worker,
                    ];
                } else {
                    $where = [
//                        'user.channel_id' => $agent_id,
                        'charge_call.worker' => $worker,
                    ];
                }
            }
        }

        return $where;
    }

    protected function _getManagerPrivilege() {
        // 获取管理员的权限
        /** @var RoleService $role_service */
        $role_service = D('Admin/Role', 'Service');
        if (session('manager')['role_id'] == 0) {
            return 'YES';
        } else {
            $privilege_list = $role_service->getPrivilegeList(session('manager')['role_id']);
            foreach ( $privilege_list as $v) {
                if ($v['id'] == 16) {
                    return 'YES';
                } else {
                    return 'NO';
                }
            }
        }

    }

    public function test() {
        p(session('manager'));
    }

    // 根据用户的网号、用户名、手机号进行开单(确定优先级)
    public function _getUserInfoToWs($info) {
        if (!empty($info['net_no'])) {
            $certain_id = $info['net_no'];
        } else {
            if (!empty($info['account'])) {
                $certain_id = $info['account'];
            } else {
                $certain_id = $info['telephone'];
            }
        }
        return $certain_id;
    }

    public function _getManagerList() {
        // 根据渠道获取管理员
        /** @var ManagerModel $manager_model */
        $manager_model = D('Admin/Manager', 'Model');

        if (session('manager')['agent_id'] == 0) {
            $where = [];
        } else {
            $where = [
                'agent_id' => session('manager')['agent_id'],
                'is_delete' => 'N',
            ];
        }
        $manager_list = $manager_model->getList($where);
        return $manager_list;
    }

    public function _getMemberType() {
        $type = [
            '0' => '全部',
            '1' => '正式会员',
            '2' => '内测会员',
        ];
        return $type;
    }

    public function _getStatus() {
        $arr = [
            'doing' => '催缴中',
            'send_account' => '已发账号',
            'cs_work' => '已开单',
            'deny_charge' => '不缴费',
            'done' => '已完成',
        ];
        return $arr;
    }

    public function _getNoChargeReason() {
        $arr = [
            'next_month' => '下月续费',
            'not_connect' => '联系不到',
            'un_sure' => '不确定',
            'not_use' => '不使用',
            'not_logistics' => '不做物流',
            'fixed_resource' => '有固定资源',
            'customer_field' => '客户在外地',
            'other_net_no' => '有其他网号',
            'ticket_reason' => '发票原因',
        ];
        return $arr;
    }

}