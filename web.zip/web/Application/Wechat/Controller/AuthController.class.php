<?php
namespace Wechat\Controller;

use Basic\Cnsts\WECHAT;
use Basic\ModelU\CenterModel;
use Common\Cnsts\ERRNO;
use Basic\ModelU\UserModel;
use Basic\Service\UuserService;
use Gaoming13\WechatPhpSdk\Api;
class AuthController extends WechatController {

    protected $user_info;
    protected $user_id;
    public $appid = 'wxcd5d96a12f7c53d4';
    public $appSecret = '48588aa71a3876b24111ddf58126163a';
    public $mch_id = '1520784241';
    public $key = 'qwertyuiopasdfghjklzxcvbnmQWERTY';
    private $template_id = '1KOvnMjsRh0O55ZlXzKRy6xRa8PTc6VQpcRq8o8zBJg';
    function __construct(){
        parent::__construct();
        $config = array(
            'appId' => $this->appid,
            'appSecret' => $this->appSecret,
            'get_access_token' => function () {
                $tmp = explode(',', file_get_contents("/tmp/token"));
                $token = json_encode(['access_token' => $tmp[0], 'expires_in' => $tmp[1]]);
                return $token;

            },
            'save_access_token' => function ($token) {
                $token = json_decode($token);
                file_put_contents("/tmp/token", $token->access_token . ',' . $token->expires_in);

            }
        );
        $this->api = new Api($config);
    }

    public function getOpenId($code){

        $code=I("code");
        if(empty($code)){
            $this->doResponse(-1,"缺少参数code");
        }
        if(S($code)){
          return S($code);
        }

        $openid=$this->api->codeToOpenid($code);
        if(!isset($openid['openid'])){
            $this->doResponse(-1,"获取openid错误");
        }
        S($code,$openid['openid']);
        $this->doResponse(0,"ok",["openid"=>$openid['openid'],'unionid'=>$openid['unionid']]);

    }
    public function test(){
        $enData="/TDw3zsZqS+HaoOOBqycuOdAxWUGxkuAcOw0fR3tMwvzZEYyT4904YE8RhaEDU8paGF3QOvG7sX2ksgbL+XeUNPllIiWAqEtvsbyhqO6r8axvKmSwh7hXoVNEeSW6ay70NdnXWRaTHaXdri2OTKZdiIV1SYyqOGqlbNO7sFTDgyypApI2Gt3sZPkqaY0KZ+Rh/PDebMwOfUgfLsmpJd1YAKPxIXUw17kRevhObBJmGDkpyobBRGIt321oLUw61LtYzc70qbMNTWSH3vtWD16yAOUDCqXwHwdskgzXw+BsGJd9wNYMlP58M3+4iAlRnMAwLRVoT30p1VYOOOMI0hAbCURxm4n8OAJ7GlObVr+SAQd31N7+INEjPpnAd+63eUR7/xW51H5x9uQ2PxfGVDQSH4s1sSbaQmN5DfWt/DrMyS8hNGPdyHOqWdGvm/AYJZ4Ftln2m2JFMnoUHSk8wW0Xw==";

         $openid=$this->api->decryptData("2NnBc/15vZtlLgVHzeFR9w==",$enData,"9p9DUpYsPr7hFqOVhGytlw==");
        p($openid);
    }

    public function login(){
        $user=  new UuserService();
        if(empty(I('openid'))||empty(I('nickname'))|| empty(I('avatar'))){
            $this->doResponse(-1,"缺少参数");
        }
        $where=['openid'=>I('openid')];
        $uid=$user->getUserInfoByFactory($where);
        $info=$user->getUserByOpenid(I('openid'));

        $data=[
            'openid'=>$info['openid'],
            'name'=> $info['name'],
            'avatar'=>$info['avatar'],
            'unionid'=>$info['unionid'],
            'userType'=>$info['role'],
            'bind_uid'=>$info['bind_uid'],
        ];
        if(!$uid){
            $data=['openid'=>I('openid'),
                'name'=>I('nickname'),
                'avatar'=>I('avatar'),
                'unionid'=>I('unionid'),
            ];
            $uid= $user->addUser($data);
            $data['userType']=0;
            $data['bind_uid']=0;
        }else{
            (new CenterModel("u_user"))->update($uid,['unionid'=>I('unionid')]);
        }
        $this->doResponse(0,"用户登录成功",$data);
    }


}