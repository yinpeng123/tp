<?php
namespace Admin\Controller;

use Admin\Model\ManagerModel;
use Common\Cnsts\ERRNO;
use Basic\Cnsts\DICT;
use Basic\Cnsts\CS_WORK_SHEET;
use Basic\Cnsts\AGENT_CHARGE;
use Admin\Service\PageService;

class CSWorkSheetController extends AdminSessionController {
    /** @var \Basic\Model\CSWorkSheetModel _ws_model */
    private $__ws_model = NULL;
    private $__ws_log_model = NULL;

    /** @var \Basic\Service\CSWorkSheetService _ws_service */
    private $__ws_service = NULL;

    public function __construct() {
        parent::__construct();

        // 权限检查
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::CS_WORK_SHEET) ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }

        $this->__ws_model = D('Basic/CSWorkSheet');
        $this->__ws_log_model = D('Basic/CSWorkSheetLog');

        $this->__ws_service = D('Basic/CSWorkSheet', 'Service');
    }

    /**
     * 获取返回列表的链接
     * @param $refer
     */
    protected function _backToListUrl($refer) {
        if ( !empty($refer) && 0 === stripos($refer, U('CSWorkSheet/index', '', '', TRUE)) ) {
            return $refer;
        } else {
            return U('CSWorkSheet/index', '', '', TRUE);
        }
    }

    /**
     * 图片上传
     */
    public function ajaxUploadImage() {
        $key = key($_FILES);
        if ( empty($_FILES[$key]) || $_FILES[$key]['size'] == 0 ) {
            die("{}");
        }

        $root_dir = C('IMAGE_PATH')['certificate'];
        $sub_dir = day();
        $image_info = array();
        list($errcode, $errmsg) = uploadImage($key, $root_dir, $sub_dir, $image_info, 'certificate');
        if ( $errcode != ERRNO::SUCCESS ) {
            echo json_encode(['error' => $errmsg]);
            exit;
        }

        $res = [
            'initialPreview' => [ imageUrl($image_info) ],
            'initialPreviewConfig' => [
                [
                    'type'      => 'image',
                    'caption'   => $image_info['name'],
                    'size'      => $_FILES[$key]['size'],
                    'url'       => '/CSWorkSheet/ajaxDeleteImage',
                    'key'       => null,
                    'extra'     => null,
                ],
            ]
        ];

        $id = I('id/d', 0);
        if ( !$id ) { // 新增记录
            $field = I('field');
            $upload_key = I('upload_key');
            if ( !$field || !$upload_key ) {
                die(json_encode(['error' => '参数 field 和 upload_key 不能为空！']));
            }

            // 从缓存中获取临时保存的上传图片信息
            $image_arr = S($upload_key);
            if ( !$image_arr ) {
                $image_arr = [$image_info];
            } else {
                $image_arr[] = $image_info;
            }

            // 更新缓存
            S($upload_key, $image_arr, 1800);

            $res['initialPreviewConfig'][0]['key'] = count($image_arr) - 1;
            $res['initialPreviewConfig'][0]['extra'] = ['field' => $field, 'upload_key' => $upload_key];

        } else { // 编辑记录
            $field = I('field');

            $sheet = $this->__ws_model->getById($id);
            if ( !$sheet ) {
                //$this->admin_error('工单不存在！');
                return;
            }

            $ad_pics = [];
            if ( strlen($sheet['ad_pics']) > 2 ) {
                $ad_pics = json_decode($sheet['ad_pics'], TRUE);
            }
            $ad_pics[] = $image_info;
            $res['initialPreviewConfig'][0]['key'] = count($ad_pics) - 1;
            $res['initialPreviewConfig'][0]['extra'] = ['field' => $field, 'id' => $id];

            // 更新数据记录
            $this->__ws_model->updateById($id, ['ad_pics' => json_encode($ad_pics)]);
        }

        echo json_encode($res);
        return;
    }

    /**
     * 删除广告图片
     */
    public function ajaxDeleteImage() {
        $id = I('id/d', 0);
        if ( !$id ) { // 新增记录
            $field = I('field');
            $upload_key = I('upload_key');
            if ( !$field || !$upload_key ) {
                die(json_encode(['error' => '参数 field 和 upload_key 不能为空！']));
            }

            // 从缓存中获取临时保存的上传图片信息
            $image_arr = S($upload_key);
            if ( !$image_arr ) {
                die('{}');
            }

            // 从记录中删除图片
            $key = I('key/d', 0);
            unset($image_arr[$key]);

            // 更新缓存
            S($upload_key, $image_arr, 1800);

        } else { // 编辑记录
            $sheet = $this->__ws_model->getById($id);
            if ( !$sheet ) {
                die(json_encode(['error' => '工单不存在！']));
            }

            $ad_pics = [];
            if ( strlen($sheet['ad_pics']) > 2 ) {
                $ad_pics = json_decode($sheet['ad_pics'], TRUE);
            }

            // 从记录中删除图片
            $key = I('key/d', 0);
            unset($ad_pics[$key]);

            // 更新记录
            $this->__ws_model->updateById($id, ['ad_pics' => json_encode($ad_pics)]);
        }

        echo '{}';
    }

    /**
     * 格式化图片预览数据
     */
    protected function _formatImagePreview($image_str) {
        if ( strlen($image_str) > 2 ) {
            $image_arr = json_decode($image_str, TRUE);
            //print_r($image_arr);

            // fileinput上传
//            $res = ['initialPreview' => [], 'initialPreviewConfig' => []];
//            foreach ( $image_arr as $k => $i ) {
//                $res['initialPreview'][] = imageUrl($i);
//                $res['initialPreviewConfig'][] = [
//                    'type'      => 'image',
//                    'caption'   => $i['name'],
//                    'size'      => filesize(imageFilePath($i)),
//                    'url'       => '/CSWorkSheet/ajaxDeleteImage',
//                    'key'       => $k,
//                ];
//            }

            // 新版图片上传控件
            $res = [];
            foreach ( $image_arr as $k => $i ) {
                $i['url'] = imageUrl($i);
                $i['extension'] = get_file_ext($i['name']);
                $res[] = $i;
            }
        } else {
            $res = [];
        }

        return $res;
    }


    public function index() {
        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);

        $cond = $this->prepareSearchCond(array('search_id', 'search_telephone', 'search_account', /*'search_net_no',*/ 'search_type',
            'search_status', 'search_charging', 'search_creator', 'search_reviewer', 'search_ctime_from', 'search_ctime_to',
            'search_ftime_from', 'search_ftime_to', 'search_agent_id', 'search_ticket_flag', 'search_referer', 'search_worker'));

        // 完成日期默认为当天
        if ( empty($cond['search_ftime_from']) ) {
            $cond['search_ftime_from'] = day();
        }
        if ( empty($cond['search_ftime_to']) ) {
            $cond['search_ftime_to'] = day();
        }

        /* @var \Admin\Model\UserModel $user_model */
        $user_model = D('User');
        /* @var \Basic\Model\AgentModel $agent_model */
        $agent_model = D('Basic/Agent');
        /* @var \Admin\Model\ManagerModel $manager_model */
        $manager_model = D('Manager');

        /* 非全国网用户只能查看其所在渠道的工单 */
        if ( $this->_manager['agent_id'] > 0 ) {
            $cond['search_agent_id'] = $this->_manager['agent_id'];

            // 渠道名称
            $manager_agent = $agent_model->getAgentById($this->_manager['agent_id']);
            $this->assign('search_agent_name', $manager_agent['name']);
        }
        $ret = $this->__ws_model->searchWorkSheet($cond, $curr_page, $per_page);
        //print_r($ret);

        foreach ( $ret['data'] as $i => &$r ) {
            if ( $this->_manager['agent_id'] > 0 ) {
                $r['agent_name'] = $manager_agent['name'];
            } else {
                if ( $r['type'] == 7 ) { // 渠道代理费
                    $agent = $agent_model->getAgentById($r['agent_id']);
                } else {
                    $agent = $agent_model->getAgentById($r['channel_id']);
                }
                $r['agent_name'] = $agent['name'];
            }

            $r['status_text'] = CS_WORK_SHEET::WS_STATUS_ARR[ $r['status'] ];
            if ( $r['status'] == 'undo' )
                $r['status_text_color'] = 'my-red';
            else if ( $r['status'] == 'finish' )
                $r['status_text_color'] = 'my-green';
            else if ( $r['status'] == 'close' || $r['status'] == 'deny' )
                $r['status_text_color'] = 'my-yellow';
            else
                $r['status_text_color'] = '';

            $r['type_text'] = CS_WORK_SHEET::WS_TYPE_ARR[ $r['type'] ];
            $r['charging_text'] = $this->_formatCharging($r['charging']);

            $creator = $manager_model->getManagerById($r['creator']);
            $r['creator_name'] = $creator['realname'];

            if ( $r['reviewer'] ) {
                $reviewer = $manager_model->getManagerById($r['reviewer']);
                $r['reviewer_name'] = $reviewer['realname'];
            } else {
                $r['reviewer_name'] = '';
            }

            if ( $r['referer'] ) {
                $referer = $manager_model->get($r['referer']);
                $r['referer_name'] = $referer['realname'];
            } else {
                $r['referer_name'] = '';
            }

            if ( $r['worker'] ) {
                $worker = $manager_model->get($r['worker']);
                $r['worker_name'] = $worker['realname'];
            } else {
                $r['worker_name'] = '';
            }

            // 对于已完成的工单，增加“作废”功能（从完成时间开始，两天内作废功能有效）
            // 并且同产品的工单只能撤销最后一个工单
            if ( $r['channel_id'] == C('AGENT_HAERBIN_ID') || $r['channel_id'] == C('AGENT_MUDANJIANG_ID')
                || $this->_manager_id == 1) {
                $r['undo'] = $this->_canUndo($r) ? 1 : 0;
            }
        }

        // 统计收入
        $ws_service = new \Basic\Service\CSWorkSheetService();
        $stats_income = $ws_service->statsIncome($cond);
        //p($stats_income);
        $stats_text = $ws_service->strStatsIncome($stats_income);
        //echo $stats_text;

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav = $page_service->show();

        // 管理员列表
        $manager_model = D('Manager');
        $manager_list = $manager_model->getAllManagerList('manager_id, realname');

        // 渠道列表
        $agent_model = D('Basic/Agent');
        $agent_list = $agent_model->getAllAgentList();

        $this->assignAll($cond);
        $this->assignAll([
            'title'         => '工单列表',
            'type_arr'      => CS_WORK_SHEET::WS_TYPE_ARR,
            'status_arr'    => CS_WORK_SHEET::WS_STATUS_ARR,
            'charging_arr'  => CS_WORK_SHEET::WS_CHARGING_ARR,
            'list'          => $ret['data'],
            'stats_text'    => $stats_text,
            'page_nav'      => $page_nav,
            'manager_list'  => $manager_list,
            'agent_list'    => $agent_list,
        ]);
        $this->display('work_sheet_list');
    }

    protected function _formatCharging($str) {
        $charging_arr = json_decode($str, TRUE);
        $charging_text = '';
        foreach ( $charging_arr as $k => $i ) {
            if ( $k )
                $charging_text .= ", "; //"<br>\n";

            $charging_text .= CS_WORK_SHEET::WS_CHARGING_ARR[ $i['source'] ].': '.$i['amount'];
        }
        return $charging_text;
    }

    // 获取操作的文字描述
    protected function _getBtnActText($btn_act) {
        switch ($btn_act) {
            case 'save':
                return '编辑工单';
            case 'finish':
                return '提交审核工单';
            case 'deny':
                return '否单';
            case 'approve':
                return '审核通过工单';
            case 'disapprove':
                return '审核不通过工单';
            case 'close':
                return '结束工单';
            default:
                return '编辑工单';
        }
    }

    // 根据工单类型显示内容模板
    public function include_content_file(&$sheet) {
        if ( isset($_GET['type']) && $_GET['type'] > 0 ) // 使用url参数优先级更好
            $sheet['type'] = $_GET['type'];

        //$this->assign('type', $type);
        if ( $sheet['type'] == 1 || $sheet['type'] == 2 || $sheet['type'] == 3 || $sheet['type'] == 4 || $sheet['type'] == 5 ) { // app, pc, 三证
            $this->display('include_general');
        } elseif ( $sheet['type'] == 6 ) { // 广告
            $sheet['ad_usage'] = 'new';
            $this->assign('sheet', $sheet);

            $this->assignAll([
                'ad_category_arr'   => AGENT_CHARGE::AD_CATEGORY_ARR,
                'ad_pos_arr'        => AGENT_CHARGE::AD_POS_ARR,
                'ad_type_arr'       => CS_WORK_SHEET::WS_AD_TYPE_ARR,
            ]);
            $this->display('include_advertise');
        }
    }

    /**
     * 添加工单
     */
    public function add() {
        $type = I('type/d', 1);
        if ( $type == 7 ) { // 渠道代理费
            $this->_addAgent();
            return;
        }

        $sheet = [
            'id'            => 0,
            'uid'           => 0,
            'type'          => $type,
            'finish_day'    => day(),
            'start_day'     => day(),
            'charge_day'    => day(),
            'ticket_status' => 0,
            'remark'        => '',
        ];

        $certain_type = I('certain_type', 1);
        $certain_id = I('certain_id', '');

        // 管理员列表
        $manager_model = D('Manager');
        $manager_list = $manager_model->getAllManagerList('manager_id, realname');
        //print_r($manager_list);exit;

        // 图片上传key,用于添加记录时需要临时保存上传的文件
        $ad_pics_upload_key = uniqid('ad_pics_');

        $this->assignAll(array(
            'act'           => 'add',
            'form_action'   => '/CSWorkSheet/doEdit',
            'title'         => '添加工单',
            'sheet'         => $sheet,
            'certain_type'  => $certain_type,
            'certain_id'    => $certain_id,
            'type_arr'      => CS_WORK_SHEET::WS_TYPE_ARR,
            'charging_arr'  => CS_WORK_SHEET::WS_CHARGING_ARR,
            'manager_list'  => $manager_list,
            'ad_pics_upload_key'=> $ad_pics_upload_key,
            'back_to_list_url'  => $this->_backToListUrl($this->_refer),
        ));
        $this->display('work_sheet_info');
    }

    // 添加渠道代理费工单
    protected function _addAgent() {
        $sheet = [
            'id'            => 0,
            'type'          => 7,
            'finish_day'    => day(strtotime('+1 day')),
            'start_day'     => day(),
            'remark'        => '',
        ];

        $certain_id = I('certain_id', '');

        // 渠道列表
        $agent_model = D('Basic/Agent');
        $agent_list = $agent_model->getAllAgentList('id,name');

        // 管理员列表
        $manager_model = D('Manager');
        $manager_list = $manager_model->getAllManagerList('manager_id, realname');
        //print_r($manager_list);exit;

        $this->assignAll(array(
            'act'           => 'add',
            'form_action'   => '/CSWorkSheet/doEditAgent',
            'title'         => '添加工单',
            'sheet'         => $sheet,
            'certain_id'    => $certain_id,
            'type_arr'      => CS_WORK_SHEET::WS_TYPE_ARR,
            'charging_arr'  => CS_WORK_SHEET::WS_CHARGING_ARR,
            'agent_list'    => $agent_list,
            'manager_list'  => $manager_list,
            'back_to_list_url'  => $this->_backToListUrl($this->_refer),
        ));
        $this->display('work_sheet_agent');
    }

    /**
     * 工单是否已关闭, 即不可修改状态
     * @param $sheet
     */
    protected function _isClosed($sheet) {
        return in_array($sheet['status'], ['finish', 'close', 'undo']) ? 1 : 0;
    }

    /**
     * 编辑工单
     */
    public function edit($id) {
        $id = (int)$id;
        if ( !$id ) {
            $this->admin_error('ID不正确！');
            return;
        }

        //$sheet = $this->__ws_model->getById($id);
        $sheet = $this->__ws_model->get($id);
        if ( !$sheet ) {
            $this->admin_error('工单不存在！');
            return;
        }

        if ( $sheet['type'] == 7 ) { // 渠道代理费
            $this->_editAgent($sheet);
            return;
        }

        $sheet['status_text'] = CS_WORK_SHEET::WS_STATUS_ARR[ $sheet['status'] ];

        // 订单是否关闭, 已关闭的订单不可编辑
        $sheet['is_closed'] = $this->_isClosed($sheet);

        $type = I('type/d');
        if ( $type ) {
            $sheet['type'] = $type;
        }

        // 用户信息
        $user_model = D('User');
        $user = $user_model->getUserById($sheet['uid']);
        $sheet['user'] = $user;

        $certain_id = I('certain_id', '');
        if ( !$certain_id ) {
            $certain_id = !empty($user['telephone']) ? $user['telephone'] :
                (!empty($user['net_no']) ? $user['net_no'] : $user['account']);
        }

        //$sheet['days'] = (strtotime($sheet['end_day']) - strtotime($sheet['start_day'])) / (24*3600) + 1;
        //$sheet['price2'] = $sheet['price'] + $sheet['price_cs'];

        $sheet['charging_arr'] = strlen($sheet['charging']) > 2 ? json_decode($sheet['charging'], TRUE) : [];
        //$sheet['remark_txt'] = htmlspecialchars_decode($sheet['remark']);

        // 计费套餐信息
        /* @var \Basic\Model\AgentChargeModel $ac_model */
        $ac_model = D('Basic/AgentCharge');
        $ac_info = $ac_model->getAgentChargeInfo($sheet['ac_id']);
        if ( $sheet['type'] == 6 ) { // 广告
            $sheet['ad_category'] = $ac_info['ad_category'];
            $sheet['ad_usage'] = $ac_info['ad_usage'];
            $sheet['ad_pos'] = $ac_info['ad_pos'];
            if ( strlen($ac_info['days']) > 2 ) {
                $sheet['days'] = json_decode($ac_info['days'], TRUE);
            } else {
                $sheet['days'] = ['year' => 0, 'month' => 0, 'day' => 0];
            }

            if ( strlen($sheet['ad_type']) > 2 ) {
                $sheet['ad_type_arr'] = json_decode($sheet['ad_type'], TRUE);
            } else {
                $sheet['ad_type_arr'] = [];
            }

            // 显示预览图片
            $ad_pics_arr = $this->_formatImagePreview($sheet['ad_pics']);
            $this->assign('ad_pics_arr', $ad_pics_arr);
        }

        // 对于待回访状态的工单，客服只有查看的权限，操作权只放开给主管客服
        if ( $sheet['status'] == 'wait_review' ) {
            $sheet['priv_exam'] = \Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::CS_WORK_SHEET_EXAM) ? 1 : 0;
        }

        // 管理员列表
        $manager_model = new ManagerModel();
        $manager_list = $manager_model->getAllManagerList('manager_id, realname');
        //print_r($manager_list);exit;

        if ( $sheet['creator'] ) {
            $creator = $manager_model->get($sheet['creator']);
            $sheet['creator_name'] = $creator['realname'];
        }
        if ( $sheet['referer'] ) {
            $referer = $manager_model->getManagerById($sheet['referer']);
            $sheet['referer_name'] = $referer['realname'];
        }
        if ( $sheet['worker'] ) {
            $worker = $manager_model->getManagerById($sheet['worker']);
            $sheet['worker_name'] = $worker['realname'];
        }

        // 工单处理日志
        $log_list = $this->__ws_log_model->getList($id, 'id DESC');
        //print_r($sheet);exit;

        $this->assignAll(array(
            'act'           => 'edit',
            'form_action'   => '/CSWorkSheet/doEdit',
            'title'         => '编辑工单',
            'sheet'         => $sheet,
            'certain_id'    => $certain_id,
            'type_arr'      => CS_WORK_SHEET::WS_TYPE_ARR,
            'charging_arr'  => CS_WORK_SHEET::WS_CHARGING_ARR,
            'manager_list'  => $manager_list,
            'log_list'      => $log_list,
            'back_to_list_url'  => $this->_backToListUrl($this->_refer),
        ));
        $this->display('work_sheet_info');
    }

    /**
     * 编辑渠道工单
     */
    protected function _editAgent($sheet) {
        $sheet['status_text'] = CS_WORK_SHEET::WS_STATUS_ARR[ $sheet['status'] ];

        $certain_id = $sheet['agent_id'];
        $new_certain_id = I('certain_id', '');
        if ( $new_certain_id ) {
            $certain_id = $new_certain_id;
        }

        $sheet['charging_arr'] = strlen($sheet['charging']) > 2 ? json_decode($sheet['charging'], TRUE) : [];

        // 渠道列表
        $agent_model = D('Basic/Agent');
        $agent_list = $agent_model->getAllAgentList('id,name');

        // 管理员列表
        $manager_model = D('Manager');
        $manager_list = $manager_model->getAllManagerList('manager_id, realname');
        //print_r($manager_list);exit;

        // 工单处理日志
        $log_list = $this->__ws_log_model->getList($sheet['id']);

        $this->assignAll(array(
            'act'           => 'edit',
            'form_action'   => '/CSWorkSheet/doEditAgent',
            'title'         => '编辑工单',
            'sheet'         => $sheet,
            'certain_id'    => $certain_id,
            'type_arr'      => CS_WORK_SHEET::WS_TYPE_ARR,
            'charging_arr'  => CS_WORK_SHEET::WS_CHARGING_ARR,
            'agent_list'    => $agent_list,
            'manager_list'  => $manager_list,
            'log_list'      => $log_list,
            'back_to_list_url'  => $this->_backToListUrl($this->_refer),
        ));
        $this->display('work_sheet_agent');
    }

    // 工单的新状态
    protected function _getNewStatus($id, $btn_act = '', $old_sheet = []) {
        if ( $id == 0 ) {
            return 'new';
        }

        if ( $btn_act == 'save' ) { // 待回访、否单状态下的工单，点击保存，不改变工单状态
            if ( $old_sheet['status'] == 'wait_review' || $old_sheet['status'] == 'deny' )
                return $old_sheet['status'];
        }

        if ( $btn_act == 'finish' )
            return 'wait_review';
        if ( $btn_act == 'deny' )
            return 'deny';
        if ( $btn_act == 'approve' )
            return 'finish';
        if ( $btn_act == 'close' )
            return 'close';

        return 'doing';
    }

    // 检查账号注册来源与工单类型是否匹配
    protected function _check_register_source($register_source, $type) {
        $ret = TRUE;
        if ( $type == 1 || $type == 2 ) {
            if ( !($register_source == 2 || $register_source == 3) ) {
                $ret = FALSE;
            }
        }
        if ( $type == 3 || $type == 4 ) {
            if ( !($register_source == 1 || $register_source == 3) ) {
                $ret = FALSE;
            }
        }
        return $ret;
    }

    public function doEdit() {
        // 验证令牌
        $this->checkFormToken();

        $id = I('id/d', 0);
        $btn_act = I('btn_act', 'save');
        if ( $id ) {
            $old_sheet = $this->__ws_model->getById($id);
        } else {
            $old_sheet = [];
        }
        $status = $this->_getNewStatus($id, $btn_act, $old_sheet);

        $type = I('type/d', 1);

        $uid = I('uid/d');
        if ( !$uid ) {
            $this->admin_error('用户不存在！');
            return;
        }
        $user_model = D('Basic/User');
        $user = $user_model->getUserInfoById($uid);

        // 检查账号来源是否与套餐匹配
        if ( !$this->_check_register_source($user['register_source'], $type) ) {
            $this->admin_error('账号注册来源与工单类型不匹配！');
            return;
        }

        // 哈尔滨渠道新建工单的状态设置为: wait_review
        if ( in_array($user['channel_id'], [C('AGENT_HAERBIN_ID'), C('AGENT_MUDANJIANG_ID')])
            && $status == 'new' ) {
            $status = 'wait_review';
        }

        $finish_day = I('finish_day');
        if ( !$finish_day ) {
            $this->admin_error('计划完成时间不能为空！');
            return;
        }

        $ticket_status = I('ticket_status/d', 0);
        $ticket_id = 0;
        $mail_id = 0;
        if ( $ticket_status ) {
            $ticket_id = I('ticket_id/d', 0);
            $mail_id = I('mail_id/d', 0);
        }

        $ac_id = I('ac_id/d', 0);
        if ( !$ac_id ) {
            $this->admin_error('计费套餐不能为空！');
            return;
        }
        $ac_model = D('Basic/AgentCharge');
        $ac_info = $ac_model->getAgentChargeInfo($ac_id);
        if ( !$ac_info ) {
            $this->admin_error('计费套餐不存在！');
            return;
        }

        //$price = I('price/f');
        $price_cs = I('price_cs/f');
        //$price_real = I('price_real/f');

        $charging = I('charging');

        $fields = [
            'type'          => $type,
            'uid'           => $uid,
            'product_id'    => CS_WORK_SHEET::getProductIdByType($type),
            'status'        => $status,
            'finish_day'    => $finish_day,
            'ticket_id'     => $ticket_id,
            'ticket_status' => $ticket_status,
            'mail_id'       => $mail_id,
            'ac_id'         => $ac_id,
            'price'         => $ac_info['price'],
            'price_cs'      => $price_cs,
            'price_real'    => $ac_info['price'] + $price_cs,
            'charging'      => $charging ? json_encode($charging) : '',
            'charge_day'    => I('charge_day') ?: NULL,
            'referer'       => I('referer'),
            'worker'        => I('worker'),
            'remark'        => I('remark'),
        ];
        //print_r($fields);exit;

        if ( $type <= 4 ) { // app, pc 信息
            // 新建、或者未处于关闭状态的工单需要设置开始、结束时间
            if ( !$id || !$this->_isClosed($old_sheet) ) {
                $this->__ws_service->setStartEndDay($type, $user, $ac_info, I('start_day'), $fields);
            }
            //print_r($fields);exit;

        } elseif ( $type == 6 ) { // 广告
            $ad_type = I('ad_type');
            if ( is_array($ad_type) && !empty($ad_type) ) {
                $fields['ad_type'] = json_encode($ad_type);
            } else {
                $fields['ad_type'] = '';
            }

            $fields['ad_content']   = I('ad_content');
            $fields['ad_url_flag']  = I('ad_url_flag/d', 0);
            $fields['ad_url']       = I('ad_url');
            $fields['ad_url_text']  = I('ad_url_text');
            $fields['ad_contact']   = I('ad_contact');
            $fields['ad_phone']     = I('ad_phone');

            // 链接图片
            $ad_pics = I('ad_pics');
            if ( !empty($ad_pics) && is_array($ad_pics) ) {
                $pic_arr = [];
                foreach ( $ad_pics as $i ) {
                    $pic_arr[] = imageUrlToArray($i);
                }
                $fields['ad_pics'] = json_encode($pic_arr);
            }
        }

        if ( $id ) { // 编辑
            $fields['mender'] = $this->_manager_id;
            $fields['mtime'] = datetime();

            // 工单废除
            if ( $btn_act == 'close' ) {
                $this->_doClose($old_sheet, $fields);
                return;
            }

            // 工单完成, 更新实际完成时间
            if ( $btn_act == 'approve' ) {
                // 权限检查
                if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::CS_WORK_SHEET_EXAM) ) {
                    $this->admin_error('你无权执行该操作！', U('index/index', '', ''));
                    exit;
                }

                $fields['finish_day_real'] = day();

                // 保存计费的关键信息
                $fields['addition'] = $this->__ws_service->setAgentChargeInfo($ac_info, $old_sheet['addition']);
            }

            //print_r($fields);
            $this->__ws_model->updateById($id, $fields);

            // 添加操作日志
            /* @var \Admin\Service\CSWorkSheetService $ws_service */
            $ws_service = D('CSWorkSheet', 'Service');
            $ws_service->addOperLog(array(
                'manager_id'    => $this->_manager_id,
                'object_id'     => $id,
                'action'        => 'update',
                'desc'          => "编辑工单：$id",
            ));

            $this->addWorkSheetLog($id, $status, $this->_manager_id, I('remark'));

            // 处理工单完成后的关联操作
            if ( $btn_act == 'approve' ) {
                // 读取更新后的工单信息
                $sheet = $this->__ws_model->getById($id);

                /* @var \Basic\Service\CSWorkSheetService $basic_ws_service */
                $basic_ws_service = D('Basic/CSWorkSheet', 'Service');
                $ret = $basic_ws_service->approveWorkSheetPostHandler($sheet, $ac_info);
                if ( $ret[0] != \Common\Cnsts\ERRNO::SUCCESS ) { // 出错
                    $this->admin_error($ret[1]);
                    return;
                }
            }

            if ( $btn_act == 'finish' || $btn_act == 'approve' ) { // 提交审核后跳转到列表页
                $this->admin_success('提交审核成功！', $this->_backToListUrl($this->_refer));
            } else {
                $this->admin_success('编辑工单成功！');
            }

        } else { // 新建
            // app/pc工单保存用户当前的会员起始时间
            if ( $type == 1 || $type == 2 ) {
                $addtion['member_start_time'] = $user['member_start_time'];
                $addtion['member_end_time'] = $user['member_end_time'];
                $fields['addition'] = json_encode($addtion);
            }
            if ( $type == 3 || $type == 4 ) {
                $addtion['pc_member_start_time'] = $user['pc_member_start_time'];
                $addtion['pc_member_end_time'] = $user['pc_member_end_time'];
                $fields['addition'] = json_encode($addtion);
            }

            $fields['creator'] = $this->_manager_id;
            $fields['ctime'] = datetime();
            //print_r($fields);

            // 处理广告图片上传数据
            if ( I('ad_pics_upload_key') ) {
                $ad_pics_arr = S(I('ad_pics_upload_key'));
                if ( !empty($ad_pics_arr) )
                    $fields['ad_pics'] = json_encode($ad_pics_arr);
            }

            $id = $this->__ws_model->add($fields);

            // 添加操作日志
            $ws_service = D('CSWorkSheet', 'Service');
            $ws_service->addOperLog(array(
                'manager_id'    => $this->_manager_id,
                'object_id'     => $id,
                'action'        => 'add',
                'desc'          => "添加工单：$id",
            ));

            $this->addWorkSheetLog($id, $status, $this->_manager_id, I('remark'));

//            echo $this->backurl('CSWorkSheet/edit/'.$id)."\n";
//            echo U($this->backurl('CSWorkSheet/edit/'.$id), '', '');
            $this->admin_success('添加工单成功！', $this->backurl('/CSWorkSheet/edit/'.$id));
        }
    }

    // 执行添加、编辑渠道工单
    public function doEditAgent() {
        //p($_POST);exit;

        // 验证令牌
        $this->checkFormToken();

        $id = I('id/d', 0);
        $btn_act = I('btn_act', 'save');
        if ( $id ) {
            $old_sheet = $this->__ws_model->getById($id);
        } else {
            $old_sheet = [];
        }
        $status = $this->_getNewStatus($id, $btn_act, $old_sheet);

        $type = I('type/d', 1);

        $agent_id = I('certain_id/d');
        if ( !$agent_id ) {
            $this->admin_error('渠道不存在！');
            return;
        }

        $finish_day = I('finish_day');
        if ( !$finish_day ) {
            $this->admin_error('计划完成时间不能为空！');
            return;
        }

        $ticket_status = I('ticket_status/d', 0);
        $ticket_id = 0;
        $mail_id = 0;
        if ( $ticket_status ) {
            $ticket_id = I('ticket_id/d', 0);
            $mail_id = I('mail_id/d', 0);
        }

        $price_real = I('price_real/f');

        $charging = I('charging');

        $fields = [
            'type'          => $type,
            'agent_id'      => $agent_id,
            'status'        => $status,
            'finish_day'    => $finish_day,
            'ticket_id'     => $ticket_id,
            'ticket_status' => $ticket_status,
            'mail_id'       => $mail_id,
            'price_real'    => $price_real,
            'charging'      => $charging ? json_encode($charging) : '',
            'charge_day'    => I('charge_day') ?: NULL,
            'remark'        => I('remark'),
        ];
        //var_dump($fields);exit;

        if ( $id ) { // 编辑
            $fields['mender'] = $this->_manager_id;
            $fields['mtime'] = datetime();
            //print_r($fields);

            $this->__ws_model->updateById($id, $fields);

            // 添加操作日志
            $ws_service = D('CSWorkSheet', 'Service');
            $btn_act_text = $this->_getBtnActText($btn_act);
            $ws_service->addOperLog(array(
                'manager_id'    => $this->_manager_id,
                'object_id'     => $id,
                'action'        => $btn_act,
                'desc'          => $btn_act_text."：$id",
            ));

            $this->addWorkSheetLog($id, $status, $this->_manager_id, I('remark'));

            // 添加开票记录
            if ( $ticket_id > 0 && $btn_act == 'approve' ) {
                $agent_model = D('Basic/Agent');
                $agent_info = $agent_model->getAgentById($agent_id);

                $data = [
                    'ticket_amount' => $price_real,
                    'username'      => $agent_info['director'],
                    'phone'         => $agent_info['mobile'],
                    'work_no'       => $id,
                    'mail_id'       => $mail_id,
                    'ticket_info_id'    => 0,
                    'agent_invoice_id'  => $ticket_id,
                    'type'          => $type,
                ];

                $ticket_service = D('Ticket', 'Service');
                $finance_ticket_id = $ticket_service->addTicket($data);

                // 更新工单记录
                $this->__ws_model->updateById($id, ['finance_ticket_id' => $finance_ticket_id]);
            }

            $this->admin_success($btn_act_text.'成功！');

        } else { // 新建
            $fields['creator'] = $this->_manager_id;
            $fields['ctime'] = datetime();
            //print_r($fields);

            $id = $this->__ws_model->add($fields);

            // 添加操作日志
            $ws_service = D('CSWorkSheet', 'Service');
            $ws_service->addOperLog(array(
                'manager_id'    => $this->_manager_id,
                'object_id'     => $id,
                'action'        => 'add',
                'desc'          => "添加工单：$id",
            ));

            $this->addWorkSheetLog($id, $status, $this->_manager_id, I('remark'));

            $this->admin_success('添加工单成功！', U('CSWorkSheet/edit/'.$id, '', ''));
        }
    }


    // 生成日志内容
    public function addWorkSheetLog($ws_id, $status, $mender, $remark, $extra = NULL) {
        $manager_model = D('Manager');

        if ( $status == 'assign' ) { // 指派
            $status_text = '指派';
            $content = '【' . $status_text . '】';

            $worker = $manager_model->getManagerById($extra['worker']);
            $content .= $this->_manager['realname'].' 指派给 '.$worker['realname'].'。';

        } elseif ( $status == 'disapprove' ) { // 审核不通过
            $status_text = '审核不通过';
            $content = '【' . $status_text . '】';
        } else {
            $status_text = CS_WORK_SHEET::WS_STATUS_ARR[$status];

            $content = '【' . $status_text . '】';
            if ( $status == 'new' ) {
                $content .= '新建工单。';
            }
        }

        // 备注
        $content .= '备注：' . (!empty($remark) ? $remark : '无') . '。';

        $manager_model = D('Manager');
        $mender_info = $manager_model->getManagerById($mender);
        $content .= '操作人：' . $mender_info['realname'];

        $fields = [
            'ws_id'     => $ws_id,
            'mender'    => $mender,
            'content'   => $content,
            'ctime'     => datetime(),
        ];

        $ws_log_model = D('Basic/CSWorkSheetLog');
        $ws_log_model->add($fields);
    }


    // 指派工单
    public function doAssign() {
        // 验证令牌
        $this->checkFormToken();

        //p($_POST);
        $id = I('id/d');
        $worker = I('worker/d');
        if ( !$id || !$worker ) {
            $this->admin_error('参数不正确！');
            return;
        }

        $sheet = $this->__ws_model->getById($id);
        if ( $sheet['status'] != 'wait_review' && $sheet['status'] != 'deny' ) {
            $this->admin_error('工单状态不正确！');
            return;
        }

        $fields = [
            'status'        => 'doing',
            'mender'        => $this->_manager_id,
            'worker'        => $worker,
            'mtime'         => datetime(),
        ];
        //print_r($fields);
        $this->__ws_model->updateById($id, $fields);

        // 添加操作日志
        $ws_service = D('CSWorkSheet', 'Service');
        $ws_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => $id,
            'action'        => 'assign',
            'desc'          => "指派工单：$id",
        ));

        $this->addWorkSheetLog($id, 'assign', $this->_manager_id, I('remark', ''), ['worker' => $worker]);

        $this->admin_success('指派工单成功！');
    }

    // 审核通过 (已废弃!!!)
    protected function _doApprove() {
        // 验证令牌
        $this->checkFormToken();

        // 权限检查
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::CS_WORK_SHEET_EXAM) ) {
            $this->admin_error('你无权执行该操作！', U('index/index', '', ''));
            exit;
        }

        $id = I('id/d');
        if ( !$id ) {
            $this->admin_error('ID不正确！');
            return;
        }

        $sheet = $this->__ws_model->getById($id);
        if ( $sheet['status'] != 'wait_review' && $sheet['status'] != 'deny' ) {
            $this->admin_error('工单状态不正确！');
            return;
        }

        $fields = [
            'status'        => 'finish',
            'mender'        => $this->_manager_id,
            'mtime'         => datetime(),
        ];
        //print_r($fields);
        $this->__ws_model->updateById($id, $fields);

        // 添加操作日志
        $ws_service = D('CSWorkSheet', 'Service');
        $ws_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => $id,
            'action'        => 'approve',
            'desc'          => "审核通过工单：$id",
        ));

        $this->addWorkSheetLog($id, 'finish', $this->_manager_id, I('remark', ''), []);

        $this->admin_success('审核工单成功！');
    }

    /**
     * 审核不通过
     */
    public function doDisapprove() {
        // 验证令牌
        $this->checkFormToken();

        // 权限检查
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::CS_WORK_SHEET_EXAM) ) {
            $this->admin_error('你无权执行该操作！', U('index/index', '', ''));
            exit;
        }

        $id = I('id/d');
        if ( !$id ) {
            $this->admin_error('ID不正确！');
            return;
        }

        $sheet = $this->__ws_model->getById($id);
        if ( $sheet['status'] != 'wait_review' && $sheet['status'] != 'deny' ) {
            $this->admin_error('工单状态不正确！');
            return;
        }

        $reason = I('reason');
        $fields = [
            'status'        => 'doing',
            'reason'        => $reason,
            'worker'        => $sheet['creator'],
            'mender'        => $this->_manager_id,
            'mtime'         => datetime(),
        ];
        //print_r($fields);
        $this->__ws_model->updateById($id, $fields);

        // 添加操作日志
        $ws_service = D('CSWorkSheet', 'Service');
        $ws_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => $id,
            'action'        => 'disapprove',
            'desc'          => "审核不通过工单：$id",
        ));

        $this->addWorkSheetLog($id, 'disapprove', $this->_manager_id, $reason, []);

        $this->admin_success('审核不通过工单！', $this->_backToListUrl($this->_refer));
    }

    /**
     * 关闭工单(工单废弃)
     * @param array $old_sheet 工单更新前的数据
     * @param array $fields 工单更新数据
     */
    protected function _doClose($old_sheet, $fields) {
        // 权限检查
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::CS_WORK_SHEET_EXAM) ) {
            $this->admin_error('你无权执行该操作！', U('index/index', '', ''));
            exit;
        }

        if ( $old_sheet['status'] != 'wait_review' && $old_sheet['status'] != 'deny' ) {
            $this->admin_error('工单状态不正确！');
            return;
        }

        $this->__ws_model->updateById($old_sheet['id'], $fields);

        // 添加操作日志
        /* @var \Admin\Service\CSWorkSheetService $ws_service */
        $ws_service = D('CSWorkSheet', 'Service');
        $ws_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => $old_sheet['id'],
            'action'        => 'close',
            'desc'          => "关闭工单：".$old_sheet['id'],
        ));

        $this->addWorkSheetLog($old_sheet['id'], 'close', $this->_manager_id, I('remark', ''), []);

        $this->admin_success('关闭工单成功！', $this->_backToListUrl($this->_refer));
    }

    // 工单是否可以作废
    public function _canUndo($sheet) {
        // 仅针对PC/APP产品类型工单
        // 从完成时间开始，两天内作废功能有效
        if ( $sheet['type'] >= 1 && $sheet['type'] <= 4
            && $sheet['status'] == 'finish' && $sheet['finish_day_real']
            && time() - strtotime($sheet['finish_day_real']) < 3*24*3600 ) {
            // 并且想同产品的工单只能撤销最后一个工单
            $count = $this->__ws_model->countByCond(['uid' => $sheet['uid'], 'product_id' => $sheet['product_id'],
                     'status' => 'finish', 'id' => array('gt', $sheet['id'])]);
            //echo $count."\n";
            if ( $count )
                return FALSE;

            /* 如果当时工单递交了发票申请，撤回时要判断下该工单对应的发票申请单的状态。
                如果为已申请，则可以撤回，同时开票申请改为已取消，开票申请中涉及到的工单和订单号均释放出来，标记成可开票的
                如果为已开票、已寄送、已完成，则在撤回时，提示该工单已开发票不可撤回。不允许撤回工单。
            */
            if ( $sheet['finance_ticket_id'] ) {
                $ticket = (new \Basic\Service\TicketService())->getTicketById($sheet['finance_ticket_id']);
                if ( $ticket['ticket_status'] >= DICT::TICKET_STATUS_OPENED && $ticket['ticket_status'] <= DICT::TICKET_STATUS_COMPLETE )
                    return FALSE;
            }

            return TRUE;
        } else {
            return FALSE;
        }
    }


    // 作废工单
    public function undo() {
        // 验证令牌
        $this->checkFormToken();

        // 权限检查
//        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::CS_WORK_SHEET_EXAM) ) {
//            $this->admin_error('你无权执行该操作！', U('index/index', '', ''));
//            exit;
//        }

        $id = I('id/d');
        if ( !$id ) {
            $this->admin_error('ID不正确！');
            return;
        }

        $sheet = $this->__ws_model->getById($id);
        if ( !$this->_canUndo($sheet) ) {
            $this->admin_error('工单状态不正确！');
            return;
        }

        $fields = [
            'status'        => 'undo',
            'mender'        => $this->_manager_id,
            'mtime'         => datetime(),
        ];
        //print_r($fields);
        $this->__ws_model->updateById($id, $fields);

        if ( $sheet['type'] >= 1 && $sheet['type'] <= 4 ) {
            // 1. 回撤会员到期时间
            $addition = @json_decode($sheet['addition'], TRUE);
            if ( empty($addition) ) {
                $this->admin_error('附加信息不完整，恢复会员到期时间失败！');
                return;
            }

            $user_model_m = new \Basic\Model\UserModel('master');
            if ( $sheet['type'] == 1 || $sheet['type'] == 2 ) {
                $user_model_m->update($sheet['uid'],
                    [
                        'member_start_time' => $addition['member_start_time'],
                        'member_end_time'   => $addition['member_end_time'],
                    ]
                );
            }

            if ( $sheet['type'] == 3 || $sheet['type'] == 4 ) {
                $user_model_m->update($sheet['uid'],
                    [
                        'pc_member_start_time' => $addition['pc_member_start_time'],
                        'pc_member_end_time'   => $addition['pc_member_end_time'],
                    ]
                );
            }

            // 2. 同步信息
            /** @var \Basic\Service\WLSendService $wl_send_service */
            $wl_send_service = D('Basic/WLSend','Service');
            $wl_send_service->syncUser($sheet['uid']);


            // 3. 作废交易记录
            /* @var \Basic\Model\FinanceModel $finance_model */
            $finance_model = D('Basic/Finance');
            $finance_model->updateByCond(['ws_id' => $sheet['id']], ['status' => -1]);

            // 4. 删除开票记录
            if ( $sheet['finance_ticket_id'] > 0 ) {
                $ticket_model = D('Ticket');
                //$ticket_model->updateTicket(['id' => $sheet['finance_ticket_id']], ['status' => 0]);
                $ticket_model->updateTicket(['id' => $sheet['finance_ticket_id']], ['ticket_status' => DICT::TICKET_STATUS_CANCEL]);
            }
        }

        // 添加操作日志
        $ws_service = D('CSWorkSheet', 'Service');
        $ws_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => $id,
            'action'        => 'undo',
            'desc'          => "作废工单：$id",
        ));

        $this->addWorkSheetLog($id, 'undo', $this->_manager_id, I('remark', ''), []);

        $this->admin_success('作废工单成功！');
    }


    // 添加广告管理记录
    protected function _insertAdvertise($data) {
        $fields = [
            'ws_id'         => $data['id'],
            'uid'           => $data['uid'],
            'ad_category'   => $data['ad_category'],
            'ad_pos'        => $data['ad_pos'],
            'status'        => 'new',
            'ad_contact'    => $data['ad_contact'],
            'ad_phone'      => $data['ad_phone'],
            'referer'       => $data['referer'],
            //'ad_start_day'  => $data['ad_start_day'],
            'ad_content'    => $data['ad_content'],
            'ad_type'       => $data['ad_type'],
            'ad_url_flag'   => $data['ad_url_flag'],
            'creator'       => $data['creator'],
            'ctime'         => datetime(),
        ];

        $ad_model = D('Basic/Advertise');
        return $ad_model->add($fields);
    }

    /**
     * 导出工单记录
     */
    public function exportWorkSheet() {
        // 先查看交易记录总数是否超过导出限制
        $max_export_record_num = 10000;
        $per_page = 1000;
        $curr_page = 1;
        $cond = $this->prepareSearchCond(array('search_ftime_from', 'search_ftime_from'));

        // 完成日期默认为当天
        if ( empty($cond['search_ftime_from']) ) {
            $cond['search_ftime_from'] = day();
        }
        if ( empty($cond['search_ftime_to']) ) {
            $cond['search_ftime_to'] = day();
        }

        /* 非全国网用户只能查看其所在渠道的工单 */
        if ( $this->_manager['agent_id'] > 0 ) {
            $cond['search_agent_id'] = $this->_manager['agent_id'];
        }
        $ret = $this->__ws_model->searchWorkSheet($cond, $curr_page, $per_page);
        if ( $ret['count'] > $max_export_record_num ) {
            $this->admin_error('导出记录数超过上限，请缩小时间范围分批导出！');
            return;
        }

        $filename = '工单记录.csv';

        // 输出Excel文件头
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        header('Cache-Control: max-age=0');

        // 打开PHP文件句柄，php://output 表示直接输出到浏览器
        $fp = fopen('php://output', 'a');

        // 输出Excel列名信息
        $head = array('ID', '所属渠道', '账号', '网号', '手机号(APP用户名）', '姓名', '工单类型', '服务项目', '所选套餐', '收款来源', '创建日期', '完成日期', '发展人部门', '发展人', '原到期日期', '到期日期', '应收金额', '实收金额', '被指派人部门', '被指派人', '是否开票', '套餐天数', '备注');
        foreach ($head as $i => $v) {
            // CSV的Excel支持GBK编码，一定要转换，否则乱码
            $head[$i] = iconv('utf-8', 'gb2312', $v);
        }
        // 将数据通过fputcsv写到文件句柄
        fputcsv($fp, $head);

        // 输出数据内容
        while (1) {
            $this->_doExportWorkSheet($fp, $ret['data']);
            if ( $curr_page >= $ret['page_number'] )
                break;

            $ret = $this->__ws_model->searchWorkSheet($cond, ++$curr_page, $per_page);
        }

        // 关闭句柄
        fclose($fp);
    }


    /**
     * 分批导出工单记录
     * @param $fp
     * @param $data
     */
    protected function _doExportWorkSheet($fp, $data) {
        $user_model = new \Basic\Model\UserModel('slave', TRUE);
        $agent_model = new \Basic\Model\AgentModel('slave', TRUE);
        $ac_model = new \Basic\Model\AgentChargeModel('slave', TRUE);
        $manager_model = new \Admin\Model\ManagerModel('slave', TRUE);

        foreach ( $data as $k => $i ) {
            $user = $user_model->get($i['uid'], 'id, user_name, telephone, account, net_no, channel_id');
            $agent = $agent_model->get($user['channel_id']);
            $ac = $ac_model->get($i['ac_id']);

            // 发展人
            if ( $i['referer'] > 0 )
                $referer = $manager_model->get($i['referer']);

            // 被指派人
            if ( $i['workder'] > 0 )
                $worker = $manager_model->get($i['worker']);

            // 原到期时间
            $old_end_day = '';
            // 套餐天数
            $ac_days = '';
            if ( strlen($i['addition']) > 2 ) {
                $addition = json_decode($i['addition'], TRUE);
                if ( $i['type'] == 1 || $i['type'] == 2 )
                    $old_end_day = substr($addition['member_end_time'], 0, 10);
                elseif ( $i['type'] == 3 || $i['type'] == 4 )
                    $old_end_day = substr($addition['pc_member_end_time'], 0, 10);

                $days_arr = json_decode($addition['days'], TRUE);
                $ac_days = sprintf("%d年%d月%d天", $days_arr['year'], $days_arr['month'], $days_arr['day']);
            }

//            $head = array('ID', '所属渠道', '账号', '网号', '手机号(APP用户名）', '姓名', '工单类型', '服务项目', '所选套餐', '收款来源', '创建日期', '完成日期', '发展人部门', '发展人', '原到期日期', '到期日期', '应收金额', '实收金额', '被指派人部门', '被指派人', '是否开票', '套餐天数', '备注');

            $row = [
                $i['id'],
                conv_to_gb2312($agent['name']),
                $user['account'],
                $user['net_no'],
                $user['telephone'],
                conv_to_gb2312($user['user_name']),
                conv_to_gb2312(CS_WORK_SHEET::WS_TYPE_ARR[ $i['type'] ]),
                '', // 服务项目
                conv_to_gb2312($ac['name']),
                conv_to_gb2312($this->_formatCharging($i['charging'])),
                $i['ctime'],
                $i['finish_day'],
                !empty($referer['department']) ? conv_to_gb2312(\Admin\Cnsts\MANAGER::DEPARTMENT_ARR[ $referer['department'] ]) : '',
                !empty($referer) ? conv_to_gb2312($referer['username']) : '',
                $old_end_day,
                $i['end_day'],
                $i['price'],
                $i['price_real'],
                !empty($worker['department']) ? conv_to_gb2312(\Admin\Cnsts\MANAGER::DEPARTMENT_ARR[ $worker['department'] ]) : '',
                !empty($worker) ? conv_to_gb2312($worker['username']) : '',
                conv_to_gb2312($i['ticket_status'] ? '是' : '否'),
                conv_to_gb2312($ac_days),
                conv_to_gb2312($i['remark']),
            ];
            fputcsv($fp, $row);
        }
    }




}