<?php
namespace Admin\Controller;


class DebugController extends AdminSessionController {

    public function __construct() {
        parent::__construct();
        if ( !APP_DEBUG ) {
            redirect(UU('index/home'));
            exit;
        }
    }

    public function zy() {
        $product = '["1","2","3","4","5","6","7","8","9","10","11","13","14","15","16","17","18","19","20","21","22","24","25","26","27","28","29","30","32","33","34"]';
        $product_arr = json_decode($product);
        if ( !in_array("2", $product_arr) )
            $product_arr[] = "2";
        if ( !in_array("12", $product_arr) )
            $product_arr[] = "12";
        //$product_arr = array_merge($product_arr, ["2", "12"]);
        sort($product_arr, SORT_NUMERIC);
        //$product_arr = array_unique($product_arr, SORT_NUMERIC);
//        $product_arr[] = "2";
//        $product_arr[] = "12";
        p($product_arr);
        echo json_encode($product_arr);
        exit;

        /* @var \Admin\Service\UserService $user_service */
        $user_service = D('User', 'Service');
        $certain_id = 13900010234;
        $res = $user_service->searchUserProfile($certain_id);
        print_r($res);
        exit;

        (new \Basic\Service\WLSendService())->syncUser(98);
        exit;

        // 发送push消息
        /* @var \Basic\Service\CSWorkSheetService $ws_service */
        $ws_service = D('Basic/CSWorkSheet', 'Service');
        $sheet_id = 228;
        $sheet = $ws_service->getWorkSheetInfo($sheet_id);
        $addition = json_decode($sheet['addition'], TRUE);
        print_r($addition);

        /* @var \Basic\Service\SendNoticeService $send_service */
        $send_service = D('Basic/SendNotice', 'Service');
        if ( $sheet['product_id'] == 1 ) { // APP
            $type = is_null_datetime($addition['member_start_time']) ? 'open_member' : 'member_recharge';
        } elseif ( $sheet['product_id'] == 24 ) { // PC
            $type = is_null_datetime($addition['member_start_time']) ? 'open_pc_member' : 'pc_member_recharge';
        }
        $send_service->addNotice($sheet['uid'], $type, ['member_open_date' => $sheet['start_day'], 'member_end_date' => $sheet['end_day']]);

        echo "ok";
    }
}