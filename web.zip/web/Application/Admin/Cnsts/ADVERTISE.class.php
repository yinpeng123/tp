<?php
namespace Admin\Cnsts;

class ADVERTISE {
    const ADVERTISE_SEARCH_FILE = [
            'ad_id' => ['type' => 'eq',],//广告工单
            'ad_pos' => ['type' => 'eq',], //广告挡位
            'status' => ['type' => 'eq',], //广告状态
            'creator' => ['type' => 'eq',],//创建人
            'telephone' => ['type' => 'like',],//手机号
            'net_no' => ['type' => 'like'], //账号
            'account' => ['type' => 'like'],//网号
            'worker' => ['type' => 'eq'],//被指派制作人
            'ad_type1' => ['type' => 'eq'],//
            'ad_type2' => ['type' => 'eq'],//广告类型
            'ws_id' => ['type' => 'eq'],//关联工单号
            'agent' => ['type' => 'eq'],//投放区域
            'ad_contact' => ['type' => 'like'],//联系人
            //广告到期日
            //广告计划上线日
    ];

    // 状态分类
    const AD_STATUS_NEW = 'new';
    const AD_STATUS_DOING = 'doing';
    const AD_STATUS_WAIT = 'wait_review';
    const AD_STATUS_PUBLISH = 'wait_publish';
    const AD_STATUS_PUBLISHING = 'publishing';
    const AD_STATUS_EXPIRED = 'expired';
    const AD_STATUS_PAUSE = 'pause';

    const AD_STATUS_ARR = [
        self::AD_STATUS_NEW   => '新建',
        self::AD_STATUS_DOING   => '制作中',
        self::AD_STATUS_WAIT   => '待审核',
        self::AD_STATUS_PUBLISH   => '待发布',
        self::AD_STATUS_PUBLISHING   => '发布中',
        self::AD_STATUS_EXPIRED   => '过期',
        self::AD_STATUS_PAUSE   => '暂停',
    ];

}