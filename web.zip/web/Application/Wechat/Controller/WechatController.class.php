<?php
namespace Wechat\Controller;

use Think\Controller;
use Basic\Cnsts\WECHAT;
use Basic\Service\SignService;
use  Qcloud\Sms\SmsSingleSender;
use Qcloud\Cos\Client;
use Qcloud_cos\Auth;
use Qcloud_cos\Cosapi;
use Qcloud_cos\CosDb;
use Basic\Service\UuserService;
class WechatController extends Controller {

    public  $openid="";
    public $pageSize=5;
    public $user=[];
    public $memKey="PLAN_WECHAT_";
    public $appid = 'wxcd5d96a12f7c53d4';
    public $appSecret = '48588aa71a3876b24111ddf58126163a';
    public $mch_id = 1489439662;
    public $key = 'qwertyuiopasdfghjklzxcvbnmQWERTY';
    private $template_id = '1KOvnMjsRh0O55ZlXzKRy6xRa8PTc6VQpcRq8o8zBJg';
    public  $api=null;
    private $cacheCount=0;
    private $order_id=0;
    private $form_id='';
     function __construct(){
        parent::__construct();
        if(!in_array(ACTION_NAME,['login','addPic','getOpenId'])){
            if (I("openid")==""){
                $this->doResponse(-1,"需要先登录");
            }
            $this->openid=I("openid");
            $this->user=(object)(new UuserService())->getUserByOpenid($this->openid);
        }
        if(!APP_DEBUG){
            cmm_log2(json_encode(I(''),JSON_UNESCAPED_UNICODE));
             $this->checkSign();
        }

    }

    /**
     * 为Ajax请求返回json格式字符串
     */
    protected function doResponse($code, $message = '', $extra = '') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('code' => $code, 'message' => $message, 'extra' => $extra), JSON_UNESCAPED_UNICODE);
        exit;
    }



    /**
     * @note :检测签名
     * @param  :
     * @return :
     */
    private function checkSign(){

        if(empty(I('sign'))||empty(I('times'))||count(I())<2){
            $this->doResponse(-1, "缺少参数", []);
            exit;
        }
        $sign=I('sign', '');
        $info=I();
        $signTime=I('times', '');
        unset($info['sign']);
        unset($info['times']);
        $signServer= new SignService();
        if(!$signServer->checkSignature($sign,$signTime,$info)){
            $this->doResponse(-1, "签名错误", []);
            exit;
        }
    }


    protected function sendCode($tel,$code){
        $appid="1400165675";
        $appkey="f2130492ca44f1c6b09540f03455d3d9";
        $ssender = new SmsSingleSender($appid, $appkey);
        $result = $ssender->send(0, "86", $tel,
            "【UPplan】".$code."为您的登录验证码，请于2分钟内填写。如非本人操作，请忽略本短信。", "", "");
        return t_json_decode($result);


    }

    // 过滤掉emoji表情
    public function filter_Emoji($str)
    {
        $str = preg_replace_callback(    //执行一个正则表达式搜索并且使用一个回调进行替换
            '/./u',
            function (array $match) {
                return strlen($match[0]) >= 4 ? '' : $match[0];
            },
            $str);

        return $str;
    }

    //过滤各类字符
    public function replaceSpecialChar($strParam)
    {
        $regex = "/\ |\/|\~|\!|\@|\#|\\$|\%|\^|\&|\*|\(|\)|\_|\+|\{|\}|\:|\<|\>|\?|\[|\]|\,|，|\.|\/|\;|\'|\`|\-|\=|\\\|\|/";
        return preg_replace($regex, "", $strParam);

    }
}