<?php
namespace Admin\Service;

use Think\Log;

class PrivilegeService {

    // 获取权限可访问的菜单id列表, 包含一级菜单id
    public function getPrivilegeMenuIdList($priv_ids) {
        if ( empty($priv_ids) )
            return [];

        $priv_model = D("Privilege");
        $priv_list = $priv_model->getList($priv_ids);

        $menu_ids = [];
        foreach ( $priv_list as $p ) {
            if ( $p['menu_ids'] && strlen($p['menu_ids']) > 2 ) {
                $ids = json_decode($p['menu_ids'], TRUE);
                $menu_ids = array_merge($menu_ids, $ids);
            }
        }
        $menu_ids = array_unique($menu_ids, SORT_NUMERIC);
        //print_r($menu_ids);

        // 获取上一级菜单id数组
        $menu_model = D('Menu');
        $pids = $menu_model->getDistinctPidList($menu_ids);
        //print_r($pids);exit;

        // 一级、二级菜单id的合集
        $menu_ids_all = array_merge($pids, $menu_ids);

        // 每个用户都能访问个人中心
        $menu_ids_all = array_merge($menu_ids_all, [4,5,53]);
        return $menu_ids_all;
    }

    // 检查用户是否具有指定的权限
    public static function checkPrivilege($manager_id, $priv) {
        if ( !$manager_id || !$priv ) {
            Log::write('[PrivilegeService::checkPrivilege] invalid parameter! manager_id:'.$manager_id.', priv:'.$priv, Log::ERR);
            return false;
        }
        // 超级管理员拥有所有权限
        if ( $manager_id == 1 )
            return true;

        $manager_model = D('Manager');
        $manager = $manager_model->getManagerById($manager_id);
        if ( empty($manager['role_id']) ) {
            Log::write('[PrivilegeService::checkPrivilege] empty role_id! manager_id:'.$manager_id.', priv:'.$priv, Log::ERR);
            return false;
        }

        $role_model = D('Role');
        $role = $role_model->get($manager['role_id']);
        if ( empty($role) || strlen($role['privileges']) <= 2 ) {
            Log::write('[PrivilegeService::checkPrivilege] empty role info or empty role privileges! manager_id:'.$manager_id.', priv:'.$priv, Log::ERR);
            return false;
        }

        $priv_arr = json_decode($role['privileges'], true);
        if ( empty($priv_arr) ) {
            Log::write('[PrivilegeService::checkPrivilege] empty role privileges! manager_id:'.$manager_id.', priv:'.$priv, Log::ERR);
            return false;
        }
        if ( in_array($priv, $priv_arr) ) {
            return true;
        } else {
            Log::write('[PrivilegeService::checkPrivilege] not allowed! manager_id:'.$manager_id.', priv:'.$priv, Log::ERR);
            return false;
        }
    }
}