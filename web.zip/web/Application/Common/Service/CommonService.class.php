<?php
namespace Common\Service;


use Basic\Cnsts\CACHE_PREFIX;
use Basic\Service\UserService;

class CommonService {

    public function __construct() {

    }

    /**
     * 获取请求参数便捷方法, 支持ThinkPHP的I()的变量过滤和变量修饰符功能
     *
     * @param        $name
     * @param string $default
     * @param null   $filter
     *
     * @return mixed
     */
    public function I($name, $default = '', $filter = NULL, $datas = NULL) {
        return I('data.'.$name, $default, $filter, $datas);
    }

    //检测设备号
    public function checkAppMemachineNo($uid, $app_info) {
        $user_id = $uid;

        if ( APP_DEBUG ) {
            //测试环境不验证
            return true;
        }

        if ( S(CACHE_PREFIX::APP_BIND_MEMACHINE_NO.$user_id) ) {
            return $this->_isMemachineNoEq($app_info['memachine_no'], S(CACHE_PREFIX::APP_BIND_MEMACHINE_NO.$user_id));
        } else {
            /** @var UserService $user_service */
            $user_service = D('Basic/User','Service');
            $user_info = $user_service->getUserInfo($user_id);
            $bind_memachine= t_json_decode($user_info['bind_memachine']);
            $app_memachine_no = $bind_memachine['app'] ? : '';
            //设置设备绑定的缓存
            S(CACHE_PREFIX::APP_BIND_MEMACHINE_NO.$user_id,$app_memachine_no);
            return $this->_isMemachineNoEq($app_info['memachine_no'], $app_memachine_no);
        }
    }

    /**
     * @param $app_memachine_no
     * @param $db_memachine_no
     * @return bool
     * 检测绑定的设备号是否相同
     */
    protected function _isMemachineNoEq( $app_memachine_no, $db_memachine_no ) {
        return $app_memachine_no == $db_memachine_no;
    }




}