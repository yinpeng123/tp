<?php
$DB_LIST = [
    'online'  => [
        'master_rw'        => [
            'DB_TYPE'  => 'mysqli',
            'DB_HOST'  => '172.21.0.3',
            'DB_NAME'  => 'twpt',
            'DB_USER'  => 'root',
            'DB_PWD'   => '123456',
            'DB_PORT'  => 3306,
            'DB_DEBUG' => false,
        ],
    ],

    'offline' => [
        'test_beta_rw'    => [
            'DB_TYPE'  => 'mysqli',
            'DB_HOST'  => '172.21.0.3',
            'DB_NAME'  => 'twpt',
            'DB_USER'  => 'root',
            'DB_PWD'   => '123456',
            'DB_PORT'  => 3306,
            'DB_DEBUG' => true,
        ],

//        'slave_1'        => [
//            'DB_TYPE'  => 'mysql',
//            'DB_HOST'  => 'rm-2ze28437xb4gvs937.mysql.rds.aliyuncs.com',
//            'DB_NAME'  => 'twpt',
//            'DB_USER'  => 'twpt',
//            'DB_PWD'   => 'twpt_20170512%',
//            'DB_PORT'  => 3306,
//            'DB_DEBUG' => false,
//        ],
    ],
];

if ( !APP_DEBUG ) {
    $current_db_config = array_merge($DB_LIST['online']['master_rw'], ['DB_LIST' => $DB_LIST['online']]);
} else {
    $current_db_config = array_merge($DB_LIST['offline']['test_beta_rw'], ['DB_LIST' => $DB_LIST['offline']]);
}

//p($current_db_config);
return $current_db_config;
