<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Cnsts\MANAGER;
use Admin\Service\PageService;
use Basic\ModelU\CenterModel;
use Basic\Service\AgentService;

class ManagerController extends AdminSessionController {

    /* @var \Admin\Model\ManagerModel $this->__manager_model */
    private $__manager_model = NULL;
    /* @var \Admin\Service\ManagerService $this->__manager_service */
    private $__manager_service = NULL;

    public function __construct() {
        parent::__construct();

        $this->__manager_model = D('Manager');
        $this->__manager_service = D('Manager', 'Service');
        // 权限检查
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::SYS_MANAGER) ) {
            $this->admin_error('正在跳转页面！', U('index/index', '', ''));
            exit;
        }
    }

    /**
     * 管理员列表
     */
    public function index() {
        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        $cond = $this->prepareSearchCond(array('search_realname', 'search_from_day', 'search_to_day', 'select_agent_id'));
        if ( $this->_manager['agent_id'] ) {
            $cond['search_agent_id'] = $this->_manager['agent_id'];
        }
        $ret = $this->__manager_model->searchManager($cond, $curr_page, $per_page);

        $role_model = D('Role');
        $agent_model = D('Basic/Agent');
        foreach ( $ret['data'] as &$i ) {
            $i['department_text'] = MANAGER::DEPARTMENT_ARR[$i['department']];
            if ( $i['role_id'] ) {
                $role = $role_model->get($i['role_id']);
                $i['role_name'] = $role['name'];
            }

            if ( $i['agent_id'] ) {
                $agent = $agent_model->getAgentById($i['agent_id']);
                $i['agent_name'] = $agent['name'];
            }
        }

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav = $page_service->show();

        // 获取信息完全的渠道列表
        /** @var AgentService $agent_service */
        $agent_service = D('Basic/Agent', 'Service');
        $agent_list = $agent_service->getAgentDoneList();

        $this->assignAll($cond);
        $this->assignAll(array(
            'title'         => '系统用户列表',
            'list'          => $ret['data'],
            'page_nav'      => $page_nav,
            'agent_list' => $agent_list,
        ));
        $this->display('manager_list');
    }

    /**
     * 获取返回列表的链接
     * @param $refer
     */
    protected function _backToListUrl($refer) {
        if ( !empty($refer) && 0 === strpos($refer, U('manager/index', '', '', TRUE)) ) {
            return $refer;
        } else {
            return U('manager/index', '', '', TRUE);
        }
    }

    /**
     * 添加管理员
     */
    public function add() {
        $manager = array(
            'manager_id'    => 0,
            'username'      => '',
            'realname'      => '',
            'password'      => '',
            'active'        => 'Y',
            'department'    => '',
            'duty'          => '',
            'work_sn'       => '',
            'phone'         => '',
            'qq'            => '',
            'email'         => '',
        );

        $this->assignAll(array(
            'act'     => 'add',
            'form_action' => '/manager/doAdd',
            'title'   => '添加系统用户',
            'manager' => $manager,
            'department_arr'    => (new CenterModel("admin_role"))->getListBy(['active'=>'Y']),
            'back_to_list_url' => $this->_backToListUrl($this->_refer),
        ));
        $this->display('manager_info');
    }

    /**
     * 保存管理员信息
     */
    public function doAdd() {
        // 验证令牌
        $this->checkFormToken();

        $username = I('username');
        $cn_len = cnstrlen($username);
        if ( $cn_len < 3 ) {
            $this->admin_error('账号名格式不正确！');
            return;
        }

        $manager = $this->__manager_model->getManagerByUsername($username);
        if ( $manager ) {
            $this->admin_error('该账号名已存在！');
            return;
        }

        $realname = I('realname');
        $cn_len = cnstrlen($realname);
        if ( $cn_len < 4 ) {
            $this->admin_error('真实姓名格式不正确！');
            return;
        }

        $password = I('password');
        $cn_len = cnstrlen($password);
        if ( $cn_len < 6 ) {
            $this->admin_error('密码格式不正确！');
            return;
        }

        $phone = I('phone');
        if ( !empty($phone) && !is_phone($phone) ) {
            $this->admin_error('联系电话格式不正确');
            return;
        }

        $identity = I('identity');
        if ( !empty($identity) && !is_identity_number($identity) ) {
            $this->admin_error('身份证号格式不正确！');
            return;
        }

        $department = I('department/d');
        if ( !$department ) {
            $this->admin_error('请选择部门！');
            return;
        }

        $email = I('email');
        if ( !empty($email) && !is_email($email) ) {
            $this->admin_error('email格式不正确！');
            return;
        }

        // 全国网管理员才能添加其它渠道的管理员
        if ( $this->_manager['agent_id'] == 0 ) {
//            $agent_id = I('agent_id/d');
            // 添加系统管理员时，如果没有选择渠道，则默认为 【全国（网络）渠道 （渠道id 177）】
            if (I('agent_id/d') == 0) {
                $agent_id = C('DEFAULT_AGENT_ID');
            } else {
                $agent_id = I('agent_id/d');
            }
        } else {
            // 渠道商只能添加自己所属渠道的管理员
            $agent_id = $this->_manager['agent_id'];
        }

        $active = I('active');
        if ( $active != 'Y' && $active != 'N' )
            $active = 'N';

        $password_encrypted = password_hash($password, PASSWORD_DEFAULT);
        $manager_id = $this->__manager_model->addManager(array(
            'username'    => $username,
            'password'    => $password_encrypted,
            'realname'    => $realname,
            'phone'       => $phone,
            'identity'    => $identity,
            'department'  => $department,
            'role_id'=>$department,
            'email'       => $email,
            'agent_id'    => $agent_id,
            'active'      => $active,
            'ctime'       => datetime(),
        ));

        // 添加操作日志
        $this->__manager_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => $manager_id,
            'action'        => 'add',
            'desc'          => "添加新管理员：$username",
        ));

        $this->admin_success('添加管理员成功！');
       // redirect(U('manager/editPrivilege/'.$manager_id, '', '').'?act=add_privilege');
    }

    /**
     * 编辑管理员
     */
    public function edit($manager_id) {
        $manager_id = (int)$manager_id;
        if ( !$manager_id ) {
            $this->admin_error('ID不正确！');
            return;
        }

        $manager = $this->__manager_model->getManagerById($manager_id);
        if ( !$manager ) {
            $this->admin_error('管理员不存在！');
            return;
        }

        // 反序列化权限
//        $manager['menus'] = array();
//        if ( strlen($manager['menu_ids']) > 1 ) {
//            $manager['menus'] = json_decode($manager['menu_ids'], true);
//        }

        // 渠道商列表
        $agent_model = D('Basic/Agent');
        $agent_list = $agent_model->getAllAgentList('id,name');
        $this->assign('agent_list', $agent_list);
        $act = I('act', 'edit');
        $department= (new CenterModel("admin_role"))->getListBy(['active'=>'Y']);
        $this->assignAll(array(
            'act'     => $act,
            'form_action' => '/manager/doEdit',
            'title'   => '编辑系统用户',
            'manager_id'=> $manager_id,
            'manager'   => $manager,
            'back_to_list_url'  => $this->_backToListUrl($this->_refer),
            'department_arr'    => $department,

        ));
        $this->display('manager_info');
    }

    /**
     * 提交编辑管理员
     */
    public function doEdit() {
        // 验证令牌
        $this->checkFormToken();

        $manager_id = I('manager_id/d');
        if ( !$manager_id ) {
            $this->admin_error('ID不正确！');
            return;
        }
        if ( $manager_id == 1 ) {
            $this->admin_error('不允许修改超级管理员账号！');
            return;
        }

        $manager_info = $this->__manager_model->getManagerById($manager_id);
        if ( empty($manager_info) ) {
            $this->admin_error('管理员不存在！');
            return;
        }

        $realname = I('realname');
        $cn_len = cnstrlen($realname);
        if ( $cn_len < 3 ) {
            $this->admin_error('真实姓名格式不正确！');
            return;
        }





        $active = I('active');
        if ( $active != 'Y' && $active != 'N' )
            $active = 'N';

//        $duty = I('duty');

//        $qq = I('qq');
//        if ( !empty($qq) && !is_qq($qq) ) {
//            $this->admin_error('QQ号格式不正确');
//            return;
//        }

        $this->__manager_model->updateManagerById($manager_id, array(
            'realname'      => $realname,
//            'agent_id'      => $agent_id,
            'active'        => $active,
           'role_id'          => I('department'),
//            'qq'            => $qq,
            'relogin'       => 1, // 修改用户信息后,需要重新登录
            'mtime'         => datetime(),
        ));

        // 添加操作日志
        $this->__manager_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => $manager_id,
            'action'        => 'edit',
            'desc'          => "编辑管理员：".$manager_info['username'],
        ));

        $this->admin_success('编辑管理员成功！',"/manager/index");
    }

    /**
     * 修改权限
     * @param string $manager_id
     */
    public function editPrivilege($manager_id) {
        $manager_id = (int)$manager_id;
        if ( !$manager_id ) {
            $this->admin_error('参数不正确！');
            return;
        }

        $manager = $this->__manager_model->getManagerById($manager_id);
        if ( !$manager ) {
            $this->admin_error('管理员不存在！');
            return;
        }

        // 反序列化权限
//        $manager['menus'] = array();
//        if ( strlen($manager['menu_ids']) > 1 ) {
//            $manager['menus'] = json_decode($manager['menu_ids'], true);
//        }
//        $menu_arr = $this->__manager_service->genMenuArr();
        //print_r($menu_arr);exit;

        $role_model = D('Role');
        $role_list = $role_model->getListByAgentId();
        // ($role_list);die;
        // 角色的权限列表
        $role_ids = array_column($role_list, 'id');
        $priv_list = [];
        if ( $manager['role_id'] && in_array($manager['role_id'], $role_ids) ) {
            $role_service = D('Role', 'Service');
            $priv_list = $role_service->getPrivilegeList($manager['role_id']);
        }
        //print_r($priv_list);exit;

        $act = I('act', 'edit_privilege');
//p($role_list);die;
        $this->assignAll(array(
            'act'           => $act,
            //'title'   => '编辑管理员',
            'manager_id'    => $manager_id,
            'manager'       => $manager,
            'role_list'     => $role_list,
            'priv_list'     => $priv_list,
            'role_key'      => count($role_list),
            'back_to_list_url' => $this->_backToListUrl($this->_refer),
        ));
        $this->display('manager_privilege');
    }

    /**
     * 保存权限设置
     */
    public function doEditPrivilege() {
        // 验证令牌
        $this->checkFormToken();

        $manager_id = I('manager_id/d');
        if ( !$manager_id ) {
            $this->admin_error('ID不正确！');
            return;
        }

        if ( $manager_id == 1 ) {
            $this->admin_error('不允许修改超级管理员账号！');
            return;
        }

        $manager_info = $this->__manager_model->getManagerById($manager_id);
        if ( empty($manager_info) ) {
            $this->admin_error('管理员不存在！');
            return;
        }

        $role_num = I('role_num');
        $role_id = I('role_id/d', 0);

        // 过滤掉渠道自身没有角色的问题
        if ($role_num != 0) {
            if ( !$role_id ) {
                $this->admin_error('请选择角色！');
                return;
            }
        }


        $this->__manager_model->updateManagerById($manager_id, array(
            'role_id'       => $role_id,
            'relogin'       => 1, // 修改用户信息后,需要重新登录
            'mtime'         => datetime(),
        ));

        // 添加操作日志
        $this->__manager_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => $manager_id,
            'action'        => 'edit',
            'desc'          => "编辑管理员权限：".$manager_info['username'],
        ));

        $act = I('act', '');
        if ( $act == 'add_privilege' ) { // 添加管理员流程
            //redirect(U('manager/editPassword/'.$manager_id, '', '').'?act=add_password');
            redirect(U('manager/edit/'.$manager_id, '', ''));
        } else {
            $this->admin_success('修改管理员权限成功！');
        }
    }

    /**
     * 修改密码
     * @param string $manager_id
     */
    public function editPassword($manager_id) {
        $manager_id = (int)$manager_id;
        if ( !$manager_id ) {
            $this->admin_error('参数不正确！');
            return;
        }

        $manager = $this->__manager_model->getManagerById($manager_id);
        if ( !$manager ) {
            $this->admin_error('管理员不存在！');
            return;
        }

        $act = I('act', 'edit_password');

        $this->assignAll(array(
            'act'     => $act,
            //'title'   => '编辑管理员',
            'manager_id'=> $manager_id,
            'manager'   => $manager,
            'back_to_list_url' => "/manager/index",
            //        'menu_arr'  => $menu_arr,
            //        'g_role_arr' => $g_role_arr,
        ));
        $this->display('manager_password');
    }

    /**
     * 提交编辑管理员密码
     */
    public function doEditPassword() {
        // 验证令牌
        $this->checkFormToken();

        $manager_id = I('manager_id/d');
        if ( !$manager_id ) {
            $this->admin_error('ID不正确！');
            return;
        }

        if ( $manager_id == 1 ) {
            $this->admin_error('不允许修改超级管理员账号！');
            return;
        }

        $manager_info = $this->__manager_model->getManagerById($manager_id);
        if ( empty($manager_info) ) {
            $this->admin_error('管理员不存在！');
            return;
        }

        $password = I('password');
        $cn_len = cnstrlen($password);
        if ( $cn_len < 6 ) {
            $this->admin_error('密码格式不正确！');
            return;
        }

        $password2 = I('password2');
        if ( $password2 != $password ) {
            $this->admin_error('两次输入密码不一致！');
            return;
        }

        $password_encrypted = password_hash($password, PASSWORD_DEFAULT);
        $this->__manager_model->updateManagerById($manager_id, array(
            'password'    => $password_encrypted,
            'relogin'     => 1, // 修改用户信息后,需要重新登录
            'mtime'       => datetime(),
        ));

        // 添加操作日志
        $this->__manager_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => $manager_id,
            'action'        => 'edit',
            'desc'          => "编辑管理员密码：".$manager_info['username'],
        ));

        $act = I('act', '');
        if ( $act == 'add_password' ) { // 添加管理员流程
            $this->admin_success('添加管理员成功！', U('manager/edit/'.$manager_id, '', ''));
        } else {
            $this->admin_success('修改管理员密码成功！',"/manager/index");
        }
    }

    /**
     * 【测试】发票管理
     * @param string $manager_id
     */
    public function editInvoice($manager_id) {
        $manager_id = (int)$manager_id;
        if ( !$manager_id ) {
            $this->admin_error('参数不正确！');
            return;
        }

        $agent_id = 66;
        $invoice_id = I('path.3/d', 0);
        if ( $invoice_id ) { // 编辑状态

        }
        $invoice_model = D('AgentInvoice');
        $list = $invoice_model->getInvoiceList(['agent_id' => $agent_id]);

        $act = I('act', 'edit_invoice');

        $this->assignAll(array(
            'act'     => $act,
            //'title'   => '编辑管理员',
            'manager_id'=> $manager_id,
            'list'      => $list,
            'back_to_list_url' => $this->_backToListUrl($this->_refer),
            //        'menu_arr'  => $menu_arr,
            //        'g_role_arr' => $g_role_arr,
        ));
        $this->display('manager_invoice');
    }

    /**
     * 保存提交编辑表格
     */
    public function doEditInvoice() {
        // 验证令牌
        $this->checkFormToken();

        //print_r($_POST);exit;
        $agent_id = 66;

        $head = I('head/d', 1);
        $fields = [
            'agent_id'  => $agent_id,
            'head'      => $head,
        ];

        if ( $head == 1 ) { // 个人
            $fields['type']         = 1;
            $fields['company']      = '';
            $fields['taxer_no']     = '';
            $fields['credit_no']    = '';
            $fields['address']      = '';
            $fields['tax_type']     = '';
            $fields['phone']        = '';
            $fields['bank_name']    = '';
            $fields['bank_passport'] = '';

        } else  { // 公司
            $type = I('type/d', 1);
            $fields['type'] = $type;

            if ( $type == 1 ) { // 增值税普通发票
                $fields['company'] = I('company', '');
                $fields['taxer_no']     = '';
                $fields['credit_no']    = '';
                $fields['address']      = '';
                $fields['tax_type']     = '';
                $fields['phone']        = '';
                $fields['bank_name']    = '';
                $fields['bank_passport'] = '';

            } else { // 增值税专用发票
                $fields['company']      = I('company', '');
                $fields['taxer_no']     = I('taxer_no', '');
                $fields['credit_no']    = I('credit_no', '');
                $fields['address']      = I('address', '');
                $fields['tax_type']     = I('tax_type', '');
                $fields['phone']        = I('phone', '');
                $fields['bank_name']    = I('bank_name', '');
                $fields['bank_passport'] = I('bank_passport', '');
            }
        }

        $invoice_model = D('AgentInvoice');

        $invoice_id = I('invoice_id/d', 0);
        if ( $invoice_id > 0 ) { // 编辑记录
            $fields['mtime'] = datetime();
            $invoice_model->updateInvoice(['id' => $invoice_id], $fields);

            // 添加操作日志
//            $this->__manager_service->addOperLog(array(
//                'manager_id'    => $this->_manager_id,
//                'object_id'     => $manager_id,
//                'action'        => 'edit',
//                'desc'          => "编辑管理员密码：".$manager_info['username'],
//            ));

            $this->admin_success('修改发票信息成功！');

        } else { // 添加记录
            $fields['ctime'] = datetime();
            $invoice_model->addAgentInvoice($fields);

            // 添加操作日志
//            $this->__manager_service->addOperLog(array(
//                'manager_id'    => $this->_manager_id,
//                'object_id'     => $manager_id,
//                'action'        => 'edit',
//                'desc'          => "编辑管理员密码：".$manager_info['username'],
//            ));

            $this->admin_success('添加发票信息成功！');
        }

//        $act = I('act', '');
//        if ( $act == 'add_password' ) { // 添加管理员流程
//            $this->admin_success('添加管理员成功！', U('manager/edit/'.$manager_id, '', ''));
//        } else {
//            $this->admin_success('修改管理员密码成功！');
//        }

    }

    public function getInvoiceInfo($invoice_id) {
        $invoice_id = (int)$invoice_id;
        if ( !$invoice_id ) {
            $this->ajaxResponse(-1, 'ID不正确！');
            return;
        }

        $invoice_model = D('AgentInvoice');
        $invoice = $invoice_model->getInvoice(['id' => $invoice_id]);
        //print_r($invoice);
        $this->ajaxResponse(0, $invoice);
    }

    public function deleteInvocie($invoice_id) {
        $invoice_id = (int)$invoice_id;
        if ( !$invoice_id ) {
            $this->admin_error('ID不正确！');
            return;
        }

        $invoice_model = D('AgentInvoice');
        $invoice_model->deleteInvoice($invoice_id);

        // 添加操作日志
//        $this->__manager_service->addOperLog(array(
//            'manager_id'    => $this->_manager_id,
//            'object_id'     => $manager_id,
//            'action'        => 'delete',
//            'desc'          => "删除管理员：".$manager_info['username'],
//        ));

        $this->admin_success('删除发票成功！');
    }

    /**
     * 批量删除
     */
    public function deleteInvoiceAll() {
        $ids = I('ids');
        if ( empty($ids) ) {
            $this->admin_error('ID不正确！');
            return;
        }

        $invoice_model = D('AgentInvoice');
        $invoice_model->deleteInvoice($ids);

        // 添加操作日志
//        $this->__manager_service->addOperLog(array(
//            'manager_id'    => $this->_manager_id,
//            'object_id'     => implode(',', $ids),
//            'action'        => 'delete',
//            'desc'          => "批量删除管理员",
//        ));

        $this->admin_success('批量删除发票成功！');
    }

    /**
     * 删除管理员
     * @param $manager_id
     */
    public function delete($manager_id) {
        if ( session('manager_id') != 1 ) {
            $this->admin_error('您无权执行该操作！');
            return;
        }

        if ( !$manager_id ) {
            $this->admin_error('ID不正确！');
            return;
        }

        if ( $manager_id == 1 ) {
            $this->admin_error('不允许删除超级管理员账号！');
            return;
        }

        $manager_info = $this->__manager_model->getManagerById($manager_id);
        if ( empty($manager_info) ) {
            $this->admin_error('管理员不存在！');
            return;
        }

        $this->__manager_model->updateManagerById($manager_id, array(
            'is_delete'   => 'Y',
            'mtime'       => datetime(),
        ));

        // 添加操作日志
        $this->__manager_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => $manager_id,
            'action'        => 'delete',
            'desc'          => "删除管理员：".$manager_info['username'],
        ));

        $this->admin_success('删除管理员成功！');
    }

    /**
     * 批量删除
     */
    public function deleteAll() {
        if ( session('manager_id') != 1 ) {
            $this->admin_error('您无权执行该操作！');
            return;
        }

        $ids = I('ids');
        if ( empty($ids) ) {
            $this->admin_error('ID不正确！');
            return;
        }

        if ( in_array(1, $ids) ) {
            $this->admin_error('不允许删除系统管理员！');
            return;
        }

        $this->__manager_model->updateManagers($ids, array(
            'is_delete'   => 'Y',
            'mtime'       => datetime(),
        ));

        // 添加操作日志
        $this->__manager_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => implode(',', $ids),
            'action'        => 'delete',
            'desc'          => "批量删除管理员",
        ));

        $this->admin_success('批量删除管理员成功！');
    }

}