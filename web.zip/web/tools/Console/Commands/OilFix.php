<?php

namespace Artisan\Console\Commands;

use Illuminate\Console\Command;

class OilFix extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'oil:fixdata';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '修正油卡数据';

    
    private $oil_cards_model = null;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        ini_set('memory_limit', -1);
        parent::__construct();
        $this->user_oil_card_model = M('user_oil_card');
        $this->oil_cards_model = M('oil_cards');
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $curpage = 1;
        while ($user_oil_cards = $this->user_oil_card_model->page($curpage, 100)->select()) {
            foreach ($user_oil_cards as $key => $user_card) {
                $cond = [
                    'id' => $user_card['card_id'],
                ];
                $data = [
                    'telephone' => $user_card['telephone'] ?: $user_card['uid'],
                ];
                $res = $this->oil_cards_model->where($cond)->save($data);
                var_dump($user_card['card_id'], $res);
            }
            $curpage++;
        }

    }

    

}
