<?php
namespace Admin\Controller;

use Admin\Service\PageService;
use Basic\Cnsts\DICT;
use Basic\Cnsts\IDENTITY;

class IdentityController extends AdminSessionController
{
    /* @var \Basic\Model\IdentityModel $__identity_model */
    private $__identity_model = null;

    public function __construct()
    {
        parent::__construct();
        $this->__identity_model = D('Basic/Identity');

        // 权限检查
//        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::IDENTITY ) ) {
//            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
//            exit;
//        }
    }


    public function index()
    {
        // 渠道列表
        /** @var AgentModel $agent_model */
        $agent_model = D('Basic/Agent');
        $agent_list  = $agent_model->getAllAgentList();
        $search_telephone  = I('search_telephone');
        $search_account    = I('search_account');
        $search_ctime_from = I('search_ctime_from');
        $search_ctime_to   = I('search_ctime_to');
        $search_agent_id   = I('search_agent_id');
        $status   = I('status');
        $payment_type = I('payment_type/d'); // 新增需求（支付方式）
        $post_from = I('post_from/d'); // 新增需求（核查来源）
        $charge = I('charge/d'); // 新增（是否计费）

        if(session('manager')['agent_id'] == 0) {
            if (!empty($search_agent_id)) {
                $cond['user.channel_id'] = ['eq', $search_agent_id];
            }
        } else {
            $cond['user.channel_id'] = ['eq', session('manager')['agent_id']];
        }

        if (!empty($search_telephone)) {
            $cond['user.telephone'] = ['eq', $search_telephone];
        }
        if (!empty($search_account)) {
            $cond['user.account'] = ['eq', $search_account];
        }
        if ($status === '') {
        } else {
            $cond['identity.status'] = ['eq', $status];
            $status = (int)$status;
        }

        if (!empty($search_ctime_from) && !empty($search_ctime_to)) {
            $cond['identity.ctime'] = [['egt', $search_ctime_from], ['elt', $search_ctime_to]];
        }
        if (!empty($search_ctime_from)) {
            $cond['identity.ctime'] = ['egt', $search_ctime_from];
        }
        if (!empty($search_ctime_to)) {
            $cond['identity.ctime'] = ['elt', $search_ctime_to];
        }
        if ($payment_type != 0) {
            $cond['payment.op_type'] = ['eq', $payment_type];
        }
        if ($post_from !=0) {
            $cond['identity.post_from'] = ['eq', $post_from];
        }
        if ($charge != 0) {
            if ($charge == 1) {
                $cond['identity.status'] = ['in', [1, 2]];
            } else {
                $cond['identity.status'] = ['in', [-1, 3]];
            }
        }

        //分页
        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        $ret       = $this->__identity_model->searchIdentityList($cond, $curr_page, $per_page);
//p($ret['data']);die;
        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();

        $agent_model = D('Basic/Agent');
        $count = count($ret['data']);
        $text = '';

        for ($i = 0; $i < $count; $i++) {
            //根据渠道ID获取名称
            $agent_info                    = $agent_model->getAgentById($ret['data'][$i]['channel_id']);
            $ret['data'][$i]['agent_name'] = $agent_info['name'];
            switch ( $ret['data'][$i]['status'] ) {
                case 0 :
                    $status_desc = '<i class="my-ft my-blue">待验证</i>';
                    break;
                case 1:
                    $status_desc = '<i class="my-ft my-green">一致</i>';
                    break;
                case 2:
                    $status_desc = '<i class="my-ft my-red">不一致</i>';
                    break;
                case 3:
                    $status_desc = '<i class="my-ft my-yellow">无此号</i>';
                    break;
                default :
                    $status_desc = '未知';
                    break;
            }
            $ret['data'][$i]['status_desc'] = $status_desc;

            // 新增需求（支付方式）
            $ret['data'][$i]['payment_type_text'] = IDENTITY::PAYMENT_LIST[$ret['data'][$i]['op_type']];

            // 新增 （查验来源）
            $ret['data'][$i]['post_from_text'] = IDENTITY::POST_FROM_LIST[$ret['data'][$i]['post_from']];

            // 新增 （是否计费）
            if ($ret['data'][$i]['status'] == -1 || $ret['data'][$i]['status'] == 3) {
                $text = '否';
            } elseif ($ret['data'][$i]['status'] == 1 || $ret['data'][$i]['status'] == 2) {
                $text = '是';
            } else {
                $text = '待验证';
            }
            $ret['data'][$i]['charge_text'] = $text;
        }

        // 处理统计数据
        $text = $this->_formateTotal($ret['data']);
//        p($ret['data']);die;
        $this->assignAll([
            'search_telephone'  => $search_telephone,
            'search_account'    => $search_account,
            'search_ctime_from' => $search_ctime_from,
            'search_ctime_to'   => $search_ctime_to,
            'status'            => $status,
            'search_agent_id'   => $search_agent_id,
            'list'              => $ret['data'],
            'title'             => '三证验证',
            'status_arr' =>    $this->_getStatusArr(),
            'agent_list'        => $agent_list,
            'page_nav'          => $page_nav,
            'manager_agent_id' => session('manager')['agent_id'],
            'payment_list' => IDENTITY::PAYMENT_LIST,
            'payment_type' => $payment_type,
            'post_from_list' => IDENTITY::POST_FROM_LIST,
            'post_from' => $post_from,
            'charge' => $charge,
            'text' => $text,
        ]);
        $this->display('index');
    }

    // 统计总金额
    private function _formateTotal($data) {
        $pc_wx = 0;
        $pc_wx_refund = 0;
        $pc_zfb = 0;
        $pc_zfb_refund = 0;
        $pc_ye = 0;
        $pc_ye_refund = 0;
        $app_wx = 0;
        $app_wx_refund = 0;
        $app_zfb = 0;
        $app_zfb_refund = 0;
        $app_ye = 0;
        $app_ye_refund = 0;
        foreach ($data as $k=>$v) {
            if ($v['post_from'] == IDENTITY::PC) {
                if ($v['op_type'] == IDENTITY::WX) {
                    $pc_wx += $v['price'];
                    $pc_wx_refund += $v['refund'];
                } elseif ($v['op_type'] == IDENTITY::ZFB) {
                    $pc_zfb += $v['price'];
                    $pc_zfb_refund += $v['refund'];
                } else {
                    $pc_ye += $v['price'];
                    $pc_ye_refund += $v['refund'];
                }
            } else {
                if ($v['op_type'] == IDENTITY::WX) {
                    $app_wx += $v['price'];
                    $app_wx_refund += $v['refund'];
                } elseif ($v['op_type'] == IDENTITY::ZFB) {
                    $app_zfb += $v['price'];
                    $app_zfb_refund += $v['refund'];
                } else {
                    $app_ye += $v['price'];
                    $app_ye_refund += $v['refund'];
                }
            }
        }
        $pc_total =sprintf("%.2f", $pc_ye + $pc_zfb + $pc_wx);
        $pc_total_refund = sprintf("%.2f", $pc_ye_refund + $pc_zfb_refund + $pc_wx_refund);
        $app_total = sprintf("%.2f", $app_ye + $app_zfb + $app_wx);
        $app_total_refund = sprintf("%.2f", $app_ye_refund + $app_zfb_refund + $app_wx_refund);
        $text = '来源PC:总收入：'.$pc_total . '；其中微信：' .sprintf("%.2f", $pc_wx) . '、支付宝：' .sprintf("%.2f", $pc_zfb). '、余额：' . sprintf("%.2f", $pc_ye). '，退款共：' .$pc_total_refund. '。来源APP:总收入：'.$app_total . '；其中微信：' .sprintf("%.2f", $app_wx) . '、支付宝：' .sprintf("%.2f", $app_zfb). '、余额：' . sprintf("%.2f", $app_ye). '，退款共：' .$app_total_refund;
        return $text;
    }

    protected function _getStatusArr() {
        $status_arr = ['' => '全部'];
        foreach (\Basic\Cnsts\IDENTITY::IDENTITY_STATUS_LIST as $k=> $v) {
            $status_arr[$k] =$v ;
        }
        return $status_arr;
    }
}