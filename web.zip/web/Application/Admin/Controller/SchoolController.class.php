<?php

namespace Admin\Controller;

use Basic\Cnsts\DICT;
use Basic\Cnsts\POINT;
use Basic\Model\SuggestLogModel;
use Basic\Model\SuggestModel;
use Basic\ModelU\CenterModel;

use Basic\Service\UserPointService;
use Common\Cnsts\ERRNO;
use Admin\Service\PageService;

class SchoolController extends AdminSessionController
{

    private $school = [
        1 => "中学",
        2 => "高中",
        3 => "大学",
        4 => "艺校",
        5 => "国外大学",
    ];
    private $city;

    public function __construct()
    {
        parent::__construct();
        $this->city = (new CenterModel("u_city"))->getListBy();

    }

    public function all()
    {
        $list = $this->school;
        $this->assign('title', '所有学校');
        $this->assign('list', $list);
        $this->assign('city', $this->city);
        $this->display('index');
    }

    public function edit($id)
    {
        $list = $this->school;
        $data = (new CenterModel("u_school"))->getListBy();
        $noPic = $havePic = $haveQrcode = [];
        $city = new CenterModel("u_city");
        foreach ($data as $key) {
            $key['cname'] = $city->get($key['region_id'])['name'];
            if (empty($key['pic'])) {
                $noPic[] = $key;
            }
            if (!empty($key['qrcode'])) {
                $haveQrcode[] = $key;
            }
            if (!empty($key['pic'])) {
                $havePic[] = $key;
            }
        }
        $this->assignAll(
            [
                'cid' => $id,
                'title' => $list[$id],
                'list' => $list,
                'data' => [
                    'nopic' => $noPic,
                    'haveQ' => $haveQrcode,
                    'haveP' => $havePic,
                ],
                'city' => $this->city,
            ]);
        $this->display('edit');
    }

    public function getShool($cid)
    {
        $where = [
            'region_id' => $cid,
        ];
        $data = (new CenterModel("u_school"))->getListBy($where);
        if (!$data) {
            $data = null;
        }
        $this->ajaxResponse(0, "ok", $data);
    }

    public function schoolList()
    {
        $curr_page = I('path.2/d', 1);
        $where = [];
        if (I("uid")) {
            $key = "%" . I('uid') . "%";
            $where['name'] = array('like', $key);;
        }
        $list = $this->school;
        $info = (new CenterModel("u_school"))->getListBy($where, "", "id desc", $curr_page, 15);
        foreach ($info as $key => $val) {
            $info[$key]['city'] = (new CenterModel("u_city"))->get($val['region_id'])['name'];
        }
        $total = (new CenterModel("u_school"))->getListTotal($where);
        $page_service = new PageService($total, 15);
        $page_nav = $page_service->show();
        $this->assign('title', '学校列表');
        $this->assign('list', $list);
        $this->assign('info', $info);
        $this->assign('city', $this->city);
        $this->display('list');
    }

    public function add()
    {
        $region_id = I("region_id");
        $type = I("type");
        $name = I("name");
        if (empty($region_id) || empty($type) || empty($name)) {
            $this->ajaxResponse(1, "必填参数不能为空");
        }
        $info = [
            "region_id" => $region_id,
            "type" => $type,
            "name" => $name,
        ];
        (new CenterModel("u_school"))->add($info);
        $this->ajaxResponse(0, "");
    }

    //上传图片，二维码
    public function doUpPic()
    {
        $type = I("type");
        $id = I("id");

        $photo = I("pic");
        if ($type == "pic") {
            $info = [
                'pic' => $photo,
            ];
        } else {
            $info = [
                'qrcode' => $photo,
            ];
        }
        $model = new CenterModel("u_school");
        $model->update($id, $info);
        $this->ajaxResponse(0, "ok");
    }


    public function delete($id)
    {
        if (!$id) {
            $this->admin_error("失败");
            return;
        }
        $model = new CenterModel("u_school");
        $model->delete($id);
        $this->admin_success("删除成功");
    }

    public function show($id = 0)
    {
        $info = [];
        $title = "增加学校";
        if ($id) {
            $info = (new CenterModel("u_school"))->get($id);
            $title = "编辑学校";
        }
        $this->assignAll(
            [
                'info' => $info,
                'title' => $title,
                'city'=>$this->city,
            ]
        );
        $this->display('show');
    }

    public function schoolAdd()
    {
        $info = new CenterModel("u_school");
        $data=[
            'name'=>I("name"),
            'region_id'=>I("school")
        ];
        $info->update(I('id'),$data);
        $this->admin_success("保存成功","/school/schoolList");
    }
}
