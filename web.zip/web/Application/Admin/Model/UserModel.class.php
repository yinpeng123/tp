<?php
namespace Admin\Model;

use Basic\Cnsts\CACHE_PREFIX;
use Basic\Model\BasicModel;

class UserModel extends BasicModel {

    private $__user_model = NULL;


    public function __construct($db_type = 'master', $enable_cache = TRUE) {
        parent::__construct('user', CACHE_PREFIX::USER, $db_type);
        $this->_enable_cache = $enable_cache;
        $this->__user_model = $this->_model;

    }
    //@todo 废弃
    public function add($user) {
        $user_id = $this->__user_model->add($user);

        // 添加到数据发送队列中, 同步到物流中国
        // 旧的同步机制, 已废弃
//        $user['id'] = $user_id;
//        $queue_model = D('Basic/WLSendQueue');
//        $queue_model->add('userpc', 'add', $user);

        return $user_id;
    }

    // 更新user数据     //@todo 废弃
    public function updateUserById($user_id, $info) {
        $res = $this->__user_model->where(['id' => $user_id])->save($info);
        // 添加到数据发送队列中, 同步到物流中国
        $info['id'] = $user_id;
        // 删除缓存
        if ( !empty($user_id) ) {
            S('user_'.$user_id, NULL);
        }
        // 旧的同步机制, 已废弃
//        $queue_model = D('Basic/WLSendQueue');
//        $queue_model->add('userpc', 'update', $info);
        return $res;
    }


    //@todo 废弃
    public function getUserById($user_id) {
        return $this->__user_model->where(['id' => $user_id])->find();
    }

    //@todo 废弃
    public function getUserByTelephone($telephone) {
        return $this->__user_model->where(['telephone' => $telephone])->find();
    }

    //@todo 废弃
    public function getUserByField($where) {
        return $this->__user_model->where($where)->find();
    }

    /**
     * 搜索操作日志
     * @param array $cond 搜索条件
     * @param int   $page_no 页码
     * @param int   $per_page 每页记录数
     */
    public function searchUser($cond, $page_no, $per_page, $join=[]) {
        $page_no = max($page_no, 1);
        if ( empty($join) ) {
            $data = $this->__user_model->field('SQL_CALC_FOUND_ROWS *')->where($cond)->order('id DESC')->page($page_no,
                $per_page)->select();
        } else {
            $data = $this->__user_model->field('SQL_CALC_FOUND_ROWS *,user.id as id,wl_tblonline.ID as 
            wl_tbl_online_id')->join($join)->where
            ($cond)->order('user.id DESC')->page($page_no,
                $per_page)->select();
        }
        $res = $this->__user_model->field("FOUND_ROWS() as total")->join($join)->find();
        $count = $res['total'];
        $page_number = ceil($count/$per_page);  // 总页数

        if ( $page_number > 0 && $page_no > $page_number ) { // 超出记录集, 返回最后一页的数据
            return $this->searchUser($cond, $page_number, $per_page);
        }

        return array('count' => $count, 'page_number' => $page_number, 'page_no' => $page_no, 'data' => $data);
    }

    /**
     * @param $where
     * @param $order_by
     * @param $limit
     * @param $fields
     * @param $join
     * 获取用户列表
     */
    public function getUserList ($where, $order_by, $limit, $fields, $join) {
        return $this->__user_model->where($where)->field($fields)->join($join)->order($order_by)->limit($limit)
            ->select();
    }

    /***
     * @return mixed 获取总条数
     */
    public function getSqlFoundRows($where,$join = null) {
        $total = $this->__user_model->join($join)->where($where)->count();
        return $total;
    }

    public function getUserByChannelId($where) {
        return $this->__user_model->where($where)->select();
    }


    public function userPointList($cond, $page_no, $per_page) {
        $page_no = max($page_no, 1);
        $data = $this->__user_model
            ->field('SQL_CALC_FOUND_ROWS user.*, user_extra.point')
            ->join("LEFT JOIN user_extra ON user.id = user_extra.uid")
            ->where($cond)
            ->order('user.id DESC')
            ->page($page_no, $per_page)
            ->select();
        $res = $this->__user_model->field("FOUND_ROWS() as total")->find();
        $count = $res['total'];
        $page_number = ceil($count/$per_page);  // 总页数

        if ( $page_number > 0 && $page_no > $page_number ) { // 超出记录集, 返回最后一页的数据
            return $this->userPointList($cond, $page_number, $per_page);
        }

        return array('count' => $count, 'page_number' => $page_number, 'page_no' => $page_no, 'data' => $data);
    }

}