<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Basic\Cnsts\CS_WORK_SHEET;
use Admin\Service\PageService;
use Basic\Cnsts\DICT;
use Basic\Model\AgentModel;
use Basic\Model\CSWorkSheetModel;
use Basic\Model\RecordModel;
use Basic\Service\AgentChargeService;

class RecordController extends AdminSessionController
{
    private $__agent_model = null;
    private $__finance_model = null;
    private $__user_model = null;
    private $__cs_work_sheet_model = null;
    private $__charge_service = null;

    public function __construct()
    {
        parent::__construct();

        $this->__agent_model         = D('Basic/Agent');
        $this->__finance_model       = D('Basic/Finance');
        $this->__user_model          = D('User');
        $this->__cs_work_sheet_model = D('Basic/CSWorkSheet');
        //$this->__manager_service = D('Manager', 'Service');

        // 权限检查
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::USER_TRANSACTION  ) ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }
    }

    public function index()
    {

        // 渠道列表
        /** @var AgentModel $agent_model */
        $agent_model = D('Basic/Agent');
        $agent_list  = $agent_model->getAllAgentList();

        //交易内容
        $record_content = CS_WORK_SHEET::WS_TYPE_ARR;

        $recordId        = I('recordId');
        $ws_id           = I('ws_id');
        $net_account     = I('net_account');
        $telephone       = I('telephone');
        $search_agent_id = I('search_agent_id');
        $type            = I('type');
        $search_from_day = I('search_from_day');
        $search_to_day   = I('search_to_day');

        if (!empty($recordId)) {
            $cond['id'] = ['eq', $recordId];
        }
        if (!empty($ws_id)) {
            $cond['ws_id'] = ['eq', $ws_id];
        }
        if (!empty($net_account)) {
            $cond['account|net_no'] = ['exp', '= ' . $net_account];
        }
        if (!empty($telephone)) {
            $cond['telephone'] = ['eq', $telephone];
        }
        if (!empty($search_agent_id)) {
            $cond['agent_id'] = ['eq', $search_agent_id];
        }
        if (!empty($type)) {
            $cond['type'] = ['eq', $type];
        }
        if (!empty($search_from_day) && !empty($search_to_day)) {
            $cond['ctime'] = [['egt', $search_from_day], ['elt', $search_to_day]];
        }
        if (!empty($search_from_day)) {
            $cond['ctime'] = ['egt', $search_from_day];
        }
        if (!empty($search_to_day)) {
            $cond['ctime'] = ['elt', $search_to_day];
        }

        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        $ret       = $this->__finance_model->searchFinanceList($cond, $curr_page, $per_page);
//        p($data);die;
        // 统计当前页数据的收款金额及来源
        /** @var CSWorkSheetModel $cs_work_sheet_model */
        $money = [];
        $online = 0;
        $weixin1 = 0;
        $weixin2 = 0;
        $alipay = 0;
        $abc5254 = 0;
        $icbc2121 = 0;
        $abc4876 = 0;
        $agent = 0;
        $cs_work_sheet_model = D('Basic/CSWorkSheet', 'Model');
        foreach ($ret['data'] as &$v) {
            $ws_info = $cs_work_sheet_model->get($v['ws_id'], $fields = '');
            $v['jisuan'] = [];
            foreach (t_json_decode($ws_info['charging']) as $vv) {
                $v['jisuan'][$vv['source']] = $vv['amount'];
            }
            $weixin1 += $v['jisuan']['weixin1'];
            $weixin2 += $v['jisuan']['weixin2'];
            $alipay += $v['jisuan']['alipay'];
            $abc5254 += $v['jisuan']['abc5254'];
            $abc4876 += $v['jisuan']['abc4876'];
            $icbc2121 += $v['jisuan']['icbc2121'];
            $agent += $v['jisuan']['agent'];
            $online += $v['jisuan']['online'];
            $money = [
                '微信1' => $weixin1,
                '微信2' => $weixin2,
                '支付宝' => $alipay,
                '农行5254' => $abc5254,
                '农行4876' => $abc4876,
                '工行2121' => $icbc2121,
                '渠道自收' => $agent,
                '在线自付' => $online,
            ];
        }
//p(array_sum($money));die;

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();

        //处理渠道
        for ($i = 0; $i < count($ret['data']); $i++) {
            if ($ret['data'][$i]['agent_id'] != 0) {
                $agent_info                    = $this->__agent_model->getAgentById($ret['data'][$i]['agent_id']);
                $ret['data'][$i]['agent_name'] = $agent_info['name'];
            } else {
                $ret['data'][$i]['agent_name'] = '全国网';
            }
        }
        //处理交易类型
        for ($i = 0; $i < count($ret['data']); $i++) {
            $ret['data'][$i]['type_name'] = CS_WORK_SHEET::WS_TYPE_ARR[$ret['data'][$i]['type']];
        }
        $this->assignAll([
            'money' => $money,
            'money_count' => array_sum($money),
            'list'            => $ret['data'],
            'record_content'  => $record_content,
            'agent_list'      => $agent_list,
            'title'           => '交易记录管理',
            'page_nav'        => $page_nav,
            'recordId'        => $recordId,
            'ws_id'           => $ws_id,
            'net_account'     => $net_account,
            'telephone'       => $telephone,
            'search_agent_id' => $search_agent_id,
            'type'            => $type,
            'search_from_day' => $search_from_day,
            'search_to_day'   => $search_to_day,
        ]);
        $this->display('record_index');
    }

}