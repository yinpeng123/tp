<?php
$CONFIG_LIST= [
    //'配置项'=>'配置值'
    'LOAD_EXT_CONFIG' => [
        'db','redis','public_redis','tags','upload','web_socket'
    ],

    // cache存储方式
    'DATA_CACHE_TYPE'        => 'Redis',
    'DATA_CACHE_PREFIX'      => 'twpt_',
    'DATA_CACHE_TIME'        => 600,
    'DATA_CACHE_KEY'         => 't1w2p3t4_',

    'TMPL_CACHE_ON'          => false,
    'TMPL_CACHE_PREFIX'      => 'TPL_',
    'TMPL_CACHE_TIME'        => 10,

    // 关闭数据表字段缓存
    'DB_FIELDS_CACHE'        => FALSE,
    // select语句默认最大执行时间,单位毫秒
    'SELECT_STATEMENT_LIMIT' => 30000,
    // sql comment
    'SQL_COMMENT'            => LOG_ID . ':' . PATH_INFO,

    // log path
    'LOG_PATH'               => LOG_PATH,
    'LOG_RECORD'             => true, //记录日志
    'LOG_TYPE'               => 'File', // 日志记录类型 默认为文件方式

    // session options
    'SESSION_OPTIONS'        => array('name' => 'twpt_sid', 'expire' => 30*24*3600),
    'SESSION_TYPE'           => 'Mysqli', //'db',
    'SESSION_TABLE'          => 'tp_session', // 必须设置成这样，如果不加前缀就找不到数据表，这个需要注意


    // memcache set '' exist time
    'REFRESH_MEMCACHE_SET_NULL_TIME'    => 1,
    // memcache expire
    'REFRESH_MEMCACHE_EXPIRE_TIME'      => 1,
    // memcache expire
    'REFRESH_MEMCACHE_MAX_SIZE'         => 1024 * 1024,

    // file compile switch
    'COMPILE_CORE_FILE'      => false,

    // default application
    'DEFAULT_MODULE'         => 'Admin',

    //component tpl config

    // 异步更新索引数据
    'ASYNC_INDEX'            => false,

    // 短信发送时间间隔要求, 单位:秒
    'SMS_SEND_INTERVAL'         => 60,
    // 短信验证码有效期, 单位:秒
    'SMS_CODE_LIFETIME'         => 600,

    // 用户在线最大空闲时间, 用于判断用户是否在线
    'MAX_IDLE_TIME'             => 5*60,


];

 $CONFIG_LIST['DEFAULT_MODULE'] = 'Admin';
 $CONFIG_LIST['MODULE_ALLOW_LIST'] = ['Basic', 'Crontab', 'Wechat', 'Doc','Client'];


return $CONFIG_LIST;
