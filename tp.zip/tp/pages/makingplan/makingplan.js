var time;
var type = getUrlParam('type');
var openid = getUrlParam('openid');
var room_id = getUrlParam('room_id');
if (type == 1) {
    $('.reward-number').text('100');
    $('.period-number').text('7');
} else {
    $('.reward-number').text('400');
    $('.period-number').text('21');
}
/**$(document).ready(function () {

    $.ajax({
        url: 'http://www.htown.xyz/Home/index/join_team',
        type: 'POST',
        data: {
            type: type,
            openid: openid,
            room_id: room_id
        },
        success: function (data) {
            $('.startTime-number').text(data.room_info.start_time.replace(/-/g, '.'));
            $('.endTime-number').text(data.room_info.end_time.replace(/-/g, '.'));
        },
        error: function () {
            console.error();
        }
    })
})**/

$('.timepicker-icon').click(function () {
    var that = this;
    showPopBox(that);
    selectTime();
});

function showPopBox(that) {
    $('.timepicker-popBox').remove();
    var html = '<div class="timepicker-popBox">' +
        '<p class="plantime-text">设定时间</p><div class="plantime-number"><p>&nbsp;</p>' +
        '<p>10</p><p>20</p><p>30</p><p>40</p><p>50</p><p>60</p><p>&nbsp;</p></div>' +
        '<p class="fenzhong-text">分钟</p><div onclick="confirmTime()" class="button-ok">确定</div></div>';
    $(html).insertAfter(that);
    $('.plantime-number').scroll(function () {
        selectTime();
    })
}


function confirmTime() {
    var html = '<div class="time">' + time + '</div><div class="text">分钟</div>';
    $('.timepicker-popBox').parent().empty().append(html);
    $('.timepicker .time').click(function () {
        var that = this;
        showPopBox(that);
        selectTime();
    });
}

function selectTime() {
    var pHeight = document.querySelector('.plantime-number p').clientHeight;
    var scrollHeight = document.querySelector('.plantime-number').scrollTop;
    var currentIndex = Math.ceil(scrollHeight / pHeight) + 1;
    if (currentIndex == 1) {
        currentIndex = 2;
    }
    var selector = '.plantime-number p:nth-child(' + currentIndex + ')';
    $('.plantime-number p').css('color', '#999999')
    $(selector).css('color', '#42ae70');
    time = (currentIndex - 1) * 10;
}

$('.button-save').click(function () {
    var plan = [];
    for (let i = 1; i <= 7; i++) {
        let planText = $($('input')[i - 1]).val();
        let planTime = $('#timepicker' + i + ' .time').text();
        if (planText != '' && planTime != '') {
            plan.push({
                planText: planText,
                planTime: planTime
            })
        };

    }
    $.ajax({
        url: 'http://www.htown.xyz/Home/index/formulate_plan',
        data: {
            plan: plan,
            openid: openid
        },
        type: 'POST',
        success: function (data) {
            window.location.href = '../index/index.html?type=' + type;
        }
    })
});






