<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/14
 * Time: 10:48
 */
namespace Home\Model;
use Think\Model;
Class RoomUserModel extends Model{



}