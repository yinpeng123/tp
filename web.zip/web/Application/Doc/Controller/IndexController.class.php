<?php
namespace Doc\Controller;

use Think\Controller;
use Basic\Cnsts\WECHAT;
use Open\Cnsts\AGENT;
use Open\Cnsts\ERRCODE;

class IndexController extends Controller{

    /**
     * 首页
     * @return [type] [description]
     */
    public function index(){
        echo "hello world";
    }

}

