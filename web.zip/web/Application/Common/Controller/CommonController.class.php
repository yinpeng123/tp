<?php
namespace Common\Controller;

use Think\Controller;
use Common\Service\UtilService;
use Common\Cnsts\ERRNO;

/**
 * 基础controller, 不验证用户登录状态
 * @package Common\Controller
 */
class CommonController extends Controller {

    // 请求
    protected $req = null;
    // 请求来源
    protected $from = null;
    protected $app_info = null;

    public function __construct() {
        parent::__construct();

        // 不需要显示初始化!
        //S(array());

        // 获取请求的req
        $req = I("req", "", "htmlspecialchars");
        if ( !APP_DEBUG ) {
            $req = UtilService::decrypt($req);
        }
        $this->req = json_decode(html_entity_decode($req), true);
        $app_info = I("app_info", "", "htmlspecialchars");
        if ( !APP_DEBUG ) {
            $app_info = UtilService::decrypt($app_info);
        }
        //cmm_log($this->req,'########REQ_DATA');
        cmm_log2($this->req, 'REQ_DATA');


        // 获取app_info
        $this->app_info = json_decode(html_entity_decode($app_info), true);
        cmm_log2($this->app_info, 'APP_INFO');

        // 请求来源 默认是pc 来自移动端是mobile
        $this->from = isset($this->app_info['from']) ? $this->app_info['from'] : 'pc';
    }

    /**
     * 获取请求参数便捷方法, 支持ThinkPHP的I()的变量过滤和变量修饰符功能
     *
     * @param        $name
     * @param string $default
     * @param null   $filter
     *
     * @return mixed
     */
    public function I($name, $default = '', $filter = null) {
        return I('data.'.$name, $default, $filter, $this->req);
    }

    /**
     * 渲染模板或直接echo
     *
     * @param[in] $errnol 错误码
     * @param[in] $errmsg 错误提示
     * @param[in] $res 返回数据
     * @param[in] $tpl 模板名称
     * return null
     * */
    public function doResponse($errno = ERRNO::SUCCESS, $errmsg = 'Success', $res = NULL, $tpl = "") {
        //从req中删除保存的当前用户信息
        unset($this->req['_user_id']);
        unset($this->req['_user_info']);
        //cmm_log('###RES_DATA:'.'ERRNO:'.$errno.'ERRMSG:'.$errmsg.'RES:'.json_encode($res,JSON_UNESCAPED_UNICODE));
        cmm_log2('errno:'.$errno.', errmsg:'.$errmsg.', res:'.json_encode($res,JSON_UNESCAPED_UNICODE), 'RES_DATA');

        //上线前期记录日志
        $req = $this->req;
        if ( !APP_DEBUG ) {
            $req = UtilService::encrypt(json_encode($req, JSON_UNESCAPED_UNICODE));
            $res = UtilService::encrypt(json_encode($res, JSON_UNESCAPED_UNICODE));
        }

        $resp = [
            "errno" => $errno,
            "errmsg" => $errmsg,
            "req" => $req,
            "res" => $res
        ];

        if (I("noreq")) {
            unset($resp["req"]);
        }

        // url中有raw参数，直接返回assgin给模板的json数据
        if (I("raw") || empty($tpl)) {
            header("Content-Type: application/json; charset=utf-8");
            echo json_encode($resp, JSON_UNESCAPED_UNICODE);
            return TRUE;
        }
        $this->assign("data", $resp);
        $this->display(I("tpl", $this->req['tpl'] ?: $tpl), 'utf-8', 'text/json');
        return TRUE;
    }

}
