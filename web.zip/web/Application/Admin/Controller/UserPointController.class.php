<?php
namespace Admin\Controller;

use Basic\Model\AgentModel;
use Basic\Model\MemberShipCardModel;
use Basic\Model\UserModel;
use Basic\Model\UserPointLogModel;
use Basic\Service\AgentService;
use Basic\Service\MemberShipCardService;
use Basic\Service\UserService;
use Common\Cnsts\ERRNO;
use Basic\Cnsts\POINT;
use Admin\Service\PageService;

class UserPointController extends AdminSessionController {

    private $_per_page = 5;

    public function __construct()
    {
        parent::__construct();
    }


    public function userPointList() {
        $search_account = I('search_account');
        $search_telephone = I('search_telephone');

        $cond = [];
        if (!empty($search_account)) {
            $cond['user.account'] = ['eq', $search_account];
        }
        if (!empty($search_telephone)) {
            $cond['user.telephone'] = ['eq', $search_telephone];
        }

        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);

        /** @var \Admin\Model\UserModel $user_model */
        $user_model = D('Admin/User', 'Model');
        $res = $user_model->userPointList($cond, $curr_page, $per_page);

        /** @var UserService $user_service */
        $user_service = D('Basic/User', 'Service');
        foreach ($res['data'] as $k=>&$r) {
            $r['member_type'] = $member_type = $user_service->getMemberType($r);
            $r['pc_member_type'] = $pc_member_type = $user_service->getPcMemberType($r);
            $r['member_type_desc'] = $user_service->getFromatMemberType($member_type);
            $r['pc_member_type_desc'] = $user_service->getFromatMemberType($pc_member_type);

            if ($r['member_end_time'] < datetime()) {
                $r['member_status'] = '到期';
                $r['member_color'] = 'my-ft my-red';
            } else {
                $r['member_status'] = '正常';
                $r['member_color'] = 'my-ft my-green';
            }

            if ($r['pc_member_end_time'] < datetime()) {
                $r['pc_member_status'] = '到期';
                $r['pc_member_color'] = 'my-ft my-red';
            } else {
                $r['pc_member_status'] = '正常';
                $r['pc_member_color'] = 'my-ft my-green';
            }
//            my-ft my-red
        }
        $search_param = [
            'search_account' => $search_account,
            'search_telephone' => $search_telephone,
        ];
        $page_service = new PageService($res['count'], $per_page);
        $page_nav = $page_service->show();
//p($res['data']);die;
        $this->assignAll(array(
            'title' => '用户积分列表',
            'list' => $res['data'],
            'page_nav' => $page_nav,
            'search_param' => $search_param,
        ));
        $this->display('user_point_list');
    }

    public function userExchangeList() {
        $search_account = I('search_account');
        $search_telephone = I('search_telephone');

        $cond = [];
        if (!empty($search_account)) {
            $cond['user.account'] = ['eq', $search_account];
        }
        if (!empty($search_telephone)) {
            $cond['user.telephone'] = ['eq', $search_telephone];
        }

        $search_param = [
            'search_account' => $search_account,
            'search_telephone' => $search_telephone,
        ];
        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);

        /** @var UserPointLogModel $user_point_log_model */
        $user_point_log_model = D('Basic/UserPointLog', 'Model');
        $res = $user_point_log_model->userExchangeList($cond, $curr_page, $per_page);

        $page_service = new PageService($res['count'], $per_page);
        $page_nav = $page_service->show();

        $this->assignAll(array(
            'title' => '用户兑换列表',
            'list' => $res['data'],
            'form_action' => "/UserPoint/userExchangeList",
            'search_param' => $search_param,
            'page_nav' => $page_nav,
        ));
        $this->display('user_exchange_list');
    }

    public function memberShipList() {
        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        /** @var MemberShipCardModel $membership_card_model */
        $membership_card_model = D('Basic/MemberShipCard', 'Model');
        $res = $membership_card_model->membershipCardList(['is_delete' => 0], $curr_page, $per_page);

        /** @var AgentService $agent_service */
        $agent_service = D('Basic/Agent', 'Service');
        foreach ($res['data'] as &$v) {
            $v['des_word'] = t_json_decode($v['des_word'])['0'] . '，' . t_json_decode($v['des_word'])['1'];

            if ($v['agent_id'] != 0) {
                $agent_info = $agent_service->getAgentById($v['agent_id']);
                $v['agent_name'] = $agent_info['name'];
            } else {
                $v['agent_name'] = '全部';
            }

            if (!in_array([1001, 1002, 1003], $v['id'])) {
                $v['action_status'] = 0;
            } else {
                $v['action_status'] = 1;
            }

        }
        $page_service = new PageService($res['count'], $per_page);
        $page_nav = $page_service->show();
        $this->assignAll(array(
            'title' => '活动礼品卡管理',
            'list' => $res['data'],
            'page_nav' => $page_nav,
        ));
        $this->display('member_ship_list');
    }

    public function shipCard() {
        /** @var AgentModel $agent_model */
        $agent_model = D('Basic/Agent', 'Model');
        $res = $agent_model->getAllAgentList($fields = NULL, $where = [] );
        $card_info = [];
        if (I('action') != 'add') {
            $card_id = I('card_id');
            /** @var MemberShipCardService $membership_card_service */
            $membership_card_service = D('Basic/MemberShipCard', 'Service');
            $ship_card_info = $membership_card_service->memberShipCardInfo($card_id);
            $card_info = $ship_card_info['data'];
            $card_info['des_word_1'] = t_json_decode($card_info['des_word'])['0'];
            $card_info['des_word_2'] = t_json_decode($card_info['des_word'])['1'];
        }
        $this->assignAll(array(
            'title' => I('action') == 'add' ? '新增礼品卡' : '编辑礼品卡',
            'card_info' => I('action') == 'add' ? '' : $card_info,
            'action' => I('action'),
            'search_list' => $res,
            'form_action' => '/UserPoint/doShip',
            'back_to_list_url' => $this->_refer,
        ));
        $this->display('ship_info');
    }

    public function doShip() {
        /** @var MemberShipCardService $membership_card_service */
        $membership_card_service = D('Basic/MemberShipCard', 'Service');
        $info = [
            'days' => I('card_days'),
            'point' => I('card_point'),
            'des_word' => t_json_encode([I('des_word_1'), I('des_word_2')]),
            'agent_id' => I('search_agent_id'),
            'dtime' => I('action_time'),
        ];
        if (I('action') == 'add') { // 新增
            $list = $membership_card_service->getListBy([], $fields = '', $order = '', $curpage = 0, $perpage = 0);
            $info['id'] = 1001 + count($list);
            $res = $membership_card_service->addMemberShipCard($info);
            if ($res['code'] != ERRNO::SUCCESS) {
                $this->admin_error('添加出错');
            } else {
                redirect(U('userPoint/memberShipList'));
            }
        } else { // 编辑

            $res = $membership_card_service->editMemberShipCard(I('card_id'), $info);
            if ($res['code'] != ERRNO::SUCCESS) {
                $this->admin_error('编辑出错');
            } else {
                redirect(U('userPoint/memberShipList'));
            }
        }
    }
    public function getUser() {

    }


    public function ajaxGetPointList() {
        $uid = I('uid');
        /** @var UserPointLogModel $user_point_log_model */
        $user_point_log_model = D('Basic/UserPointLog', 'Model');
        $res = $user_point_log_model->getlist(['uid' => $uid], $order = 'ctime desc', $curpage=I('p'), $perpage = $this->_per_page);

        foreach ($res['data'] as &$v) {
            $v['type_desc'] = POINT::POINT_TYPE_NAMES[$v['type']];
            $v['in_out_desc'] = $v['in_out'] == 1 ? '积分增加' : '消费';
            $v['change_desc'] = $v['in_out'] == 1 ? '+' . $v['point'] : '-' . $v['point'];
        }

        return $this->ajaxResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), $res);

    }

    public function ajaxGetExchangeList() {
        $uid = I('uid');
        /** @var UserPointLogModel $user_point_log_model */
        $user_point_log_model = D('Basic/UserPointLog', 'Model');
        $res = $user_point_log_model->getlist(['uid' => $uid, 'in_out' => 2], $order = 'ctime desc', $curpage=I('p'), $perpage = $this->_per_page);

        /** @var MemberShipCardService $member_ship_service */
        $member_ship_service = D('Basic/MemberShipCard', 'Service');

        foreach ($res['data'] as &$v) {
            $info = $member_ship_service->memberShipCardInfo($v['certain_id']);
            $v['member_ship_card'] = $info['data']['days'] . '天会员卡';
        }

        return $this->ajaxResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), $res);
    }
}