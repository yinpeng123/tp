<?php
namespace Admin\Controller;

use Admin\Model\TicketModel;
use Admin\Controller\AdminSessionController;
use Admin\Service\PageService;
use Basic\Cnsts\DICT;
use Admin\Service\ManagerService;
use Basic\Model\AgentModel;
use Basic\Model\CityModel;
use Basic\Model\StatsAgentFinanceModel;
use Basic\Service\AgentService;
use Basic\Service\StatsService;
use Basic\Service\WLSendService;
use Think\Model;
use Common\Cnsts\ERRNO;
use Basic\Service\CityService;
use Basic\Service\AddressService;

class AgentController extends AdminSessionController
{
    private $__agent_model = null;
    private $__user_service = null;
    private $__manager_service = null;

    public function __construct()
    {
        parent::__construct();

        $this->__agent_model     = D('Basic/Agent');
        $this->__user_service    = D('User', 'Service');
        $this->__manager_service = D('Manager', 'Service');

        // 权限检查
        if (!\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::AGENT)) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }
    }

    /**
     * 渠道列表
     */
    public function index()
    {
        //获取渠道类型
        $agent_style_arr = $this->getAgentStyle();
        //获取渠道状态
        $agent_status_arr = $this->getAgentStatus();

        $agentId         = I('agentId');
        $name            = I('name');
        $director        = I('director');
        $mobile          = I('mobile');
        $type            = I('type');
        $contract_no     = I('contract_no');
        $agent_status    = I('agent_status');
        $search_from_day = I('start_day');
        $search_to_day   = I('end_day');
        $search_agent_id = I('search_agent_id');
//p($agent_status);
        if (!empty($agentId)) {
            $cond['id'] = ['eq', $agentId];
        }

        if (!empty($search_agent_id)) {
            $cond['id'] = ['eq', $search_agent_id];
        }
        if (!empty($director)) {
            $cond['director'] = ['like', '%' . $director . '%'];
        }
        if (!empty($mobile)) {
            $cond['mobile'] = ['like', '%' . $mobile . '%'];
        }
        if (!empty($type)) {
            $cond['type'] = ['eq', $type];
        }
        if (!empty($contract_no)) {
            $cond['contract_no'] = ['like', '%' . $contract_no . '%'];
        }
        if (!empty($agent_status)) {
            $cond['agent_status'] = ['eq', $agent_status];
        }
        if (!empty($search_from_day) || !empty($search_to_day)) {
            $cond['end_day'] = [['egt', $search_from_day], ['elt', $search_to_day]];
        }
        if (!empty($search_from_day)) {
            $cond['end_day'] = ['egt', $search_from_day];
        }
        if (!empty($search_to_day)) {
            $cond['end_day'] = ['elt', $search_to_day];
        }

        //列表页只显示信息填写完备的渠道数据
        $cond['is_done'] = 1;

        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        $ret       = $this->__agent_model->searchAgentList($cond, $curr_page, $per_page);
//p($ret);die;
        // 全部已完成渠道数据
        $res = $this->__agent_model->getAllAgentList($fields = NULL, $where = [] );
//        p($res);die;
        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();

//        p($ret['data']);
//        foreach ($ret['data'] as $i => &$r) {
//            $r['type'] = DICT::getDictValue($r['type'], 'type');
//        }

        $product_model = new \Basic\Model\ProductModel('', TRUE);
//        $product_model = D('Basic/Product');
        //处理产品数据
        for ($i = 0; $i < count($ret['data']); $i++) {
            $product_names = '';
            $product_arr   = json_decode($ret['data'][$i]['product'], true);

            for ($j = 0; $j < count($product_arr); $j++) {
                // 产品功能名称
                $where        = [
                    'id' => $product_arr[$j],
                ];
                $info = S('product'.'_'.$product_arr[$j]); // 缓存数据
                if (empty($info)) {
                    $value = $product_model->getBy($where, $fields = '');
                } else {
                    $value = $info;
                }
//                $product_name = $product_model->getBy($where, $fields = '');
                $product_names .= $value['name'] . '/';
            }
            $ret['data'][$i]['product'] = $product_names;

        }

//        p($ret['data']);die;
        $this->assignAll([
            'title'            => '渠道管理',
            'search_list'     => $res,
            'list'             => $ret['data'],
            'action'           => 'list',
            'name'             => $name,
            'agentId'          => $agentId,
            'director'         => $director,
            'mobile'           => $mobile,
            'start_day'        => $search_from_day,
            'end_day'          => $search_to_day,
            'contract_no'      => $contract_no,
            'agent_style_arr'  => $agent_style_arr,
            'agent_status_arr' => $agent_status_arr,
            'page_nav'         => $page_nav,
            'type'             => $type,
            'agent_status'     => $agent_status,
            'search_agent_id' => I('search_agent_id'),
        ]);
        $this->display('agent_list');
    }

    /**
     * 新增页面
     */
    public function addAgent()
    {
        //获取渠道类型
        $agent_style_arr = $this->getAgentStyle();

        //获取渠道状态
        $agent_status_arr = $this->getAgentStatus();

        //获取邮箱后缀
        $email_fix = $this->getEmailFix();

//        p($email_fix);

        //获取城市数据
        $city_model    = D('Basic/City');
        $province_list = $city_model->getCitiesByWhere(['parent_id' => -1], 'short_spell asc');

        $agent_id = I('0');
        if (I('btn') === 'prev') {
            //获取渠道类型
            $agent_style_arr = $this->getAgentStyle();
            //获取渠道状态
            $agent_status_arr = $this->getAgentStatus();
            $agent            = $this->__agent_model->getAgentById($agent_id);

            /** @var CityService $city_service */
            $city_service = D('Basic/City', 'Service');
            $province_city_dis = $city_service->getAreaFullName($agent['fixed_area'], $sep = '-');

            $this->assignAll([
                'type'             => $agent['type'],
                'agent_status'     => $agent['agent_status'],
                'agent_style_arr'  => $agent_style_arr,
                'agent_status_arr' => $agent_status_arr,
                'agent'            => $agent,
                'fixed_area' => $province_city_dis,
                'start_district' => $agent['fixed_area'],
                'start_city' => substr($agent['fixed_area'], 0, 4),
                'start_province' => substr($agent['fixed_area'], 0, 2),
            ]);
        }
        $this->assignAll([
            'title'            => '新增渠道',
            'act'              => 'addAgent',
            'form_action'      => '/agent/doAddAgent',
            'agent_status_arr' => $agent_status_arr,
            'agent_style_arr'  => $agent_style_arr,
            'province_list'    => $province_list,
            'cctime'           => date('Y-m-d H:i:s'),
            'email_fix'        => $email_fix,
        ]);
        $this->assign('back_to_list_url', $this->_backToListUrl($this->_refer));
        $this->display('agent_add');
    }

    /**
     * 资质文件上传页面
     */
    public function certification()
    {
        $data = I('');
        if ($data['actn'] === 'add_certification') {
            $this->assignAll([
                'title'       => '新增渠道',
                'agent_id'    => $data[0],
                'act'         => 'addCertification',
                'action'      => 'add',
                'form_action' => '/agent/doCertifi',
            ]);
            $this->assign('back_to_list_url', $this->_backToListUrl($this->_refer));
        } else {
            $agent       = $this->__agent_model->getAgentById($data[0]);
            $agent['id'] = $data[0];
            $ret         = $this->__agent_model->getAgentById($data[0]);
//        p($ret);die;
            //获取资质图片信息
            $photo                              = json_decode($ret['certification'], true);
            $card_photo['card_photo']           = $photo['card_photo'];
            $card_photo_back['card_photo_back'] = $photo['card_photo_back'];
            $business_photo['business_photo']   = $photo['business_photo'];
            $image                              = json_decode($ret['contract_file'], true);

            if (empty($card_photo_back['card_photo_back'])) {
                unset($card_photo_back);
            }
            if (empty($card_photo['card_photo'])) {
                unset($card_photo);
            }
            if (empty($business_photo['business_photo'])) {
                unset($business_photo);
            }

            foreach ($image as $k => &$v) {
                $v['url'] = imageUrl($v);

                // 获取图片的路径信息
                $ret = getImage($v['type'], $v['path'], $v['name'], $info);
                if ($ret == ERRNO::SUCCESS) {
                    $v['size']           = $info['size'];
                    $v['initialPreview'] = $v['url'];
                    $v['type']           = 'image';
                    $v['caption']        = $v['name'];
                    $v['key']            = $k;
                    $v['url']            = '/agent/deleteImage/' . $agent['id'];
                } else {
                    $v['size'] = 0;
                }
            }
            foreach ($card_photo as $k => &$v) {
                $v['url'] = imageUrl($v);

                // 获取图片的路径信息
                $ret = getImage($v['type'], $v['path'], $v['name'], $info);
                if ($ret == ERRNO::SUCCESS) {
                    $v['size']           = $info['size'];
                    $v['initialPreview'] = $v['url'];
                    $v['type']           = 'image';
                    $v['caption']        = $v['name'];
                    $v['key']            = $k;
                    $v['url']            = '/agent/deleteImage/' . $agent['id'];
                } else {
                    $v['size'] = 0;
                }
            }
            foreach ($card_photo_back as $k => &$v) {
                $v['url'] = imageUrl($v);

                // 获取图片的路径信息
                $ret = getImage($v['type'], $v['path'], $v['name'], $info);
                if ($ret == ERRNO::SUCCESS) {
                    $v['size']           = $info['size'];
                    $v['initialPreview'] = $v['url'];
                    $v['type']           = 'image';
                    $v['caption']        = $v['name'];
                    $v['key']            = $k;
                    $v['url']            = '/agent/deleteImage/' . $agent['id'];
                } else {
                    $v['size'] = 0;
                }
            }

            foreach ($business_photo as $k => &$v) {
                $v['url'] = imageUrl($v);

                // 获取图片的路径信息
                $ret = getImage($v['type'], $v['path'], $v['name'], $info);
                if ($ret == ERRNO::SUCCESS) {
                    $v['size']           = $info['size'];
                    $v['initialPreview'] = $v['url'];
                    $v['type']           = 'image';
                    $v['caption']        = $v['name'];
                    $v['key']            = $k;
                    $v['url']            = '/agent/deleteImage/' . $agent['id'];
                } else {
                    $v['size'] = 0;
                }
            }


            if (!empty($image)) {
                if (!empty($card_photo)) {
                    if (!empty($card_photo_back)) {
                        if (!empty($business_photo)) {
                            $this->assignAll([
                                'card_photo'      => $card_photo['card_photo'],
                                'business_photo'  => $business_photo['business_photo'],
                                'card_photo_back' => $card_photo_back['card_photo_back'],
                                'image'           => $image['contract_file'],
                                'title'           => '编辑渠道',
                                'action'          => 'edit',
                                'acti'            => 'editCertification',
                                'agent'           => $agent,
                                'form_action'     => '/agent/doEditCertification',
                            ]);
                        } else {
                            $this->assignAll([
                                'card_photo'      => $card_photo['card_photo'],
                                'card_photo_back' => $card_photo_back['card_photo_back'],
                                'image'           => $image['contract_file'],
                                'title'           => '编辑渠道',
                                'action'          => 'edit',
                                'acti'            => 'editCertification',
                                'agent'           => $agent,
                                'form_action'     => '/agent/doEditCertification',
                            ]);
                        }
                    } else {
                        if (!empty($business_photo)) {
                            $this->assignAll([
                                'card_photo'     => $card_photo['card_photo'],
                                'business_photo' => $business_photo['business_photo'],
                                'image'          => $image['contract_file'],
                                'title'          => '编辑渠道',
                                'action'         => 'edit',
                                'acti'           => 'editCertification',
                                'agent'          => $agent,
                                'form_action'    => '/agent/doEditCertification',
                            ]);
                        } else {
                            $this->assignAll([
                                'card_photo'  => $card_photo['card_photo'],
                                'image'       => $image['contract_file'],
                                'title'       => '编辑渠道',
                                'action'      => 'edit',
                                'acti'        => 'editCertification',
                                'agent'       => $agent,
                                'form_action' => '/agent/doEditCertification',
                            ]);
                        }
                    }
                } else {
                    if (!empty($card_photo_back)) {
                        if (!empty($business_photo)) {
                            $this->assignAll([
                                'business_photo'  => $business_photo['business_photo'],
                                'card_photo_back' => $card_photo_back['card_photo_back'],
                                'image'           => $image['contract_file'],
                                'title'           => '编辑渠道',
                                'action'          => 'edit',
                                'acti'            => 'editCertification',
                                'agent'           => $agent,
                                'form_action'     => '/agent/doEditCertification',
                            ]);
                        } else {
                            $this->assignAll([
                                'card_photo_back' => $card_photo_back['card_photo_back'],
                                'image'           => $image['contract_file'],
                                'title'           => '编辑渠道',
                                'action'          => 'edit',
                                'acti'            => 'editCertification',
                                'agent'           => $agent,
                                'form_action'     => '/agent/doEditCertification',
                            ]);
                        }
                    } else {
                        if (!empty($business_photo)) {
                            $this->assignAll([
                                'business_photo' => $business_photo['business_photo'],
                                'image'          => $image['contract_file'],
                                'title'          => '编辑渠道',
                                'action'         => 'edit',
                                'acti'           => 'editCertification',
                                'agent'          => $agent,
                                'form_action'    => '/agent/doEditCertification',
                            ]);
                        } else {
                            $this->assignAll([
                                'image'       => $image['contract_file'],
                                'title'       => '编辑渠道',
                                'action'      => 'edit',
                                'acti'        => 'editCertification',
                                'agent'       => $agent,
                                'form_action' => '/agent/doEditCertification',
                            ]);
                        }
                    }
                }
            } else {
                if (!empty($card_photo)) {
                    if (!empty($card_photo_back)) {
                        if (!empty($business_photo)) {
                            $this->assignAll([
                                'card_photo'      => $card_photo['card_photo'],
                                'card_photo_back' => $card_photo_back['card_photo_back'],
                                'business_photo'  => $business_photo['business_photo'],
                                'title'           => '编辑渠道',
                                'action'          => 'edit',
                                'acti'            => 'editCertification',
                                'agent'           => $agent,
                                'form_action'     => '/agent/doEditCertification',
                            ]);
                        } else {
                            $this->assignAll([
                                'card_photo'      => $card_photo['card_photo'],
                                'card_photo_back' => $card_photo_back['card_photo_back'],
                                'title'           => '编辑渠道',
                                'action'          => 'edit',
                                'acti'            => 'editCertification',
                                'agent'           => $agent,
                                'form_action'     => '/agent/doEditCertification',
                            ]);
                        }
                    } else {
                        if (!empty($business_photo)) {
                            $this->assignAll([
                                'card_photo'     => $card_photo['card_photo'],
                                'business_photo' => $business_photo['business_photo'],
                                'title'          => '编辑渠道',
                                'action'         => 'edit',
                                'acti'           => 'editCertification',
                                'agent'          => $agent,
                                'form_action'    => '/agent/doEditCertification',
                            ]);
                        } else {
                            $this->assignAll([
                                'card_photo'  => $card_photo['card_photo'],
                                'title'       => '编辑渠道',
                                'action'      => 'edit',
                                'acti'        => 'editCertification',
                                'agent'       => $agent,
                                'form_action' => '/agent/doEditCertification',
                            ]);
                        }
                    }
                } else {
                    if (!empty($card_photo_back)) {
                        if (!empty($business_photo)) {
                            $this->assignAll([
                                'card_photo_back' => $card_photo_back['card_photo_back'],
                                'business_photo'  => $business_photo['business_photo'],
                                'title'           => '编辑渠道',
                                'action'          => 'edit',
                                'acti'            => 'editCertification',
                                'agent'           => $agent,
                                'form_action'     => '/agent/doEditCertification',
                            ]);
                        } else {
                            $this->assignAll([
                                'card_photo_back' => $card_photo_back['card_photo_back'],
                                'title'           => '编辑渠道',
                                'action'          => 'edit',
                                'acti'            => 'editCertification',
                                'agent'           => $agent,
                                'form_action'     => '/agent/doEditCertification',
                            ]);
                        }
                    } else {
                        if (!empty($business_photo)) {
                            $this->assignAll([
                                'business_photo' => $business_photo['business_photo'],
                                'title'          => '编辑渠道',
                                'action'         => 'edit',
                                'acti'           => 'editCertification',
                                'agent'          => $agent,
                                'form_action'    => '/agent/doEditCertification',
                            ]);
                        } else {
                            $this->assignAll([
                                'title'       => '编辑渠道',
                                'action'      => 'edit',
                                'acti'        => 'editCertification',
                                'agent'       => $agent,
                                'form_action' => '/agent/doEditCertification',
                            ]);
                        }
                    }
                }
            }
            $this->assign('back_to_list_url', $this->_backToListUrl($this->_refer));
        }

        $this->display('agent_certifiation');
    }

    // ajax上传图片接口
    public function ajaxUploadImage()
    {
//        p($_FILES);die;
        $key = key($_FILES);
        if (empty($_FILES[$key]) || $_FILES[$key]['size'] == 0) {
            die("{}");
        }

        $root_dir   = C('IMAGE_PATH')['certificate'];
        $sub_dir    = day();
        $image_info = [];
        list($errcode, $errmsg) = uploadImage($key, $root_dir, $sub_dir, $image_info, 'certificate');
        if ($errcode != ERRNO::SUCCESS) {
            echo json_encode(['error' => $errmsg]);
            exit;
        } else {
            // 前端显示为和初始预览框一样的状态: 移动排序图标, 无进度条
            $res = [
                'initialPreview'       => [imageUrl($image_info)],
                'initialPreviewConfig' => [
                    [
                        'type'    => 'image',
                        'caption' => $image_info['name'],
                        'size'    => $_FILES[$key]['size'],
                        'url'     => '/api/ajaxDeleteImage',
                        'key'     => 1,
                    ],
                ]
            ];
            echo json_encode($res);
            exit;
        }
    }

    /**
     * 执行上传(资质信息)
     */
    public function doCertifi()
    {
        $data = I('');
//        p($data);die;
        $agent_id = $data['agent_id'];
        //上传处理
        $root_dir = C('IMAGE_PATH')['certificate'];
        $sub_dir  = day();

        $arr = explode('/', $data['card_photo']);

        $ajax_card_photo = [
            'name' => $arr[8],
            'path' => $arr[7],
            'type' => 'certificate'
        ];

        $card_photo_info = $ajax_card_photo;
        if (!empty($_FILES['card_photo']['name']) && $_FILES['card_photo']['size'] > 0) { // 身份证正面照片
            list($errcode, $errmsg) = uploadImage('card_photo', $root_dir, $sub_dir, $card_photo_info, 'certificate');
            if ($errcode != ERRNO::SUCCESS) {
                $this->admin_error('身份证正面照片上传失败！' . $errmsg);

                return;
            }
        }

        $arr = explode('/', $data['card_photo_back']);

        $ajax_card_back = [
            'name' => $arr[8],
            'path' => $arr[7],
            'type' => 'certificate'
        ];

        $card_photo_back_info = $ajax_card_back;
        if (!empty($_FILES['card_photo_back']['name']) && $_FILES['card_photo_back']['size'] > 0) { // 身份证背面照片
            list($errcode, $errmsg) = uploadImage('card_photo_back', $root_dir, $sub_dir, $card_photo_back_info,
                'certificate');
            if ($errcode != ERRNO::SUCCESS) {
                $this->admin_error('身份证背面照片上传失败！' . $errmsg);

                return;
            }
        }

        $arr = explode('/', $data['business_photo']);

        $ajax_business_photo = [
            'name' => $arr[8],
            'path' => $arr[7],
            'type' => 'certificate'
        ];

        $business_photo_info = $ajax_business_photo;
        if (!empty($_FILES['business_photo']['name']) && $_FILES['business_photo']['size'] > 0) { // 营业执照照片
            list($errcode, $errmsg) = uploadImage('business_photo', $root_dir, $sub_dir, $business_photo_info,
                'certificate');
            if ($errcode != ERRNO::SUCCESS) {
                $this->admin_error('营业执照照片上传失败！' . $errmsg);

                return;
            }
        }

        $arr = explode('/', $data['contract_file']);

        $ajax_contract_file = [
            'name' => $arr[8],
            'path' => $arr[7],
            'type' => 'certificate'
        ];

        $contract_file_info = $ajax_contract_file;
        if (!empty($_FILES['contract_file']['name']) && $_FILES['contract_file']['size'] > 0) { // 合同文件
            list($errcode, $errmsg) = uploadImage('contract_file', $root_dir, $sub_dir, $contract_file_info,
                'certificate');
            if ($errcode != ERRNO::SUCCESS) {
                $this->admin_error('合同文件上传失败！' . $errmsg);

                return;
            }
        }

        // 处理图片数据
        if (!empty($card_photo_info)) {
            $photos['card_photo'] = $card_photo_info;
        }
        if (!empty($card_photo_back_info)) {
            $photos['card_photo_back'] = $card_photo_back_info;
        }
        if (!empty($business_photo_info)) {
            $photos['business_photo'] = $business_photo_info;
        }
        if (!empty($contract_file_info)) {
            $contract['contract_file'] = $contract_file_info;
        }

        $fields['certification'] = json_encode($photos);
        $fields['contract_file'] = json_encode($contract);
        $fields['is_done']       = 1;
        $fields['ctime']         = date('Y-m-d H:i:s');

//        //添加固定区域
//        $fields['fixed_area'] = $this->addFixedArea($agent_id);

        $agent_model = new \Basic\Model\AgentModel();
        $agent_model->updateAgent($agent_id, $fields);

        //同步agent数据
        /** @var WLSendService $send_service */
        $send_service = D('Basic/WLSend', 'Service');
        $res          = $send_service->syncAgent($agent_id);

        // 添加操作日志
        $this->__user_service->addOperLog([
            'manager_id' => $this->_manager_id,
            'object_id'  => $agent_id,
            'action'     => 'add',
            'desc'       => "上传信息成功",
        ]);
        $this->__manager_service->addOperLog([
            'manager_id' => $this->_manager_id,
            'action'     => 'doCertifi',
            'desc'       => "上传资质信息",
        ]);
        $url = 'index';
        $this->admin_success('添加渠道成功！', $url);
    }

    /**
     * 获取渠道的固定区域
     * @param $agent_id 渠道ID
     *
     * @return mixed 返回固定区域（地址代码）
     */
    private function addFixedArea($agent_id)
    {
        /** @var AgentService $agent_service */
        $agent_service = D('Basic/Agent', 'Service');
        $agent_info = $agent_service->getAgentById($agent_id);
        $fixed_area = current(json_decode($agent_info['area']));
        return $fixed_area;
    }

    /**
     * 执行新增渠道
     */
    public function doAddAgent()
    {
        $act  = I('act');
        $name = I('name');
        if (empty($name)) {
            $this->admin_error('渠道名不能为空');

            return;
        }
        $director = I('director');
        if (empty($director)) {
            $this->admin_error('负责人不能为空');

            return;
        }
        $contract_no = I('contract_no');
        if (empty($contract_no)) {
            $this->admin_error('合同号不能为空');

            return;
        }
        $contract_amount = I('contract_amount');
        $mobile          = I('mobile');
        if (!is_mobile($mobile)) {
            $this->admin_error('手机号格式不正确！');

            return;
        }
        $mail = I('mail');
        if (!is_email($mail) && !empty($mail)) {
            $this->admin_error('邮箱格式不正确');

            return;
        }
        $identity = I('identity');
        if (!preg_match("/^(\d{15}$|^\d{18}$|^\d{17}(\d|X|x))$/", $identity)) {
            $this->admin_error('身份证号格式不正确！');

            return;
        }
        $phone1 = I('phone1/s');
        if (!empty($phone1) && !is_phone($phone1)) {
            $this->admin_error('联系电话1格式不正确！');

            return;
        }
        $phone2 = I('phone2/s');
        if (!empty($phone2) && !is_phone($phone2)) {
            $this->admin_error('联系电话2格式不正确！');

            return;
        }
        $wphone = I('service_phone/s');
        if (!empty($wphone) && !is_phone($wphone) && !is_mobile($wphone)) {
            $this->admin_error('客服电话格式不正确！');

            return;
        }
        if (I('district') == -1) {
            $fixed_area = I('province');
        } elseif (I('district') == 0) {
            $fixed_area = I('city');
        } else {
            $fixed_area = I('district');
        }

        $data              = [
            'area'            => json_encode(explode(',', I('area'))),
            'name'            => str_replace('&amp;', '&', $name),
            'type'            => I('type'),
            'agent_status'    => I('agent_status'),
            'director'        => $director,
            'contract_no'     => $contract_no,
            'contract_amount' => $contract_amount,
            'mobile'          => $mobile,
            'try_days'        => I('try_days'),
            'phone1'          => $phone1,
            'phone2'          => $phone2,
            'service_phone'  => $wphone,
            'mail'            => $mail,
            'identity'        => $identity,
            'start_day'       => I('start_day'),
            'end_day'         => I('end_day'),
            'remark'          => I('remark'),
            'ctime'           => I('ctime'),
            'is_check_telephone' => I('is_check_telephone/d'), // 新增是否电话号格式验证
            'fixed_area' => $fixed_area,
        ];

        $add_agent_service = new \Basic\Service\AgentService();
        $res               = $add_agent_service->addAgent($data);
        if ($res) {
            $this->__manager_service->addOperLog([
                'manager_id' => $this->_manager_id,
                'action'     => 'doAddAgent',
                'desc'       => "添加渠道基本信息",
            ]);
            $this->assignAll([
                'agent_id' => $res,
            ]);
            redirect(U('agent/editInvoice/' . $res, '', '') . '?acti=agent_id');
        } else {
            $this->admin_error('新增失败');
        }

    }


    /**
     * 地区黑名单
     */
    public function blackarea()
    {
        $data = I('');
//p($data);die;
        //获取城市数据
        $city_model    = D('Basic/City');
        $province_list = $city_model->getCitiesByWhere(['parent_id' => -1], 'short_spell asc');
//p($province_list);die;
        if ($data['actn'] === 'add_blackarea') {
            $this->assignAll([
                'province_list'    => $province_list,
                'agent_id'         => $data[0],
                'act'              => 'addBlackarea',
                'form_action'      => '/agent/addBlackarea',
                'back_to_list_url' => $this->_backToListUrl($this->_refer),
            ]);
            if ($data['btn'] === 'prev') {
                $agent = $this->__agent_model->getAgentById($data[0]);
//p($agent);die;
                //黑名单信息(超群的组件)
                $black_area_list = $this->getBlackArea($agent['id'], $area = 'blackarea');
//p($black_area_list);die;
                $this->assignAll([
                    'province_list'   => $province_list,
                    'agent_id'        => $data[0],
                    'agent'           => $agent,
                    'black_area_list' => $black_area_list,
                ]);
            }
        } else {
            $agent = $this->__agent_model->getAgentById($data[0]);
//p($agent);die;
            //黑名单信息(超群的组件)
            $black_area_list = $this->getBlackArea($agent['id'], $area = 'blackarea');
//p($black_area_list);die;
            $this->assignAll([
                'province_list'    => $province_list,
                'agent_id'         => $data[0],
                'agent'            => $agent,
                'action'           => 'edit',
                'form_action'      => '/agent/addBlackarea',
                'black_area_list'  => $black_area_list,
                'act'              => 'editBlackarea',
                'back_to_list_url' => $this->_backToListUrl($this->_refer),
            ]);
        }
        $this->display('agent_blackarea');
    }

    /**
     * 添加地区黑名单
     */
    public function addBlackarea()
    {
        $data = I('');
//        p($data);die;
        if ($data['act'] === 'addBlackarea') {
            $blackarea = [];
            foreach ($data['area'] as $i => $v) {
                $keys                      = array_keys($v);
                $blackarea[$i]['province'] = $v[$keys[0]];
                $blackarea[$i]['city']     = $v[$keys[1]];
                $blackarea[$i]['district'] = $v[$keys[2]];
            }
            $where       = [
                'id' => $data['agent_id'],
            ];
            $fields      = [
                'blackarea' => json_encode($blackarea),
            ];
            $agent_model = new \Basic\Model\AgentModel();
            $agent_model->update($data['agent_id'], $fields);
            $this->__manager_service->addOperLog([
                'manager_id' => $this->_manager_id,
                'action'     => 'addBlackarea',
                'desc'       => "添加渠道黑名单",
            ]);
            redirect(U('agent/certification/' . $data['agent_id'], '', '') . '?actn=add_certification');
        } else {
            $data   = I('data');
            $fields = [
                'blackarea' => json_encode($data['black_info']),
            ];

            $where    = [
                'id' => $data['agent_id'],
            ];
            $agent_id = $data['agent_id'];
            list($errno, $errmsg, $data) = $this->__agent_model->updateAgent($where, $fields);

            if ($errno != ERRNO::SUCCESS) {
                // @todo 报错
            } else {
                if ($_POST['data']['act'] == 'editBlackarea') {
                    $jump_href = $agent_id . '?act=edit';
                } else {
                    $jump_href = '/agent/certification/' . $agent_id . '?actn=add_certification';
                }
                $this->doResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS),
                    ['tab' => $data['tab'], 'act' => $data['act'], 'jump_href' => $jump_href]);
            }

        }
    }

    /**
     * 获取地址黑名单信息
     */
    public function getBlackArea($id, $area = '')
    {

        $agent      = $this->__agent_model->getAgentById($id);
        $black_area = json_decode($agent[$area], true);

        if (strlen($black_area[0]['province']) != 1) {
            $black_area = [];
        } else {
            /** @var CityService $city_service */
            $city_service = D('Basic/City', 'Service');

            if ($black_area) {
                $black_area = $city_service->getCitiesByWhere(['id' => ['in', $black_area]], 'id asc');
            }
//p($black_area);die;
            $format_city = $city_service->getFormaltAllCity();
            foreach ($black_area as $key => &$value) {
                if ($value['level'] == 1) {
                    $value['p_parent_id'] = 0;
                }

                if ($value['level'] == 2) {
                    $value['p_parent_id'] = -1;
                    $parent_id            = $value['parent_id'];
                    $name                 = $value['name'];
                    $value['name']        = $format_city[$parent_id]['name'] . $name;
                }

                if ($value['level'] == 3) {
                    $parent_id            = $value['parent_id'];
                    $p_parent_id          = $format_city[$parent_id]['parent_id'];
                    $value['p_parent_id'] = $p_parent_id;
                    $parent_name          = $format_city[$parent_id]['name'];
                    $name                 = $value['name'];
                    $value['name']        = $format_city[$p_parent_id]['name'] . $parent_name . $name;
                }
            }
        }

        return $black_area ?: [];

    }

    /**
     * 获取产品列表
     * @return array
     */
    protected function getProductList()
    {
        $product_arr  = [];
        $product_list = DICT::PRODUCT_LIST;
        $product_keys = array_keys($product_list);
        foreach ($product_keys as $i => &$r) {
            $product_arr[] = ['id' => $r, 'text' => $product_list[$r]];
        }

        return $product_arr;
    }

    /**
     * 获取渠道类型
     */
    protected function getAgentStyle()
    {
        $agent_style_arr  = [];
        $agent_style_list = DICT::AGENT_STYLE_LIST;
        $agent_style_keys = array_keys($agent_style_list);
        foreach ($agent_style_keys as $i => &$r) {
            $agent_style_arr[] = ['id' => $r, 'text' => $agent_style_list[$r]];
        }

        return $agent_style_arr;
    }

    /**
     * 获取渠道状态
     */
    protected function getAgentStatus()
    {
        $agent_status_arr  = [];
        $agent_status_list = DICT::AGENT_STATUS_LIST;
        $agent_status_keys = array_keys($agent_status_list);
        foreach ($agent_status_keys as $i => &$r) {
            $agent_status_arr[] = ['id' => $r, 'text' => $agent_status_list[$r]];
        }

        return $agent_status_arr;
    }

    /**
     * 获取渠道状态
     */
    protected function getEmailFix()
    {
        $email_fix_arr  = [];
        $email_fix_list = DICT::EMAIL_FIX;
        $email_fix_keys = array_keys($email_fix_list);
        foreach ($email_fix_keys as $i => &$r) {
            $email_fix_arr[] = ['id' => $r, 'text' => $email_fix_list[$r]];
        }

        return $email_fix_arr;
    }


    /**
     * 获取发票抬头
     */
    protected function getTicketStyle()
    {
        $ticket_style_arr  = [];
        $ticket_style_list = DICT::TICKET_HEAD_LIST;
        $ticket_style_keys = array_keys($ticket_style_list);
        foreach ($ticket_style_keys as $i => &$r) {
            $ticket_style_arr[] = ['id' => $r, 'text' => $ticket_style_list[$r]];
        }

        return $ticket_style_arr;
    }

    protected function getTicketStyles()
    {
        $ticket_styles_arr  = [];
        $ticket_styles_list = DICT::TICKET_STYLE_LIST;
        $ticket_style_keys  = array_keys($ticket_styles_list);
        foreach ($ticket_style_keys as $i => &$r) {
            $ticket_styles_arr[] = ['id' => $r, 'text' => $ticket_styles_list[$r]];
        }

        return $ticket_styles_arr;
    }


    /**
     * 渠道区域
     */
    public function agentCity()
    {
        $data = I('');
//        p($data);die;
        //获取城市数据
        $city_model    = D('Basic/City');
        $province_list = $city_model->getCitiesByWhere(['parent_id' => -1], 'short_spell asc');

        if ($data['acti'] === 'add_city') {
            $this->assignAll([
                'province_list'    => $province_list,
                'agent_id'         => $data[0],
                'act'              => 'addCity',
                'back_to_list_url' => $this->_backToListUrl($this->_refer),
                'form_action'      => '/agent/addCity',
            ]);
        } else {
            $agent       = $this->__agent_model->getAgentById($data[0]);
            $area        = json_decode($agent['area'], true);
            $agent['id'] = $data[0];
            $agent       = $this->__agent_model->getAgentById($data[0]);

            //黑名单信息(超群的组件)
            $black_area_list = $this->getBlackArea($agent['id'], $area = 'area');

            $this->assignAll([
                'province_list'    => $province_list,
                'agent_id'         => $data[0],
                'act'              => 'editCity',
                'action'           => 'edit',
                'black_area_list'  => $black_area_list,
                'form_action'      => '/agent/addCity',
                'agent'            => $agent,
                'back_to_list_url' => $this->_backToListUrl($this->_refer),
            ]);
        }
        $this->display('agent_city');
    }


    // 获取城市列表的ajax接口
    public function city($parent_id = -1)
    {
        $city_model    = D('Basic/City');
        $province_list = $city_model->getCityList($parent_id);
        //print_r($province_list);
        $this->ajaxReturn($province_list);
    }

    /**
     * 添加渠道区域
     */
    public function addCity()
    {
        $data = I('');

        $fields = [
            'area' => json_encode($data['area']),
        ];
        $where  = [
            'id' => $data['agent_id'],
        ];
        $this->__agent_model->updateAgent($where, $fields);

        if ($data['act'] === 'addCity') {//添加地区
//            $this->redirect('agent/editInvoice/'.$data['agent_id'].'?act=agent_id');
            // 添加操作日志
            $this->__user_service->addOperLog([
                'manager_id' => $this->_manager_id,
                'object_id'  => $data['agent_id'],
                'action'     => 'addCity',
                'desc'       => "添加渠道区域成功",
            ]);
            redirect(U('agent/editInvoice/' . $data['agent_id'], '', '') . '?acti=agent_id');
        } else {//编辑地区
            $data = I('data');
//            p($data);die;
            $fields = [
                'area' => json_encode($data['black_info']),
            ];

            $where    = [
                'id' => $data['agent_id'],
            ];
            $agent_id = $data['agent_id'];
            list($errno, $errmsg, $data) = $this->__agent_model->updateAgent($where, $fields);

            if ($errno != ERRNO::SUCCESS) {
                // @todo 报错
            } else {
//                p($_POST['data']['act']);die;
                if ($_POST['data']['act'] == 'editCity') {
                    $jump_href = $agent_id . '?act=edit';
                } else {
                    $jump_href = '/agent/editInvoice/' . $agent_id . '?acti=agent_id';
                }
                $this->doResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS),
                    ['tab' => $data['tab'], 'act' => $data['act'], 'jump_href' => $jump_href]);
            }

        }
    }


    /**
     * 可用产品页面
     */
    public function product()
    {
        $data = I('');
//        p($data);die;
        // 产品功能列表
        $product_model = D('Basic/Product');
        $product_list  = $product_model->getAllProductList();


        if ($data['actn'] === 'add_product') {
            $agent_id        = $data[0];
            $product_checked = []; // 选中的功能

            $product_arr = $this->getProductList();
            $this->assignAll([
                'agentid'          => $agent_id,
                'agent_id'         => $agent_id,
                'act'              => 'addProduct',
                'product_arr'      => $product_arr,
                'product_list'     => $product_list,
                'product_checked'  => $product_checked,
                'form_action'      => '/agent/doAgentProduct',
                'back_to_list_url' => $this->_backToListUrl($this->_refer),
            ]);
            //返回上一步的操作
            if ($data['btn'] === 'prev') {
                $agent['id'] = $data[0];
                $agent       = $this->__agent_model->getAgentById($data[0]);
//        p($agent);die;
                $product_ratio = json_decode($agent['product_ratio'], true);
//            p($product_ratio);die;
                $product_checked = json_decode($agent['product'], true); // 选中的功能
                $product_arr     = $this->getProductList();
                $this->assignAll([
                    'agent_id'        => $data[0],
                    'agent'           => $agent,
                    'product_ratio'   => $product_ratio,
                    'product_arr'     => $product_arr,
                    'product_list'    => $product_list,
                    'product_checked' => $product_checked,
                ]);
            }
        } else {
            $agent['id'] = $data[0];
            $agent       = $this->__agent_model->getAgentById($data[0]);
//        p($agent);die;
            $product_ratio = json_decode($agent['product_ratio'], true);
//            p($product_ratio);die;
            $product_checked = json_decode($agent['product'], true); // 选中的功能
            $product_arr     = $this->getProductList();
            $this->assignAll([
                'agent_id'         => $data[0],
                'act'              => 'editProduct',
                'agent'            => $agent,
                'action'           => 'edit',
                'product_ratio'    => $product_ratio,
                'product_arr'      => $product_arr,
                'product_list'     => $product_list,
                'product_checked'  => $product_checked,
                'form_action'      => '/agent/doAgentProduct',
                'back_to_list_url' => $this->_backToListUrl($this->_refer),
            ]);
        }
        $this->display('agent_product');
    }

    /**
     * 添加可用的产品
     */
    public function doAgentProduct()
    {
        $data = I('');
//        p($data);die;.
        if ($data['act'] === 'addProduct') {
            $str         = substr($data['product_ids'], 0, strlen($data['product_ids']) - 1);
            $product_ids = explode(',', $str);
            $where       = [
                'id' => $data['agent_id'],
            ];

            $fields      = [
                'product'       => json_encode($product_ids),
                'product_ratio' => json_encode($data['ratio']),
            ];
            $agent_model = new \Basic\Model\AgentModel();
            $agent_model->update($data['agent_id'], $fields);

            $this->__manager_service->addOperLog([
                'manager_id' => $this->_manager_id,
                'action'     => 'doAgentProduct',
                'desc'       => "添加渠道可用产品",
            ]);
            redirect(U('agent/blackarea/' . $data['agent_id'], '', '') . '?actn=add_blackarea');
//            $this->redirect('agent/blackarea/'.$data['agent_id']);
        } else {
//            $data = I('');
//        p($data);die;
            $str         = substr($data['product_ids'], 0, strlen($data['product_ids']) - 1);
            $product_ids = explode(',', $str);
//        p($product_ids);die;
//            $where = [
//                'id' => $data['id'],
//            ];

            $fields = [
                'product'       => json_encode($product_ids),
                'product_ratio' => json_encode($data['ratio']),
            ];

            $this->__agent_model->update($data['id'], $fields);

            // 添加操作日志
            $this->__user_service->addOperLog([
                'manager_id' => $this->_manager_id,
                'object_id'  => $data['id'],
                'action'     => 'updateProduct',
                'desc'       => "编辑可用产品成功",
            ]);
            $this->admin_success('编辑产品成功！');
        }

    }

    /**
     *导出Excel
     */
    public function expAgent()
    {
        //引入PHPExcel类库文件
        require_once BASE_PATH . '/ThinkPHP/Library/Vendor/PHPExcel.class.php';
        require_once BASE_PATH . '/ThinkPHP/Library/Vendor/PHPExcel/Writer/Excel2007.php';

        $expPHPExcel = new \PHPExcel();
        $objWriter   = new \PHPExcel_Writer_Excel2007($expPHPExcel);

        //获取数据
        $dataList = $this->getDataList();

        $expPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', '渠道数据')
            ->setCellValue('A2', '渠道名')
            ->setCellValue('B2', '合同号')
            ->setCellValue('C2', '渠道状态')
            ->setCellValue('D2', '付费产品标识')
            ->setCellValue('E2', '负责人')
            ->setCellValue('F2', '联系方式')
            ->setCellValue('G2', '合同金额（元）')
            ->setCellValue('H2', '开始日期')
            ->setCellValue('I2', '结束日期');
        for ($i = 0; $i < count($dataList); $i++) {
            $expPHPExcel->getActiveSheet(0)->setCellValue('A' . ($i + 3), $dataList[$i]['name']);
            $expPHPExcel->getActiveSheet(0)->setCellValue('B' . ($i + 3), $dataList[$i]['contract_no']);
            $expPHPExcel->getActiveSheet(0)->setCellValue('C' . ($i + 3), $dataList[$i]['agent_status']);
            $expPHPExcel->getActiveSheet(0)->setCellValue('D' . ($i + 3), $dataList[$i]['product']);
            $expPHPExcel->getActiveSheet(0)->setCellValue('E' . ($i + 3), $dataList[$i]['director']);
            $expPHPExcel->getActiveSheet(0)->setCellValue('F' . ($i + 3), $dataList[$i]['mobile']);
            $expPHPExcel->getActiveSheet(0)->setCellValue('G' . ($i + 3), $dataList[$i]['contract_amount']);
            $expPHPExcel->getActiveSheet(0)->setCellValue('H' . ($i + 3), $dataList[$i]['start_day']);
            $expPHPExcel->getActiveSheet(0)->setCellValue('I' . ($i + 3), $dataList[$i]['end_day']);
        }

        $expPHPExcel->getActiveSheet()->setTitle('渠道汇总表');

        // excel头参数
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="渠道汇总表(' . date('Ymd-His') . ').xls"');  //日期为文件名后缀
        header('Cache-Control: max-age=0');
        header('Cache-Control: max-age=1');
        $objWriter->save('php://output');
        // 添加操作日志
        if ($objWriter) {
            $this->__manager_service->addOperLog([
                'manager_id' => $this->_manager_id,
                'action'     => 'expAgent',
                'desc'       => "导出渠道信息",
            ]);
            $this->admin_success("导出数据成功！");
        } else {
            $this->__manager_service->addOperLog([
                'manager_id' => $this->_manager_id,
                'action'     => 'expAgent',
                'desc'       => "导出渠道信息",
            ]);
            $this->admin_error("导出数据失败！！！");
        }
    }

    //获取数据
    public function getDataList()
    {
        //获取渠道类型
        $agent_style_arr = $this->getAgentStyle();
        //获取渠道状态
        $agent_status_arr = $this->getAgentStatus();

        //获取当前页数据
        $code            = I('code');
        $name            = I('name');
        $director        = I('director');
        $mobile          = I('mobile');
        $type            = I('type');
        $contract_no     = I('contract_no');
        $agent_status    = I('agent_status');
        $search_from_day = I('search_from_day');
        $search_to_day   = I('search_to_day');


        if (!empty($code)) {
            $cond['code'] = ['like', '%' . $code . '%'];
        }
        if (!empty($name)) {
            $cond['name'] = ['like', '%' . $name . '%'];
        }
        if (!empty($director)) {
            $cond['director'] = ['like', '%' . $director . '%'];
        }
        if (!empty($mobile)) {
            $cond['mobile'] = ['like', '%' . $mobile . '%'];
        }
        if (!empty($type)) {
            $cond['type'] = ['eq', $type];
        }
        if (!empty($contract_no)) {
            $cond['contract_no'] = ['like', '%' . $contract_no . '%'];
        }
        if (!empty($agent_status)) {
            $cond['agent_status'] = ['like', '%' . $agent_status . '%'];
        }
        if (!empty($search_from_day) || !empty($search_to_day)) {
            $cond['end_day'] = [['egt', $search_from_day], ['elt', $search_to_day]];
        }

        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        $ret       = $this->__agent_model->searchAgentList($cond, $curr_page, $per_page);

        return $ret['data'];
    }

    /**
     * 修改渠道信息页面
     *
     * @param $agent_id
     */
    public function edit($agent_id)
    {
        //获取渠道类型
        $agent_style_arr = $this->getAgentStyle();
        //获取渠道状态
        $agent_status_arr = $this->getAgentStatus();

        //获取邮箱后缀
        $email_fix = $this->getEmailFix();

        //获取城市数据
        $city_model    = D('Basic/City');
        $province_list = $city_model->getCitiesByWhere(['parent_id' => -1], 'short_spell asc');

        $agent_id = (int)$agent_id;

        //黑名单信息(超群的组件)
        $black_area_list = $this->getBlackArea($agent_id, $area = 'area');
//p($black_area_list);die;
        //固定区域
//         废弃
//        /** @var AgentModel $agent_model */
//        $agent_model = D('Basic/Agent', 'Model');
//        $agent_info = $agent_model->getAgentById($agent_id);
////        p($agent_info);die;
//        /** @var CityService $city_service */
//        $city_service = D('Basic/City', 'Service');
//        $city = $city_service->getName($agent_info['fixed_area']);
//        $province = $city_service->getName(substr($agent_info['fixed_area'], 0, 2));

        if (!$agent_id) {
            $this->admin_error('ID不正确！');

            return;
        }

        $agent = $this->__agent_model->getAgentById($agent_id);

        if (!$agent) {
            $this->admin_error('渠道不存在！');

            return;
        }
        /** @var CityService $city_service */
        $city_service = D('Basic/City', 'Service');
        if ($agent['fixed_area'] == 0) {
            $fixed_area_code = current(t_json_decode($agent['area']));
            $ret = $city_service->getName($fixed_area_code);
            if (empty($ret)) {
                $errno_msg = '区域地址码不正确！！！';
            }
        } else {
            $fixed_area_code = $agent['fixed_area'];
        }
        $province_city_dis = $city_service->getAreaFullName($fixed_area_code, $sep = '-');

        $this->assignAll([
            'act'              => 'edit',
            'action'           => 'edit',
            'fixed_area' => $province_city_dis,
            'start_district' => $agent['fixed_area'],
            'start_city' => substr($agent['fixed_area'], 0, 4),
            'start_province' => substr($agent['fixed_area'], 0, 2),
            'title'            => '编辑渠道',
            'type'             => $agent['type'],
            'agent_status'     => $agent['agent_status'],
            'agent_style_arr'  => $agent_style_arr,
            'agent_status_arr' => $agent_status_arr,
            'form_action'      => '/agent/editAgent',
            'email_fix'        => $email_fix,
            'province_list'    => $province_list,
            'black_area_list'  => $black_area_list,
            'agent'            => $agent,
            'cctime'           => $agent['ctime'],
            'errno_msg'         => $errno_msg,
        ]);
        $this->display('agent_add');
    }

    public function editAgent()
    {
        $name = I('name');
        if (empty($name)) {
            $this->admin_error('渠道名不能为空');

            return;
        }

        $director = I('director');
        if (empty($director)) {
            $this->admin_error('负责人不能为空');

            return;
        }
        $contract_no = I('contract_no');
        if (empty($contract_no)) {
            $this->admin_error('合同号不能为空');

            return;
        }
        $mobile = I('mobile');
        if (!is_mobile($mobile)) {
            $this->admin_error('手机号格式不正确！');

            return;
        }
        $mail = I('mail');
        if (!is_email($mail) && !empty($mail)) {
            $this->admin_error('邮箱格式不正确');

            return;
        }
        $identity = I('identity');
        if (!preg_match("/^(\d{15}$|^\d{18}$|^\d{17}(\d|X|x))$/", $identity)) {
            $this->admin_error('身份证号格式不正确！');

            return;
        }
        $contract_amount = I('contract_amount');
        $phone1          = I('phone1/s');
        if (!empty($phone1) && !is_phone($phone1)) {
            $this->admin_error('联系电话1格式不正确！');

            return;
        }
        $phone2 = I('phone2/s');
        if (!empty($phone2) && !is_phone($phone2)) {
            $this->admin_error('联系电话2格式不正确！');

            return;
        }
        $wphone = I('service_phone/s');
        if (!empty($wphone) && !is_phone($wphone) && !is_mobile($wphone)) {
            $this->admin_error('客服电话格式不正确！');
            return;
        }

        $data  = [
            'area'            => json_encode(explode(',', I('area'))),
            'name'            => str_replace('$amp;', '&', $name),
            'type'            => I('type'),
            'agent_status'    => I('agent_status'),
            'director'        => $director,
            'contract_no'     => $contract_no,
            'contract_amount' => $contract_amount,
            'mobile'          => $mobile,
            'try_days'        => I('try_days'),
            'phone1'          => $phone1,
            'phone2'          => $phone2,
            'service_phone'          => $wphone,
            'mail'            => $mail,
            'identity'        => $identity,
            'start_day'       => I('start_day'),
            'end_day'         => I('end_day'),
            'remark'          => I('remark'),
            'is_check_telephone' => I('is_check_telephone/d'),
            'mtime'           => date('Y-m-d'),
        ];
        $id    = I('agent_id');
        $where = [
            'id' => $id,
        ];
        $this->__agent_model->updateAgent($where, $data);

        //同步agent数据
        /** @var WLSendService $send_service */
        $send_service = D('Basic/WLSend', 'Service');
        $res          = $send_service->syncAgent($id);

        // 添加操作日志
        $this->__user_service->addOperLog([
            'manager_id' => $this->_manager_id,
            'object_id'  => I('id'),
            'action'     => 'editAgent',
            'desc'       => "编辑渠道成功",
        ]);
        $this->admin_success('编辑渠道成功！');
    }


    public function doEditCertification()
    {
        $data = I('');
//        p($data);die;
        if (!empty($data['card_photo'])) {
            $card_photo_arr  = explode('/', $data['card_photo']);
            $ajax_card_photo = [
                'name' => $card_photo_arr[8],
                'path' => $card_photo_arr[7],
                'type' => 'certificate'
            ];
        }

//p($_FILES);die;
        $agentInfo = $this->__agent_model->getAgentById($data['id']);
//        p($agentInfo);die;
        $photo = $agentInfo['certification'];
//        p($photo);die;
        $photos = json_decode($photo, true);
//p($photos);die;

        $contractInfo = $agentInfo['contract_file'];
        $contract     = json_decode($contractInfo, true);
//        $contract = $agentInfo['contract_file'];

        //上传处理
        $root_dir = C('IMAGE_PATH')['certificate'];
        $sub_dir  = day();

        $card_photo_info = $ajax_card_photo;
//        $card_photo_info = [];
        if (!empty($_FILES['card_photo']['name']) && $_FILES['card_photo']['size'] > 0) { // 身份证正面照片
            list($errcode, $errmsg) = uploadImage('card_photo', $root_dir, $sub_dir, $card_photo_info, 'certificate');
            if ($errcode != ERRNO::SUCCESS) {
                $this->admin_error('身份证正面照片上传失败！' . $errmsg);

                return;
            }
        }

        if (!empty($data['card_photo_back'])) {
            $card_photo_back_arr = explode('/', $data['card_photo_back']);

            $ajax_card_photo_back = [
                'name' => $card_photo_back_arr[8],
                'path' => $card_photo_back_arr[7],
                'type' => 'certificate'
            ];
        }


        $card_photo_back_info = $ajax_card_photo_back;
        if (!empty($_FILES['card_photo_back']['name']) && $_FILES['card_photo_back']['size'] > 0) { // 身份证背面照片
            list($errcode, $errmsg) = uploadImage('card_photo_back', $root_dir, $sub_dir, $card_photo_back_info,
                'certificate');
            if ($errcode != ERRNO::SUCCESS) {
                $this->admin_error('身份证背面照片上传失败！' . $errmsg);

                return;
            }
        }

        if (!empty($data['business_photo'])) {
            $business_photo_arr = explode('/', $data['business_photo']);

            $ajax_business_photo = [
                'name' => $business_photo_arr[8],
                'path' => $business_photo_arr[7],
                'type' => 'certificate'
            ];
        }


        //营业执照照片
        $business_photo_info = $ajax_business_photo;
        if (!empty($_FILES['business_photo']['name']) && $_FILES['business_photo']['size'] > 0) { // 营业执照照片
            list($errcode, $errmsg) = uploadImage('business_photo', $root_dir, $sub_dir, $business_photo_info,
                'certificate');
            if ($errcode != ERRNO::SUCCESS) {
                $this->admin_error('营业执照照片上传失败！' . $errmsg);

                return;
            }
        }

        if (!empty($data['contract_file'])) {
            $contract_file_arr = explode('/', $data['contract_file']);

            $ajax_contract_file = [
                'name' => $contract_file_arr[8],
                'path' => $contract_file_arr[7],
                'type' => 'certificate'
            ];
        }


        $contract_file_info = $ajax_contract_file;
        if (!empty($_FILES['contract_file']['name']) && $_FILES['contract_file']['size'] > 0) { // 合同文件
            list($errcode, $errmsg) = uploadImage('contract_file', $root_dir, $sub_dir, $contract_file_info,
                'certificate');
            if ($errcode != ERRNO::SUCCESS) {
                $this->admin_error('合同文件上传失败！' . $errmsg);

                return;
            }
        }
        // 处理图片数据
        if (!empty($card_photo_info)) {
            $photos['card_photo'] = $card_photo_info;
        }
        if (!empty($card_photo_back_info)) {
            $photos['card_photo_back'] = $card_photo_back_info;
        }
        if (!empty($business_photo_info)) {
            $photos['business_photo'] = $business_photo_info;
        }
        if (!empty($contract_file_info)) {
            $contract['contract_file'] = $contract_file_info;
        }

        $fields['certification'] = json_encode($photos);
        $fields['contract_file'] = json_encode($contract);
        $fields['mtime']         = date('Y-m-d');

        $agent_model = new \Basic\Model\AgentModel();
        $agent_model->updateAgent($data['id'], $fields);

        // 添加操作日志
        $this->__user_service->addOperLog([
            'manager_id' => $this->_manager_id,
            'object_id'  => $data['id'],
            'action'     => 'doEditCertification',
            'desc'       => "编辑资质信息成功",
        ]);
        $this->admin_success('编辑资质信息成功！');
    }

    //提交编辑产品
    public function doEditProduct()
    {
        $data = I('');
//        p($data);die;
        $str         = substr($data['product_ids'], 0, strlen($data['product_ids']) - 1);
        $product_ids = explode(',', $str);
//        p($product_ids);die;
        $where = [
            'id' => $data['id'],
        ];

        $fields = [
            'product' => json_encode($product_ids),
            'mtime'   => date('Y-m-d'),
        ];

//        $this->__agent_model->updateAgent($where, $fields);
        // 更新缓存
        $this->__agent_model->update($data['id'], $fields);

        // 添加操作日志
        $this->__user_service->addOperLog([
            'manager_id' => $this->_manager_id,
            'object_id'  => $data['id'],
            'action'     => 'doEditProduct',
            'desc'       => "编辑产品成功",
        ]);
        $this->admin_success('编辑产品成功！');

    }

    /**
     * 发票模块
     *
     * @param $manager_id
     */

    public function editInvoice()
    {
        $data = I('');
//        p($data);die;

        if ($data['acti'] === 'agent_id') {
            $agent_id   = $data[0];
            $invoice_id = I('path.3/d', 0);
            if ($invoice_id) { // 编辑状态

            }
            $invoice_model = D('Basic/AgentInvoice');
            $list          = $invoice_model->getInvoiceList(['agent_id' => $agent_id]);

            $num = count($list);
//            $act = I('act', 'edit_invoice');
            $this->assignAll([
                'act'              => 'addInvoice',
                //                'manager_id'=> $manager_id,
                'agent_id'         => $agent_id,
                'list'             => $list,
                'num'              => $num,
                'back_to_list_url' => $this->_backToListUrl($this->_refer),
            ]);
        } else {
            $agent_id   = $data[0];
            $invoice_id = I('path.3/d', 0);
            if ($invoice_id) { // 编辑状态

            }
            $invoice_model = D('Basic/AgentInvoice');
            $list          = $invoice_model->getInvoiceList(['agent_id' => $agent_id]);
            $num           = count($list);
//            $act = I('act', 'edit_invoice');
            $agent = $this->__agent_model->getAgentById($agent_id);

            $agent['id'] = $agent_id;
            $this->assignAll([
                'action'           => 'edit',
                'act'              => 'editInvoice',
                'agent_id'         => $agent_id,
                'list'             => $list,
                'agent'            => $agent,
                'invoice_id'       => $data['invoice_id'],
                'num'              => $num,
                'back_to_list_url' => $this->_backToListUrl($this->_refer),
            ]);
        }
        $this->display('agent_invoice');
    }

    /**
     * 保存提交编辑表格
     */
    public function doEditInvoice()
    {
        // 验证令牌
        $this->checkFormToken();
        $agent_id = $_POST['agent_id'];
        $head     = I('head/d', 1);
        $fields   = [
            'agent_id' => $agent_id,
            'head'     => $head,
        ];

        if ($head == 1) { // 个人
            $fields['type']          = 1;
            $fields['company']       = '';
            $fields['taxer_no']      = '';
            $fields['credit_no']     = '';
            $fields['address']       = '';
            $fields['tax_type']      = '';
            $fields['phone']         = '';
            $fields['bank_name']     = '';
            $fields['bank_passport'] = '';

        } else { // 公司
            $type           = I('type/d', 1);
            $fields['type'] = $type;

            if ($type == 1) { // 增值税普通发票
                $fields['company']       = I('company', '');
                $fields['taxer_no']      = I('taxer_no', '');
                $fields['credit_no']     = '';
                $fields['address']       = '';
                $fields['tax_type']      = '';
                $fields['phone']         = '';
                $fields['bank_name']     = '';
                $fields['bank_passport'] = '';

            } else { // 增值税专用发票
                $fields['company']       = I('company', '');
                $fields['taxer_no']      = I('taxer_no', '');
                $fields['credit_no']     = I('credit_no', '');
                $fields['address']       = I('address', '');
                $fields['tax_type']      = I('tax_type', '');
                $fields['phone']         = I('phone', '');
                $fields['bank_name']     = I('bank_name', '');
                $fields['bank_passport'] = I('bank_passport', '');
            }
        }

        $invoice_model = D('Basic/AgentInvoice');

        $invoice_id = I('invoice_id/d', 0);
        if ($invoice_id > 0) { // 编辑记录
            $fields['mtime'] = datetime();
            $invoice_model->updateInvoice(['id' => $invoice_id], $fields);

            //添加操作日志
            $this->__manager_service->addOperLog([
                'manager_id' => $this->_manager_id,
                'object_id'  => $agent_id,
                'action'     => 'doEditInvoice',
                'desc'       => "修改发票成功",
            ]);

            $this->admin_success('修改发票信息成功！');

        } else { // 添加记录
            $fields['ctime'] = datetime();
            $invoice_model->addAgentInvoice($fields);

            // 添加操作日志
            $this->__manager_service->addOperLog([
                'manager_id' => $this->_manager_id,
                'object_id'  => $agent_id,
                'action'     => 'addInvoice',
                'desc'       => "添加发票成功",
            ]);
        }
        if (I('act') === 'addInvoice') {
            redirect(U('agent/editInvoice/' . $agent_id, '', '') . '?acti=agent_id');
        } else {
            $this->redirect('agent/editInvoice/' . $agent_id);
        }
    }

    public function getInvoiceInfo($invoice_id)
    {
        $invoice_id = (int)$invoice_id;
        if (!$invoice_id) {
            $this->ajaxResponse(-1, 'ID不正确！');

            return;
        }

        $invoice_model = D('Basic/AgentInvoice');
        $invoice       = $invoice_model->getInvoice(['id' => $invoice_id]);
        //print_r($invoice);
        $this->ajaxResponse(0, $invoice);
    }

    public function deleteInvocie($invoice_id)
    {
        $invoice_id = (int)$invoice_id;
        if (!$invoice_id) {
            $this->admin_error('ID不正确！');

            return;
        }

        $invoice_model = D('Basic/AgentInvoice');
        $invoice_model->deleteInvoice($invoice_id);

        // 添加操作日志
        $this->__manager_service->addOperLog([
            'manager_id' => $this->_manager_id,
            'object_id'  => $invoice_id,
            'action'     => 'deleteInvoice',
            'desc'       => "删除发票成功",
        ]);
        redirect(U('agent/editInvoice/' . I('agent_id'), '', '') . '?acti=agent_id');
//        $this->admin_success('删除发票成功！');
    }

    /**
     * 批量删除
     */
    public function deleteInvoiceAll()
    {
        $ids = I('ids');
        if (empty($ids)) {
            $this->admin_error('ID不正确！');

            return;
        }

        $invoice_model = D('Basic/AgentInvoice');
        $invoice_model->deleteInvoice($ids);

        // 添加操作日志
        $this->__manager_service->addOperLog([
            'manager_id' => $this->_manager_id,
            'object_id'  => implode(',', $ids),
            'action'     => 'deleteInvoiceAll',
            'desc'       => "批量删除发票",
        ]);

        $this->admin_success('批量删除发票成功！');
    }

    public function editMail()
    {
        $data = I('');
//        p(I(''));die;
//        $act = I('act','edit');
//        $tab = I('tab','mail');
        $agent_id = $data[0];

        if ($data['actn'] == 'add_mail') {
            /** @var CityService $city_service */
            $city_service = D('Basic/City', 'Service');
            //省列表
            $province_list = $city_service->getCitiesByWhere(['parent_id' => -1], 'id asc');
            $cities        = $city_service->getFormaltAllCity();
            $list          = $this->getMailList($agent_id);

            $num = count($list);

            $this->assignAll([
                'act'              => 'addMail',
                //                'manager_id'=> $manager_id,
                'province_list'    => $province_list,
                'agent_id'         => $agent_id,
                'list'             => $list,
                'num'              => $num,
                'back_to_list_url' => $this->_backToListUrl($this->_refer),
            ]);
        } else {
            /** @var CityService $city_service */
            $city_service = D('Basic/City', 'Service');
            //省列表
            $province_list = $city_service->getCitiesByWhere(['parent_id' => -1], 'id asc');
            $cities        = $city_service->getFormaltAllCity();
            $list          = $this->getMailList($agent_id);
//p($list);die;
            $num   = count($list);
            $agent = $this->__agent_model->getAgentById($data[0]);
            foreach ($list as $key => &$value) {
                $value['province_name'] = $cities[$value['province']]['name'] ?: '';
                $value['city_name']     = $cities[$value['city']]['name'] ?: '';
                $value['district_name'] = $cities[$value['district']]['name'] ?: '';
                if ($value['is_default'] == 1) {
                    $value['is_default_desc'] = '是';
                } else {
                    $value['is_default_desc'] = '否';
                }
            }

            $this->assignAll([
                'agent'            => $agent,
                'act'              => 'editMail',
                //            'tab'     => $tab,
                'title'            => '编辑渠道',
                'agent_id'         => $agent_id,
                'province_list'    => $province_list,
                'list'             => $list,
                'num'              => $num,
                'mail_id'          => $data['mail_id'],
                'back_to_list_url' => $this->_backToListUrl($this->_refer),
            ]);
        }

        $this->display('agent_mail');
    }

    /**
     * 获取邮寄信息
     */
    public function getMailList($agent_id)
    {
        if (empty($agent_id)) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO, ERRNO::e(ERRNO::INPUT_PARAM_ERRNO), []);

            return;
        }
        /** @var AddressService $address_service */
        $address_service = D('Basic/Address', 'Service');
        $filter          = [
            'status'    => 1,
            'agent_id'  => $agent_id,
            'page_num'  => 1,
            'page_size' => 100,
        ];
        $data            = $address_service->getAddressList($filter);
        $mail_list       = $data['list'];

        return $mail_list;
    }

    /**
     * 添加或更新邮寄信息
     */
    public function doEditMail()
    {
        $mail_info = $_POST;
//        p($mail_info);die;
        $act     = $mail_info['act'];
        $user_id = $mail_info['user_id'];
        if (empty($mail_info['mail_id'])) {
            unset($mail_info['mail_id']);
        } else {
            $mail_info['id'] = $mail_info['mail_id'];
        }

        /** @var AddressService $address_service */
        $address_service = D('Basic/Address', 'Service');
        if ($mail_info['is_default'] == 1) {
            $address_model = new \Basic\Model\AddressModel();
            // 取消默认地址
            $cancle_return = $address_model->cancleDefaultAddressById($mail_info['agent_id']);
        }
        if (empty($mail_info['id'])) {
            list($errno, $errmsg, $data) = $address_service->addAddr($mail_info);

        } else {
            list($errno, $errmsg, $data) = $address_service->upAddr($mail_info);

        }
        //@todo 设置默认
        if ($act !== 'edit') {
            $this->admin_success('添加邮寄信息成功');
        } else {
            $this->admin_success('编辑邮寄信息成功');
        }

        return;
    }


    public function deleteMailAll()
    {
        $ids = I('ids');
        if (empty($ids)) {
            $this->admin_error('ID不正确！');

            return;
        }
        /** @var AddressService $address_service */
        $address_service = D('Basic/Address', 'Service');
        $where           = [
            'id' => ['in', $ids],
        ];
        list($errno, $errmsg, $data) = $address_service->upAddrByWhere($where, ['status' => 0]);
        //@todo 添加日志
        if ($errno == ERRNO::SUCCESS) {
            $this->admin_success('删除邮寄地址成功！');
        } else {
            $this->admin_error('删除邮寄地址失败！');
        }

        return;
    }


    /**
     * 删除管理员
     *
     * @param $manager_id
     */
    public function delete($manager_id)
    {
        if (session('manager_id') != 1) {
            $this->admin_error('您无权执行该操作！');

            return;
        }

        if (!$manager_id) {
            $this->admin_error('ID不正确！');

            return;
        }

        if ($manager_id == 1) {
            $this->admin_error('不允许删除超级管理员账号！');

            return;
        }

        $manager_info = $this->__manager_model->getManagerById($manager_id);
        if (empty($manager_info)) {
            $this->admin_error('管理员不存在！');

            return;
        }

        $this->__manager_model->updateManagerById($manager_id, [
            'is_delete' => 'Y',
            'mtime'     => datetime(),
        ]);

        // 添加操作日志
        $this->__manager_service->addOperLog([
            'manager_id' => $this->_manager_id,
            'object_id'  => $manager_id,
            'action'     => 'delete',
            'desc'       => "删除管理员：" . $manager_info['username'],
        ]);

        $this->admin_success('删除管理员成功！');
    }

    /**
     * 批量删除
     */
    public function deleteAll()
    {
        if (session('manager_id') != 1) {
            $this->admin_error('您无权执行该操作！');

            return;
        }

        $ids = I('ids');
        if (empty($ids)) {
            $this->admin_error('ID不正确！');

            return;
        }

        if (in_array(1, $ids)) {
            $this->admin_error('不允许删除系统管理员！');

            return;
        }

        $this->__manager_model->updateManagers($ids, [
            'is_delete' => 'Y',
            'mtime'     => datetime(),
        ]);

        // 添加操作日志
        $this->__manager_service->addOperLog([
            'manager_id' => $this->_manager_id,
            'object_id'  => implode(',', $ids),
            'action'     => 'delete',
            'desc'       => "批量删除管理员",
        ]);

        $this->admin_success('批量删除管理员成功！');
    }

    /**
     * 获取返回列表的链接
     *
     * @param $refer
     */
    protected function _backToListUrl($refer)
    {
        if (!empty($refer) && 0 === strpos($refer, U('agent/index', '', '', true))) {
            return $refer;
        } else {
            return U('agent/index', '', '', true);
        }
    }

    public function deleteAgent()
    {
        $ids = I('ids');
        if (empty($ids)) {
            $this->admin_error('ID不正确！');

            return;
        }
        $this->__agent_model->deleteAgent($ids);
        $this->admin_success('批量删除渠道成功！');
    }

    /**
     * 删除图片
     */
    public function deleteImage($id)
    {
        $id = (int)$id;
        if (!$id) {
            echo json_encode(['error' => '渠道ID不正确！']);

            return;
        }

        $key = I('key', '');
        if (!$key) {
            echo json_encode(['error' => '图片参数不正确！']);

            return;
        }

        $agent = $this->__agent_model->getAgentById($id);

        if (!$agent) {
            echo json_encode(['error' => '渠道不存在！']);

            return;
        }

        if (strlen($agent['certification']) > 2) {
            $agent['certification'] = json_decode($agent['certification'], true);
        }

        if (strlen($agent['contract_file']) > 2) {
            $agent['contract_file'] = json_decode($agent['contract_file'], true);
        }

        // 反序列化图片字符串
        if (!empty($agent['certification'][$key])) {
            unset($agent['certification'][$key]);
            $new_agent = json_encode($agent['certification']);
            $where     = [
                'id' => $id,
            ];
            $fields    = [
                'certification' => $new_agent,
            ];
            $this->__agent_model->updateAgent($where, $fields);
        }
        if (!empty($agent['contract_file'][$key])) {
            unset($agent['contract_file'][$key]);
            $new_agent = json_encode($agent['contract_file']);
            $where     = [
                'id' => $id,
            ];
            $fields    = [
                'contract_file' => $new_agent,
            ];
            $this->__agent_model->updateAgent($where, $fields);
        }
        echo '{}';
    }

    /**
     * 测试定时任务 （可删除）
     */
    public function getStats() {
        /** @var StatsService $stats_service */
        $stats_service = D('Basic/Stats', 'Service');
        $year = date('Y');
        $month = date('m');
        $stats = $stats_service->statsAgentFinance($year, $month);
        /** @var StatsAgentFinanceModel $stats_agent_model */
        $stats_agent_model = D('Basic/StatsAgentFinance', 'Model');
        foreach ($stats as $v) {
            $res = $stats_agent_model->statsExist(['month' => ['eq', $v['month']],['agent_id' => $v['agent_id']]]);
            if ($res) {
                $v['id'] = $res;
                $stats_agent_model->save($v);
            } else {
                $stats_agent_model->add($v);
            }
        }
    }

}