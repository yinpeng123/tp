<?php

namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\AuthService;
use Basic\ModelU\CenterModel;
use Admin\Service\PageService;

class BbsController extends AdminSessionController
{
    public function __construct()
    {
        parent::__construct();

    }

    public function index()
    {
        $curr_page = I('path.2/d', 1);
        $model = new CenterModel('u_bbs');
        $type=I("type",0);
        $where = ['is_del' => "N"];
        $title=I("net_no");
        if($title){
            $key="%".$title."%";
            $where['title']= array('like',$key);
        }
        if($type==1){
            $where['group']=['neq',0];
        }
        if($type==2){
            $where['group']=['eq',0];
        }
        $list = $model->getListBy($where, "*", "push desc ,id desc", $curr_page, 15);
        foreach($list as $key =>$val){
            $list[$key]['desc']=mb_substr($val['describe'], 0, 20, 'utf-8');
        }
        $total = $model->getListTotal($where);
        $page_service = new PageService($total, 15);
        $page_nav = $page_service->show();
        $this->assignAll(array(
            'title' => '所有社区列表',
            'list' => $list,
            'type'=>$type,
            'ac'=>'index',
            'page_nav' => $page_nav
        ));
        $this->display('index');
    }

    public function indexC()
    {
        $curr_page = I('path.2/d', 1);
        $model = new CenterModel('u_bbs');
        $type=I("type",0);
        $where = ['is_del' => "N"];
        $title=I("net_no");
        if($title){
            $key="%".$title."%";
            $where['title']= array('like',$key);
        }
        if($type==1){
            $where['group']=['neq',0];
        }
        if($type==2){
            $where['group']=['eq',0];
        }
        $list = $model->getListBy($where, "*", "push desc ,id desc", $curr_page, 15);
        foreach($list as $key =>$val){
            $list[$key]['desc']=mb_substr($val['describe'], 0, 20, 'utf-8');
        }
        $total = $model->getListTotal($where);
        $page_service = new PageService($total, 15);
        $page_nav = $page_service->show();
        $this->assignAll(array(
            'title' => '家长社区列表',
            'list' => $list,
            'type'=>$type,
            'ac'=>'indexC',
            'page_nav' => $page_nav
        ));
        $this->display('index');
    }
    public function indexB()
    {
        $curr_page = I('path.2/d', 1);
        $model = new CenterModel('u_bbs');
        $type=I("type",0);
        $where = ['is_del' => "N"];
        $title=I("net_no");
        if($title){
            $key="%".$title."%";
            $where['title']= array('like',$key);
        }
        if($type==1){
            $where['group']=['neq',0];
        }
        if($type==2){
            $where['group']=['eq',0];
        }
        $list = $model->getListBy($where, "*", "push desc ,id desc", $curr_page, 15);
        foreach($list as $key =>$val){
            $list[$key]['desc']=mb_substr($val['describe'], 0, 20, 'utf-8');
        }
        $total = $model->getListTotal($where);
        $page_service = new PageService($total, 15);
        $page_nav = $page_service->show();
        $this->assignAll(array(
            'title' => '学生社区列表',
            'list' => $list,
            'type'=>$type,
            'ac'=>'indexB',
            'page_nav' => $page_nav
        ));
        $this->display('index');
    }
    public function edit($id = 0)
    {
        $this->show($id);
    }
    public function show($id = 0)
    {
        $model = new CenterModel('u_bbs');
        $list = [];
        if ($id) {
            $list = $model->get($id);
        }
        else{
            $this->admin_error("出错了");
            return;
        }
        if(!$list){
            $this->admin_error("出错了");
            return;
        }
        $user= (new CenterModel("u_user"))->get($list['uid']);
        $list['name']=$user['name'];
        $where=[
            'fid'=>$id,
            'is_del'=>'N'
        ];
        $comment=(new CenterModel("u_bbs_comment"))->getListBy($where,"id,content,name","id desc");
        $this->assignAll(array(
            'title' => '内容查看',
            'list' => $list,
            'comment'=>$comment,
        ));
        $this->display('edit');
    }
    public function add()
    {
        $model = new CenterModel('u_bbs');

        $this->assignAll(array(
            'title' => '新增内容',

        ));
        $this->display('add');
    }

    public function pushTop()
    {
        $url=I("url","/bbs/");
        $url.=I("ac");
        $url.="?type=".I("type");
        $id = I("ids", 0);
        $model = new CenterModel("u_bbs");
        $info=$model->get($id);
        $push=$info['push']==1?0:1;
        $model->update($id,['push'=>$push]);
        $this->admin_success("", $url);
    }

    public function doEdit($id)
    {

        $id = I("tid", 0);
        $info = [
            'title' => I('title'),
            'describe' => mb_substr(I("content"), 0, 50, 'utf-8'),
            'content' => I("content"),
            'name' => I("name"),

            'ctime' => I("ctime") ? I("ctime") : datetime(),
            'pic' => implode(",", I("identity_photo")),
        ];
        $model = new CenterModel("u_bbs");
        if ($id) {
            $model->update($id, $info);
            $msg = "修改文章成功";
        } else {
            $model->add($info);
            $msg = "添加文章成功";
        }
        $this->admin_success($msg, "/article/index");

    }

//删除所有
    public function delete()
    {
        $ids = I("ids");
        $url=I("url");
        if (is_array($ids)) {
            $where = 'id in(' . implode(',', $ids) . ')';
        } else {
            $where = 'id=' . $ids;
        }  //dump($where);
        M("u_bbs")->where($where)->delete();
        $this->admin_success("删除成功",$url);
    }

    //删除评论
    public function delComment(){
        $id = I("ids");
        $model = new CenterModel("u_bbs_comment");
        $model->update($id,['is_del'=>'Y']);
        $this->admin_success("删除成功");
    }

    //添加社区内容
    public function doAdd(){
        $model = new CenterModel("u_user");
        $user=[
            'name'=>I("name"),
            'avatar'=>I("identity_photo")[0],
        ];
       $id= $model->add($user);
        $model = new CenterModel("u_bbs");
        $info=[
            'uid'=>$id,
            'title'=>I("title"),
            'group'=>I("type")==1?1:0,
            'describe'=>mb_substr(I("describe"),0,20,'utf-8'),
            'content'=>I("content")
        ];
        $model->add($info);
        $this->admin_success("删除成功");

    }

}