<?php

namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\AuthService;
use Basic\ModelU\CenterModel;
use Admin\Service\PageService;

class FinanceController extends AdminSessionController
{
    public function __construct()
    {
        parent::__construct();

    }

    public function index()
    {
        $curr_page = I('path.2/d', 1);
        $model = new CenterModel('u_finance_log');
        $where=[];
        $uid=I("uid");
        $start=I("search_ftime_from");
        $end=I("search_ftime_to");
        if($uid){
            $where['uid']=$uid;
        }
        if($start){
            $where['ctime']=['egt',$start];
        }
        if($end){
            $where['ctime']=['elt',$end];
        }
        $list = $model->getListBy($where, "*", "id desc", $curr_page, 15);
        $total = $model->getListTotal($where);
        $page_service = new PageService($total, 15);
        $page_nav = $page_service->show();
        $frozen=$total=0;
        $days= day();
        $where=[
            'ctime'=>['gt',$days],
            'type'=>'reward',
        ];
        $frozen=M('u_finance_log')->where($where)->sum('amount');

        $where=[
            'ctime'=>['gt',$days],
            'type'=>['in',['recharge','member','vip']],
        ];
        $total=M('u_finance_log')->where($where)->sum('amount');
        $this->assignAll(array(
            'title' => '资金管理',
            'list' => $list,
            'frozen'=>$frozen,
            'total'=>$total,
            'page_nav' => $page_nav
        ));
        $this->display('index');
    }

    public function show($id = 0)
    {
        $model = new CenterModel("u_plan");
        $list = $model->get($id);
        $info = (new CenterModel("u_plan_info"))->getListBy(['pid' => $id]);
        $user = (new CenterModel("u_user"))->get($list['uid']);
        $this->assignAll(array(
            'title' => '计划详情',
            'list' => $list,
            'info' => $info,
            'user' => $user,
            'day' => day()
        ));
        $this->display('edit');
    }
    //教练编辑
    public function trainer()
    {

    }

}