<?php
namespace Admin\Model;


use Basic\Cnsts\CACHE_PREFIX;
use Basic\Model\BasicModel;

class TicketModel extends BasicModel {
    private $__ws_model = NULL;
    private $__ticket_model = NULL;
    private $__ticket_log_model = NULL;
    private $__ticket_info_model = NULL;
    private $__agent_invoice_model = NULL;
    private $__mail_info_model = NULL;
    private $__agnet_model = NULL;

    const MODEL_LIST = [
        [
            'model' => '__ws_model',
            'table' => 'cs_work_sheet',
        ],
        [
            'model' => '__ticket_model',
            'table' => 'ticket',
        ],
        [
            'model' => '__ticket_log_model',
            'table' => 'ticket_log',
        ],
        [
            'model' => '__ticket_info_model',
            'table' => 'ticket_info',
        ],
        [
            'model' => '__agent_invoice_model',
            'table' => 'agent_invoice',
        ],
        [
            'model' => '__mail_info_model',
            'table' => 'mail_info',
        ],
        [
            'model' => '__agent_model',
            'table' => 'agent',
        ]
    ];
    public function __construct($db_type = 'master', $enable_cache = FALSE) {
        $model_list = self::MODEL_LIST;
        foreach($model_list as $k=>$v) {
            parent::__construct($v['table'], CACHE_PREFIX::TICKET, $db_type);
            $this->_enable_cache = $enable_cache;
            $this->$v['model'] = $this->_model;
        }
//        $this->__ws_model = M('cs_work_sheet');
//        $this->__ticket_model = M('ticket');
//        $this->__ticket_log_model = M('ticket_log');
//        $this->__ticket_info_model = M('ticket_info');
//        $this->__agent_invoice_model = M('agent_invoice');
//        $this->__mail_info_model = M('mail_info');
//        $this->__agnet_model = M('agent');
    }

    /**
     * @param $field
     * @param $join
     * @param $where
     * @param $order
     * @param $limit
     *获取开票列表
     */
    public function getTicketList($field, $join, $where, $order, $limit) {
        return  $this->__ticket_model->field($field)->join($join)->where($where)->order($order)->limit($limit)
            ->select();
    }

    public function getTicketListTotal($where,$join = []) {
        $total = $this->__ticket_model->join($join)->where($where)->count();
        return $total;
    }

    public function getTicketById($ticket_id) {
        $where = [
            'id' => $ticket_id,
        ];
        return  $this->__ticket_model->where($where)->find();
    }

    /**
     * 开票管理
     *
     * @param array $field 搜索字段
     * @param array $join 关联表
     * @param array $where 搜索条件
     * @param array $order 排序
     * @param int   $page_no 页码
     * @param int   $per_page 每页记录数
     */
    public function searchTicketList($field, $join, $where, $order, $page_no, $per_page) {
        $page_no = max($page_no, 1);
        $data = $this->__ticket_model->field($field)->join($join)->where($where)->order($order)->page($page_no,
            $per_page)->select();
        $res = $this->__ticket_model->field("FOUND_ROWS() as total")->find();
        $count = $res['total'];
        $page_number = ceil($count / $per_page);  // 总页数

        if ($page_number > 0 && $page_no > $page_number) { // 超出记录集, 返回最后一页的数据
            return $this->searchGoodsList($field, $join, $where, $order, $page_number, $per_page);
        }
        return array('count' => $count, 'page_number' => $page_number, 'page_no' => $page_no, 'data' => $data);
    }

    /**
     * 开票管理导出
     *
     * @param array $field 搜索字段
     * @param array $join 关联表
     * @param array $where 搜索条件
     * @param array $order 排序
     * @param array $limit_start 起始行
     * @param array $limit_size 查询条数
     */
    public function exportTicketList($field, $join, $where, $order, $limit_start, $limit_size) {
        return $this->__ticket_model->field($field)->join($join)->where($where)->order($order)->page($limit_start,
            $limit_size)->select();
    }

    /**
     * 开票管理操作日志
     */
    public function saveTicketLog($ticket_log) {
        $this->__ticket_log_model->add($ticket_log);
    }

    /**
     * 查询开票信息
     */
    public function searchTicket($where) {
        $where['status'] = 1;
        return $this->__ticket_model->where($where)->find();
    }

    /**
     * 查询工单信息
     */
    public function searchWork($where) {
        $field = 'id,uid,type,finance_ticket_id,price_real,agent_id,status';
        return $this->__ws_model->field($field)->where($where)->find();
    }

    public function searchWorkList($where) {
        $field = 'id,uid,type,finance_ticket_id,price_real,agent_id,status';
        return $this->__ws_model->field($field)->where($where)->select();
    }

    /**
     * 查询代理商信息
     */
    public function getAgentById($id) {
        $where['id'] = $id;
        return $this->__agnet_model->where($where)->find();
    }

    /**
     * 查询开票信息
     */
    public function searchUserTicketInfo($where) {
        $where['status'] = 1;
        $field = 'company_name,tax_no,credit_no,addr,open_bank,bank_card';
        return $this->__ticket_info_model->field($field)->where($where)->find();
    }

    public function searchUserTicketInfoList($where) {
        $where['status'] = 1;
        $field = 'id,company_name,tax_no,credit_no,addr,open_bank,bank_card';
        return $this->__ticket_info_model->field($field)->where($where)->select();
    }

    public function searchAgentTicketInfo($where) {
        $field = 'company,taxer_no,credit_no,address,bank_name,bank_passport';
        return $this->__agent_invoice_model->field($field)->where($where)->find();
    }

    public function searchAgentTicketInfoList($where) {
        $field = 'id,company,taxer_no,credit_no,address,bank_name,bank_passport';
        return $this->__agent_invoice_model->field($field)->where($where)->select();
    }

    /**
     * 查询邮寄信息
     */
    public function searchMailInfo($where) {
        $where['status'] = 1;
        $field = 'addr,user_name,telephone';
        return $this->__mail_info_model->field($field)->where($where)->find();
    }

    public function searchMailInfoList($where) {
        $where['status'] = 1;
        $field = 'id,addr,user_name,telephone';
        return $this->__mail_info_model->field($field)->where($where)->select();
    }

    /**
     * 查询开票操作历史记录
     */
    public function searchTicketLog($id) {
        $where['ticket_id'] = $id;
        return $this->__ticket_log_model->where($where)->order('id desc')->select();
    }

    /**
     * 保存开票
     */
    public function saveTicket($cond) {
        return $this->__ticket_model->add($cond);
    }



    /**
     * 更新开票
     */
    public function updateTicket($where, $data) {
        return $this->__ticket_model->where($where)->save($data);
    }

    /**
     * 更新工单
     */
    public function updateWork($where, $data) {
        return $this->__ws_model->where($where)->setField($data);
    }


    /**
     * 搜索发票
     */
    public function searchTickets($cond) {
        $where = ['status' => 1];
        if (isset($cond['drawer']) && $cond['drawer']) {
            $where['drawer'] = array('like', '%'.$cond['drawer'].'%');
        }

        if (isset($cond['search_from_day']) && $cond['search_from_day']) {
            $where['create_time'] = array('egt', $cond['search_from_day'].' 00:00:00');
        }

        if (isset($cond['search_to_day']) && $cond['search_to_day']) {
            $where['create_time'] = array('elt', $cond['search_to_day'].' 23:59:59');
        }

        return $this->__ticket_model->where($where)->order('id DESC')->select();
    }

    public function searchTicket1($cond, $page_no, $per_page) {
        $page_no = max($page_no, 1);
        $data = $this->__ticket_model->field('SQL_CALC_FOUND_ROWS *')->where($cond)->order('id DESC')->page($page_no,
            $per_page)->select();
        $res = $this->__ticket_model->field("FOUND_ROWS() as total")->find();
        $count = $res['total'];
        $page_number = ceil($count / $per_page);  // 总页数

        if ($page_number > 0 && $page_no > $page_number) { // 超出记录集, 返回最后一页的数据
            return $this->searchTicket($cond, $page_number, $per_page);
        }

        return array('count' => $count, 'page_number' => $page_number, 'page_no' => $page_no, 'data' => $data);
    }

    public function searchTicketInfoList($cond, $page_no, $per_page) {
        $page_no = max($page_no, 1);
        $data = $this->__ticket_info_model->field('SQL_CALC_FOUND_ROWS *')->where($cond)->order('id DESC')->page($page_no,
            $per_page)->select();
        $res = $this->__ticket_info_model->field("FOUND_ROWS() as total")->find();
        $count = $res['total'];
        $page_number = ceil($count / $per_page);  // 总页数

        if ($page_number > 0 && $page_no > $page_number) { // 超出记录集, 返回最后一页的数据
            return $this->searchTicketInfoList($cond, $page_number, $per_page);
        }

        return array('count' => $count, 'page_number' => $page_number, 'page_no' => $page_no, 'data' => $data);
    }

    //查询单条开票信息
    public function searchTicketInfo($where) {
        return $this->__ticket_info_model->where($where)->find();
    }

    //修改发票数据
    public function updateOne($where, $data) {
        return $this->__ticket_model->where($where)->setField($data);
    }

    //获取发票列表（根据开票ID）
    public function searchTicketList1($where) {
        return $this->__ticket_model->where($where)->select();
    }

    /**
     * 保存开票
     */
    public function addTicket($data) {
        return $this->__ticket_model->add($data);
    }

    public function upTicketById($ticket_id, $up_data) {
        $where = [
            'id' => $ticket_id,
        ];

        return $this->__ticket_model->where($where)->save($up_data);
    }
}