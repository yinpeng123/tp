<?php
return array(
    //'配置项'=>'配置值'
    '__LAYUI__'=>__ROOT__.'/public/static/layui'





);