<?php
namespace Client\Behavior;

use Think\Behavior;
use Think\Log;

class profileLogHeadBehavior extends Behavior
{
    // 行为扩展的执行入口必须是run
    public function run(&$params)
    {
        $user = session('user_info');
        $user_id = !empty($user['id']) ? $user['id'] : '';
        $account = !empty($user['account']) ? $user['account'] : '';
        $telephone = !empty($user['telephone']) ? $user['telephone'] : '';
        $log_content   = [
            'uid=' . $user_id,
            'account=' . $account,
            'telephone=' . $telephone,
            'ip=' . I('server.REMOTE_ADDR'),
            str_replace(' ', '', I('server.HTTP_X_FORWARDED_FOR')),
            PATH_INFO,
            'post=' . json_encode(I('post.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
            'get=' . json_encode(I('get.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
            'refer=' . I('server.HTTP_REFERER', '', 'url'),
            'ua=\'' . I('server.HTTP_USER_AGENT') . '\'',
            'cookie=' . json_encode($_COOKIE),
            'sid=' . session_id(),
            'rid=' . $_REQUEST['request_id'],
        ];
//        $shape_shifter = session('shape_shifter');
//        if ($shape_shifter) {
//            $log_content[] = 'shape_shifter=' . $shape_shifter;
//        }
//        $company_group = session('company_group');
//        if ($company_group) {
//            $log_content[] = 'company_group=' . $company_group;
//        }
        Log::write(implode(' ', $log_content), 'PROFILE_HEAD');
    }
}

