<?php
namespace Admin\Controller;


class DemozgzController extends AdminSessionController {

    public function __construct() {
        parent::__construct();
    }
    // 图片可缩小放大 拖拽模板
    public function imgDragBig() {
        $this->display('imgDragBig'); 

    }
    // 弹框列表模板
    public function bootstrapmodals() {
        $this->display('bootstrapmodals'); 

    }
}