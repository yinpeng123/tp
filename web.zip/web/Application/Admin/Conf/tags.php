<?php
if (!IS_CLI) {
    return [
        'app_begin'  => [
            'Admin\\Behavior\\preventRefreshBehavior',
        ],
        'action_begin' => [
            'Admin\\Behavior\\profileLogHeadBehavior',
        ],
        'app_end'    => [
            'Admin\\Behavior\\updateRefreshCacheBehavior',
            'Admin\\Behavior\\profileLogTailBehavior',
        ],
        'view_filter' => [
            'Behavior\TokenBuildBehavior'
        ],
    ];
} else {
//    return [
//        'app_begin'  => [
//            'Common\\Behavior\\profileLogHeadBehavior',
//        ],
//        'app_end'    => [
//            'Common\\Behavior\\profileLogTailBehavior',
//        ],
//        'view_filter' => [
//            'Behavior\TokenBuildBehavior'
//        ],
//    ];
    return [];
}
