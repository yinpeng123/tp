<?php
namespace Admin\Model;

use Basic\Model\BasicModel;

class UserEventModel extends BasicModel {

    protected $_user_event = NULL;

    /**
     * 构造函数, 缺省为连接主库并不使用缓存!
     *
     * @param string     $db_type 指定主、从数据库, 值分别为: master/slave
     * @param bool|FALSE $enable_cache 是否启用缓存
     */
    public function __construct($db_type = 'master', $enable_cache = FALSE) {
        parent::__construct('user_event', '', $db_type);
        $this->_enable_cache = $enable_cache;

        $this->_user_event = $this->_model;
    }

}