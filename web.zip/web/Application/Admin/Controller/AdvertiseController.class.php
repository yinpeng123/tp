<?php
namespace Admin\Controller;

use Admin\Cnsts\ADVERTISE;
use Admin\Service\ManagerService;
use Admin\Service\UserService;
use Basic\Model\AgentChargeModel;
use Basic\Service\AgentChargeService;
use Common\Cnsts\ERRNO;
use Admin\Service\AdvertiseService;
use Basic\Model\CSWorkSheetModel;
use Basic\Service\AgentService;
use Basic\Cnsts\AGENT_CHARGE;
use Basic\Cnsts\CS_WORK_SHEET;

class AdvertiseController extends AdminSessionController {

    public function __construct() {
        parent::__construct();
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::ADVERTISE) ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }
    }

    /**
     * 广告列表 reviewed
     */
    public function Index() {

        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);

        $limit = ($curr_page -1) * $per_page.",".$per_page;
        $order_by = 'advertise.id desc ';
        $where = $this->_getAdListWhere();
        $fields = $this->_getAdListField();
        $join = $this->_getAdListJoin();

        /** @var \Basic\Service\AdvertiseService $ad_service */
        $ad_service = D('Basic/Advertise', 'Service');
        $list = $ad_service->getAdList($where, $order_by, $limit, $fields,$join);
        $total = $ad_service->getSqlFoundRows($where, $join);
        $ad_status_arr = ADVERTISE::AD_STATUS_ARR;
        $ad_category_arr   = AGENT_CHARGE::AD_CATEGORY_ARR;
        $ad_pos_arr        = AGENT_CHARGE::AD_POS_ARR;
        $ad_type_arr       = CS_WORK_SHEET::WS_AD_TYPE_ARR;
        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');
        $format_manager_list = $manager_service->getFormatManger();
        /** @var AgentService $agent_service */
        $agent_service = D('Basic/Agent','Service');
        $agent_list = $agent_service->getFormatAgent();
//p($agent_list);die;
        /** @var AgentChargeService $agent_charge_service */
        $agent_charge_service = D('Basic/AgentCharge', 'Service');

        foreach ($list as &$value) {
            $value['status_desc'] = $ad_status_arr[$value['status']];
            $value['ad_pos_desc'] = $ad_pos_arr[$value['ad_pos']];
            $value['creator_name'] = $format_manager_list[$value['creator']];
            $value['worker_name'] = $format_manager_list[$value['worker']];
            $agents = $value['agents'];
            $agents = trim($agents,',');
            $agents = explode(',', $agents);
            $agents_name = '';
            foreach($agents as $v) {
                $agents_name .= $agent_list[$v]['name'].'|';
            }
            $agents_name = trim($agents_name,'|');
            $value['agents_name'] = $agents_name;

            // 新增需求（广告类型）
            $value['ad_type_text'] = '';
            foreach (json_decode($value['ad_type'], true) as $va) {
                $value['ad_type_text'] .= $ad_type_arr[$va] . '|';
            }
            // 广告套餐处理
            $info= $agent_charge_service->getBy($value['ac_id']);
            $value['ac_id_text'] = $info['name'];

            // 新增广告发展人
            $value['referer_name'] = $format_manager_list[$value['referer']];

            // 新增审核人
            $value['mender_name'] = $format_manager_list[$value['mender']];

            // 新增归属渠道
            $agent_info = $agent_service->getAgentById($value['agent_id']);
            $value['agent_belong_to'] = $agent_info['name'];
        }

        $page_service = new \Admin\Service\PageService($total, $per_page);
        $page_nav = $page_service->show();

        foreach($_GET as $gk => $gv) {
            $this->assign($gk,$gv);
        }
//        p($list);die;
        $this->assignAll(
            array(
                'format_manager_list' => $format_manager_list,
                'list' => $list,
                'title' => '广告管理',
                'ad_pos_arr' => $ad_pos_arr,
                'ad_category_arr' => $ad_category_arr,
                'ad_type_arr' => $ad_type_arr,
                'ad_status_arr' => $ad_status_arr,
                'agent_list' => $agent_list,
                'page_nav' => $page_nav,
                'ad_url_flag_arr' => AGENT_CHARGE::AD_URL_FLAG_ARR,
                'search_ad_content' => I('search_ad_content'),
                'ad_url_flag' => I('ad_url_flag'),
            )
        );
        $this->display('ad_list');
    }

    /**
     *获取广告筛选条件 reviewed
     */
    protected  function _getAdListWhere() {
        $ad_id = I('ad_id',0, 'int');
        $ad_pos = I('ad_pos',0, 'int');
        $status = I('status','');
        $creator = I('creator');
        $telephone = I('telephone','');
        $net_no = I('net_no',0, 'int');
        $account = I('account');
        $worker = I('worker');
        $ad_end_day1 = I('ad_end_day1');//广告到期日
        $ad_end_day2 = I('ad_end_day2');
        $ad_type = I('ad_type',0, 'int');
        $ad_type2 = I('ad_type2',0, 'int');
        $agent_id = I('agent_id',0, 'int');
        $ad_start_day1 = I('ad_start_day1');//计划上线日期
        $ad_start_day2 = I('ad_start_day2');
        $ws_id = I('ws_id',0, 'int');
        $ad_contact= I('ad_contact');
        $ad_url_flag = I('ad_url_flag/d'); // 链接情况
        $search_ad_content = I('search_ad_content'); // 备注和广告内容模糊搜索
        $search_referer = I('search_referer'); // 发展人
        $where = [];
        if ($ad_id) {
            $where['advertise.id'] = $ad_id;
        }

        if ($ad_pos) {
            $where['advertise.ad_pos'] = $ad_pos;

        }

        if ($status) {
            $where['advertise.status'] = $status;

        }
        if ($creator) {
            $where['advertise.creator'] = $creator;

        }
        if ($telephone) {
            $where['user.telephone'] = $telephone;
        }
        if ($net_no) {
            $where['user.net_no'] = ['like',"%$net_no%"];
        }
        if ($account) {
            $where['user.account'] = ['like',"%$account%"];
        }

        if ($worker) {
            $where['advertise.worker'] = $worker;
        }

        if ( $ad_end_day1 && $ad_end_day2 ) {
            $where['ad_end_day'] = ['between',[$ad_end_day1,$ad_end_day2]];
        } else {
            if ( $ad_end_day1 ) {
                $where['ad_end_day'] = array('egt', $ad_end_day1);
            }
            if ( $ad_end_day2 ) {
                $where['ad_end_day'] = array('elt', $ad_end_day2);
            }
        }

        if ($ad_type) {
            $where['advertise.ad_type'] = $ad_type;
        }

        if ($ad_type2) {
            $where['advertise.ad_type2'] = $ad_type2;
        }

        if ($agent_id) {
            $where['advertise.agents'] = ['like', "%$agent_id%"];
        }

        if ($ws_id) {
            $where['advertise.ws_id'] = ['like', "$ws_id%"];
        }

        if ( $ad_start_day1 && $ad_start_day2 ) {
            $cond_other['ad_start_day'] = ['between',[$ad_start_day1,$ad_start_day2]];
        } else {
            if ( $ad_start_day1 ) {
                $cond_other['ad_start_day'] = array('egt', $ad_start_day1);
            }
            if ( $ad_start_day2 ) {
                $cond_other['ad_start_day'] = array('elt', $ad_start_day2.' 23:59:59');
            }
        }
        if ($ad_contact) {
            $cond['advertise.ad_contact'] = ['like', "$ad_contact%"];
            $cond['cs_work_sheet.remark'] = ['like', "$ad_contact%"];
            $cond['_logic'] = 'OR';
            $where['_complex'] = $cond;
        }

        if ( !empty($search_referer)) {
            $where['advertise.referer'] = ['eq', $search_referer];
        }
        if ( $ad_url_flag == AGENT_CHARGE::URL_YES) {
            $where['advertise.ad_url_flag'] = ['eq', $ad_url_flag];
        } elseif ($ad_url_flag == AGENT_CHARGE::URL_NOT) {
            $where['advertise.ad_url_flag'] = ['eq', 0];
        }

        if ( !empty($search_ad_content)) {
            $where['advertise.ad_content'] = ['like', "%$search_ad_content%"];
        }
        return $where;
    }

    /**
     * 广告列表所需字段 reviewed
     */
    protected function _getAdListField() {
        return [
            'user.id as user_id',
            'user.telephone ',
            'user.net_no',
            'user.account',
            'advertise.id as ad_id',
            'advertise.ws_id',
            'advertise.status',
            'advertise.ad_start_day',
            'advertise.ad_start_day_real',
            'advertise.ad_contact',
            'advertise.ad_pos',
            'advertise.ad_end_day',
            'advertise.agents',
            'advertise.creator',
            'advertise.worker',
            'advertise.ad_content', // 新增广告内容
            'advertise.referer', // 新增发展人
            'advertise.mender', // 新增审核人
            'advertise.ad_type',  // 新增广告类型
            'cs_work_sheet.ac_id', // 新增广告套餐
            'cs_work_sheet.agent_id', // 新增归属渠道
            'cs_work_sheet.remark', // 新增备注(工单表字段)

        ];
    }

    /**
     * 广告join表 reviewed
     */
    protected function _getAdListJoin() {
        return [
            'left join cs_work_sheet on advertise.ws_id = cs_work_sheet.id',
            'left join user on cs_work_sheet.uid = user.id',
        ];
    }

    /**
     * 添加广告记录 reviewed
     */
    public function add($ws_id = 0) {
        //@todo 修改广告工单的逻辑
        $ws_id = (int) $ws_id;
        if ($ws_id) {
            /** @var \Basic\Service\AdvertiseService $ad_service */
            $ad_service = D('Basic/Advertise', 'Service');
            $ad = $ad_service->getAdByWsId($ws_id);
            if ($ad) {
                $this->_formatAd($ad);
//                $attachment = $this->_getImagePreview($ad['attachment'], $ad['ad_id']);
            } else {
                $ad = [];
            }
        } else {
            $ad = [];
        }
        $attachment_upload_key = uniqid('attachment_');
        // 管理员列表
        $manager_model = D('Manager');
        $manager_list = $manager_model->getAllManagerList('manager_id, realname');
        /** @var AgentService $agent_service */
        $agent_service = D('Basic/Agent','Service');
        $agent_list = $agent_service->getFormatAgent();
        $this->assignAll(array(
            'act'           => 'add',
            'form_action'   => '/Advertise/doEdit',
            'title'         => '添加广告',
            'ad'         => $ad,
            'manager_list'  => $manager_list,
            'agent_list' => $agent_list,
            'ad_category_arr'   => AGENT_CHARGE::AD_CATEGORY_ARR,
            'ad_pos_arr'        => AGENT_CHARGE::AD_POS_ARR,
            'ad_status_arr'    => ADVERTISE::AD_STATUS_ARR,
            'ad_type_arr'       => CS_WORK_SHEET::WS_AD_TYPE_ARR,
            'attachment_upload_key'=> $attachment_upload_key,
        ));
        $this->display('add');
    }

    /**
     * @param $ad_id
     * @todo 修改广告内容
     */
    public function edit($ad_id) {
        $ad_id = (int) $ad_id;
        $act = I('act','edit');
        if (empty($ad_id)) {
            $this->admin_error('请选择广告单号');
            return;
        }
        /** @var \Basic\Service\AdvertiseService $ad_service */
        $ad_service = D('Basic/Advertise', 'Service');
        $ad = $ad_service->getAdById($ad_id);

        if ($ad) {
            $this->_formatAd($ad);
            $attachment = $this->_formatImagePreview($ad['attachment']);

            $this->assign('attachment', $attachment);
//            $attachment = $this->_getImagePreview(, $ad_id);
        } else {
            $ad = [];
        }
        // 管理员列表
        $manager_model = D('Manager');
        $manager_list = $manager_model->getAllManagerList('manager_id, realname');
        /** @var AgentService $agent_service */
        $agent_service = D('Basic/Agent','Service');
        $agent_list = $agent_service->getFormatAgent();

        // 操作记录
        $log_list = $ad_service->logList($ad_id);


        // 处理管理员姓名
        foreach( $log_list as &$v) {
            $manager_info = $manager_model->getManagerById($v['manager_id'], $fields = NULL);
            $v['m_name'] = $manager_info['username'];
            $action_text = '';
            switch ($v['action']) {
                case 'save':
                    $action_text = '保存';
                    break;
                case 'update':
                    $action_text = '完成';
                    break;
                case 'verify_fail':
                    $action_text = '审核不通过';
                    break;
                case 'verify':
                    $action_text = '审核通过';
                    break;
            }

            $v['action_text'] = $action_text;
        }

        $log_list_less = [];
        if (count($log_list) < 5 || count($log_list) == 5) {
            $log_list_less = $log_list;
        } else {
            for ($i =0; $i<5; $i++) {
                $log_list_less[$i] = $log_list[$i];
            }
        }

        $this->assignAll(array(
            'act'           => $act,
            'form_action'   => '/Advertise/doEdit',
            'title'         => '编辑广告',
            'ad'         => $ad,
//            'attachment' => $attachment,
            'manager_list'  => $manager_list,
            'agent_list' => $agent_list,
            'ad_category_arr'   => AGENT_CHARGE::AD_CATEGORY_ARR,
            'ad_pos_arr'        => AGENT_CHARGE::AD_POS_ARR,
            'ad_status_arr'    => ADVERTISE::AD_STATUS_ARR,
            'ad_type_arr'       => CS_WORK_SHEET::WS_AD_TYPE_ARR,
            'log_list'          => $log_list,
            'log_list_less' => $log_list_less,
            'num' => count($log_list),
        ));

        $this->display('add');
    }

    protected function _formatImagePreview($image_arr) {
        if ($image_arr) {
//            $image_arr = json_decode($image_str, TRUE);
            //print_r($image_arr);

            $res = ['initialPreview' => [], 'initialPreviewConfig' => []];
            foreach ( $image_arr as $k => $i ) {
                $res['initialPreview'][] = imageUrl($i);
                $res['initialPreviewConfig'][] = [
                    'type'      => 'image',
                    'caption'   => $i['name'],
                    'size'      => filesize(imageFilePath($i)),
                    'url'       => '/Advertise/ajaxDeleteImage',
                    'key'       => $k,
                ];
            }
        } else {
            $res = [];
        }

        return $res;
    }

    /**
     * 上传附件的预览
     */
    protected  function _getImagePreview($photos, $ad_id) {
        $initialPreview = [];
        $initialPreviewConfig = [];
        $prefix = '/Basic/Image/View/';
        foreach ($photos as $value) {
            $img_url = $prefix.$value['type'].'/'.$value['path'].'/'.$value['name'];
            $initialPreview[] = $img_url;
            $initialPreviewConfig[] = [
                'type'      => 'image',
                'caption'   => $value['name'],
                'size'      => 20000,
                'url'       => '/Advertise/ajaxDeleteImage/'.$ad_id,
                'key'       => $value['key'],
            ];
        }

        $pre_photos = [
            'initialPreview' => $initialPreview,
            'initialPreviewConfig' => $initialPreviewConfig,

        ];
        return $pre_photos;

    }


    /**
     * ajax 删除图片 reviewed
     */

//    public function ajaxDeleteImage($ad_id) {
//        /** @var \Basic\Service\AdvertiseService $ad_service */
//        $ad_service = D('Basic/Advertise', 'Service');
//        $ad  = $ad_service->getAdById($ad_id);
//        $attachment = $ad['attachment'];
//        $key = I('key');
//        foreach ($attachment as  $k => $value) {
//            if ($value['key'] == $key) {
//                unset($attachment[$k]);
//            }
//        }
//        $attachment = array_values($attachment);
//        $up_data['attachment'] = json_encode($attachment,JSON_UNESCAPED_UNICODE);
//        $up_res = $ad_service->updateAdById($ad_id,$up_data);
//        echo '{}';
//
//    }
    /**
     * 修改,添加广告内容 @todo 优化代码
     */
    public function doEdit() {
        $ad_data = $_POST;
        $ws_id = (int)$ad_data['ws_id'];
        $ad_id = (int)$ad_data['ad_id'];
        if (empty($ws_id))  {
            $this->admin_error('请输入工单号和广告单号');
            return;
        }
        if (empty($ad_data['agents'])) {
            $this->admin_error('请选择投放区域');
            return;
        }
        /** @var CSWorkSheetModel $ws_model */
        $ws_model = D('Basic/CSWorkSheet', 'Model');
        $ws = $ws_model->getById($ws_id);
        if ($ws['status'] != 'finish') { //校验工单状态，只有完成的才能添加广告
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO, '请先完成工单操作',[]);
            return;
        }
        /** @var \Basic\Service\AdvertiseService $ad_service */
        $ad_service = D('Basic/Advertise', 'Service');
        if (!empty($ad_id)) {
            $ad = $ad_service->getAdById($ad_id);
            if ($ad['ws_id'] != $ws_id ) {
                $this->admin_error('工单号不正确');
                return;
            }
        } else {
            // 处理广告图片上传数据
            if ( I('attachment_upload_key') ) {
                $attachment = S(I('attachment_upload_key'));
                if ( !empty($attachment)) {
                    $attachment= json_encode($attachment,JSON_UNESCAPED_UNICODE);
                }
            }
            $ad['status'] = 'new';
        }

        $up_data = $this->_formatUpData($ad_data);
        if (!empty($attachment)) {
            $up_data['attachment'] = $attachment;
        }
        if ($ad_data['btn_act'] == 'update') {
            $up_data['status'] = $this->_getNewStatus($ad['status']);
            if ($up_data['status'] == ADVERTISE::AD_STATUS_WAIT) {
                //进入审核中更新制作完成时间
                $up_data['produce_day_real'] = date('Y-m-d');
            }
        } else if($ad_data['btn_act'] == 'verify_fail') {
            //审核不通过
            $up_data['status'] = ADVERTISE::AD_STATUS_DOING;
        }

        //@todo 添加操作日志
        $log_data = [
            'manager_id' => $this->_manager_id,
            'ad_id'     => $ad_id,
            'action'        => $ad_data['btn_act'],
            'content'          => $ad_data['verify_fail_content'],
        ];
//        p($log_data);die;
        $ad_service->addAdLog($log_data);

        list($ch_er, $ck_msg, $data) = $ad_service->checkAdParam($up_data);
        if ($ch_er != ERRNO::SUCCESS) {
            $this->admin_error($ck_msg);
            return;
        }
        if (!empty($ad_id)) {
            list($errno, $errmsg,$up_res) = $ad_service->updateAdById($ad_id, $up_data);
            $desc = "编辑广告";
            $action = 'update';
        } else {
            //添加广告
            $desc = "添加广告";
            $action = 'add';
            $ws_asc = $ad_service->getAdByWsId($ws_id);
            $up_data['uid'] = $ws_asc['user_id'];
            $up_data['ws_id'] = $ws_id;
            $up_data['creator'] = $ws_asc['creator'];
            $up_data['ctime'] = datetime();
            $up_data['ad_category'] = $ws_asc['ad_category'];
            $up_data['ad_pos'] = $ws_asc['ad_pos'];
            $up_data['status'] = $up_data['status'] ? : 'new';
            list($errno, $errmsg,$add_res) = $ad_service->addAd($up_data);
            $ad_id = $add_res['ad_id'];
        }
        if ($errno == ERRNO::SUCCESS) {
            if ($ad_data['btn_act'] == 'update') {
                redirect(U('Advertise/index/', '', ''));
            } else {
                $this->admin_success('编辑广告成功');
            }
            //@todo 添加操作日志
            fastcgi_finish_request();
            $log_data = [
                'manager_id' => $this->_manager_id,
                'object_id'     => $ad_id,
                'action'        => $action,
                'desc'          => $desc,
            ];
            $ad_service->addOperLog($log_data);
            return;
        } else {
            $this->admin_error($errmsg);
            return;
        }
    }

    protected function _formatUpData($ad_data) {
        $agents = $ad_data['agents'];
        $agents = implode(',',$agents);
        $agents = ','.$agents.',';
        $up_data = [
            'ad_contact' => $ad_data['ad_contact'],
            'ad_phone' => $ad_data['ad_phone'],
//            'referer' => $ad_data['referer'],
            'ad_start_day' => $ad_data['ad_start_day'],
            'ad_content' => $ad_data['ad_content'],
            'ad_type' => $ad_data['ad_type'] ? json_encode($ad_data['ad_type'],JSON_UNESCAPED_UNICODE) : '',
            'agent' => $ad_data['agent'],
            'ad_url_flag' => $ad_data['ad_url_flag'],
            'ad_url_text' => $ad_data['ad_url_text'], // 广告链接词
            'ad_url' => $ad_data['ad_url'],
            'worker' => $ad_data['worker'],
            'produce_day' => $ad_data['produce_day'],
            'mtime' => datetime(),
            'mender' => $this->_manager_id,
            'agents' => $agents,
            '_form_token_' => $ad_data['_form_token_'],
        ];
       return $up_data;
    }

    //获取广告和工单信息
    public function getAdByWsId() {
        $ws_id = I('ws_id');
        if (empty($ws_id)) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO, '请输入工单号',[]);
            return;
        }
        /** @var CSWorkSheetModel $ws_model */
        $ws_model = D('Basic/CSWorkSheet', 'Model');
        $ws = $ws_model->getById($ws_id);
        if (empty($ws))  {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO, '工单号不存在',[]);
            return;
        }

        if ($ws['status'] != 'finish') {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO, '请先完成工单操作',[]);
            return;
        }
        /** @var \Basic\Service\AdvertiseService $ad_service */
        $ad_service = D('Basic/Advertise', 'Service');
        $ad = $ad_service->getAdByWsId($ws_id);
        $ad['status'] = 'new';
        if ($ad) {
//            $ad['attachment'] = $this->_getImagePreview($ad['attachment'],$ad['ad_id']);
        } else {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO, '广告单号不存在此工单',[]);
            cmm_log($ws_id.'广告单号不存在此工单');
            return;
        }
        $this->_formatAd($ad);
        $this->doResponse(ERRNO::SUCCESS,ERRNO::e(ERRNO::SUCCESS),$ad);
    }

    protected function _formatAd(&$ad) {
        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');
        $format_manager_list = $manager_service->getFormatManger();
        $ad['ad_id'] = $ad['id'];
        $ad['referer_name'] = !empty($ad['referer']) ? $format_manager_list[$ad['referer']] : '';
        $ad['creator_name'] = !empty($ad['creator']) ? $format_manager_list[$ad['creator']] : '';
        $ad['worker_name'] = !empty($ad['worker']) ? $format_manager_list[$ad['worker']] : '';
    }


    /**
     * @param $now_status
     *获取下一状态
     */
    public function _getNewStatus($now_status) {
        switch($now_status) {
            case ADVERTISE::AD_STATUS_NEW :
                $next_status = ADVERTISE::AD_STATUS_DOING;
                break;
            case ADVERTISE::AD_STATUS_DOING :
                $next_status = ADVERTISE::AD_STATUS_WAIT;
                break;
            case ADVERTISE::AD_STATUS_WAIT:
                $next_status = ADVERTISE::AD_STATUS_PUBLISH;
                break;
            default:
                $next_status = $now_status;
                break;
        }
        return $next_status;
    }

    /*
     * 广告操作
     */
    public function adOP(){
        $ad_id = I('ad_id',0,'int');
        $op_type = I('op_type');
        if (empty($ad_id)) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO,ERRNO::e(ERRNO::INPUT_PARAM_ERRNO),[]);
            return;
        }
        /** @var \Basic\Service\AdvertiseService $ad_service */
        $ad_service = D('Basic/Advertise','Service');
        $ad = $ad_service->getAdById($ad_id);

        switch($op_type) {
            case 'point_worker':
                $worker = I('worker',0,'int');
                if (empty($worker)) {
                    $this->doResponse(ERRNO::INPUT_PARAM_ERRNO,ERRNO::e(ERRNO::INPUT_PARAM_ERRNO),[]);
                    return;
                }
                $up_data = [
                    'status' => 'doing',
                    'worker' => $worker,
                ];
                $desc = '指派制作人';
                break;
            case 'publish':
                if ($ad['status'] != ADVERTISE::AD_STATUS_PUBLISH && $ad['status'] != ADVERTISE::AD_STATUS_PAUSE) {
                    $this->doResponse(ERRNO::OP_NOT_ALLOW,ERRNO::e(ERRNO::OP_NOT_ALLOW),[]);
                    return;
                }
                $up_data = [
                    'status' => ADVERTISE::AD_STATUS_PUBLISHING,
                ];

                if ($ad['ad_start_day_real'] < 1) {
                    $up_data['ad_start_day_real'] = date('Y-m-d',strtotime("+1 days"));
                }

                if($ad['ad_end_day']<1) {
                    $days = $ad['days'];
                    $ad_end_day = date('Y-m-d', strtotime("+{$days['year']} year {$days['month']} month 
                    {$days['day']} days"));
                    $up_data['ad_end_day'] = $ad_end_day;
                }
                $desc = '发布广告';
                break;
            case 'pause':
                if ($ad['status'] != ADVERTISE::AD_STATUS_PUBLISHING) {
                    $this->doResponse(ERRNO::OP_NOT_ALLOW,ERRNO::e(ERRNO::OP_NOT_ALLOW),[]);
                    return;
                }
                $up_data = [
                    'status' => ADVERTISE::AD_STATUS_PAUSE,
                ];
                $desc = '暂停发布';
                break;
            default:
                break;
        }
        $up_data['mender'] = $this->_manager_id;
        list($errno, $errmsg,$data) = $ad_service->updateAdById($ad_id,$up_data);
        $this->doResponse($errno,$errmsg,[]);
        fastcgi_finish_request();
        $log_data = [
            'manager_id' => $this->_manager_id,
            'object_id'     => $ad_id,
            'action'        => 'update',
            'desc'          => $desc,
        ];
        $ad_service->addOperLog($log_data);
        return;
    }

    /**
     * 修改广告到期时间
     */
    public function editAdStartEnd() {
        $ad_id = I('ad_id');
        $user_id = I('user_id');
        if (empty($ad_id)) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO,'没有关联的广告单号',[]);
            return;
        }

        $ad_start_day_real = I('ad_start_day_real');
        $ad_end_day = I('ad_end_day');
        if (empty($ad_start_day_real) || empty($ad_end_day)) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO,'请填写广告结束和开始时间',[]);
            return;
        }
        if ($ad_start_day_real > $ad_end_day) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO,'广告结束日期必须大于开始日期',[]);
            return;
        }
        if($ad_end_day < date('Y-m-d')) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO,'广告结束日期必须大于当前日期',[]);
            return;
        }
        /** @var \Basic\Service\AdvertiseService $ad_service */
        $ad_service = D('Basic/Advertise','Service');
        $ad = $ad_service->getAdById($ad_id);
        $up_data = [
            'ad_start_day_real' => $ad_start_day_real,
            'ad_end_day' => $ad_end_day
        ];
        $old_time = $ad['ad_start_day_real'] ? $ad['ad_start_day_real'].'至'
            .$ad['ad_end_day'] : '空';
        $desc = $ad_start_day_real ? '更改有效期,旧值为:'.$old_time.',新值为:'.$ad_start_day_real.'至'.$ad_end_day : '';
        /** @var \Basic\Service\AdvertiseService $ad_service */
        $ad_service = D('Basic/Advertise','Service');
        list($errno, $errmsg,$data) = $ad_service->updateAdById($ad_id,$up_data);
        $this->doResponse($errno,$errmsg,[]);
        fastcgi_finish_request();
        if ($errno== ERRNO::SUCCESS) {
            $log_info = [
                'c_manager_id'    => $this->_manager_id,
                'type'     => 'ad',
                'content' => $desc,
                'user_id'        => $user_id,
                'desc'          => $desc,
            ];
            /** @var ProductStatusLogModel $product_status_log_m */
            $product_status_log_m = D('Admin/ProductStatusLog','Model');
            $product_status_log_m->addLog($log_info);
//            $oper_info = [
//                'manager_id'    => $this->_manager_id,
//                'object_id'     => $ad_id,
//                'action'        => 'update',
//                'desc'          => '修改广告有效期为开始时间'.$ad_start_day_real.'结束时间'.$ad_end_day,
//            ];
//            $ad_service->addOperLog($oper_info);
        }
    }
    public function ajaxUploadImage() {
        $key = key($_FILES);
        if ( empty($_FILES[$key]) || $_FILES[$key]['size'] == 0 ) {
            die("{}");
        }

        $root_dir = C('IMAGE_PATH')['certificate'];
        $sub_dir = day();
        $image_info = array();
        list($errcode, $errmsg) = uploadImage($key, $root_dir, $sub_dir, $image_info, 'certificate');
        if ( $errcode != ERRNO::SUCCESS ) {
            echo json_encode(['error' => $errmsg]);
            exit;
        }

        $res = [
            'initialPreview' => [ imageUrl($image_info) ],
            'initialPreviewConfig' => [
                [
                    'type'      => 'image',
                    'caption'   => $image_info['name'],
                    'size'      => $_FILES[$key]['size'],
                    'url'       => '/Advertise/ajaxDeleteImage',
                    'key'       => null,
                    'extra'     => null,
                ],
            ]
        ];

        $id = I('id/d', 0);
        if ( !$id ) { // 新增记录
            $field = I('field');
            $upload_key = I('upload_key');
            if ( !$field || !$upload_key ) {
                die(json_encode(['error' => '参数 field 和 upload_key 不能为空！']));
            }

            // 从缓存中获取临时保存的上传图片信息
            $image_arr = S($upload_key);
            if ( !$image_arr ) {
                $image_arr = [$image_info];
            } else {
                $image_arr[] = $image_info;
            }

            // 更新缓存
            S($upload_key, $image_arr, 1800);

            $res['initialPreviewConfig'][0]['key'] = count($image_arr) - 1;
            $res['initialPreviewConfig'][0]['extra'] = ['field' => $field, 'upload_key' => $upload_key];

        } else { // 编辑记录
            $field = I('field');
            /** @var \Basic\Service\AdvertiseService $ad_service */
            $ad_service = D('Basic/Advertise','Service');
            $ad = $ad_service->getAdById($id);
            if ( !$ad ) {
                $this->admin_error('广告不存在！');
                return;
            }
            $attachment = $ad['attachment'] ?  : [];

            $attachment[] = $image_info;
            $res['initialPreviewConfig'][0]['key'] = count($attachment) - 1;
            $res['initialPreviewConfig'][0]['extra'] = ['field' => $field, 'id' => $id];
            // 更新数据记录
            $ad_service->updateAdById($id, ['attachment' => json_encode($attachment),JSON_UNESCAPED_UNICODE]);
        }

        echo json_encode($res);
        return;
    }

    public function ajaxDeleteImage() {
        echo '{}';die;
        $id = I('id/d', 0);
        if ( !$id ) { // 新增记录
            $field = I('field');
            $upload_key = I('upload_key');
            if ( !$field || !$upload_key ) {
                die(json_encode(['error' => '参数 field 和 upload_key 不能为空！']));
            }

            // 从缓存中获取临时保存的上传图片信息
            $image_arr = S($upload_key);
            if ( !$image_arr ) {
                die('{}');
            }

            // 从记录中删除图片
            $key = I('key/d', 0);
            unset($image_arr[$key]);

            // 更新缓存
            S($upload_key, $image_arr, 1800);

        } else { // 编辑记录
            /** @var \Basic\Service\AdvertiseService $ad_service */
            $ad_service = D('Basic/Advertise','Service');
            $ad = $ad_service->getAdById($id);
            if ( !$ad ) {
                die(json_encode(['error' => '广告不存在！']));
            }
            $attachment = $ad['attachment'] ? json_decode($ad['attachment'], JSON_UNESCAPED_UNICODE) :[];
            // 从记录中删除图片
            $key = I('key/d', 0);
            unset($attachment[$key]);
            // 更新记录
            // 更新记录
            $ad_service->updateAdById($id, ['attachment' => json_encode($attachment)]);
        }

        echo '{}';
    }
    /**
     * 打包下载工单图片
     */
    public function downWsPic() {
        $ws_id = I('ws_id');
        if (empty($ws_id)) {
            $this->admin_error('工单号不存在');
            return;
        }
        /** @var CSWorkSheetModel $ws_model */
        $ws_model = D('Basic/CSWorkSheet');
        $ws = $ws_model->getById($ws_id);
        $ad_pics = json_decode($ws['ad_pics'],JSON_UNESCAPED_UNICODE);
        if(empty($ad_pics)) {
            $this->admin_error('工单无图片信息');
            return;
        }
        $files = [];
        $root_dir = C('IMAGE_PATH');
        foreach($ad_pics as $v) {
            $path = $root_dir[$v['type']];
            $files[] = $path.'/'.$v['path'].'/'.$v['name'];
        }
        zip_file($files);
    }
    public function test() {
        $files = [
            '/local/storage/twpt_test/certficate/2017-10-23/certificate_59edd7783dca4.jpeg',
        ];
        zip_file($files);
    }

}