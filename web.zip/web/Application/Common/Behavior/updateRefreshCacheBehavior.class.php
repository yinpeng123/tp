<?php
namespace Common\Behavior;

use Think\Behavior;
use Think\Log;

class updateRefreshCacheBehavior extends Behavior
{
    // 行为扩展的执行入口必须是run
    public function run(&$params)
    {
        // 进行黑名单过滤
        $req_method = $_SERVER['REQUEST_METHOD'];
        $rncb = C('REFRESH_NOT_CACHE_BLACK_LIST');

        if ($rncb[MODULE_NAME] != null
            && $rncb[MODULE_NAME][CONTROLLER_NAME] != null
            && $rncb[MODULE_NAME][CONTROLLER_NAME][ACTION_NAME] != null
            && $rncb[MODULE_NAME][CONTROLLER_NAME][ACTION_NAME][$req_method] != null) {
            foreach ($rncb[MODULE_NAME][CONTROLLER_NAME][ACTION_NAME][$req_method] as $k=>$v) {
                $req = json_decode(html_entity_decode(I("req", "", "htmlspecialchars")), true);
                if ($req[$k] === $v) {
                    return;
                }
            }
        }

        $ott['expire'] = C('REFRESH_MEMCACHE_EXPIRE_TIME');
//        $val = ob_get_contents();
        $_REQUEST['request_id'] = !empty($_REQUEST['request_id']) ? $_REQUEST['request_id'] : '';
        $val = S($_REQUEST['request_id']);
        $valSize = ob_get_length();
        if ($valSize > C('REFRESH_MEMCACHE_MAX_SIZE')) {
//            $log_content = [
//                round(microtime($get_as_float = true) - I('server.REQUEST_TIME_FLOAT'), 4),
//                'uid=' . session('ucmm_uid'),
//                'pid=' . session('ucmm_pid'),
//                I('server.REMOTE_ADDR'),
//                str_replace(' ', '', I('server.HTTP_X_FORWARDED_FOR')),
//                I('server.PATH_INFO'),
//                'post=' . json_encode(I('post.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
//                'get=' . json_encode(I('get.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
//                'refer=' . I('server.HTTP_REFERER'),
//                'ua=\'' . I('server.HTTP_USER_AGENT') . '\'',
//                'sid=' . session_id(),
//                'message=业务程序处理生成数据超过' . C('REFRESH_MEMCACHE_MAX_SIZE'),
//            ];
//            Log::write(implode(' ', $log_content), 'PREVENT_REFRESH');
            cmm_log('业务程序处理生成数据超过' . C('REFRESH_MEMCACHE_MAX_SIZE'), 'PREVENT_REFRESH');
            // clear cache
            S($_REQUEST['request_id'], null);

            return;
        }

        // cached
        S($_REQUEST['request_id'], $val, $ott);
    }
}

?>
