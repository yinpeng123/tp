<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Basic\Cnsts\AGENT_CHARGE;
use Admin\Service\PageService;
use Basic\Cnsts\DICT;
use Basic\Model\AgentModel;
use Basic\Service\AgentChargeService;
use Basic\Service\AgentService;

class AgentChargeController extends AdminSessionController
{

    private $__agent_charge_model = null;
    private $__agent_charge_log_model = null;
    private $__agent_model = null;

    public function __construct()
    {
        parent::__construct();

        $this->__agent_charge_model     = D('Basic/AgentCharge');
        $this->__agent_charge_log_model = D('Basic/AgentChargeLog');
        $this->__agent_model            = D('Basic/Agent');

        // 权限检查
        if (!\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id,
            \Admin\Cnsts\PRIVILEGE::AGENT_CHARGE)
        ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }
    }

    /**
     * 获取返回列表的链接
     *
     * @param $refer
     */
    protected function _backToListUrl($refer)
    {
        if (!empty($refer) && 0 === stripos($refer, U('agentCharge/index', '', '', true))) {
            return $refer;
        } else {
            return U('agentCharge/index', '', '', true);
        }
    }

    /**
     * 列表页
     */
    public function index()
    {
//        p(session('manager'));die;
        //获取计费类型
        $charge_type_arr   = $this->getChargeType();
        $bonus_status_arr  = $this->getBonusStatus();
        $paying_status_arr = $this->getPayingStatus();
        $status_arr        = $this->getStatus();

        /** @var AgentService $agent_service */
        $agent_service = D('Basic/Agent', 'Service');
        $agent_list = $agent_service->getFormatAgent();
//        p($agentList);

        $product         = I('product');
        $has_bonus       = I('has_bonus');
        $paying          = I('paying');
        $status          = I('status');
        $code            = I('code');
        $usage           = I('usage');
        $chargeType      = I('chargeType');


        if (!empty($chargeType)) {
            $cond['product_id'] = ['eq', $chargeType];
        }
        if(session('manager')['agent_id'] == 0){
            $search_agent_id = I('search_agent_id');
            if (!empty($search_agent_id)) {
                $cond['agent_id'] = ['eq', $search_agent_id];
            }
        } else {
            $cond['agent_id'] = ['eq', session('manager')['agent_id']];
        }

        //搜索条件优化
        if (!empty($usage)) {
            if ($usage == 'new_ad') {
                $cond['ad_usage']   = ['eq', 'new'];
                $cond['product_id'] = ['eq', 33];
            } elseif ($usage == 'renew_ad') {
                $cond['ad_usage']   = ['eq', 'renew'];
                $cond['product_id'] = ['eq', 33];
            } else {
                $cond['usage'] = ['eq', $usage];
            }
        }
        if (!empty($code)) {
            $cond['id'] = ['eq', $code];
        }
        if (!empty($product)) {
            $cond['product_id'] = ['eq', $product];
        }
        if (!empty($has_bonus)) {
            $cond['has_bonus'] = ['eq', $has_bonus];
        }
        if (!empty($paying)) {
            $cond['paying'] = ['eq', $paying];
        }
        if (!empty($status)) {
            $cond['status'] = ['eq', $status];
        }

        //分页
        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        $ret       = $this->__agent_charge_model->searchAgentChargeList($cond, $curr_page, $per_page);
//p($ret['data']);
        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();

        //关联渠道名称
        for ($i = 0; $i < count($ret['data']); $i++) {
            $agentInfo                     = $this->__agent_model->getAgentById($ret['data'][$i]['agent_id']);
            $ret['data'][$i]['agent_name'] = $agentInfo['name'];
        }
        for ($i = 0; $i < count($ret['data']); $i++) {
            $days = json_decode($ret['data'][$i]['days'], true);
            $year = $days['year'] . "年";
            if ($days['year'] == 0) {
                unset($year);
            }
            $month = $days['month'] . "月";
            if ($days['month'] == 0) {
                unset($month);
            }
            $day = $days['day'] . "天";
            if ($days['day'] == 0) {
                unset($day);
            }
            $ret['data'][$i]['times'] = $year . $month . $day;
        }
//        p($ret['data']);
        $agent_info = $this->__agent_model->getAgentById(session('manager')['agent_id']);

        $this->assignAll([
            'search_agent_id_owner' => session('manager')['agent_id'],
            'search_agent_id_name' => $agent_info['name'],
            'list'              => $ret['data'],
            'product'           => $product,
            'hsa_bonus'         => $has_bonus,
            'paying'            => $paying,
            'status'            => $status,
            'code'              => $code,
            'usage'             => $usage,
            'search_agent_id'   => $search_agent_id,
            'chargeType'        => $chargeType,
            'charge_type_arr'   => $charge_type_arr,
            'bonus_status_arr'  => $bonus_status_arr,
            'paying_status_arr' => $paying_status_arr,
            'status_arr'        => $status_arr,
            'page_nav'          => $page_nav,
            'agent_list'        => $agent_list,
            'manager_id' => $this->_manager_id,
        ]);
        $this->display('agent_charge_list');
    }

    /**
     * 添加计费套餐
     */
    public function add()
    {
        $data = I('');
//p($data);
        // 渠道商列表
        /** @var AgentModel $agent_model */
        $agent_model = D('Basic/Agent', 'Model');
        $agent_list  = $agent_model->getAllAgentList('id,name');
        //print_r($agent_list);exit;

        if(session('manager')['agent_id'] == 0) {
            $this->assign('agent_list', $agent_list);
        } else {
            $agent = $agent_model->getAgentById(session('manager')['agent_id']);
            $this->assign('agent_text', $agent['name']);
        }

            $this->assign('account_agent_id', session('manager')['agent_id']);

        //动态获取渠道对应的产品
        /** @var AgentChargeService $agent_charge_service */
        $agent_charge_service = D('Basic/AgentCharge', 'Service');
        if(empty($data['agent_id'])) {
            $search_agent_id = session('manager')['agent_id'];
        } else {
            $search_agent_id = $data['agent_id'];
        }
        $product_list         = $agent_charge_service->getAgentPrimeProductList($search_agent_id);
//        p($product_list);die;
//        // 一级产品列表, 排除保险
//        $product_model = D('Basic/Product');
//        $product_list = $product_model->getProductListByWhere("pid=0 AND name<>'保险'");
////        p($product_list);
        $this->assign('product_list', $product_list);

        $paying = I('paying/d');
        if (empty($paying)) {
            $paying = 1;
        }

        if ($paying == 1) { // 应收
            $this->__addPaying_1();

            return;
        } else { // 应付
            $this->__addPaying_2();

            return;
        }
    }

    /**
     * 编辑计费套餐
     */
    public function edit()
    {
        $data = I('');
        // 渠道商列表
        $agent_model = D('Basic/Agent', 'Model');
        $agent_list  = $agent_model->getAllAgentList('id,name');
        $this->assign('agent_list', $agent_list);

        $paying = I('paying/d');
        $charge = $this->__agent_charge_model->getAgentChargeInfo($data[0]);
        if (empty($paying)) {
            $charge_paying = $charge['paying'];
        } else {
            $charge_paying = $paying;
        }
        $days = json_decode($charge['days'], true);

        // 提交成功后跳转的地址（回到带有搜索条件的页面，如果有的话）
        $this->assign('back_search_url', $this->_refer);
        if ($charge_paying == 1) {// 应收
            $this->assignAll([
                'year'  => $days['year'],
                'month' => $days['month'],
                'day'   => $days['day'],

            ]);
            $this->assign('charge', $charge);
            $this->assign('agent_id', $charge['agent_id']);
            $this->assign('product_id', $charge['product_id']);
            $this->__addPaying_1($data['act'], $data[0], $data['copy']);

            return;
        } else { // 应付
            $this->__addPaying_2($data['act'], $data[0], $data['copy']);

            return;
        }
    }

    public function include_content_file($charge)
    {
        $product_id = I('product_id/d');
        if (empty($product_id)) {
            $product_id = $charge['product_id'];
        }
        if ($product_id == 1) { // app
            $this->display('include_app_1');
        } elseif ($product_id == 33) { // 广告
            $this->display('include_advertise_1');
        } elseif ($product_id == 32) { // 三证
            $this->display('include_certs_1');
        } else { // pc
            $this->display('include_pc_1');
        }
    }

    // 添加"应收"类型的计费套餐
    private function __addPaying_1($act = null, $id = null, $copy = null)
    {
        $status     = I('status/d', 2);
        $product_id = I('product_id/d');
        $paying     = I('paying/d', 1);
//p($product_id);
        if (empty($usage)) {
            $usage = 'new';
        }
        $charge = [
            'id'         => $id,
            'paying'     => $paying,
            'product_id' => $product_id,
            'status'     => $status,
            'usage'      => $usage,
        ];
//p($copy);die;
        if ($act === 'edit') {

            if ($copy != 1) {
                $title = '编辑计费';
            } else {
                $title = '复制计费';
            }
            $action = 'edit';
            $charge = $this->__agent_charge_model->getAgentChargeInfo($id);
//            p($charge);die;

            if ($product_id == 0) {
                $edit_product = $charge['product_id'];
            } else {
                $edit_product = $product_id;
            }

            if (!empty($paying)) {
                $edit_paying = $paying;
            } else {
                $edit_paying = $charge['paying'];
            }

            $agent_id = I('agent_id');
            if (empty($agent_id)) {
                $agent_ids = $charge['agent_id'];
                $agent     = $charge['agent_id'];
            } else {
                $agent_ids = $agent_id;
                $agent     = $agent_id;
            }
            //动态获取渠道对应的产品
            /** @var AgentChargeService $agent_charge_service */
            $agent_charge_service = D('Basic/AgentCharge', 'Service');
            $product_list         = $agent_charge_service->getAgentPrimeProductList($agent);

            $this->assign('agent_id', $agent_ids);
            $this->assign('copy', $copy);
            $this->assign('product_list', $product_list);
            $this->assign('edit_paying', $edit_paying);
            $this->assign('edit_product', $edit_product);
            $this->assign('charge', $charge);
        } else {
            $agent_id  = I('agent_id');
            $agentInfo = $this->__agent_model->getAgentById($agent_id);
            $this->assignAll([
                'agent_name' => $agentInfo['name'],
                'agent_id'   => $agent_id,
                'act'        => 'add',
            ]);
            $title  = '添加计费';
            $action = 'add';
        }

        if ($act === 'edit') {
            //操作记录
            $logList = $this->__agent_charge_log_model->getAgentChargeListById($id);
            $this->assign('agent_charge_log_list', $logList);
        }
//        p($this->_refer);die;
        $this->assignAll([
            'act'              => $action,
            'form_action'      => '/agentCharge/doEdit',
            'title'            => $title,
            'charge'           => $charge,
            'ad_category_arr'  => AGENT_CHARGE::AD_CATEGORY_ARR,
            'ad_pos_arr'       => AGENT_CHARGE::AD_POS_ARR,
            'ad_fee_arr'       => AGENT_CHARGE::AD_FEE_ARR,
            'back_to_list_url' => $this->_backToListUrl($this->_refer),
        ]);
        $this->display('agent_charge_info_1');
    }

    // 添加"应付"类型的计费套餐
    private function __addPaying_2($act = null, $id = null, $copy = null)
    {
        $status     = I('status/d', 1);
        $product_id = I('product_id/d', 1);
        $paying     = I('paying');

        if (empty($usage)) {
            $usage = 'new';
        }
        $charge = [
            'id'         => $id,
            'paying'     => 2,
            'product_id' => $product_id,
            'status'     => $status,
            'usage'      => $usage,
        ];
//p($copy);die;
        if ($act === 'edit') {

            if ($copy != 1) {
                $title = '编辑计费';
            } else {
                $title = '复制计费';
            }
            $action = 'edit';

            $charge = $this->__agent_charge_model->getAgentChargeInfo($id);
            if (!empty($product_id) && !empty($paying)) {
                $edit_paying  = $paying;
                $edit_product = $product_id;
            } else {
                $edit_paying  = $charge['paying'];
                $edit_product = $charge['product_id'];
            }

            $agent_id = I('agent_id');
            if (empty($agent_id)) {
                $agent_ids = $charge['agent_id'];
                $agent     = $charge['agent_id'];
            } else {
                $agent_ids = $agent_id;
                $agent     = $agent_id;
            }
            //动态获取渠道对应的产品
            /** @var AgentChargeService $agent_charge_service */
            $agent_charge_service = D('Basic/AgentCharge', 'Service');
            $product_list         = $agent_charge_service->getAgentPrimeProductList($agent);

            $this->assign('agent_id', $agent_ids);
            $this->assign('copy', $copy);
            $this->assign('product_list', $product_list);
            $this->assign('edit_paying', $edit_paying);
            $this->assign('edit_product', $edit_product);
            $this->assign('charge', $charge);
        } else {
            $agent_id  = I('agent_id');
            $agentInfo = $this->__agent_model->getAgentById($agent_id);
            $this->assignAll([
                'agent_name' => $agentInfo['name'],
                'agent_id'   => $agent_id,
            ]);
            $title  = '添加计费';
            $action = 'add';
        }

        //操作记录
        $logList = $this->__agent_charge_log_model->getAgentChargeListById($id);

        $this->assignAll([
            'act'                   => $action,
            'form_action'           => '/agentCharge/doEdit',
            'title'                 => $title,
            'charge'                => $charge,
            'agent_charge_log_list' => $logList,
            'ad_category_arr'       => AGENT_CHARGE::AD_CATEGORY_ARR,
            'ad_pos_arr'            => AGENT_CHARGE::AD_POS_ARR,
            'back_to_list_url'      => $this->_backToListUrl($this->_refer),
        ]);
        $this->display('agent_charge_info_2');
    }


    // 执行编辑、添加操作
    public function doEdit()
    {
        $data = I('');
//        p($data);die;
        if ($data['copy'] == 1) {
            $data['act'] = 'add';
        }

        if ($data['act'] == 'add') {
            if ($data['paying'] == 1 || $data['edit_paying'] == 1) { // 应收
                $this->__doEditPaying_1();

                return;
            } else { // 应付
                $this->__doEditPaying_2();

                return;
            }
        } else {
            if ($data['edit_paying'] == 1) { // 应收
                $this->__doEditPaying_1();

                return;
            } else { // 应付
                $this->__doEditPaying_2();

                return;
            }
        }
    }

    // 执行编辑、添加"应收"操作
    private function __doEditPaying_1()
    {
        $product_id = I('product_id/d', 1);
        if ($product_id == 33) { // 广告
            $this->__doEditPaying_1_advertise();
        } elseif ($product_id == 32) { // 三证
            $this->__doEditPaying_1_certs();
        } else { // app/pc
            $this->__doEditPaying_1_pc();
        }
    }

    // PC信息、APP信息
    private function __doEditPaying_1_pc()
    {
//        p($_POST);die;
        $_manager = session('manager');
        $data     = I('');
        if (empty($data['status'])) {
            $data['status'] = 1;
        }
        $days   = [
            'year'  => (int)$data['year'],
            'month' => (int)$data['month'],
            'day'   => (int)$data['day'],
        ];
        $fields = [
            'agent_id'   => $data['agent_id'],
            'status'     => $data['status'],
            'product_id' => $data['product_id'],
            'usage'      => $data['usage'],
            'name'       => $data['name'],
            'has_bonus'  => 0,
            'add_days'   => 0,
            'price'      => $data['price'],
            'days'       => json_encode($days),
        ];
        if ($data['copy'] == 1) {
            $data['act'] = 'add';
        }
        if ($data['act'] === 'edit') {
            $fields['mtime']  = date("Y-m-d H:i:s");
            $ac_id            = $data['id'];
            $fields['paying'] = $data['edit_paying'];
            $this->__agent_charge_model->updateAgentCharge($data['id'], $fields);
        } else {
            if ($data['copy'] != 1) {
                $fields['ctime']  = date("Y-m-d H:i:s");
                $fields['paying'] = $data['paying'];
            } else {
                $fields['ctime']  = date("Y-m-d H:i:s");
                $fields['paying'] = $data['edit_paying'];
            }

            $ac_id = $this->__agent_charge_model->addAgentCharge($fields);
        }

        //同步添加记录信息
        if ($data['act'] === 'add') {
            $action = '新建';
            $desc   = '新增计费信息成功！';
        } else {
            $action = '修改';
            $desc   = '编辑计费信息成功！';
        }

        // 产品功能列表
        $product_model = D('Basic/Product');
        $product_list  = $product_model->getProductList();
        $list          = [];
        foreach ($product_list as $v) {
            $list[$v['id']] = $v['name'];
        }

        if ($data['usage'] == 'new') {
            $chargeContent = '入网';
        } else {
            $chargeContent = '续费';
        }

        $logData = [
            'ac_id'   => $ac_id,
            'mender'  => $_manager['manager_id'],
            'content' => "【" . $action . "】" . $list[$data['product_id']] . $chargeContent . "：" . $data['name'] . "。" . "操作人：" . $_manager['username'],
            'ctime'   => date("Y-m-d H:i:s"),
        ];
        $this->__agent_charge_log_model->addAgentChargeLog($logData);
        $url = I('back_search_url', '', 'url');
        redirect(U('agentCharge/index/'));
    }

    // 广告
    private function __doEditPaying_1_advertise()
    {
//        p(I(''));die;
        $_manager = session('manager');
        $data     = I('');
        if (empty($data['status'])) {
            $data['status'] = 1;
        }
        $days   = [
            'year'  => (int)$data['year'],
            'month' => (int)$data['month'],
            'day'   => (int)$data['day'],
        ];
        $fields = [
            'agent_id'    => $data['agent_id'],
            'status'      => $data['status'],
            'product_id'  => $data['product_id'],
            'ad_category' => $data['ad_category'],
            'ad_usage'    => $data['ad_usage'],
            'name'        => $data['name'],
            'has_bonus'   => 0,
            'add_days'    => 0,
            'ad_fee'      => $data['ad_fee'],
            'price'       => $data['price'],
            'days'        => json_encode($days),
        ];

        if ($data['act'] === 'edit') {
            $fields['mtime'] = date("Y-m-d H:i:s");
        } else {
            $fields['ctime'] = date("Y-m-d H:i:s");
        }

        if ($data['copy'] == 1) {
            $data['act'] = 'add';
        }
        if ($data['act'] === 'edit') {
            $fields['paying'] = $data['edit_paying'];
            $this->__agent_charge_model->updateAgentCharge($data['id'], $fields);
            $ac_id = $data['id'];
        } else {
            if ($data['copy'] != 1) {
                $fields['paying'] = $data['paying'];
            } else {
                $fields['paying'] = $data['edit_paying'];
            }
            $ac_id = $this->__agent_charge_model->addAgentCharge($fields);

        }

        //同步添加记录信息
        if ($data['act'] === 'add') {
            $action = '新建';
            $desc   = '新增计费信息成功！';
        } else {
            $action = '修改';
            $desc   = '编辑计费信息成功！';
        }

        // 产品功能列表
        $product_model = D('Basic/Product');
        $product_list  = $product_model->getProductList();
        $list          = [];
        foreach ($product_list as $v) {
            $list[$v['id']] = $v['name'];
        }

        if ($data['ad_usage'] == 'new') {
            $chargeContent = '新广告';
        } else {
            $chargeContent = '续费广告';
        }

        $logData = [
            'ac_id'   => $ac_id,
            'mender'  => $_manager['manager_id'],
            'content' => "【" . $action . "】" . $list[$data['product_id']] . $chargeContent . "：" . $data['name'] . "。" . "操作人：" . $_manager['username'],
            'ctime'   => date("Y-m-d H:i:s"),
        ];
        $this->__agent_charge_log_model->addAgentChargeLog($logData);

        $url = I('back_search_url', '', 'url');
        redirect(U('agentCharge/index/'));
    }

    // 三证
    private function __doEditPaying_1_certs()
    {
//        p($_POST);die;
        $_manager = session('manager');
        $data     = I('');
//        p($data);die;
        if (empty($data['status'])) {
            $data['status'] = 1;
        }
        $days   = [
            'year'  => (int)$data['year'],
            'month' => (int)$data['month'],
            'day'   => (int)$data['day'],
        ];
        $fields = [
            'agent_id'         => $data['agent_id'],
            'status'           => $data['status'],
            'product_id'       => $data['product_id'],
            'certs_price_ok'   => $data['certs_price_ok'],
            'certs_price_fail' => $data['certs_price_fail'],
            'price'            => $data['price'],
            'days'             => json_encode($days),
        ];

        if ($data['copy'] == 1) {
            $data['act'] = 'add';
        }
        if ($data['act'] === 'edit') {
            $fields['mtime'] = date("Y-m-d H:i:s");
        } else {
            $fields['ctime'] = date("Y-m-d H:i:s");
        }

        if ($data['act'] === 'edit') {
            $fields['paying'] = $data['edit_paying'];
            $this->__agent_charge_model->updateAgentCharge($data['id'], $fields);
            $ac_id = $data['id'];
        } else {
            if ($data['copy'] != 1) {
                $fields['paying'] = $data['paying'];
            } else {
                $fields['paying'] = $data['edit_paying'];
            }

            $ac_id = $this->__agent_charge_model->addAgentCharge($fields);
        }

        //同步添加记录信息
        if ($data['act'] === 'add') {
            $action = '新建';
            $desc   = '新增计费信息成功！';
        } else {
            $action = '修改';
            $desc   = '编辑计费信息成功！';
        }

        // 产品功能列表
        $product_model = D('Basic/Product');
        $product_list  = $product_model->getProductList();
        $list          = [];
        foreach ($product_list as $v) {
            $list[$v['id']] = $v['name'];
        }

        $logData = [
            'ac_id'   => $ac_id,
            'mender'  => $_manager['manager_id'],
            'content' => "【" . $action . "】" . $list[$data['product_id']] . "：" . $data['name'] . "。" . "操作人：" . $_manager['username'],
            'ctime'   => date("Y-m-d H:i:s"),
        ];
        $this->__agent_charge_log_model->addAgentChargeLog($logData);

        $url = I('back_search_url', '', 'url');
        redirect(U('agentCharge/index/'));
    }


    // 执行编辑、添加"应付"操作
    private function __doEditPaying_2()
    {
        $_manager = session('manager');
        $data     = I('');
//        p($data);die;
        $fields = [
            'agent_id'      => $data['agent_id'],
            'paying'        => 2,
            'status'        => $data['status'],
            'product_id'    => $data['product_id'],
            'name'          => $data['name'],
            'price'         => $data['price'],
            'bank_name'     => $data['bank_name'],
            'bank_passport' => $data['bank_passport'],
            'bank_username' => $data['bank_username'],
            'creator'       => $_manager['manager_id'],
        ];

        if ($data['product_id'] == '1' || $data['product_id'] == '24') {
            $fields['usage'] = $data['usage'];
        } else {
            $fields['usage'] = '';
        }

        if ($data['product_id'] == '33') {
            $fields['ad_category'] = $data['ad_category'];
        } else {
            $fields['ad_category'] = '';
        }

//        if($data['product_id'] == '32') {
//            $fields = [];
//        }
//p($fields);die;
        if ($data['copy'] == 1) {
            $data['act'] = 'add';
        }
        if ($data['act'] === 'edit') {
            $fields['mtime'] = date("Y-m-d H:i:s");
        } else {
            $fields['ctime'] = date("Y-m-d H:i:s");
        }
//        p($fields);die;
        if ($data['act'] === 'edit') {
            $this->__agent_charge_model->updateAgentCharge($data['id'], $fields);
            $ac_id = $data['id'];
        } else {
            $ac_id = $this->__agent_charge_model->addAgentCharge($fields);
        }

        //同步添加记录信息
        if ($data['act'] === 'add') {
            $action = '新建';
            $desc   = '新增计费信息成功！';
        } else {
            $action = '修改';
            $desc   = '编辑计费信息成功！';
        }

        // 产品功能列表
        $product_model = D('Basic/Product');
        $product_list  = $product_model->getProductList();
        $list          = [];
        foreach ($product_list as $v) {
            $list[$v['id']] = $v['name'];
        }

        if ($data['usage'] === 'new') {
            $chargeContent = '入网';
        } else {
            $chargeContent = '续费';
        }

        $logData = [
            'ac_id'   => $ac_id,
            'mender'  => $_manager['manager_id'],
            'content' => "【" . $action . "】" . $list[$data['product_id']] . $chargeContent . "：" . $data['name'] . "。" . "操作人：" . $_manager['username'],
            'ctime'   => date("Y-m-d H:i:s"),
        ];
        $this->__agent_charge_log_model->addAgentChargeLog($logData);

        $url = I('back_search_url', '', 'url');
        redirect(U('agentCharge/index/'));
    }

    /**
     * 删除单条计费信息
     *
     * @param $id 计费ID
     */
    public function deleteAgentCharge($id)
    {
        $id = (int)$id;
        if (!$id) {
            $this->admin_error('ID不正确！');

            return;
        }
        $this->__agent_charge_model->deleteCharge($id);

        $this->admin_success('单条删除计费信息成功！');
    }

    /**
     * 删除多条计费信息
     *
     */
    public function deleteAgentChargeAll()
    {
        $data = I('');
        if (empty($data['copyId'])) {
            if (!$data['ids']) {
                $this->admin_error('ID不正确！');

                return;
            }
            $this->__agent_charge_model->deleteCharge($data['ids']);
            $this->admin_success('批量删除计费信息成功！');
        } else {
            redirect(U('agentCharge/edit/' . $data['ids'][0], '', '') . '?act=edit&copy=1');
        }

    }


    //获取状态值
    protected function getChargeType()
    {
        $charge_type_arr  = [];
        $charge_type_list = DICT::CHARGE_TYPE_LIST;
        $charge_type_keys = array_keys($charge_type_list);
        foreach ($charge_type_keys as $i => &$r) {
            $charge_type_arr[] = ['id' => $r, 'text' => $charge_type_list[$r]];
        }

        return $charge_type_arr;
    }

    protected function getBonusStatus()
    {
        $bonus_status_arr  = [];
        $bonus_status_list = DICT::BONUS_LIST;
        $bonus_status_keys = array_keys($bonus_status_list);
        foreach ($bonus_status_keys as $i => &$r) {
            $bonus_status_arr[] = ['id' => $r, 'text' => $bonus_status_list[$r]];
        }

        return $bonus_status_arr;
    }

    protected function getPayingStatus()
    {
        $paying_status_arr  = [];
        $paying_status_list = DICT::PAYING_LIST;
        $paying_status_keys = array_keys($paying_status_list);
        foreach ($paying_status_keys as $i => &$r) {
            $paying_status_arr[] = ['id' => $r, 'text' => $paying_status_list[$r]];
        }

        return $paying_status_arr;
    }

    protected function getStatus()
    {
        $status_arr  = [];
        $status_list = DICT::STATUS_LIST;
        $status_keys = array_keys($status_list);
        foreach ($status_keys as $i => &$r) {
            $status_arr[] = ['id' => $r, 'text' => $status_list[$r]];
        }

        return $status_arr;
    }

    // 计时函数
    public function runtime($mode = 0)
    {
        static $t;
        if (!$mode) {
            $t = microtime();

            return;
        }
        $t1 = microtime();
        //list($m0,$s0) = split(" ",$t);
        list($m0, $s0) = explode(" ", $t);
        //list($m1,$s1) = split(" ",$t1);
        list($m1, $s1) = explode(" ", $t1);

        return sprintf("%.3f ms", ($s1 + $m1 - $s0 - $m0) * 1000);
    }


}