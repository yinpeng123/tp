<?php
namespace Admin\Cnsts;


class PRIVILEGE {

    const SYS_MANAGER           = 2; // 系统用户
    const SYS_ROLE              = 3; // 系统角色
    const APP_VERSION           = 4; // 版本管理
    const USER                  = 7; // 用户管理
    const USER_PRODUCT          = 8; // 用户管理-用户产品
    const USER_DELETE           = 47; // 用户管理-用户删除
    const USER_TRANSACTION      = 9; // 用户交易记录
    const TRUCK_OWNER_VERIFY    = 10; // 车主资质审核
    const GOODS_OWNER_VERIFY    = 11; // 货主资质审核
    const SYS_MENU              = 36; // 菜单管理

    const CS_WORK_SHEET         = 13; // 工单管理
    const CS_WORK_SHEET_EXAM    = 14; // 工单管理-审核关闭
    const CS_CHARGE_CALL        = 15; // 催缴管理
    const CS_CHARGE_CALL_EXAM   = 16; // 催缴管理-审核关闭
    const CS_CONSULT_COMPLAIN   = 17; // 咨询投诉管理
    const CS_CONSULT_COMPLAIN_EXAM = 18; // 咨询投诉管理-审核关闭
    const AGENT_CHARGE          = 19; // 计费管理
    const AGENT_INVOICE         = 20; // 开票管理

    const GOODS_RESOURCE        = 22; // 货源管理
    const TRUCK_RESOURCE        = 23; // 车源管理
    const TRUCK                 = 24; // 车辆管理
    const TRUCK_VERIFY          = 37; // 车辆认证

    const AGENT                 = 26; // 渠道管理
    const AGENT_FINANCE         = 27; // 渠道收支

    const FINANCE               = 28; // 财务管理 *

    const ADVERTISE             = 30; // 广告管理
    const ADVERTISE_EXAM        = 31; // 广告管理-审核关闭
    const IDENTITY              = 32; // 三证管理
    const INSURANCE             = 33; // 保单管理 *
    const OILCARD               =48; // 油卡销售管理

    const OPERATION             = 34; // 产品运营 *
    const HISTORY_LOG           = 35; // 历史日志

    const MESSAGE               = 39; // 消息管理
    const SYS_NOTICE            = 40; // 公告管理

    const STATS_USER            = 42; // 车货主比例
    const STATS_BID_ORDER       = 43; // 竞价成交率
    const STATS_FINANCE         = 44; // 平台收款
    const STATS_INVOICE         = 45; // 开票率
    const STATS_TRUCK           = 46; // 货源统计

}