<?php
/*
 *  定时任务
 */
namespace Home\Controller;
use Think\Controller;
class TaskController extends Controller
{

    # 每天 12点 去执行
    public function index(){
        $room = M("Room")->select();
        foreach ($room as $k=>$v){
            $id = $v['id'];
            $where['room_id'] = $v['id'];
            $room_user= M("RoomUser")->where($where)->count();
            $num =$v['num'];
            $create_time = strtotime($v['create_time']);
            if($room_user < $num && $create_time < time()){
                $data['status'] = 3;
                $data['failcause'] = '因队员在当日未进行组队成功，挑战组失败';
                $data['last_update_time'] = date("Y-m-d H:i:s",time());
                $update = M("Room")->where("id =$id")->save($data);
            }
        }
    }
    # 每日计划  去查找当日完成情况
    public function everyday_plan(){
        # 去room_user 表中查询openid  根据openid 去计划表中查寻制定的计划

        $room_user = M("room")
                    ->alias('r')
                    ->field("r.id,ru.openid,r.create_time")
                    ->join("left join room_user as ru on r.id = ru.room_id")
                    ->where("r.status=1")
                    ->select();
        print_R($room_user);
        foreach ($room_user as $k=>$v){
            $where['room_id'] = $v['id'];
            $where['openid'] = $v['openid'];
            $where['status'] = 0;
            $where['create_time'] = array(array('egt', $v['create_time']), array('elt', date("Y-m-d H:i:s",strtotime($v['create_time'])+1800)));
            $plan_info = M("plan")->where($where)->count();

            if($plan_info){
                $plan_info1[$v['id']] = $plan_info;
            }
        }
        print_R($plan_info1);

    }


    public function team(){
        $room_user = M("room")
            ->alias('r')
            ->field("r.id,ru.openid,r.create_time")
            ->join("left join room_user as ru on r.id = ru.room_id")
            ->where("r.status=1")
            ->select();

        foreach ($room_user as $k=>$v){
            $where['openid'] = $v['openid'];
            $where['status'] = 0;
            $where['create_time'] = array(array('egt', $v['create_time']), array('elt', date("Y-m-d H:i:s",strtotime($v['create_time'])+1800)));
            $plan_info = M("plan")->where($where)->select();

            if(!$plan_info){
                $plan_info1['openid'] = $v['openid'];
            }
        }



    }






}