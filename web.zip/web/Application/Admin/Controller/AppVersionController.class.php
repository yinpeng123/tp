<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Cnsts\MANAGER;
use Basic\Service\AppVersionService;
use Common\Cnsts\ERRNO;
use Admin\Service\PageService;
use Basic\Service\VersionManageService;

class AppVersionController extends AdminSessionController {

    public function __construct() {
        parent::__construct();

        // 权限检查
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::APP_VERSION) ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }
    }

    /**
     * 管理员列表
     */
    public function manage() {
        $per_page = C('TABLE_PER_PAGE');
//        $per_page = 2;
        $curr_page = I('path.2/d', 1);

        $where = [];
        $os_type = I('os_type');
        $search_from_day = I('search_from_day');
        $search_to_day = I('search_to_day');
        if ( $os_type ) {
            $where['os_type'] = $os_type;
        }
        if ( $search_from_day ) {
            $where['build_time'][] = ['egt', $search_from_day];
        }
        if ( $search_to_day ) {
            $where['build_time'][] = ['elt', $search_to_day. '23:59:59'];
        }
        /** @var AppVersionService $version_service */
        $version_service = D('Basic/AppVersion', 'Service');
        $list = $version_service->getListBy($where, [], $order = 'id desc',$curr_page, $per_page);
        $version_service->formatList($list);
        $total = $version_service->getListTotal($where);

        $cond = $this->prepareSearchCond(array('os_type', 'search_from_day', 'search_to_day'));
        $page_service = new PageService($total, $per_page);
        $page_nav = $page_service->show();

        $this->assignAll($cond);
        $this->assignAll(array(
            'title'         => '版本管理',
            'os_type_list' => [
                'ios',
                'android',
            ],
            'list'          => $list,
            'page_nav'      => $page_nav,
        ));
        $this->display('app_version_list');
    }

    /**
     * 获取返回列表的链接
     * @param $refer
     */
    protected function _backToListUrl($refer) {
        if ( !empty($refer) && 0 === strpos($refer, U('AppVersion/manage', '', '', TRUE)) ) {
            return $refer;
        } else {
            return U('AppVersion/manage', '', '', TRUE);
        }
    }

    /**
     * 添加版本
     */
    public function add() {
        $this->assignAll(array(
            'act'     => 'add',
            'form_action' => '/AppVersion/doAdd',
            'title'   => '新增版本',
            'update_type_list' => [
                'N' => '不升级',
                'Y' => '提示升级',
                'F' => '强制升级',
            ],
            'back_to_list_url' => $this->_backToListUrl($this->_refer),
        ));
        $this->display('version_add');
    }

    /**
     * 保存版本信息
     */
    public function doAdd() {
        // 验证令牌
        $this->checkFormToken();
        $data = $this->getFormatPostData();
        /** @var AppVersionService $version_service */
        $version_service = D('Basic/AppVersion', 'Service');
        list($errno ,$errmsg, $ret_data) = $version_service->add($data);
        if ( $errno == ERRNO::SUCCESS ) {
            return $this->admin_success('添加版本成功！', '/AppVersion/manage');
        } else {
            return $this->admin_error('添加版本失败！');
        }
    }

    /**
     * 编辑版本
     */
    public function edit($id) {
        $id = (int)$id;
        /** @var AppVersionService $version_service */
        $version_service = D('Basic/AppVersion', 'Service');
        $version_info = $version_service->getById($id);
        $update_desc = [];
        if ($version_info['update_desc']) {
            $update_desc = t_json_decode($version_info['update_desc']);
        }
        $this->assignAll(array(
            'form_action' => '/AppVersion/doEdit',
            'title'   => '编辑版本',
            'update_type_list' => [
                'N' => '不升级',
                'Y' => '提示升级',
                'F' => '强制升级',
            ],
            'version_info' => $version_info,
            'update_desc' => $update_desc,
            'refer'  => $this->_backToListUrl($this->_refer),
            'back_to_list_url'  => $this->_backToListUrl($this->_refer),
        ));
        return $this->display('version_edit');
    }

    /**
     * 提交编辑管理员
     */
    public function doEdit() {
        $data = $this->getFormatPostData();
        $id = I('id');
        if ( empty($id) ) {
            return $this->admin_error('ID格式不正确！');
        }
        /** @var AppVersionService $version_service */
        $version_service = D('Basic/AppVersion', 'Service');
        list($errno ,$errmsg, $ret_data) = $version_service->updateById($id, $data);
        if ( $errno == ERRNO::SUCCESS ) {
            return $this->admin_success('添加版本成功！', '/AppVersion/edit/'.$id);
        } else {
            return $this->admin_error('添加版本失败！', '/AppVersion/edit/'.$id);
        }
    }

    protected  function getFormatPostData() {
        $update_desc = I('update_desc');
        foreach($update_desc as &$desc) {
            $desc = trim($desc);
        }
        $data = [
            'os_type' => I('os_type'),
            'version' => I('version'),
            'update_type' => I('update_type'),
            'update_desc' => t_json_encode($update_desc),
            'down_url' => I('down_url'),
            'build_time' => I('build_time'),
            'apk_size' => I('apk_size'),
        ];
        return $data;
    }

}