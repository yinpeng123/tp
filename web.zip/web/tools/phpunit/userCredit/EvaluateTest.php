<?php
require __DIR__.'/../../common.php';
use Basic\Service\EvaluateService;
/**
 * 投诉测试用例
 * @author Chenc <chenchen@56sino.cn>
 */
class EvaluateTest extends PHPUnit_Framework_TestCase {

    const UID  = 64;
    const FUID = 65;
    const CERTAIN_ID = 12;

    public static function setUpBeforeClass(){
        M('user_evaluate')->where(['uid' => self::UID, 'fuid' => self::FUID])->delete();
        M('user_credit')->where(['uid' => self::UID])->save(['evaluate_point' => 0, 'status' => 1]);
        M('user_credit_log')->where(['uid' => self::UID, 'score_type' => 'evaluate_point'])->delete();
    }

    /**
     * @dataProvider addEvaluateProvider
     */
    public function testAddEvaluate($type, $score1, $score2, $score3, $score4, $res, $evaluate_point){
        $add = D('Basic/Evaluate', 'Service')->addEvaluate(self::UID, self::FUID, $type, self::CERTAIN_ID, $score1, $score2, $score3, $score4, time());  
        $this->assertEquals($add, $res);
        $usercredit = D('Basic/UserCredit', 'Service')->getUserCredit(self::UID, ['evaluate_point']);
        $this->assertEquals($usercredit['evaluate_point'], $evaluate_point);
    }

    public function addEvaluateProvider(){
        return [
            [EvaluateService::EVALUATE_TYPE_CARGO, 1, 1, 1, 1, true, 1],        
            [EvaluateService::EVALUATE_TYPE_CARGO, 1, 1, 1, 1, -2,   1],
            [EvaluateService::EVALUATE_TYPE_DRIVER, 1, 2, 3, 4, true, 3.5],
            [EvaluateService::EVALUATE_TYPE_DRIVER, 1, 2, 3, 4, -2, 3.5],
            [3, 1, 2, 3, 4, -1, 3.5],
        ];
    }
}
?>