<?php
require __DIR__.'/../../common.php';
use Basic\Service\ComplainService;
/**
 * 投诉测试用例
 * @author Chenc <chenchen@56sino.cn>
 */
class ComplainTest extends PHPUnit_Framework_TestCase {

    const UID  = 64;
    const FUID = 65;
    const CERTAIN_ID = 12;

    const ID_KEY = 'PHPUNIT_COMPLAIN_TEST_IDS';

    public static function setUpBeforeClass(){
        M('user_complain')->where(['uid' => self::UID, 'fuid' => self::FUID])->delete();
        M('user_credit')->where(['uid' => self::UID])->save(['relation_point' => 150, 'status' => 1]);
        M('user_credit_log')->where(['uid' => self::UID, 'score_type' => 'relation_point'])->delete();
        S(self::ID_KEY, null);
    }

    /**
     * @dataProvider addComplainProvider
     */
    public function testAddComplain($type, $reason, $res, $relation_point){
        $add = D('Basic/Complain', 'Service')->addComplain(self::UID, self::FUID, $type, $reason, self::CERTAIN_ID, time());  
        $this->assertEquals($add, $res);
        $usercredit = D('Basic/UserCredit', 'Service')->getUserCredit(self::UID, ['relation_point']);
        $this->assertEquals($usercredit['relation_point'], $relation_point);
        if ($add > 0) {
            $ids = S(self::ID_KEY);
            $ids[] = $add;
            S(self::ID_KEY, $ids);
            return $add;
        }
    }

    public function addComplainProvider(){
        return [
            [ComplainService::COMPLAIN_TYPE_CARGO, ComplainService::COMPLAIN_REASON_CARGO_FAKE_CARGO, true, 150],        
            [ComplainService::COMPLAIN_TYPE_CARGO, ComplainService::COMPLAIN_REASON_DRIVER_STEAL_CARGO, -2, 150],
            [ComplainService::COMPLAIN_TYPE_DRIVER, ComplainService::COMPLAIN_REASON_CARGO_FAKE_CARGO, -2, 150],
            [ComplainService::COMPLAIN_TYPE_DRIVER, ComplainService::COMPLAIN_REASON_DRIVER_STEAL_CARGO, true, 150],
            [3, ComplainService::COMPLAIN_REASON_CARGO_FAKE_CARGO, -1, 150],
        ];
    }

    public function testAcceptComplain(){
        $ids = S(self::ID_KEY);
        $relation_point = 150;
        foreach ($ids as $key => $id) {
            $up = D('Basic/Complain', 'Service')->updateStatus($id, ComplainService::COMPLAIN_STATUS_ACCEPTED);
            if ($up) {
                $relation_point -= 30;
            }
            $usercredit = D('Basic/UserCredit', 'Service')->getUserCredit(self::UID, ['relation_point']);
            $this->assertEquals($usercredit['relation_point'], $relation_point);
        }
    }
}
?>