<?php
namespace Admin\Service;

use Admin\Model\ProductStatusLogModel;

class ProductStatusLogService {
    public function getList($user_id) {
        /** @var ProductStatusLogModel $service */
        $service = D('Admin/ProductStatusLog','Model');
        $where = [
            'user_id' => $user_id,
        ];
        $log_list = $service->getLogList($where);
        $list = [];
        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');
        $format_manager_list = $manager_service->getFormatManger();
        foreach ($log_list as $value) {
            $type = $value['type'];
            $value['c_manager_name'] = $format_manager_list[$value['c_manager_id']];
            $list[$type][] = $value;
        }
        return $list;
    }

}