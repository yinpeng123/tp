<?php
namespace Client\Controller;

use Common\Cnsts\ERRNO;
use Basic\Service\EvaluateService;
use Common\Controller\SessionController;

class EvaluateController extends SessionController  {

    public function __construct() {
        parent::__construct();
    }

    /**
     * 添加评价
     */
    public function add(){
        $so_id = $this->I('so_id');
        if (!$so_id) {
            return $this->doResponse(ERRNO::INPUT_PARAM_ERRNO , ERRNO::e(ERRNO::INPUT_PARAM_ERRNO).':未指定运单', []);
        }
        // 判断当前用户是否是运单参与人
        $shipping = D('Basic/ShippingOrder', 'Service')->getShippingByOrderId($so_id);
        list($code, $msg, $order_info) = D("Basic/Order",'Service')->getOrderDetail($so_id, $this->user_id);
        if ($code) {
             return $this->doResponse(ERRNO::INPUT_PARAM_ERRNO , ERRNO::e(ERRNO::INPUT_PARAM_ERRNO).':运单错误', []);
        }
        $grab['user_id'] = $order_info['order_info']['carry_user_id'];
        if ($shipping['user_id'] == $this->user_id) {
            $type = EvaluateService::EVALUATE_TYPE_DRIVER;
            $uid = $grab['user_id'];
        } elseif ($grab['user_id'] == $this->user_id) {
            $type = EvaluateService::EVALUATE_TYPE_CARGO;
            $uid = $shipping['user_id'];
        } else {
            return $this->doResponse(ERRNO::INPUT_PARAM_ERRNO , ERRNO::e(ERRNO::INPUT_PARAM_ERRNO).':运单错误', []);
        }
        $score_1 = $this->I('score_1', 0, 'intval');
        if ($score_1 < 0) {
            $score_1 = 0;
        } elseif ($score_1 > 10) {
            $score_1 = 10;
        }
        $score_2 = $this->I('score_2', 0, 'intval');
        if ($score_2 < 0) {
            $score_2 = 0;
        } elseif ($score_2 > 10) {
            $score_2 = 10;
        }
        $score_3 = $this->I('score_3', 0, 'intval');
        if ($score_3 < 0) {
            $score_3 = 0;
        } elseif ($score_3 > 10) {
            $score_3 = 10;
        }
        $score_4 = $this->I('score_4', 0, 'intval');
        if ($score_4 < 0) {
            $score_4 = 0;
        } elseif ($score_4 > 10) {
            $score_4 = 10;
        }
        $remark = $this->I('remark','');
        $add = D('Basic/Evaluate', 'Service')->addEvaluate($uid, $this->user_id, $type, $so_id, $score_1, $score_2, $score_3, $score_4, $remark);
        if ($add) {
            return $this->doResponse(ERRNO::SUCCESS , ERRNO::e(ERRNO::SUCCESS), $add);
        }
        return $this->doResponse(ERRNO::DB_ERROR , ERRNO::e(ERRNO::DB_ERROR), $add);
    }

    public function getone(){
        $so_id = $this->I('so_id');
        if (!$so_id) {
            return $this->doResponse(ERRNO::INPUT_PARAM_ERRNO , ERRNO::e(ERRNO::INPUT_PARAM_ERRNO).':未指定运单', []);
        }
        // 判断当前用户是否是运单参与人
        $shipping = D('Basic/ShippingOrder', 'Service')->getShippingByOrderId($so_id);
        list($code, $msg, $order_info) = D("Basic/Order",'Service')->getOrderDetail($so_id, $this->user_id);
        if ($code) {
             return $this->doResponse(ERRNO::INPUT_PARAM_ERRNO , ERRNO::e(ERRNO::INPUT_PARAM_ERRNO).':运单错误', []);
        }
        $grab['user_id'] = $order_info['order_info']['carry_user_id'];
        if ($shipping['user_id'] == $this->user_id) {
            $type = EvaluateService::EVALUATE_TYPE_DRIVER;
            $uid = $grab['user_id'];
        } elseif ($grab['user_id'] == $this->user_id) {
            $type = EvaluateService::EVALUATE_TYPE_CARGO;
            $uid = $shipping['user_id'];
        } else {
            return $this->doResponse(ERRNO::INPUT_PARAM_ERRNO , ERRNO::e(ERRNO::INPUT_PARAM_ERRNO).':运单错误', []);
        }
        $data = D('Basic/Evaluate', 'Service')->getone($so_id, $type);
        return $this->doResponse(ERRNO::SUCCESS , ERRNO::e(ERRNO::SUCCESS), $data);
    }

}
