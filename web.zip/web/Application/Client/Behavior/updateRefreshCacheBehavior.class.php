<?php
namespace Client\Behavior;

use Think\Behavior;
use Think\Log;

class updateRefreshCacheBehavior extends Behavior
{
    // 白名单
    const WHITE_LIST = [
//        'web/sino/query',
//        'basic/dealresque/closeorderbyque',
//        'basic/dealresque/closeorderbyque',
//        'basic/dealresque/closeunpay',
//        'web/sino/checkcarnum',
    ];

    // 行为扩展的执行入口必须是run
    public function run(&$params)
    {
//        // 进行黑名单过滤
//        $req_method = $_SERVER['REQUEST_METHOD'];
//        $rncb = C('REFRESH_NOT_CACHE_BLACK_LIST');
//
//        if ($rncb[MODULE_NAME] != null
//            && $rncb[MODULE_NAME][CONTROLLER_NAME] != null
//            && $rncb[MODULE_NAME][CONTROLLER_NAME][ACTION_NAME] != null
//            && $rncb[MODULE_NAME][CONTROLLER_NAME][ACTION_NAME][$req_method] != null) {
//            foreach ($rncb[MODULE_NAME][CONTROLLER_NAME][ACTION_NAME][$req_method] as $k=>$v) {
//                $req = json_decode(html_entity_decode(I("req", "", "htmlspecialchars")), true);
//                if ($req[$k] === $v) {
//                    return;
//                }
//            }
//        }

        if ( in_array(strtolower(MODULE_NAME . '/' . CONTROLLER_NAME . '/' . ACTION_NAME), self::WHITE_LIST) ) {
            return;
        }


        $ott['expire'] = C('REFRESH_MEMCACHE_EXPIRE_TIME');
//        $val = ob_get_contents();
//        $_REQUEST['request_id'] = !empty($_REQUEST['request_id']) ? $_REQUEST['request_id'] : '';

        if ( !empty($_REQUEST['request_id']) ) {
            $valSize = ob_get_length();
            if ($valSize > C('REFRESH_MEMCACHE_MAX_SIZE')) {
                cmm_log('业务程序处理生成数据超过' . C('REFRESH_MEMCACHE_MAX_SIZE'), 'PREVENT_REFRESH');
                // clear cache
                S($_REQUEST['request_id'], null);

                return;
            }

            // cached
            $val = S($_REQUEST['request_id']);
            //cmm_log2("request_id:".$_REQUEST['request_id'].", val:".$val.", expire:".C('REFRESH_MEMCACHE_EXPIRE_TIME'));
            if ( $val != '#$#' ) {
                S($_REQUEST['request_id'], $val, $ott);
            }
        }
    }
}

