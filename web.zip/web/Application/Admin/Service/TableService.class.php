<?php
namespace Admin\Service;

class TableService {
    protected $_table_config = null;
    public function __construct($table_config) {
        $this->_table_config = $table_config;
    }
    /**
     * @param $table_config
     * 获取表格内容
     */
    public function getTableContent($data) {
        $header = $this->_table_config['header'];
        $data_id = $this->_table_config['data_id'];
        $thead = $this->_getTheadContent($header);
        $tbody = $this->_getTbodyContent($header,$data,$data_id);
        $tableContent = [
            'thead' => $thead,
            'tbody' => $tbody,
        ];
        return $tableContent;
    }

    /**
     * 获取表格头内容
     * */
    protected function _getTheadContent($header) {
        $thead = '';
        $thead .= '<thead>';
        $thead .= '<tr class="headings">';
        foreach ($header as $key=> $value) {
            if($key == 'check_box') {
                if ($value['show']) {
                    $thead .= '<th class="column-title column-width-45"><input type="checkbox" id="check-all" 
                    class=""></th>';
                }
            } else {
                if ($value['show']) {
                    $thead .= '<th class="column-title '.$value['class'].'">'.$value['title'].'</th>';

                } else {
                    $thead .= '<th class="column-title '.$value['class'].'" style="display:none">'.$value['title']
                        .'</th>';
                }
            }
        }
        $thead .= '</thead>';
        return $thead;
    }

    /**
     *获取表格body体内容
     */
    protected function _getTbodyContent($header,$data, $data_id = '') {
        $tbody = '';
        $tbody .= '<tbody>';
//        $header_keys = array_keys($header);
        foreach ($data as $key => $value) {
            $data_id_value = $data_id ? $value[$data_id] : '';
            $tbody .= '<tr class="pointer" data_id="'.$data_id_value.'">';

            foreach ($header as $h_key => $hv) {
                if ($h_key == 'check_box') {
                    if ($hv['show'] == true) {
                        $tbody .= '<td class="a-center">
                        <input type="checkbox" class="data_id" name="ids[]" value="'.$data_id_value.'">
                        </td>';
                    }
                } else {
                    if (empty($header[$h_key]['callback'])) {
                        if ($h_key == "op") {
                            $tbody .='<td class="last">'.$value[$h_key].'</td>';
                        } else {
                            $tbody .='<td class="">'.$value[$h_key].'</td>';
                        }
                    } else {
                        $class = new $hv['callback']['class'];
                        $content = $class->$hv['callback']['method']($value);
                        $tbody .= $content;
                    }
                }


            }
            $tbody .= '</tr>';
        }
        $tbody .= '</tbody>';
        return $tbody;
    }
    /**
     *获取搜索头内容
     */
    public function getFilterContent($cond = []) {
        $filter = $this->_table_config['filter'];
        $enum = $this->_table_config['enum'];
        $filter_content = '';
        foreach ($filter as $key => $value) {
            switch ($value['type']) {
                case 'text' :
                    $search_v = $cond[$key] ? :'';
                    $filter_content .= '<div class="flt">
                      <span class="search-label">'.$value['title'].'：</span>
                      <span class="col-md-2 col-sm-12 col-xs-12 form-group search-input-150">
                        <input type="text" id="'.$value['id'].'" name="'.$key.'" value="'.$search_v.'" 
                        class="form-control" placeholder="">
                      </span>
                    </div>';
                    break;
                case 'select' :
                    $options = '';
                    foreach ($enum[$key] as $enum_k => $enum_v) {
                        if ($cond[$key] == $enum_k) {
                            $options .= '<option value="'.$enum_k.'" selected="selected">'.$enum_v.'</option>';
                        } else {
                            $options .= '<option value="'.$enum_k.'" >'.$enum_v.'</option>';
                        }
                    }
                    $filter_content .= '<div class="flt">
                      <span class="search-label">'.$value['title'].'：</span>
                      <span class="col-md-2 col-sm-12 col-xs-12 form-group search-input-150">
                        <select id="'.$value['id'].'" name="'.$key.'" class="form-control" >
                            '.$options.'
                        </select>
                      </span>
                    </div>';
                    break;
                case 'date' :
                    $start_time = $cond[$key][0] ? : '';
                    $end_time = $cond[$key][1] ? : '';
                    $filter_content .= '
                        <div class="flt">
                            <span class="search-label">'.$value['title'].'：</span>
                            <span class="col-md-2 col-sm-12 col-xs-12 form-group search-input-150">
                                <div class="search-dt">
                                    <div class="control-group">
                                        <div class="controls">
                                            <div class="ldate input-append col-md-12 xdisplay_inputx form-group has-feedback">
                                                <input type="text" id="'.$value['id'].'_0'.'" name="'.$key.'[0]"
                                                       class="span2 form-control has-feedback-left"
                                                       value="'.$start_time.'" data-date="'.$start_time.'"
                                                       data-date-format="yyyy-mm-dd" style="" date_time="date_time">
                                                <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </span>
                        </div>
                        <div class="flt">
                            <span class="search-label" style="text-align: center">——</span>
                            <span class="col-md-2 col-sm-12 col-xs-12 form-group search-input-150">
                                <div class="search-dt">
                                    <div class="control-group">
                                        <div class="controls">
                                            <div class="ldate input-append col-md-11 xdisplay_inputx form-group has-feedback">
                                                <input type="text" id="'.$value['id'].'_1'.'" name="'.$key.'[1]"
                                                       class="span2 form-control has-feedback-left"
                                                       value="'.$end_time.'" data-date="'.$end_time.'"
                                                       data-date-format="yyyy-mm-dd" style="" date_time="date_time">
                                                <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </span>
                        </div>
                    ';
                    break;
                default :
                    break;
            }
        }
        return $filter_content;
    }
}