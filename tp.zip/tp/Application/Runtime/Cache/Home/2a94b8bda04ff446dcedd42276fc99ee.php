<?php if (!defined('THINK_PATH')) exit();?>
<html>

<body>

<form action="http://www.htown.xyz/Home/index/upload" enctype="multipart/form-data" method="post">
    <input type="file" name="pic[]">
    <input type="file" name="pic[]">
    <input type="file" name="pic[]">
    <input type="submit" value="提交" >
</form>
</body>
</html>