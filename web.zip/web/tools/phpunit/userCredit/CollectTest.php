<?php
require __DIR__.'/../../common.php';
use Basic\Service\CollectService;
/**
 * 收藏测试用例
 * @author Chenc <chenchen@56sino.cn>
 */
class CollectTest extends PHPUnit_Framework_TestCase {

    const UID  = 64;
    const FUID = 65;

    const ID_KEY = 'PHPUNIT_COLLECT_TEST_IDS';


    public static function setUpBeforeClass(){
        M('user_collect')->where(['uid' => self::UID])->delete();
        M('user_credit')->where(['uid' => self::UID])->save(['relation_point' => 150, 'status' => 1]);
        M('user_credit_log')->where(['uid' => self::UID, 'score_type' => 'relation_point'])->delete();
        S(self::ID_KEY, null);
    }

    /**
     * @dataProvider addCollectProvider
     */
    public function testAddCollect($type, $res, $relation_point){
        $add = D('Basic/Collect', 'Service')->addCollect(self::UID, self::FUID, $type);       
        $this->assertEquals($add, $res);
        $usercredit = D('Basic/UserCredit', 'Service')->getUserCredit(self::UID, ['relation_point']);
        $this->assertEquals($usercredit['relation_point'], $relation_point);
        if ($add > 0) {
            $ids = S(self::ID_KEY);
            $ids[] = $add;
            S(self::ID_KEY, $ids);
            return $add;
        }
    }

    public function addCollectProvider(){
        return [
            [CollectService::COLLECT_TYPE_CARGO,   true, 152],
            [CollectService::COLLECT_TYPE_CARGO,  -2, 152],
            [CollectService::COLLECT_TYPE_DRIVER,  true, 152],
            [CollectService::COLLECT_TYPE_DRIVER, -2, 152],
            [3,                                   -1, 152],
        ];
    }

    public function testCancelCollect(){
        $ids = S(self::ID_KEY);
        $points = [152, 150];
        foreach ($ids as $key => $id) {
            D('Basic/Collect', 'Service')->cancelCollect($id);
            $usercredit = D('Basic/UserCredit', 'Service')->getUserCredit(self::UID, ['relation_point']);
            $this->assertEquals($usercredit['relation_point'], $points[$key]);
        }
    }
}
?>