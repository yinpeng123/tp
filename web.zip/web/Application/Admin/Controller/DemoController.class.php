<?php
namespace Admin\Controller;


class DemoController extends AdminSessionController {

    public function __construct() {
        parent::__construct();
    }

    public function editTable() {
        $this->assignAll(array(
            'title'   => '可编辑表格',
        ));
        $this->display('edit_table');
    }

    public function doEditTable() {
        p($_POST);
    }

}