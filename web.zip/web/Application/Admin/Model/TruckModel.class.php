<?php
namespace Admin\Model;

use Basic\Cnsts\CACHE_PREFIX;
use Basic\Model\BasicModel;

class TruckModel extends BasicModel
{

    private $__truck_model = NULL;

//    public function __construct() {
//        $this->__truck_model = M('truck');
//    }

    /**
     * 构造函数, 缺省为连接主库并不使用缓存!
     *
     * @param string     $db_type 指定主、从数据库, 值分别为: master/slave
     * @param bool|FALSE $enable_cache 是否启用缓存
     */
    public function __construct($db_type = 'master', $enable_cache = FALSE) {
        parent::__construct('truck', CACHE_PREFIX::TRUCK, $db_type);
        $this->_enable_cache = $enable_cache;

        $this->__truck_model = $this->_model;
    }

//    /**
//     * 车辆列表
//     *
//     * @param array $field 搜索字段
//     * @param array $join 关联表
//     * @param array $where 搜索条件
//     * @param array $order 排序
//     * @param int   $page_no 页码
//     * @param int   $per_page 每页记录数
//     */
//    public function searchTruckList($field, $join, $where, $order, $page_no, $per_page) {
//        $page_no = max($page_no, 1);
//        $data = $this->__truck_model->field($field)->join($join)->where($where)->order($order)->page($page_no,
//            $per_page)->select();
//        $res = $this->__truck_model->field("FOUND_ROWS() as total")->find();
//        $count = $res['total'];
//        $page_number = ceil($count / $per_page);  // 总页数
//
//        if ($page_number > 0 && $page_no > $page_number) { // 超出记录集, 返回最后一页的数据
//            return $this->searchTruckList($field, $join, $where, $order, $page_number, $per_page);
//        }
//        return array('count' => $count, 'page_number' => $page_number, 'page_no' => $page_no, 'data' => $data);
//    }
//
    /**
     * 车辆列表
     * @param $cond
     * @param $page_no
     * @param $per_page
     *
     * @return array
     */
    public function searchTruckList($cond, $page_no, $per_page) {
        $page_no = max($page_no, 1);
        $data = $this->__truck_model->field('SQL_CALC_FOUND_ROWS *')->where($cond)->order('id DESC')->page($page_no, $per_page)->select();
        $res = $this->__truck_model->field("FOUND_ROWS() as total")->find();
        $count = $res['total'];
        $page_number = ceil($count/$per_page);  // 总页数

        if ( $page_number > 0 && $page_no > $page_number ) { // 超出记录集, 返回最后一页的数据
            return $this->searchTruckList($cond, $page_number, $per_page);
        }

        return array('count' => $count, 'page_number' => $page_number, 'page_no' => $page_no, 'data' => $data);
    }

    /**
     * 车辆列表导出
     *
     * @param array $field 搜索字段
     * @param array $join 关联表
     * @param array $where 搜索条件
     * @param array $order 排序
     * @param array $limit_start 起始行
     * @param array $limit_size 查询条数
     */
    public function exportTruckList($field, $join, $where, $order, $limit_start, $limit_size) {
        return $this->__truck_model->field($field)->join($join)->where($where)->order($order)->page($limit_start,
            $limit_size)->select();
    }

    public function searchTruckCertList($cond, $page_no, $per_page) {
        $page_no = max($page_no, 1);
        $data = $this->__truck_model
            ->field('SQL_CALC_FOUND_ROWS truck.*, user.account, user.telephone')
            ->join('left join user on truck.user_id = user.id')
            ->where($cond)->order('truck.id DESC')
            ->page($page_no, $per_page)->select();
        $res = $this->__truck_model->field("FOUND_ROWS() as total")->find();
        $count = $res['total'];
        $page_number = ceil($count/$per_page);  // 总页数

        if ( $page_number > 0 && $page_no > $page_number ) { // 超出记录集, 返回最后一页的数据
            return $this->searchLog($cond, $page_number, $per_page);
        }

        return array('count' => $count, 'page_number' => $page_number, 'page_no' => $page_no, 'data' => $data);
    }

    public function getTruckInfo($id) {
        //读取缓存
        $key = 'truck_'.$id;
        if($info = S($key)) {
            return $info;
        }

        //写入缓存
        $info = $this->__truck_model->where(['id' => $id])->find();
        if(!empty($info)) {
            S($key, $info);
        }
        return $info;
    }

    public function updateInfo($id, $fields) {
        $where = [
            'id' => $id,
        ];
        $res = $this->__truck_model->where($where)->setField($fields);

        $key = 'truck_'.$id;
        //删除缓存
        if(!empty($id)) {
            S($key, null);
        }
        return $res;
    }
}