<?php
namespace Admin\Controller;

use Basic\Cnsts\USER_FINANCE;
use Admin\Controller\AdminSessionController;
use Admin\Service\PageService;


class UserFinanceController extends AdminSessionController {

    /* @var \Basic\Model\UserFinanceModel $this->__finance_model */
    private $__finance_model = NULL;
    /* @var \Basic\Model\UserFinanceLogModel $this->__finance_log_model */
    private $__finance_log_model = NULL;

    public function __construct() {
        parent::__construct();

        // 权限检查
//        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::CS_WORK_SHEET) ) {
//            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
//            exit;
//        }

        $this->__finance_model = D('Basic/UserFinance');
        $this->__finance_log_model = D('Basic/UserFinanceLog');
    }

    /**
     * 获取返回列表的链接
     * @param $refer
     */
    protected function _backToListUrl($refer) {
        if ( !empty($refer) && 0 === stripos($refer, U('UserFinance/index', '', '', TRUE)) ) {
            return $refer;
        } else {
            return U('UserFinance/index', '', '', TRUE);
        }
    }

    /**
     * 现金记录的certain_id值是否是运单id
     * @param $type
     *
     * @return bool
     */
    protected function _isShippingOrderId($type) {
        if ( in_array($type, [
            USER_FINANCE::IN_SHIPPING_FIRST, USER_FINANCE::IN_SHIPPING_FINAL,
            USER_FINANCE::OUT_SHIPPING, USER_FINANCE::OUT_SHIPPING_FIRST, USER_FINANCE::OUT_SHIPPING_FINAL,
            USER_FINANCE::OUT_SERVICE_CARRIER, USER_FINANCE::OUT_SERVICE_SHIPPER
            ]) )
            return TRUE;
        else
            return FALSE;
    }


    /**
     * 现金交易记录查询
     */
    public function index() {
        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);

        /* @var \Basic\Model\PaymentModel $payment_model */
        $payment_model = D('Basic/Payment');

        $cond = $this->prepareSearchCond(array('search_ctime_from', 'search_ctime_to', 'search_certain_id', 'search_account',
                   'search_pay_by', 'search_type'));

        /* 非全国网用户只能查看其所在渠道的工单 */
//        if ( $this->_manager['agent_id'] > 0 ) {
//            $cond['search_agent_id'] = $this->_manager['agent_id'];
//        }
        $ret = $this->__finance_log_model->searchFinanceLog($cond, $curr_page, $per_page);
        //print_r($ret);
        foreach ( $ret['data'] as &$i ) {
            $i['type_text'] = USER_FINANCE::TYPE_ARR[$i['type']];
            $i['pay_by_text'] = USER_FINANCE::PAY_TYPE_ARR[$i['pay_by']];

            // certain_id是否为运单id
            $i['shipping_order_id'] = $this->_isShippingOrderId($i['type']) ? $i['certain_id'] : '-';

            // 支付信息
            if ( $i['payment_id'] > 0 ) {
                $payment = $payment_model->getById($i['payment_id']);
                $i['payment_out_trade_no'] = $payment['out_trade_no'];
            } else {
                $i['payment_out_trade_no'] = '';
            }
        }

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav = $page_service->show();
//p($ret['data']);die;
        $text = $this->_getTotalFee($ret['data']);
        $this->assignAll($cond);
        $this->assignAll([
            'title'         => '现金交易列表',
            'pay_by_arr'    => USER_FINANCE::PAY_TYPE_ARR,
            'type_arr'      => USER_FINANCE::TYPE_ARR,
            'list'          => $ret['data'],
            'page_nav'      => $page_nav,
            'text'          => $text,
        ]);
        $this->display('user_finance_list');
    }

    private function _getTotalFee($data) {
        $money_arr = $this->_getMoney($data);
        $get_money_total = 0;
        $pay_money_total = 0;
        foreach ($money_arr['get_money'] as $v) {
            $get_money_total += $v['add_money'];
        }
        foreach ($money_arr['pay_money'] as $v) {
            $pay_money_total += $v['add_money'];
        }

//        p($money_arr);die;
        $get_money_type = $this->_getPayTypeMoney($money_arr['get_money']);
//        p($get_money_type);die;
        $pay_money_type = $this->_getPayTypeMoney($money_arr['pay_money']);

        $get = '总收款：' . $get_money_total . '；' . $get_money_type;
        $pay = '总付款：' . $pay_money_total . '；' . $pay_money_type;
        return $get . $pay;
    }

    private function _getMoney($data) {
        $get_money = [];
        $pay_money = [];
        foreach ($data as $k=>$v) {
            if ($v['type'] < 100) {
                $get_money[] = $v;
            } else {
                $pay_money[] = $v;
            }
        }
        return ['get_money' => $get_money, 'pay_money' => $pay_money];
    }

    private function _getPayTypeMoney($data) {
        $list = [];
        foreach ($data as $v) {
            $list[] = $v['pay_by_text'];
        }
        $list_by = array_merge(array_unique($list));
//        p($data);die;
        $money = [];
        foreach ($list_by as $k=>$v) {
            foreach ($data as $vv) {
                if ($vv['pay_by_text'] == $v) {
                    $money[$k]['type'] = $v;
                    $money[$k]['total'] += $vv['add_money'];
                }
            }
        }
        $text = '';
        foreach ($money as $v) {
            $text .= $v['type'] . '：' . sprintf("%.2f", $v['total']) . '元。';
        }
        return $text;
    }


    /**
     * 导出现金交易记录
     */
    public function exportFinanceLog() {
        // 先查看交易记录总数是否超过导出限制
        $max_export_record_num = 10000;
        $per_page = 1000;
        $curr_page = 1;
        $cond = $this->prepareSearchCond(array('search_ctime_from', 'search_ctime_to', 'search_certain_id', 'search_account',
                                               'search_pay_by', 'search_type'));

        /* 非全国网用户只能查看其所在渠道的工单 */
//        if ( $this->_manager['agent_id'] > 0 ) {
//            $cond['search_agent_id'] = $this->_manager['agent_id'];
//        }
        $ret = $this->__finance_log_model->searchFinanceLog($cond, $curr_page, $per_page);
        if ( $ret['count'] > $max_export_record_num ) {
            $this->admin_error('导出记录数超过上限，请缩小时间范围分批导出！');
            return;
        }

        $filename = '现金交易记录.csv';

        // 输出Excel文件头
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        header('Cache-Control: max-age=0');

        // 打开PHP文件句柄，php://output 表示直接输出到浏览器
        $fp = fopen('php://output', 'a');

        // 输出Excel列名信息
        $head = array('ID', '时间', '运单编号', '交易流水', '类型', '付款', '收款', '收(付)款人', '会员号', '用户手机', '支付方式');
        foreach ($head as $i => $v) {
            // CSV的Excel支持GBK编码，一定要转换，否则乱码
            $head[$i] = iconv('utf-8', 'gb2312', $v);
        }
        // 将数据通过fputcsv写到文件句柄
        fputcsv($fp, $head);

        // 输出数据内容
        while (1) {
            $this->_doExportFinanceLogs($fp, $ret['data']);
            if ( $curr_page >= $ret['page_number'] )
                break;

            $ret = $this->__finance_log_model->searchFinanceLog($cond, ++$curr_page, $per_page);
        }

        // 关闭句柄
        fclose($fp);
    }

    /**
     * 分批导出现金交易记录
     * @param $fp
     * @param $data
     */
    protected function _doExportFinanceLogs($fp, $data) {
        /* @var \Basic\Model\PaymentModel $payment_model */
        $payment_model = D('Basic/Payment');

        foreach ( $data as $k => $i ) {
            $i['type_text'] = USER_FINANCE::TYPE_ARR[$i['type']];
            $i['pay_by_text'] = USER_FINANCE::PAY_TYPE_ARR[$i['pay_by']];

            // certain_id是否为运单id
            $i['shipping_order_id'] = $this->_isShippingOrderId($i['type']) ? $i['certain_id'] : '';

            // 支付信息
            if ( $i['payment_id'] > 0 ) {
                $payment = $payment_model->getById($i['payment_id']);
                $i['payment_out_trade_no'] = $payment['out_trade_no'];
            } else {
                $i['payment_out_trade_no'] = '';
            }

            $row = [
                $i['id'],
                $i['ctime'],
                $i['shipping_order_id'],
                $i['payment_out_trade_no'],
                iconv('utf-8', 'gb2312', $i['type_text']),
                $i['type'] >= 100 ? $i['add_money'] : '',
                $i['type'] < 100 ? $i['add_money'] : '',
                iconv('utf-8', 'gb2312', $i['account']),
                $i['net_no'],
                $i['telephone'],
                iconv('utf-8', 'gb2312', $i['pay_by_text']),
            ];
            fputcsv($fp, $row);
        }
    }


    /**
     * 现金提现记录查询
     */
    public function withdrawIndex() {
        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);

        $cond = $this->prepareSearchCond(array('search_ctime_from', 'search_ctime_to', 'search_stime_from', 'search_stime_to',
                                               'search_status', 'search_bank_code', 'search_card_no'));
        $cond['search_status'] = I('search_status/s') != '' ? I('search_status/s') : '';
        //print_r($cond);

        /* @var \Basic\Model\UserWithdrawLogModel $withdraw_model */
        $withdraw_model = D('Basic/UserWithdrawLog');
        $ret = $withdraw_model->searchWithdrawLog($cond, $curr_page, $per_page);
        //print_r($ret);

        /* @var \Basic\Model\UserBankCardModel $card_model */
        $card_model = D('Basic/UserBankCard');

        /* @var \Basic\Service\CityService $city_service */
        $city_service = D('Basic/City', 'Service');

        foreach ( $ret['data'] as &$i ) {
            // 银行卡信息
            $i['card'] = $card_model->getCard($i['card_id']);

            if ( $i['card']['type'] == 1 )
                $i['card']['type_text'] = '个人';
            elseif ( $i['card']['type'] == 2 )
                $i['card']['type_text'] = '公司';
            else
                $i['card']['type'] = '个人';

            $i['card']['bank_name'] = \Basic\Cnsts\BANK::CODE_ARR[ $i['card']['bank_code'] ];

            if ( $i['card']['bank_city'] > 0 )
                $i['card']['bank_city_text'] = $city_service->getAreaFullName($i['card']['bank_city']);
            else
                $i['card']['bank_city_text'] = '';

            // 状态样式
            $i['status_text'] = USER_FINANCE::WITHDRAW_STATUS_ARR[ (string)$i['status'] ];
            if ( $i['status'] < 0 )
                $i['status_color'] = 'my-red';
            elseif ( $i['status'] == 1 )
                $i['status_color'] = 'my-green';
        }

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav = $page_service->show();
//p($ret['data']);die;
        $text = $this->_getTotalGas($ret['data']);
        $this->assignAll($cond);
        $this->assignAll([
            'title'         => '现金提现列表',
            'list'          => $ret['data'],
            'page_nav'      => $page_nav,
            'status_arr'    => USER_FINANCE::WITHDRAW_STATUS_ARR,
            'bank_code_arr' => \Basic\Cnsts\BANK::CODE_ARR,
            'text'          => $text,
        ]);
        $this->display('user_withdraw_list');
    }

    private function _getTotalGas($data) {
        $list = [];
        foreach ($data as $v) {
            $list[] = $v['status_text'];
        }
        $list_by = array_merge(array_unique($list));
        $money = [];
        foreach ($list_by as $k=>$v) {
            foreach ($data as $vv) {
                if ($vv['status_text'] == $v) {
                    $money[$k]['type'] = $v;
                    $money[$k]['total'] += $vv['amount'];
                }
            }
        }
        $text = '';
        foreach ($money as $v) {
            $text .= $v['type'] . '：' . sprintf("%.2f", $v['total']) . '元。';
        }
        return $text;
    }

    /**
     * 确认现金提现已结算
     */
    public function confirmWithdraw() {
        // 验证令牌
        $this->checkFormToken();

        $id = I('id/d', 0);
        if ( !$id ) {
            $this->admin_error('参数不正确！');
            return;
        }

        /* @var \Basic\Service\UserFinanceService $finance_service */
        $finance_service = D('Basic/UserFinance', 'Service');
        $ret = $finance_service->confirmWithdraw($id, $this->_manager_id);
        if ( $ret == -3 ) {
            $this->admin_error('提现记录状态不正确！');
            return;
        } elseif ( $ret < 0 ) {
            $this->admin_error('确认结算失败！');
            return;
        }

        // 发送push消息
        $withdraw_log = $finance_service->getWithdrawById($id);
        /* @var \Basic\Service\SendNoticeService $send_service */
        $send_service = D('Basic/SendNotice', 'Service');
        $send_service->addNotice($withdraw_log['uid'], 'withdraw_draw_cash_status', ['amount' => $withdraw_log['amount']]);

        $this->admin_success('确认结算成功！');
    }

    /**
     * 取消现金提现
     */
    public function cancelWithdraw() {
        // 验证令牌
        $this->checkFormToken();

        $id = I('id/d', 0);
        if ( !$id ) {
            return $this->admin_error('参数不正确！');
        }

        /* @var \Basic\Service\UserFinanceService $finance_service */
        $finance_service = D('Basic/UserFinance', 'Service');
        $ret = $finance_service->cancelWithdraw($id, $this->_manager_id);
        if ( $ret == -3 ) {
            return $this->admin_error('提现记录状态不正确！');
        } elseif ( $ret == -4 ) {
            return $this->admin_error('退款给用户失败！');
        } elseif ( $ret < 0 ) {
            return $this->admin_error('取消提现失败！');
        }

        $this->admin_success('取消提现成功！');
    }


    /**
     * 导出现金提现记录
     */
    public function exportWithdrawLog() {
        // 先查看交易记录总数是否超过导出限制
        $max_export_record_num = 10000;
        $per_page = 1000;
        $curr_page = 1;
        $cond = $this->prepareSearchCond(array('search_ctime_from', 'search_ctime_to', 'search_stime_from', 'search_stime_to',
                                               'search_status', 'search_bank_code', 'search_card_no'));
        $cond['search_status'] = I('search_status/s') != '' ? I('search_status/s') : '';

        /* @var \Basic\Model\UserWithdrawLogModel $withdraw_model */
        $withdraw_model = D('Basic/UserWithdrawLog');
        $ret = $withdraw_model->searchWithdrawLog($cond, $curr_page, $per_page);
        if ( $ret['count'] > $max_export_record_num ) {
            return $this->admin_error('导出记录数超过上限，请缩小时间范围分批导出！');
        }

        $filename = '现金提现记录.csv';

        // 输出Excel文件头
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        header('Cache-Control: max-age=0');

        // 打开PHP文件句柄，php://output 表示直接输出到浏览器
        $fp = fopen('php://output', 'a');

        // 输出Excel列名信息
        $head = array('ID', '提现时间', '提现金额', '账户类型', '提现银行', '开户人', '支行名称', '开户地', '银行卡号', '结算状态', '结算时间');
        foreach ($head as $i => $v) {
            // CSV的Excel支持GBK编码，一定要转换，否则乱码
            $head[$i] = iconv('utf-8', 'gb2312', $v);
        }
        // 将数据通过fputcsv写到文件句柄
        fputcsv($fp, $head);

        // 输出数据内容
        while (1) {
            $this->_doExportWithdrawLogs($fp, $ret['data']);
            if ( $curr_page >= $ret['page_number'] )
                break;

            $ret = $withdraw_model->searchWithdrawLog($cond, ++$curr_page, $per_page);
        }

        // 关闭句柄
        fclose($fp);
    }

    /**
     * 分批导出现金提现记录
     * @param $fp
     * @param $data
     */
    protected function _doExportWithdrawLogs($fp, $data) {
        /* @var \Basic\Model\UserBankCardModel $card_model */
        $card_model = D('Basic/UserBankCard');

        /* @var \Basic\Service\CityService $city_service */
        $city_service = D('Basic/City', 'Service');

        foreach ( $data as $k => $i ) {
            // 银行卡信息
            $i['card'] = $card_model->getCard($i['card_id']);

            if ( $i['card']['type'] == 1 )
                $i['card']['type_text'] = '个人';
            elseif ( $i['card']['type'] == 2 )
                $i['card']['type_text'] = '公司';
            else
                $i['card']['type'] = '个人';

            $i['card']['bank_name'] = \Basic\Cnsts\BANK::CODE_ARR[ $i['card']['bank_code'] ];

            if ( $i['card']['bank_city'] > 0 )
                $i['card']['bank_city_text'] = $city_service->getAreaFullName($i['card']['bank_city']);
            else
                $i['card']['bank_city_text'] = '';

            // 状态样式
            $i['status_text'] = USER_FINANCE::WITHDRAW_STATUS_ARR[ (string)$i['status'] ];

    $head = array('ID', '提现时间', '提现金额', '账户类型', '提现银行', '开户人', '支行名称', '开户地', '银行卡号', '结算状态', '结算时间');
            $row = [
                $i['id'],
                $i['ctime'],
                $i['amount'],
                iconv('utf-8', 'gb2312', $i['card']['type_text']),
                iconv('utf-8', 'gb2312', $i['card']['bank_name']),
                iconv('utf-8', 'gb2312', $i['card']['name']),
                iconv('utf-8', 'gb2312', $i['card']['bank_branch']),
                iconv('utf-8', 'gb2312', $i['card']['bank_city_text']),
                $i['card']['card_no'],
                iconv('utf-8', 'gb2312', $i['status_text']),
                $i['settle_time'],
            ];
            fputcsv($fp, $row);
        }
    }



    /**
     * 油卡交易记录查询
     */
    public function gasIndex() {
        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);

        $cond = $this->prepareSearchCond(array('search_ctime_from', 'search_ctime_to', 'search_certain_id', 'search_id',
               'search_account', 'search_telephone', 'search_type'));

        /* @var \Basic\Model\UserGasLogModel $log_model */
        $log_model = D('Basic/UserGasLog');

        /* 非全国网用户只能查看其所在渠道的工单 */
//        if ( $this->_manager['agent_id'] > 0 ) {
//            $cond['search_agent_id'] = $this->_manager['agent_id'];
//        }
        $ret = $log_model->searchLog($cond, $curr_page, $per_page);
        //print_r($ret);exit;
        foreach ( $ret['data'] as &$i ) {
            $i['type_text'] = USER_FINANCE::GAS_TYPE_ARR[$i['type']];

        }
//p($ret['data']);die;
        $page_service = new PageService($ret['count'], $per_page);
        $page_nav = $page_service->show();

        $text = $this->_getTotal($ret['data']);
        $this->assignAll($cond);
        $this->assignAll([
            'title'         => '油卡交易列表',
            'type_arr'      => USER_FINANCE::GAS_TYPE_ARR,
            'list'          => $ret['data'],
            'page_nav'      => $page_nav,
            'text'          => $text,
        ]);
        $this->display('user_gas_list');
    }

    private function _getTotal($data) {
        $list = [];
        foreach ($data as $v) {
            $list[] = $v['type_text'];
        }
        $list_by = array_merge(array_unique($list));
        $money = [];
        foreach ($list_by as $k=>$v) {
            foreach ($data as $vv) {
                if ($vv['type_text'] == $v) {
                    $money[$k]['type'] = $v;
                    $money[$k]['total'] += $vv['add_money'];
                }
            }
        }
        $text = '';
        foreach ($money as $v) {
            $text .= $v['type'] . '：' . sprintf("%.2f", $v['total']) . '元。';
        }
        return $text;
    }
    /**
     * 导出油卡交易记录
     */
    public function exportGasRecords() {
        // 先查看交易记录总数是否超过导出限制
        $max_export_record_num = 10000;
        $per_page = 1000;
        $curr_page = 1;
        $cond = $this->prepareSearchCond(array('search_ctime_from', 'search_ctime_to', 'search_certain_id', 'search_id',
                                               'search_account', 'search_telephone', 'search_type'));

        /* @var \Basic\Model\UserGasLogModel $log_model */
        $log_model = D('Basic/UserGasLog');

        /* 非全国网用户只能查看其所在渠道的工单 */
//        if ( $this->_manager['agent_id'] > 0 ) {
//            $cond['search_agent_id'] = $this->_manager['agent_id'];
//        }
        $ret = $log_model->searchLog($cond, $curr_page, $per_page);
        if ( $ret['count'] > $max_export_record_num ) {
            $this->admin_error('导出记录数超过上限，请缩小时间范围分批导出！');
            return;
        }

        $filename = '油卡交易记录.csv';

        // 输出Excel文件头
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        header('Cache-Control: max-age=0');

        // 打开PHP文件句柄，php://output 表示直接输出到浏览器
        $fp = fopen('php://output', 'a');

        // 输出Excel列名信息
        $head = array('ID', '时间', '运单编号', '类型', '金额', '用户账号', '用户手机');
        foreach ($head as $i => $v) {
            // CSV的Excel支持GBK编码，一定要转换，否则乱码
            $head[$i] = iconv('utf-8', 'gb2312', $v);
        }
        // 将数据通过fputcsv写到文件句柄
        fputcsv($fp, $head);

        // 输出数据内容
        while (1) {
            $this->_doExportGasRecords($fp, $ret['data']);
            if ( $curr_page >= $ret['page_number'] )
                break;

            $ret = $log_model->searchLog($cond, ++$curr_page, $per_page);
        }

        // 关闭句柄
        fclose($fp);
    }

    /**
     * 分批导出油卡交易记录
     * @param $fp
     * @param $data
     */
    protected function _doExportGasRecords($fp, $data) {
        foreach ( $data as $k => $i ) {
            $row = [
                        $i['id'],
                        $i['ctime'],
                        $i['type'] == 10 ? $i['certain_id'] : '',
                        iconv('utf-8', 'gb2312', USER_FINANCE::GAS_TYPE_ARR[$i['type']]),
                        $i['add_money'],
                        iconv('utf-8', 'gb2312', $i['account']),
                        $i['telephone'],
            ];
            fputcsv($fp, $row);
        }
    }

    /**
     * 油卡交易记录查询
     */
    public function gasWithdrawIndex() {
        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);

        $cond = $this->prepareSearchCond(array('search_ctime_from', 'search_ctime_to', 'search_status', 'search_card_no', 'search_id',
                                               'search_account', 'search_telephone'));
        $cond['search_status'] = I('search_status/s') != '' ? I('search_status/s') : '';

        /* @var \Basic\Model\UserGasWithdrawLogModel $withdraw_log_model */
        $withdraw_log_model = D('Basic/UserGasWithdrawLog');

        /* @var \Basic\Model\PaymentModel $payment_model */
        $payment_model = D('Basic/Payment');

        /* 非全国网用户只能查看其所在渠道的工单 */
        $ret = $withdraw_log_model->searchLog($cond, $curr_page, $per_page);
        //print_r($ret);exit;
        foreach ( $ret['data'] as &$i ) {
            $card_arr = json_decode($i['cards'], TRUE);

            // 将每张油卡作为单独的记录存储
            $row = $i;
            unset($row['cards']);

            // 状态样式
            $row['status_text'] = USER_FINANCE::GAS_WITHDRAW_STATUS_ARR[ (string)$row['status'] ];
            if ( $row['status'] < 0 )
                $row['status_color'] = 'my-red';
            elseif ( $row['status'] == 1 )
                $row['status_color'] = 'my-green';

            // 支付信息
            if ( $row['payment_id'] > 0 ) {
                $payment = $payment_model->getById($row['payment_id']);
                $row['payment_op_type'] = USER_FINANCE::PAY_TYPE_ARR[ $payment['op_type'] ];
                $row['payment_out_trade_no'] = $payment['out_trade_no'];
            } else {
                $row['payment_op_type'] = '';
                $row['payment_out_trade_no'] = '';
            }

            $i = [];
            foreach ( $card_arr as $k => $c ) {
                $row['card_no'] = $c['card'];
                $row['card_money'] = $c['money'];
                $row['card_count'] = count($card_arr); // 油卡张数

                $i[] = $row;
            }
        }
        //print_r($ret['data']);exit;

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav = $page_service->show();
//p($ret['data']);die;
        $text = $this->_getTotalGasDraw($ret['data']);
        $this->assignAll($cond);
        $this->assignAll([
            'title'         => '油卡提现记录',
            'type_arr'      => USER_FINANCE::GAS_TYPE_ARR,
            'list'          => $ret['data'],
            'page_nav'      => $page_nav,
            'express_company_arr' => \Basic\Cnsts\EXPRESS::COMPANY_ARR,
            'text' => $text,
        ]);
        $this->display('user_gas_withdraw_list');
    }

    private function _getTotalGasDraw($data) {
        $list = [];
        foreach ($data as $v) {
            $list[] = $v[0]['status_text'];
        }
        $list_by = array_merge(array_unique($list));
        $money = [];
        foreach ($list_by as $k=>$v) {
            foreach ($data as $vv) {
                if ($vv[0]['status_text'] == $v) {
                    $money[$k]['type'] = $v;
                    $money[$k]['total'] += $vv[0]['amount'];
                }
            }
        }
        $text = '';
        foreach ($money as $v) {
            $text .= $v['type'] . '：' . sprintf("%.2f", $v['total']) . '元。';
        }
        return $text;
    }

    /**
     * 绑定油卡
     */
    public function gasBindCardNo() {
        $id = I('id/d', 0);
        if ( !$id ) {
            $this->admin_error('参数不正确！');
            return;
        }

        $no = I('no/d', 0);
        $card_no = I('card_no');
        if ( empty($card_no) ) {
            $this->admin_error('参数不正确！');
            return;
        }

        /* @var \Basic\Service\UserFinanceService $finance_service */
        $finance_service = D('Basic/UserFinance', 'Service');
        $ret = $finance_service->bindGasCard($id, $no, $card_no);
        if ( $ret == -10 ) {
            $this->admin_error('提现记录不存在！');
            return;
        } elseif ( $ret == -11 ) {
            $this->admin_error('油卡数据为空！');
            return;
        } elseif ( $ret < 0 ) {
            $this->admin_error('参数不正确！');
            return;
        }

        $this->admin_success('绑定油卡成功！');
    }

    /**
     * 寄送油卡
     */
    public function gasMailCard() {
        $id = I('id/d', 0);
        if ( !$id ) {
            $this->admin_error('参数不正确！');
            return;
        }

        $express_company = I('express_company');
        $express_order = I('express_order');
        if ( empty($express_order) ) {
            $this->admin_error('快递单号不能为空！');
            return;
        }

        /* @var \Basic\Service\UserFinanceService $finance_service */
        $finance_service = D('Basic/UserFinance', 'Service');
        $ret = $finance_service->expressGasCard($id, $express_company, $express_order, $this->_manager_id);
        if ( $ret == -10 ) {
            $this->admin_error('提现记录不存在！');
            return;
        } elseif ( $ret == -11 ) {
            $this->admin_error('油卡数据为空！');
            return;
        } elseif ( $ret == -12 ) {
            $this->admin_error('请先绑定油卡！');
            return;
        } elseif ( $ret <  0 ) {
            $this->admin_error('系统错误！');
            return;
        }

        // 发送push消息
        $withdraw_log = $finance_service->getGasWithdrawLog($id);
        /* @var \Basic\Service\SendNoticeService $send_service */
        $send_service = D('Basic/SendNotice', 'Service');
        $send_service->addNotice($withdraw_log['uid'], 'withdraw_oil_fee_status', ['withdraw_status' => '已寄送']);

        $this->admin_success('寄送油卡成功！');
    }

    /**
     * 取消油卡提现
     */
    public function gasCancelWithdraw() {
        $id = I('id/d', 0);
        if ( !$id ) {
            $this->admin_error('参数不正确！');
            return;
        }

        /* @var \Basic\Service\UserFinanceService $finance_service */
        $finance_service = D('Basic/UserFinance', 'Service');
        $ret = $finance_service->cancelGasWithdraw($id, $this->_manager_id);
        if ( $ret == -3 ) {
            $this->admin_error('提现记录不存在或者状态不正确！');
            return;
        } elseif ( $ret < 0 ) {
            $this->admin_error('系统错误！error:'.$ret);
            return;
        }

        $this->admin_success('取消提现成功！');
    }

    /**
     * 导出油卡提现记录
     */
    public function exportGasWithdrawRecords() {
        // 先查看交易记录总数是否超过导出限制
        $max_export_record_num = 10000;
        $per_page = 1000;
        $curr_page = 1;
        $cond = $this->prepareSearchCond(array('search_ctime_from', 'search_ctime_to', 'search_status', 'search_card_no', 'search_id',
                                               'search_account', 'search_telephone'));
        $cond['search_status'] = I('search_status/s') != '' ? I('search_status/s') : '';

        /* @var \Basic\Model\UserGasWithdrawLogModel $withdraw_log_model */
        $withdraw_log_model = D('Basic/UserGasWithdrawLog');

        $ret = $withdraw_log_model->searchLog($cond, $curr_page, $per_page);
        if ( $ret['count'] > $max_export_record_num ) {
            $this->admin_error('导出记录数超过上限，请缩小时间范围分批导出！');
            return;
        }
        //print_r($ret);exit;

        $filename = '油卡提现记录.csv';

        // 输出Excel文件头
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        header('Cache-Control: max-age=0');

        // 打开PHP文件句柄，php://output 表示直接输出到浏览器
        $fp = fopen('php://output', 'a');

        // 输出Excel列名信息
        $head = array('ID', '提现时间', '提现金额', '油卡账户', '状态', '用户账号', '用户手机', '邮寄地址', '收件人', '快递公司', '快递单号', '支付方式');
        foreach ($head as $i => $v) {
            // CSV的Excel支持GBK编码，一定要转换，否则乱码
            $head[$i] = iconv('utf-8', 'gb2312', $v);
        }
        // 将数据通过fputcsv写到文件句柄
        fputcsv($fp, $head);

        // 输出数据内容
        while (1) {
            $this->_doExportGasWithdrawRecords($fp, $ret['data']);
            if ( $curr_page >= $ret['page_number'] )
                break;

            $ret = $withdraw_log_model->searchLog($cond, ++$curr_page, $per_page);
        }

        // 关闭句柄
        fclose($fp);
    }

    /**
     * 分批导出油卡提现记录
     * @param $fp
     * @param $data
     */
    protected function _doExportGasWithdrawRecords($fp, $data) {
        /* @var \Basic\Model\PaymentModel $payment_model */
        $payment_model = D('Basic/Payment');

        foreach ( $data as $k => $i ) {
            $card_arr = json_decode($i['cards'], TRUE);

            // 状态
            $i['status_text'] = USER_FINANCE::GAS_WITHDRAW_STATUS_ARR[ (string)$i['status'] ];

            // 支付信息
            if ( $i['payment_id'] > 0 ) {
                $payment = $payment_model->getById($i['payment_id']);
                $i['payment_op_type'] = USER_FINANCE::PAY_TYPE_ARR[ $payment['op_type'] ];
                $i['payment_out_trade_no'] = $payment['out_trade_no'];
            } else {
                $i['payment_op_type'] = '';
                $i['payment_out_trade_no'] = '';
            }

            //$i = [];
            foreach ( $card_arr as $n => $c ) {
                $row = [
                    $i['id'],
                    $i['ctime'],
                    $c['money'],
                    $c['card'],
                    iconv('utf-8', 'gb2312', $i['status_text']),
                    iconv('utf-8', 'gb2312', $i['account']),
                    $i['telephone'],
                    iconv('utf-8', 'gb2312', $i['mail_address']),
                    iconv('utf-8', 'gb2312', $i['mail_user']),
                    iconv('utf-8', 'gb2312', $i['express_company']),
                    $i['express_order'],
                    iconv('utf-8', 'gb2312', $i['payment_op_type'])
                ];
                fputcsv($fp, $row);
            }
        }
    }


}