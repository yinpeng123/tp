<?php

return [
    'SITE_NAME'         => 'UP-PLAN',
    'SYS_NAME'          => '管理后台',

    'TOKEN_ON'          => true,  // 是否开启令牌验证 默认关闭
    'TOKEN_NAME'        => '_form_token_',    // 令牌验证的表单隐藏字段名称，默认为__hash__
    'TOKEN_TYPE'        => 'md5',  //令牌哈希验证规则 默认为MD5
    'TOKEN_RESET'       => true,  //令牌验证出错后是否重置令牌 默认为true

    // 模板替换
    'TMPL_PARSE_STRING'  => array(
        //'__JS__'     => '/Public/JS/', // 增加新的JS类库路径替换规则
        //'__UPLOAD__' => '/Uploads', // 增加新的上传路径替换规则
    ),

    'URL_PARAMS_BIND'       =>  true, // URL变量绑定到操作方法作为参数
    'URL_PARAMS_BIND_TYPE'  =>  1, // 设置参数绑定按照变量顺序绑定

    // session options
    // 新增 cookie_lifetime 用来设置 session.cookie_lifetime 的值，ThinkPHP默认使用 expire 来设置 session.cookie_lifetime 的值，
    // 这样如果设置会话过期时间(无访问时长)为30分钟，那么cookie的失效时间也是30分钟，30分钟后及时会话还没有过期也会因为cookie失效而无法正常访问
    // +zhongying 2017-06-16
    'SESSION_OPTIONS'       => array('name' => 'twpt_admin_sid', 'expire' => 3*60*60, 'cookie_lifetime' => 0),
    'SESSION_TYPE'          => 'Mysqli', //'db',
    'SESSION_TABLE'         => 'tp_session', // 必须设置成这样，如果不加前缀就找不到数据表，这个需要注意

    'COOKIE_PREFIX'         => 'twpt_admin_',

    'MAX_LOGIN_FAIL_NUMBER' => 5, // 单日登录失败的最大次数, 超过账号将被冻结

    'TABLE_PER_PAGE'        => 15, // 列表页表格每页显示的条数

];
