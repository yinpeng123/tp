<?php


use Phinx\Migration\AbstractMigration;

class UserCollect extends AbstractMigration
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $user_collect = $this->table('user_collect', ['signed' => false]);
        $user_collect->addColumn('uid', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => '被收藏人UID'])
            ->addColumn('fuid', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => '收藏人UID'])
            ->addColumn('type', 'integer', [
                    'length'    => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 1,
                    'comment'   => '收藏类型 1 货主 2 车主'])
            ->addColumn('create_time', 'datetime', [
                    'null'      => false,
                    'default'   => 'CURRENT_TIMESTAMP',
                    'comment'   => '时间'])
            ->addIndex(['uid','fuid','type'], ['unique' => true, 'name' => 'u-f-t'])
            ->create();

        $user_complain = $this->table('user_complain', ['signed' => false]);
        $user_complain->addColumn('uid', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => '被投诉人'])
            ->addColumn('fuid', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => '投诉人'])
            ->addColumn('type', 'integer', [
                    'length'    => 2,
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => '投诉类型 1货主 2车主'])
            ->addColumn('reason', 'integer', [
                    'length'    => 3,
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => '投诉原因 常量'])
            ->addColumn('remark', 'string', [
                    'length'    => 1000,
                    'default'   => '',
                    'null'      => false,
                    'comment'   => '备注'])
            ->addColumn('co_id', 'integer', [
                    'length'    => 11,
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => '相应货源或车源ID'])
            ->addColumn('status', 'integer', [
                    'length'    => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 1,
                    'comment'   => '状态'])
            ->addColumn('create_time', 'datetime', [
                    'null'      => false,
                    'default'   => 'CURRENT_TIMESTAMP',
                    'comment'   => '创建时间'])
            ->addColumn('update_time', 'datetime', [
                    'null'      => false,
                    'default'   => 'CURRENT_TIMESTAMP',
                    'update'    => 'CURRENT_TIMESTAMP',
                    'comment'   => '修改时间'])
            ->addIndex(['uid','fuid','type','co_id'], ['unique' => true, 'name' => 'u-f-t-c'])
            ->create();

        $user_evaluate = $this->table('user_evaluate', ['signed' => false]);
        $user_evaluate->addColumn('uid', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => '被评价人'])
            ->addColumn('fuid', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => '评价人'])
            ->addColumn('type', 'integer', [
                    'length'    => 2,
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => '投诉类型 1货主 2车主'])
            ->addColumn('score_1', 'integer', [
                    'length'    => 2,
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => ''])
            ->addColumn('score_2', 'integer', [
                    'length'    => 2,
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => ''])
            ->addColumn('score_3', 'integer', [
                    'length'    => 2,
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => ''])
            ->addColumn('score_4', 'integer', [
                    'length'    => 2,
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => ''])
            ->addColumn('remark', 'string', [
                    'length'    => 1000,
                    'default'   => '',
                    'null'      => false,
                    'comment'   => '备注'])
            ->addColumn('so_id', 'integer', [
                    'length'    => 11,
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => '运单ID'])
            ->addColumn('create_time', 'datetime', [
                    'null'      => false,
                    'default'   => 'CURRENT_TIMESTAMP',
                    'comment'   => '创建时间'])
            ->addIndex(['uid','fuid','type','so_id'], ['unique' => true, 'name' => 'u-f-t-s'])
            ->create();

        $user = $this->table('user');
        $user->addColumn('in_blacklist', 'integer', [
                            'length'    => 2,
                            'signed'    => false,
                            'null'      => false,
                            'default'   => 0,
                            'comment'   => '是否在行业黑名单 0 否 1是'])
            ->update();
    }
}
