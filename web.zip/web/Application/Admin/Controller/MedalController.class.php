<?php

namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\AuthService;
use Basic\ModelU\CenterModel;
use Admin\Service\PageService;

class MedalController extends AdminSessionController
{
    public function __construct()
    {
        parent::__construct();

    }

    public function index()
    {
        $curr_page = I('path.2/d', 1);
        $model = new CenterModel('u_medal');
        $where = [];
        $list = $model->getListBy($where, "*", "id desc", $curr_page, 15);
        $one=$two=[];
        foreach($list as $key){
            if($key['type']==1){
                $one[]=$key;
            }else{
                $two[]=$key;
            }
        }
        $info=[
            'one'=>$one,
            'two'=>$two,
        ];
        $this->assignAll(array(
            'title' => '勋章管理',
            'list' => $info,
        ));
        $this->display('index');
    }

    public function doAdd(){
        $model = new CenterModel('u_medal');
        $type= I("type");
        $id= I("id");
        $name=I("name");
        $color=I("color");
        $point=I("point");
        $pic=I("pic");
        $info=[
            'type'=>$type,
            'point'=>$point,
            'name'=>$name,
            'pic'=>$pic,
            'color'=>$color,
        ];
        if($id){
            $model->update($id,$info);
        }else{
            $model->add($info);
        }
        $this->ajaxResponse(0,"ok");
    }


    public function getOne(){
        $model = new CenterModel('u_medal');
        if(empty(I("id"))){
            $this->ajaxResponse(-1,"err");
        }
        $data= $model->get(I("id"));
        $this->ajaxResponse(0,"ok",$data);
    }

    public function delete($id){
        $model = new CenterModel('u_medal');
        if(empty($id)){
            $this->admin_error("错误的ID");
            exit;
        }
        $model->delete($id);
        $this->admin_success("ok");
    }
    //编辑，添加
    public function edit($id=0){
        $list=[];
        $title="增加勋章";
        if($id){
            $list= (new CenterModel("u_medal"))->get($id);
            $title="编辑勋章";
        }
        $this->assignAll(array(
            'title' => $title,
            'list' => $list,
        ));
        $this->display('edit');
    }
    //编辑，添加
    public function doEdit(){
        $model = new CenterModel('u_medal');
        $type= I("type");
        $id= I("id");
        $name=I("name");
        $color=I("color");
        $point=I("point");
        $pic=I("pic");
        $info=[
            'type'=>$type,
            'point'=>$point,
            'name'=>$name,
            'pic'=>$pic,
            'color'=>$color,
        ];
        if($id){
            $model->update($id,$info);
        }else{
            $model->add($info);
        }
        $this->admin_success("保存成功","/medal/index");
    }

}