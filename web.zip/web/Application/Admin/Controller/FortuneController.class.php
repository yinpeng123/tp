<?php

namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\AuthService;
use Basic\ModelU\CenterModel;
use Admin\Service\PageService;
use Basic\Service\FortuneService;

class FortuneController extends AdminSessionController
{
    public function __construct()
    {
        parent::__construct();

    }

    public function index()
    {
        $list = (new FortuneService())->allConstellation();
        $this->assignAll(array(
            'title' => '所有星座',
            'list' => $list,

        ));
        $this->display('index');
    }

    public function edit($id = 0,$day="")
    {
        $this->show($id);
    }

    public function show($id = 0)
    {
        $list = (new FortuneService())->allConstellation();

        $day = I("days", day());
        $info=$this->getDays($day,$id);
        $this->assignAll(array(
            'title' => $list[$id],
            'list' => $list,
            'day' => $day,
            'fid' => $id,
            'info'=>$info,

        ));

        $this->display('edit');
    }



    public function doAdd()
    {

        $days = I("d1");
        $type = I("type");
        $fid = I("fid");
        $model = new CenterModel("u_fortune");
        switch ($type) {
            case "2":
                $days = date('Y-m-d', (time() - ((date('w') == 0 ? 7 : date('w')) - 1) * 24 * 3600));
                break;
            case "3" :
                $days = date('Y-m-01', strtotime(date("Y-m-d")));
                break;

        }
        $where = [
            'days' => $days,
            'fid' => $fid,
            'type' => $type,
        ];
        $info = $this->paramPack($type);

        if ($model->getBy($where)) {
            $model->updateBy($where, $info);
        } else {
            $model->add(array_merge($where, $info));
        }
        $this->admin_success("添加成功");
    }


//删除所有
    public function delete()
    {
        $ids = I("ids");
        if (is_array($ids)) {
            $where = 'id in(' . implode(',', $ids) . ')';
        } else {
            $where = 'id=' . $ids;
        }  //dump($where);
        M("u_bbs")->where($where)->delete();
        $this->admin_success("删除成功");
    }


    //月，周，日数据组合
    private function paramPack($type)
    {
        $info = [];
        $score = [
            "whole" => I("d2"),
            "learning" => I("d3"),
            "feeling" => I("d5"),
            "finance" => I("d4"),
            "healthy" => I("d6"),
            "luckyNumber" => I("d7"),
            "luckyColor" => I("d8"),
        ];
        switch ($type) {
            case 1:
                $content = [
                    'total' => I("d9")
                ];
                $info = [
                    'total_score' => I("d2"),
                    'score_info' => t_json_encode($score),
                    'content' => t_json_encode($content)
                ];
                break;
            case 2:
                $content = [
                    'whole' => I("c1"),
                    "learning" => I("c2"),
                    "feeling" => I("c3"),
                    "finance" => I("c4"),
                    "healthy" => I("c5"),
                ];
                $info = [
                    'total_score' => I("d2"),
                    'score_info' => t_json_encode($score),
                    'content' => t_json_encode($content)
                ];
                break;
            case 3:
                $content = [
                    'whole' => I("c1"),
                    "learning" => I("c2"),
                    "feeling" => I("c3"),
                    "finance" => I("c4"),
                    "healthy" => I("c5"),
                    "secret" => I("c6"),
                ];
                $info = [
                    'total_score' => I("d2"),
                    'score_info' => t_json_encode($score),
                    'content' => t_json_encode($content)
                ];
                break;

        }
        if(empty($info['total_score'])){
            $this->admin_error("请填写完整信息");
            exit;
        }
        return $info;
    }


    private function getDays($day,$fid)
    {

        $wdays = date('Y-m-d', (strtotime($day) - ((date('w',strtotime($day)) == 0 ? 7 : date('w',strtotime($day))) - 1) * 24 * 3600));
        $mdays = date('Y-m-01', strtotime(date("Y-m-d", strtotime($day))));
        $model = new CenterModel("u_fortune");
        $dwhere = [
            'fid'=>$fid,
            'type'=>1,
            'days'=>$day
        ];
        $dinfo=$model->getBy($dwhere);
        if($dinfo){
            $dinfo['score_info']=t_json_decode($dinfo['score_info']);
            $dinfo['content']=t_json_decode($dinfo['content']);
        }
        $wwhere = [
            'fid'=>$fid,
            'type'=>2,
            'days'=>$wdays
        ];
        $winfo=$model->getBy($wwhere);
        if($winfo){
            $winfo['score_info']=t_json_decode($winfo['score_info']);
            $winfo['content']=t_json_decode($winfo['content']);
        }
        $where = [
            'fid'=>$fid,
            'type'=>3,
            'days'=>$mdays
        ];
        $minfo=$model->getBy($where);
        if($minfo){
            $minfo['score_info']=t_json_decode($minfo['score_info']);
            $minfo['content']=t_json_decode($minfo['content']);
        }
        $info=[
            'days'=>$dinfo,
            'week'=>$winfo,
            'month'=>$minfo,
        ];
        return $info;
    }


}