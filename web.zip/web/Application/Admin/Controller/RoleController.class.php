<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\RoleService;
use Basic\Cnsts\AGENT_CHARGE;
use Admin\Service\PageService;
use Basic\Cnsts\DICT;
use Admin\Service\ManagerService;
use Basic\Model\AgentModel;
use Basic\ModelU\CenterModel;
use Basic\Service\AgentChargeService;
use Admin\Cnsts\MANAGER;

class RoleController extends AdminSessionController
{

    private $__role_model = null;
    private $__privilege_model = null;
    private $__manager_service = null;
    private $__manager_model = null;
    private $__agent_model = null;

    public function __construct()
    {
        parent::__construct();

        $this->__role_model      = D('Role');
        $this->__privilege_model = D('Menu');
        $this->__manager_model   = D('Manager');
        $this->__agent_model   = D('Basic/Agent');
        $this->__manager_service = D('Manager', 'Service');

        // 权限检查
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::SYS_ROLE  ) ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }
    }

    public function index()
    {
        $_manager = session('manager');
//        p($_manager);
        $name      = I('name');
        $id        = I('id');
        $active    = I('active');
        $privilege = I('privilege');

        if (!empty($name)) {
            $cond['name'] = ['like', '%' . $name . '%'];
        }
        if (!empty($id)) {
            $cond['id'] = ['eq', $id];
        }
        if (!empty($active)) {
            $cond['active'] = ['eq', $active];
        }
        if (!empty($privilege)) {
            $cond['privilege'] = ['eq', $privilege];
        }

        // 过滤非admin的渠道搜索请求，防止url直接传参
        if ($this->_manager_id == 1) {
            $select_agent_id = I('select_agent_id');
            if (!empty($select_agent_id)) {
                $cond['agent_id'] = ['eq', $select_agent_id];
            }
        } else {
            if ($_manager['agent_id'] != 0) {
                $cond['agent_id'] = ['eq', $_manager['agent_id']];
            }
        }

        //分页
        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        $ret       = $this->__role_model->searchRoleList($cond, $curr_page, $per_page);
        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();
        $menuModel= new CenterModel("admin_menu");
        //处理权限
        for ($i = 0; $i < count($ret['data']); $i++) {
            $privilege_names = '';
            $privilege_arr   = json_decode($ret['data'][$i]['privileges'], true);

            for ($j = 0; $j < count($privilege_arr); $j++) {
                // 产品功能名称

                $privilege_name = $menuModel->get($privilege_arr[$j]);
                $privilege_names .= $privilege_name['name'] . '/';
            }
            $ret['data'][$i]['privileges'] = $privilege_names;
        }

        //处理渠道
        for( $i=0; $i<count($ret['data']); $i++) {
            if($ret['data'][$i]['agent_id'] != 0) {
                $agent_info = $this->__agent_model->getAgentById($ret['data'][$i]['agent_id']);
                $ret['data'][$i]['agent_name'] = $agent_info['name'];
            } else {
                $ret['data'][$i]['agent_name'] = '全国网';
            }
        }
        $agent_list = $this->__agent_model->getAllAgentList($fields = NULL, $where = [] );
//        p($agent_list);die;
        $this->assignAll([
            'title'       => '系统角色',
            'list'        => $ret['data'],
            'name'        => $name,
            'code'        => $id,
            'active'      => $active,
            'privilege'   => $privilege,
            'active_list' => DICT::ACTIVE_LIST,
            'page_nav'    => $page_nav,
            'manager_id' => $this->_manager_id,
            'agent_list' => $agent_list,
            'select_agent_id' => $select_agent_id,
        ]);
        $this->display('role_index');
    }


    public function addRole()
    {
        $data = I('');
//        p($data);die;
        // 渠道列表
        /** @var AgentModel $agent_model */
        $agent_model = D('Basic/Agent', 'Model');
        $agent_list = $agent_model->getAllAgentList('id,name');
        $this->assign('agent_list', $agent_list);

        //当前登录的管理员信息
        $_manager = session('manager');
//        p($_manager);die;
//        if($_manager['role_id'] == 0 && $_manager['agent_id'] == 0 && $_manager['manager_id'] != 1) {
//            $privilege_list = array();
//        }

        if($_manager['role_id'] != 0   ) {
            //权限列表(渠道管理员享有的权限)
            $privilege_list = $this->getPrivilegeList($_manager['role_id']);
//            p($privilege_list);die;
        } else  {
            $privilege_list = [];
        }
   // p($privilege_list);die;

        if ($data['act'] != 'edit') {
            $privilege_checked = [];

            //查询渠道名称
            $agent_info = $this->__agent_model->getAgentById($_manager['agent_id']);
            $privilege_list= (new  CenterModel("admin_menu"))->getListBy(['is_delete'=>0]);
            $this->assignAll([
                'agent_name'        =>  $agent_info['name'],
                'manager_agent_id'          =>  $_manager['agent_id'],
                'form_action'       => '/Role/doAddRole',
                'privilege_list'    => $privilege_list,
                'privilege_checked' => $privilege_checked,
                'act'                => 'add',
            ]);
        } else {
//            p($data);die;
            $role_id   = $data[0];
            $role_info = $this->__role_model->get($role_id);
//p(department_arr);die;
            /** @var RoleService $role_service */
            $role_service = D('Menu', 'Service');
            $privilege_list= (new  CenterModel("admin_menu"))->getListBy(['is_delete'=>0]);

            $privilege_checked = json_decode($role_info['privileges'], true);
               $this->assignAll([
                'manager_agent_id'  =>  $_manager['agent_id'],
                'agent_name'        =>  0,
                'agent_id'          =>  $role_info['agent_id'],
                'form_action'       => '/Role/doAddRole',
                'privilege_list'    => $privilege_list,
                'role_info'         => $role_info,
                'privilege_checked' => $privilege_checked,
                'act'               => 'edit',
            ]);
        }
        $this->display('role_add');
    }

    //角色权限
    private function getPrivilegeList($role_id) {
        /** @var RoleService $role_service */
        $role_service = D('Role', 'Service');
        $list = $role_service->getPrivilegeList($role_id);
        return $list;
    }


    public function doAddRole()
    {
        $data = I('');
//        p($data);die;
        $str        = substr($data['product_ids'], 0, strlen($data['product_ids']) - 1);
        $privileges = explode(',', $str);
        $_manager   = session('manager');
//        p($_manager);die;


        if ($data['act'] != 'edit') {

            if (empty($data['active'])) {
                $active = 'N';
            } else {
                $active = $data['active'];
            }
            // 区分admin跟渠道管理员
            if (!empty($data['agent_id'])) {
                $agent_id = $data['agent_id'];
            } else {
                $agent_id = $_manager['agent_id'];
            }
            $fields = [
                'name'       => $data['name'],
                'active'     => $active,
                'privileges' => json_encode($privileges),
                'agent_id'   => $agent_id,
                'creator'    => $_manager['manager_id'],
                'ctime'      => date('Y-m-d H:i:s'),
            ];

            $this->__role_model->add($fields);
            $this->__manager_service->addOperLog([
                'manager_id' => $this->_manager_id,
                'action'     => 'addRole',
                'desc'       => "添加系统角色",
            ]);
            $this->admin_success('添加角色成功！', U('/Role/index'));
        } else {
            if (empty($data['active'])) {
                $active = 'N';
            } else {
                $active = $data['active'];
            }

            if($_manager['agent_id'] != 0) {
                /** @var AgentModel $agent_model */
                $agent_model = D('Basic/Agent', 'Model');
                $aid = $agent_model->getId($data['edit_role_agent']);
//            p($aid);die;
                $fields = [
                    'name'       => $data['name'],
                    'active'     => $active,
                    'agent_id' => $aid,
                    'privileges' => json_encode($privileges),
                    'mender'     => $_manager['manager_id'],
                    'mtime'      => date('Y-m-d H:i:s'),
                ];
            } else {
                $fields = [
                    'name'       => $data['name'],
                    'active'     => $active,
                    'agent_id' => $data['agent_id'],
                    'privileges' => json_encode($privileges),
                    'mender'     => $_manager['manager_id'],
                    'mtime'      => date('Y-m-d H:i:s'),
                ];
            }

            $this->__role_model->update($data['role_id'], $fields);
            $this->__manager_service->addOperLog([
                'manager_id' => $this->_manager_id,
                'action'     => 'addRole',
                'desc'       => "编辑系统角色",
            ]);
            $this->admin_success('编辑角色成功！');
        }

    }

    public function addUser()
    {
        $data = I('');
//        p($data);die;
        $role_info = $this->__role_model->get($data[0]);
//p($role_info);die;
        $where        = [
            'agent_id' => $role_info['agent_id'],
            'role_id'  => ['eq', 0],
        ];
//        p($where);die;
        $manager_list = $this->__manager_model->getList($where);
//        p($manager_list);die;

        //处理数据（1.去除超级管理员2.去除is_delete为Y的数据）
        for($i=0; $i<count($manager_list); $i++) {
            if(($manager_list[$i]['manager_id'] == 1) || ($manager_list[$i]['is_delete'] == 'Y')) {
                array_splice($manager_list, $i, 1);
            }
        }
//        p($manager_list);die;
        //处理数据（没有角色的数据）
        $manager_list_left = [];
        for ($i = 0; $i < count($manager_list); $i++) {
            $manager_list_left[$i]['id']   = $manager_list[$i]['manager_id'];
            if($manager_list[$i]['department'] == 0) {
                $manager_list_left[$i]['name'] = '';
            } else {
                $manager_list_left[$i]['name'] = MANAGER::DEPARTMENT_ARR[$manager_list[$i]['department']];
            }
            $manager_list_left[$i]['time'] = $manager_list[$i]['realname'];
        }
//        p($manager_list_left);
        $where             = [
            'agent_id' => $role_info['agent_id'],
            'role_id'  => $data[0],
        ];
        $manager_list_role = $this->__manager_model->getList($where);

        //已经有角色的数据
        $manager_list_right = [];
        for ($i = 0; $i < count($manager_list_role); $i++) {
            $manager_list_right[$i]['id']   = $manager_list_role[$i]['manager_id'];
            if($manager_list[$i]['department'] == 0) {
                $manager_list_right[$i]['name'] = '';
            } else {
                $manager_list_right[$i]['name'] = MANAGER::DEPARTMENT_ARR[$manager_list[$i]['department']];
            }
            $manager_list_right[$i]['time'] = $manager_list_role[$i]['realname'];
        }

        $this->assignAll([
//            'manager_list_left'  => json_encode($manager_list_left),
//            'manager_list_right' => json_encode($manager_list_right),
            'role_info'          => $role_info,
            'title'              => '角色添加用户',
            'form_action'        => '/Role/doAddUser',
            'department_allot_to' => I('dep'),
            'department_arr'    => MANAGER::DEPARTMENT_ARR,
        ]);
        $this->display('user_add');
    }

    public function doAddUser()
    {
//        p($_POST);die;
        $right_arr = explode(',', $_POST['right']);
        $left_arr  = explode(',', $_POST['left']);

//        p($right_arr);
        $fields = [
            'role_id' => $_POST['role_id'],
        ];
        for ($i = 0; $i < count($right_arr); $i++) {
            $this->__manager_model->updateManagerById($right_arr[$i], $fields);
        }

        $field = [
            'role_id' => 0,
        ];
        for ($i = 0; $i < count($left_arr); $i++) {
            $this->__manager_model->updateManagerById($left_arr[$i], $field);
        }

        $this->__manager_service->addOperLog([
            'manager_id' => $this->_manager_id,
            'action'     => 'doAddUser',
            'desc'       => "添加用户",
        ]);
        redirect(U('role/addUser/' . $_POST['role_id'], '', '') . '?dep='.$_POST['department_allot_to']);
//        $this->admin_success('添加用户成功');
    }

    //角色权限
    public function getPrivList($role_id) {
        /** @var RoleService $role_service */
        $role_service = D('Role', 'Service');
        $list = $role_service->getPrivilegeList($role_id);
        $this->ajaxReturn($list);
    }
    public function delRole($id=0){
        if($id==0){
            $this->error("不能删除默认管理员角色");
        }
        (new CenterModel("admin_role"))->delete($id);
        $this->admin_success('ok');
    }

    }