<?php
namespace Admin\Controller;

use Basic\Service\CityService;
use Admin\Model\ManagerModel;
use Admin\Cnsts\MANAGER;

class ApiController extends AdminSessionController {

    public function __construct() {
        parent::__construct();
    }

    // 获取城市列表的ajax接口
    public function city($parent_id = -1) {
        $city_model = D('Basic/City');
        $province_list = $city_model->getCityList($parent_id);
        //print_r($province_list);
        $this->ajaxReturn($province_list);
    }

    public function getCities(){
        /** @var  CityService $city_service*/
        $city_service = D('Basic/City','Service');
        $parent_ids = I('parent_ids');
        if(is_array($parent_ids)) {
            $where=[
                'parent_id' => ['in',$parent_ids],
            ];
        } else {
            $parent_ids = $parent_ids ? : -1;
            $where=[
                'parent_id' => $parent_ids,
            ];
        }
        $order_by = 'parent_id';
        $cities = $city_service->getCitiesByWhere($where, $order_by);
        $this->doResponse(\Common\Cnsts\ERRNO::SUCCESS,'success',$cities);
    }

    // 上传图片接口
    public function ajaxUploadImage() {
        echo '{}';
    }

    // 删除图片接口
    public function ajaxDeleteImage() {
        echo '{}';
    }


    private function __searchUser($certain_id, $uid = 0) {
        /* @var \Admin\Service\UserService $user_service */
        $user_service = D('User', 'Service');
        /* @var \Admin\Model\UserModel $user_model */
        $user_model = D('User');

        // 如果设置了uid参数值, 则需检查certain_id的值是否与该uid用户信息一致,
        // 如果一致则返回该用户信息, 不一致则根据certain_id来查询用户信息
        if ( $uid > 0 ) {
            $user = $user_model->getUserById($uid);
            if ( !empty($user) && ($certain_id == $user['telephone'] || $certain_id == $user['account'] || $certain_id == $user['net_no']) ) {
                return [1, 'success', $user];
            }
        }

        return $user_service->searchUserProfile($certain_id);
    }

    // 根据网号、账号或手机号查询用户信息
    public function searchUserProfile($certain_id) {
        if ( !$certain_id ) {
            $this->ajaxResponse(-1, '参数不正确！');
            return;
        }

        // 查询用户信息
        $uid = I('uid/d');
        list($errno, , $user) = $this->__searchUser($certain_id, $uid);
        if ( $errno == 0 ) {
            $this->ajaxResponse(0, '用户不存在！');
            return;
        } elseif ( $errno > 1 ) {
            $this->ajaxResponse($errno, '查询到多条用户记录！');
            return;
        }

        // 渠道信息
        $agent = [];
        if ( $user['channel_id'] > 0 ) {
            $agent_model = D('Basic/Agent');
            $agent = $agent_model->getAgentById($user['channel_id']);
        }

        $register_source_arr = \Basic\Cnsts\DICT::REGISTER_SOURCE_LIST;
        $this->ajaxResponse(1, [
            'id'        => $user['id'],
            'user_name' => $user['user_name'],
            'telephone' => $user['telephone'],
            'account'   => $user['account'],
            'net_no'    => $user['net_no'],
            'agent_id'  => $agent ? $agent['id'] : 0,
            'agent_name'=> $agent ? $agent['name'] : '',
            'register_source'       => $user['register_source'],
            'register_source_text'  => $register_source_arr[ $user['register_source'] ],
            'phone1'    => $user['phone1'],
            'phone2'    => $user['phone2'],
            'phone3'    => $user['phone3'],
            'email'     => $user['email'],
            'channel_id'=> $user['channel_id'],
            'member_start_time'     => $user['member_start_time'],
            'member_end_time'       => $user['member_end_time'],
            'pc_member_start_time'  => $user['pc_member_start_time'],
            'pc_member_end_time'    => $user['pc_member_end_time']
        ]);

    }

    /**
     * 为添加、编辑工单提供查询用户信息的接口
     *
     * 参数:
     * $certain_type 查询字段的类型, 1:网号、用户名或手机号, 2:用户ID
     * $certain_id   查询字段的值
     * 或者
     * $uid          查询指定ID的用户信息
     */
    public function wsSearchUserProfile() {
        $certain_type = I('certain_type', 1);
        $certain_id = I('certain_id', 0);
        $uid = I('uid/d', 0);

        if ( $uid > 0 ) {
            $user = (new \Basic\Model\UserModel('slave', TRUE))->get($uid);
            if ( empty($user) ) {
                $this->ajaxResponse(0, '用户不存在！');
                return;
            }

        } else {
            if ( !$certain_id ) {
                $this->ajaxResponse(-1, '参数不正确！');
                return;
            }

            // 查询用户信息
            if ( $certain_type == 1 ) {
                list($errno, , $user) = (new \Admin\Service\UserService())->searchUserProfile($certain_id);
                if ( $errno == 0 ) {
                    $this->ajaxResponse(0, '用户不存在！');
                    return;
                } elseif ( $errno > 1 ) {
                    $this->ajaxResponse($errno, '查询到多条用户记录！');
                    return;
                }
            } else {
                $user = (new \Basic\Model\UserModel('slave', TRUE))->get($certain_id);
                if ( empty($user) ) {
                    $this->ajaxResponse(0, '用户不存在！');
                    return;
                }
            }
        }

        if ( $user['status'] == 0 ) {
            $this->ajaxResponse(0, '用户信息未填写完成！');
            return;
        }

        // 渠道信息
        $agent = [];
        if ( $user['channel_id'] > 0 ) {
            $agent_model = D('Basic/Agent');
            $agent = $agent_model->getAgentById($user['channel_id']);
        }

        $register_source_arr = \Basic\Cnsts\DICT::REGISTER_SOURCE_LIST;
        $this->ajaxResponse(1, [
            'id'        => $user['id'],
            'user_name' => $user['user_name'],
            'telephone' => $user['telephone'],
            'account'   => $user['account'],
            'net_no'    => $user['net_no'],
            'agent_id'  => $agent ? $agent['id'] : 0,
            'agent_name'=> $agent ? $agent['name'] : '',
            'register_source'       => $user['register_source'],
            'register_source_text'  => $register_source_arr[ $user['register_source'] ],
            'phone1'    => $user['phone1'],
            'phone2'    => $user['phone2'],
            'phone3'    => $user['phone3'],
            'email'     => $user['email'],
            'channel_id'=> $user['channel_id'],
            'member_start_time'     => $user['member_start_time'],
            'member_end_time'       => $user['member_end_time'],
            'pc_member_start_time'  => $user['pc_member_start_time'],
            'pc_member_end_time'    => $user['pc_member_end_time']
        ]);

    }

    // 获取用户的发票信息列表
    public function getUserTicketList($uid) {
        $ticket_service = D('Basic/TicketInfo', 'Service');
        $list = $ticket_service->getTicketList(['user_id' => $uid, 'status' => 1]);
//        $city_model = D('Basic/City');
//        foreach ( $list as &$i ) {
//            $i['province_name'] = $i['city_name'] = $i['district_name'] = '';
//            if ( $i['province'] > 0 ) {
//                $province = $city_model->getCity($i['province']);
//                $i['province_name'] = $province['name'];
//            }
//            if ( $i['city'] > 0 ) {
//                $city = $city_model->getCity($i['city']);
//                $i['city_name'] = $city['name'];
//            }
//            if ( $i['district'] > 0 ) {
//                $district = $city_model->getCity($i['district']);
//                $i['district_name'] = $district['name'];
//            }
//        }

        //print_r($list);
        $this->ajaxReturn($list);
    }

    // 获取用户的邮寄地址列表
    public function getUserMailAddressList($uid) {
        $address_model = D('Basic/Address');
        $list = $address_model->getAddressListByUserId(['user_id' => $uid]);
        $city_model_s = new \Basic\Model\CityModel('slave', TRUE);
        foreach ( $list as &$i ) {
            if ( $i['province'] ) {
                $p = $city_model_s->get($i['province']);
                $i['province_name'] = $p['name'];
            } else {
                $i['province_name'] = '';
            }

            if ( $i['city'] ) {
                $c = $city_model_s->get($i['city']);
                $i['city_name'] = $c['name'];
            } else {
                $i['city_name'] = '';
            }

            if ( $i['district'] ) {
                $d = $city_model_s->get($i['district']);
                $i['district_name'] = $d['name'];
            } else {
                $i['district_name'] = '';
            }

        }
        //print_r($list);
        $this->ajaxReturn($list);
    }

    // 获取渠道信息
    public function getAgentInfo($agent_id) {
        if ( !$agent_id ) {
            $this->ajaxResponse(-1, '参数不正确！');
            return;
        }

        $agent_service = D('Basic/Agent', 'Service');
        $agent = $agent_service->getAgentById($agent_id);
        if ( empty($agent) ) {
            $this->ajaxResponse(0, '渠道不存在！');
            return;
        }

        $this->ajaxResponse(1, $agent);
    }

    // 获取渠道的一级产品列表
    public function getAgentPrimeProductList($agent_id) {
        $product_model = D('Basic/Product');
        $prime_list = $product_model->getProductList();
        $prime_ids = array_column($prime_list, 'id');
        //print_r($prime_ids);

        $agent_service = D('Basic/Agent', 'Service');
        $agent = $agent_service->getAgentById($agent_id);
        $product_ids = json_decode($agent['product']);
        foreach ( $product_ids as &$id ) {
            $id = intval($id); // 格式转换
        }

        // 求交集
        $res = array_values(array_intersect($prime_ids, $product_ids));
        //print_r($res);

        // 获取产品的信息
        $list = [];
        foreach ( $prime_list as $p ) {
            if ( in_array($p['id'], $res) )
                $list[] = $p;
        }

        return $this->ajaxReturn($list);
    }

    // 获取渠道计费的信息列表
    public function getAgentChargeList($agent_id, $product_id = 0) {
        $ac_service = D('Basic/AgentCharge', 'Service');
        $cond = ['agent_id' => $agent_id, 'status' => '2'];
        if ( $product_id )
            $cond['product_id'] = $product_id;

        $usage = I('usage', '');
        if ( $usage )
            $cond['usage'] = $usage;

        $ad_category = I('ad_category', '');
        if ( $ad_category )
            $cond['ad_category'] = $ad_category;

        $ad_pos = I('ad_pos', '');
        if ( $ad_pos )
            $cond['ad_pos'] = $ad_pos;

        $ad_usage = I('ad_usage', '');
        if ( $ad_usage )
            $cond['ad_usage'] = $ad_usage;

        $list = $ac_service->getChargeListByCond($cond);
        foreach ( $list as &$i ) {
            if ( strlen($i['days']) > 2 ) {
                $day_arr = @json_decode($i['days'], true);
                $i['day_arr'] = $day_arr ?: [];
            } else {
                $i['day_arr'] = [];
            }
        }
        $this->ajaxReturn($list);
    }

    // 获取渠道的发票列表
    public function getAgentInvoiceList($agent_id) {
        if ( !$agent_id ) {
            $this->ajaxReturn([]);
        }

        $invoice_model = D('Basic/AgentInvoice');
        $list = $invoice_model->getInvoiceList(['agent_id' => $agent_id]);
        $this->ajaxReturn($list);
    }

    // 获取渠道的邮寄地址列表
    public function getAgentMailAddressList($agent_id) {
        $address_model = D('Basic/Address');
        $list = $address_model->getAddressListByUserId(['agent_id' => $agent_id]);
        $city_model_s = new \Basic\Model\CityModel('slave', TRUE);
        foreach ( $list as &$i ) {
            $p = $city_model_s->get($i['province']);
            $i['province_name'] = $p['name'];

            $c = $city_model_s->get($i['city']);
            $i['city_name'] = $c['name'];

            $d = $city_model_s->get($i['district']);
            $i['district_name'] = $d['name'];
        }
        $this->ajaxReturn($list);
    }

    //获取管理员接口
    public function getManagerList() {
        $department = $_POST['data'];
        $agent_id = $_POST['agent_id'];

        if($department != 0) {
            $where = [
                'department'    =>  $department,
                'agent_id'    =>  $agent_id,
                'role_id' => ['eq' , 0],
            ];
        } else {
            $where = [
                'agent_id'    =>  $agent_id,
                'role_id' => ['eq' , 0],
            ];
        }
        // 管理员列表
        /** @var ManagerModel $manager_model */
        $manager_model = D('Manager');

        $manager_list_all = $manager_model->getAllManagerList($where, 'manager_id, realname, department, is_delete');

        //处理管理员数据（1.去除manager_id=1的数据2.去除is_delete为Y 的数据3.去除role_id不为0的数据）
        for($i=0; $i<count($manager_list_all); $i++) {
            if(($manager_list_all[$i]['manager_id'] == 1) || ($manager_list_all[$i]['is_delete'] == 'Y')) {
                array_splice($manager_list_all, $i, 1);
            }
        }
//        p($manager_list_all);
        $manager_list_left = [];

        for ($i = 0; $i < count($manager_list_all); $i++) {
            $manager_list_left[$i]['id']   = $manager_list_all[$i]['manager_id'];
            if($manager_list_all[$i]['department'] == 0) {
                $manager_list_left[$i]['name'] = '';
            } else {
                $manager_list_left[$i]['name'] = MANAGER::DEPARTMENT_ARR[$manager_list_all[$i]['department']];
            }
            $manager_list_left[$i]['time'] = $manager_list_all[$i]['realname'];
        }
//        p($manager_list_left);

        //已有角色的用户
        if($department != 0) {
            $where = [
                'department'    =>  $department,
                'agent_id'    =>  $agent_id,
                'role_id' => ['neq' , 0],
            ];
        } else {
            $where = [
                'agent_id'    =>  $agent_id,
                'role_id' => ['neq' , 0],
            ];
        }

        $manager_list_role = $manager_model->getAllManagerList($where, 'manager_id, realname, department, is_delete');
        $manager_list_right = [];
        for ($i = 0; $i < count($manager_list_role); $i++) {
            $manager_list_right[$i]['id']   = $manager_list_role[$i]['manager_id'];
            if($manager_list_role[$i]['department'] == 0) {
                $manager_list_right[$i]['name'] = '';
            } else {
                $manager_list_right[$i]['name'] = MANAGER::DEPARTMENT_ARR[$manager_list_role[$i]['department']];
            }
            $manager_list_right[$i]['time'] = $manager_list_role[$i]['realname'];
        }
//        p($manager_list_right);
        $manager_list = [
            'left' => $manager_list_left,
            'right' => $manager_list_right,
        ];
        $this->ajaxReturn($manager_list);
    }


    public function getAssignManagerList()
    {
        $department = $_POST['data'];
        $agent_id = $_POST['agent_id'];

        if($department != 0) {
            $where = [
                'department'    =>  $department,
                'agent_id'    =>  $agent_id,
            ];
        } else {
            $where = [
                'agent_id'    =>  $agent_id,
            ];
        }
        // 管理员列表
        /** @var ManagerModel $manager_model */
        $manager_model = D('Manager');

        $manager_list_all = $manager_model->getAllManagerList($where, 'manager_id, realname, department, is_delete');

        //处理管理员数据（1.去除manager_id=1的数据2.去除is_delete为Y 的数据3.去除role_id不为0的数据）
        for($i=0; $i<count($manager_list_all); $i++) {
            if(($manager_list_all[$i]['manager_id'] == 1) || ($manager_list_all[$i]['is_delete'] == 'Y')) {
                array_splice($manager_list_all, $i, 1);
            }
        }
//        p($manager_list_all);
        $manager_list_left = [];
        $manager_list_right = [];
        for ($i = 0; $i < count($manager_list_all); $i++) {
            $manager_list_left[$i]['id']   = $manager_list_all[$i]['manager_id'];
            if($manager_list_all[$i]['department'] == 0) {
                $manager_list_left[$i]['name'] = '';
            } else {
                $manager_list_left[$i]['name'] = MANAGER::DEPARTMENT_ARR[$manager_list_all[$i]['department']];
            }
            $manager_list_left[$i]['time'] = $manager_list_all[$i]['realname'];
        }
//        p($manager_list_left);
        $manager_list = [
            'left' => $manager_list_left,
            'right' => $manager_list_right,
        ];
        $this->ajaxReturn($manager_list);
    }
}