<?php
namespace Client\Controller;

use Basic\Cnsts\DICT;
use Basic\Cnsts\VERSION_CONFIG;
use Basic\Service\UserService;
use Client\Service\OrderService;
use Common\Controller\CommonController;
use Basic\Service\SignService;

class OrderShareController extends CommonController {
    public function __construct() {
        parent::__construct();
    }

//    public function isCanViewDetail() {
//        $order_id = $this->req['order_id'];
//
//    }
    //分享的订单详情 @todo
    public function orderDetail() {

        /**
         * 检查签名
         */
        if (!SignService::checkSignature($this->req['signature'], $this->req['timestamp'], ['order_id' => $this->req['order_id'], 'type' => $this->req['type']])) {
            return false;
        }

        // return false;

        $order_id = $this->req['order_id'];

        /** @var \Basic\Service\OrderService $order_service */
        $order_service = D('Basic/Order', 'Service');
        $order_info = $order_service->getCoOrderById($order_id);

        /** @var CityService $city_service */
        $city_service = D("Basic/City", 'Service');
        $cities = $city_service->getFormatCityByIds([$order_info['start_province'],$order_info['start_city'],
            $order_info['start_district'], $order_info['to_province'], $order_info['to_city'],
            $order_info['to_district']]);

        $start_province_name = $cities[$order_info['start_province']]['name'];
        $start_city_name = $cities[$order_info['start_city']]['name'];
        $start_district_name = $cities[$order_info['start_district']]['name'];
        $to_province_name = $cities[$order_info['to_province']]['name'];
        $to_city_name = $cities[$order_info['to_city']]['name'];
        $to_district_name = $cities[$order_info['to_district']]['name'];
        if (empty($order_info)) {
            //@todo 提示运单不存在或者已经关闭
        } else {
            $order_info['start_city_name'] = $start_city_name;
            $order_info['to_city_name'] = $to_city_name;
        }
        /** @var UserService $user_service */
        $user_service = D('Basic/User', 'Service');
        $user_info = $user_service->getUserInfo($order_info['user_id']);
        $share_list_where = [
            'start_code' => ['like', $order_info['start_city'].'%'],
            'to_code' => ['like', $order_info['to_city'].'%']
        ];
        if ($user_info['avatar']) {
            $user_info['avatar'] = [
                'url' => imageUrl($user_info['avatar']),
            ];
        } else {
            $user_info['avatar']['url'] ='';
        }
        $ret = $order_service->orderList($share_list_where, '' , '5');
        $share_list = $ret['list'];
        foreach ($share_list as $key => &$value) {
            $sh_user_info = $user_service->getUserInfo($value['user_id']);
            if ($sh_user_info['avatar'] && !is_object($sh_user_info['avatar'])) {
                $sh_user_info['avatar'] = [
                    'url' => imageUrl($sh_user_info['avatar']),
                ];
            } else {
                $sh_user_info['avatar']['url'] ='';
            }
            $value['company_name'] = $sh_user_info['company_name'];
            $value['avatar'] = $sh_user_info['avatar']['url'];

        }
        if ($this->isFromIphone()) {
            $down_data = VERSION_CONFIG::versionDown($from = 'ios');
        } else {
            $down_data = VERSION_CONFIG::versionDown($from='android');
        }
        $feed = D('Basic/CoOrderFeed')->getBy(['order_id' => $this->req['order_id']], ['id']);
        $update_url = $down_data['update_url'];
        $app_url = $down_data['app_url'].'?order_id='.$feed['id'].'&type='.($order_info['order_type'] == 100 ? 1:2 );
        $to_detail_url = $down_data['to_detail_url'].'?order_id='.$order_info['order_id']
            .'&start_province='.$order_info['start_province'].'&start_city='
            .$order_info['start_city'].'&start_district='.$order_info['start_district'].'&start_province_name='.$start_city_name
            .'&start_city_name='.$start_city_name.'
            &start_district_name='.$start_district_name.'&to_province='.$order_info['to_province']
            .'&to_city='.$order_info['to_city'].'&to_district='.$order_info['to_district'].'&to_province_name='.$to_province_name
            .'&to_city_name='.$to_city_name.'
            &to_district_name='.$to_district_name;
        $this->assign('feed_id',$feed['id']);
        $this->assign('update_url',$update_url);
        $this->assign('app_url',$app_url);
        $this->assign('to_detail_url',$to_detail_url);
        $this->assign('hasApp','1');
        $this->assign('order_info', $order_info);
        $this->assign('user_info', $user_info);
        $this->assign('share_list', $share_list);
        $this->assign('ret_count', count($ret['list']));
        $this->display('OrderShare/share');
    }

    public function isFromIphone(){
        if (isset ($_SERVER['HTTP_USER_AGENT'])) {
            $clientkeywords = array('iphone');
            //从HTTP_USER_AGENT中查找手机浏览器的关键字
            if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT'])) == 1) {
                return true;
            }
            $clientkeywords = array('ipad');
            //从HTTP_USER_AGENT中查找手机浏览器的关键字
            if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT'])) == 1) {
                return true;
            }
        }
        return false;
    }
}