<?php
namespace Admin\Behavior;

use Think\Behavior;
use Think\Log;
use Think\Think;
use Common\Cnsts\ERRNO;

class preventRefreshBehavior extends Behavior
{
    const WHITE_LIST = [
        'Admin/innerNotice/newInnerNotice',
        'Admin/User/checkLoginAcc'
    ];

    // 行为扩展的执行入口必须是run
    public function run(&$params)
    {
//        // 进行黑名单过滤
//        $req_method = $_SERVER['REQUEST_METHOD'];
//        $rncb = C('REFRESH_NOT_CACHE_BLACK_LIST');
//
//        if ($rncb[MODULE_NAME] != null
//            && $rncb[MODULE_NAME][CONTROLLER_NAME] != null
//            && $rncb[MODULE_NAME][CONTROLLER_NAME][ACTION_NAME] != null
//            && $rncb[MODULE_NAME][CONTROLLER_NAME][ACTION_NAME][$req_method] != null) {
//            foreach ($rncb[MODULE_NAME][CONTROLLER_NAME][ACTION_NAME][$req_method] as $k=>$v) {
//                $req = json_decode(html_entity_decode(I("req", "", "htmlspecialchars")), true);
//                if ($req[$k] === $v) {
//                    cmm_log('该请求不进行缓存处理');
//                    return;
//                }
//            }
//        }
        // @todo 参考专业版
        $white_list = self::WHITE_LIST;
        foreach ($white_list as &$w) {
            $w = strtolower($w);
        }
        if ( in_array(strtolower(MODULE_NAME . '/' . CONTROLLER_NAME . '/' . ACTION_NAME), $white_list) ) {
            return;
        }

        // 取业务程序处理生成数据用
        ob_start();

        $sid_cookie_name = C('SESSION_OPTIONS')['name'];
        $sid = $_COOKIE[$sid_cookie_name];

        if (empty($_REQUEST['request_id'])) {
            // session id
//            $arr = explode(';', $_SERVER['HTTP_COOKIE']);
//            $sid = session_id();
//            foreach ($arr as $hc) {
//                if (strpos(trim($hc), 'PHPSESSID') === 0) {
//                    $sid = explode('=', $hc)[1];
//                }
//            }

            // 完整URL
            $uri = $_SERVER['REQUEST_URI'];

            $fd = file_get_contents('php://input');
            $request_id = md5($sid . $uri . $fd);
            $_REQUEST['request_id'] = $request_id;
        }

        // log 记录请求request_id起始log
        cmm_log('request_id=' . $_REQUEST['request_id'], 'PREVENT_REFRESH');

        $mval = S($_REQUEST['request_id']);
        if (false === $mval) {
            $ot['expire'] = C('REFRESH_MEMCACHE_SET_NULL_TIME');
            S($_REQUEST['request_id'], '#$#', $ot);
        } else {
            if ($mval === '#$#') {
                // log 第一次请求后未处理完时（及缓存数据为空）第二次请求
                $errmsg = ERRNO::e(ERRNO::REQUEST_FREQUENT);
                cmm_log($errmsg, 'PREVENT_REFRESH');

                if ( !is_ajax() ) {
                    $view = Think::instance('Think\View');
                    $view->assign('message', $errmsg);
                    $view->assign('seconds', 3);
                    $view->display('Common/refresh_message');
                    tag('app_end');
                    exit();

                } else {
                    $errno = ERRNO::REQUEST_FREQUENT;
                    $res = null;
                    $resp = [
                        "errno"  => $errno,
                        "errmsg" => $errmsg,
                        "res"    => $res,
                    ];
                    cmm_exit(json_encode($resp, JSON_UNESCAPED_UNICODE));
                }

            } else {
                // @todo 直接返回缓存数据

                // log
                $log_content = [
                    'sid=' . $sid,
                    'request_id=' . $_REQUEST['request_id'],
                    'message=' . '返回缓存数据',
                ];
                Log::write(implode(' ', $log_content), 'PREVENT_REFRESH');

                tag('app_end');
            }
        }
    }
}

