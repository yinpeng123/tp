<?php
namespace Wechat\Service;

class UserService {

    const OPENID_TOKEN = 'smkdafphe0fn3u';
    
    /**
     * 用户信息
     * @param  [type] $openid [description]
     * @return [type]         [description]
     */
    public function getUserInfoByOpenid($openid){
        $user = D('Basic/User', 'Service')->getListBy(['mp_openid' => $openid]);
        return $user[0];
    }

    /**
     * 取消关注
     * @param  [type] $openid [description]
     * @return [type]         [description]
     */
    public function unSubscribe($openid){
        if (!$openid) {
            return false;
        }
        D('Basic/User', 'Service')->updateUserByOpenid($openid, ['mp_openid' => null]);
        D('Wechat/Login', 'Service')->sessionDestory($openid);
    }

    /**
     * 加密参数
     * @param  [type] $openid [description]
     * @return [type]         [description]
     */
    public function getQueryString($openid){
        $params = $this->genParams($openid);
        foreach ($params as $key => $value) {
            $paramstr .= $key.'='.$value.'&';
        }
        $paramstr = trim($paramstr,'&');
        return $paramstr;
    }

    /**
     * 生成签名参数
     * @param  [type] $openid [description]
     * @return [type]         [description]
     */
    public function genParams($openid){
        $timestamp = time();
        $tmpArr    = [self::OPENID_TOKEN, $timestamp, $openid];
        sort($tmpArr, SORT_STRING);
        $tmpStr    = implode( $tmpArr );
        $signature = sha1( $tmpStr );
        return [
            'openid'    => $openid,
            'signature' => $signature,
            'timestamp' => $timestamp
            ];
    }

    /**
     * 检查签名
     * @param  [type] $get [description]
     * @return [type]      [description]
     */
    public function checkSignature($get){
        $signature = $get['signature'];
        $timestamp = $get['timestamp'];
        $openid    = $get['openid'];
        $tmpArr    = [self::OPENID_TOKEN, $timestamp, $openid];
        sort($tmpArr, SORT_STRING);
        $tmpStr = implode( $tmpArr );
        $tmpStr = sha1( $tmpStr );  
        if( $tmpStr == $signature ){
            return true;
        }else{
            return false;
        }
    }
}

?>