<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\AuthService;
use Basic\ModelU\CenterModel;
use Admin\Service\PageService;

class PlanController extends AdminSessionController
{
    public function __construct() {
        parent::__construct();

    }

    public function index  (){
        $curr_page = I('path.2/d', 1);
        $model = new CenterModel('u_plan');
        $where = [];
        if(I("net_no")){
            $where['uid']=["like",'%'.I("net_no").'%'];
        }
        $list = $model->getListBy($where, "*", "id desc", $curr_page, 15);
        $total = $model->getListTotal($where);
        $page_service = new PageService($total, 15);
        $page_nav = $page_service->show();
        $this->packData($list);
        $this->assignAll(array(
            'title' => '计划列表',
            'list' => $list,
            'page_nav' => $page_nav
        ));
        $this->display('index');
    }
    public function show($id=0){
        $model= new CenterModel("u_plan");
        $list=$model->get($id);
        $info= (new CenterModel("u_plan_info"))->getListBy(['pid'=>$id]);
        $user =(new CenterModel("u_user"))->get($list['uid']);
        $this->assignAll(array(
            'title' => '计划详情',
            'list' => $list,
            'info'=>$info,
            'user'=>$user,
            'day'=>day()
        ));
        $this->display('edit');
    }
   //合并计划内容时间
    private function packData(&$data){
        $model= new CenterModel("u_plan_info");
        foreach($data as $key=>$val){
            $info=$model->getListBy(['pid'=>$val['id']],"title");
            $content=array_column($info,'title');
            $data[$key]['content']=implode("<br>",$content);
            $data[$key]['ptime']=$val['stime']."至".$val['etime'];
        }
    }

    public function delete(){
        $ids=I("ids");
        if(is_array($ids)){
            $where = 'id in('.implode(',',$ids).')';
        }else{
            $where = 'id='.$ids;
        }  //dump($where);
        M("u_plan")->where($where)->delete();
        $this->admin_success("删除成功");
    }

}