<?php

$REDIS_CONF = array(
    'prod' => "redis://:127.0.0.1",
    'develop' => "redis://:127.0.0.1",
//    'develop' => "redis://:JJMKeNTF64A7@6a556476ca014391.m.cnbja.kvstore.aliyuncs.com",
);

if ( !APP_DEBUG ) {
    return array(
        'REDIS_CONF' => $REDIS_CONF['prod'],
        'REDIS_HOST' => '127.0.0.1',
        'REDIS_PORT' => 6379,
        'REDIS_PASSWORD' => '',
    );
} else {
    return array(
        'REDIS_CONF' => $REDIS_CONF['develop'],
        'REDIS_HOST' => '127.0.0.1',
        'REDIS_PORT' => 6379,
        'REDIS_PASSWORD' => '',
    );
}
