<?php
namespace Admin\Model;

use Basic\Model\BasicModel;

class InnerNoticeModel extends BasicModel {
    protected $_inner_model = null;
    protected $_inner_model_link = null;
//    public function __construct() {
//        if ($this->_inner_model == null) {
//            $this->_inner_model = M('inner_notice');
//        }

//    }
    public function __construct($db_type = 'master', $enable_cache = FALSE) {
        parent::__construct('inner_notice', '', $db_type);
        $this->_enable_cache = $enable_cache;
        $this->_inner_model = $this->_model;
        if ($this->_inner_model_link == null) {
            $this->_inner_model_link = M('inner_notice_link');
        }
    }

    /**
     * @param $data
     *添加系统公告
     */
    public function addInnerNotice($data) {
        return $this->_inner_model->add($data);
    }

    public function mulitiAddLink($data) {
        return $this->_inner_model_link->addAll($data);
    }

    //根据主键查询内部公告
    public function getInnerNoticeById($id) {
        $where = [
            'id' => $id,
            'status' => 1,
        ];
        return $this->_inner_model->where($where)->find();
    }

    //根据条件查询内部公告消息
    public function getInnerNoticeList($where, $field= [], $limit=[],$order_by = [],$join = []) {
        return $this->_inner_model->where($where)->field($field)->join($join)->order($order_by)->limit($limit)->select();
    }


    /**
     *获取内部公告关联列表
     */
    public function getInnerNoticeLinks($where) {
        return $this->_inner_model_link->where($where)->select();
    }

    //获取总条数
    public function getSqlFoundRows($where,$join = []) {
        $total = $this->_inner_model->where($where)->join($join)->count();
        return $total;
    }

    public function updateInnerLink($where,$data) {
        return $this->_inner_model_link->where($where)->save($data);
    }

    public function updateInner($where,$data) {
        return $this->_inner_model->where($where)->save($data);
    }

}