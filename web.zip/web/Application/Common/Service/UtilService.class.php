<?php
namespace Common\Service;

use Common\Cnsts\ERRNO;
use Common\Service\XxteaService;
/**
* 设置返回数据类型
*/

class UtilService
{
    private static $key = "wuliuzhijia-2017_07";

    public static function sendResponse($errno = ERRNO::SUCCESS, $res = [])
    {

        $errmsg = ERRNO::e($errno);
        $resp = [
            "errno"  => $errno,
            "errmsg" => $errmsg,
            "res"    => $res,
        ];

        header("Content-type: application/json;charset=utf-8");
        echo json_encode($resp);
        exit;

    }

    //参考ThinkPHP/Extend/Library/ORG/Util/Image.class.php buildImageVerify
    public function buildImageVerify($length=4, $mode=1, $type='png', $width=60, $height=22, $verifyName='img_code') {
        import('Org.Util.String');
        import('Org.Util.Image');
        $randval = \Org\Util\String::randString($length, $mode);
        session($verifyName, $randval);
        $timestamp = $verifyName."_timestamp";
        session($timestamp, time());


        $width = ($length * 10 + 10) > $width ? $length * 10 + 10 : $width;
        if ($type != 'gif' && function_exists('imagecreatetruecolor')) {
            $im = imagecreatetruecolor($width, $height);
        } else {
            $im = imagecreate($width, $height);
        }
        $r = Array(225, 255, 255, 223);
        $g = Array(225, 236, 237, 255);
        $b = Array(225, 236, 166, 125);
        $key = mt_rand(0, 3);

        $backColor = imagecolorallocate($im, 255,255,255);    //背景色（随机）
        $borderColor = imagecolorallocate($im, 153, 153, 153);                    //边框色
        imagefilledrectangle($im, 0, 0, $width - 1, $height - 1, $backColor);
        imagerectangle($im, 0, 0, $width - 1, $height - 1, $borderColor);
        $stringColor = imagecolorallocate($im, mt_rand(0, 200), mt_rand(0, 120), mt_rand(0, 120));
        // 干扰
        for ($i = 0; $i < 5; $i++) {
            imagearc($im, mt_rand(-10, $width), mt_rand(-10, $height), mt_rand(30, 300), mt_rand(20, 200), 55, 44, $stringColor);
        }
        for ($i = 0; $i < 25; $i++) {
            imagesetpixel($im, mt_rand(0, $width), mt_rand(0, $height), $stringColor);
        }
        for ($i = 0; $i < $length; $i++) {
            imagestring($im, 5, $i * 10 + 5, mt_rand(1, 8), $randval{$i}, $stringColor);
        }
        \Org\Util\Image::output($im, $type);
    }

    public function buildSmsVerify($telephone, $length=4, $mode=1, $verifyName='sms_code') {
        import('Org.Util.String');
        $randval = session($verifyName);
        if(empty($randval)){
            $randval = 1234;//\Org\Util\String::randString($length, $mode);
            session($verifyName, $randval);
            $timestamp = $verifyName."_timestamp";
            session($timestamp, time());
        }
        $msg = "【登陆】验证码为: ".$randval. "请在10分钟内输入";

        $ret= 0;
        //$this->sendMsgInfo($telephone, $msg);
        return $ret;
    }

    /**
     * 获取发送短信的URL
     * @param $is_sms 是否群发短信
     */
    private function __msgCurlHeader($num, $msg){

        // 亿美通道与华信通道区分

        $sms_config = C("SMS_CONFIG");
        $url = $sms_config['URL'];
        $url .= "cdkey=".$sms_config['USER'];
        $url .= "&password=".$sms_config['PWD'];
        $url .= "&phone=".$num;
        $url .= "&message=".urlencode($msg);

        $header = "Content-type: text/xml";
        $sendUrlHeaderInfo = array(
            "url" => $url,
            "header" => $header
        );
        return $sendUrlHeaderInfo;
    }

    /**
     * 发送短信
     * 单条发送，目前不支持批量
     * @param $is_sms 是否群发短信
     */
    public function sendMsgInfo($telephone, $msg){
        $ret = ERRNO::SUCCESS;
        // 获取发送短信的URL
        $urlHeader = UtilService::__msgCurlHeader($telephone, $msg);
        var_dump($urlHeader["url"]);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $urlHeader["url"]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $urlHeader["header"]);

        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            curl_close($ch);
            //return ERRORNO::SEND_MSG_FAILED;
            $ret = ERRNO::SEND_MSG_FAILED;
        }
        // 关闭通道
        curl_close($ch);
        return $ret;
    }

    public static function encrypt($string){
        return base64_encode(XxteaService::encrypt($string, self::$key));
    }

    public static function decrypt($string){
        return XxteaService::decrypt(base64_decode($string), self::$key);
    }

    /**
     * 生成数字验证码
     *
     * @param int $len
     *
     * @return string
     */
    public static function gen_verify_code($len = 4)
    {
        $numArr = range(0, 9);
        $randArr = array();
        for ($i = 0; $i < $len; $i++) {
            $randArr[] = array_rand($numArr);
        }
        shuffle($randArr);
        return join("", $randArr);
    }
}