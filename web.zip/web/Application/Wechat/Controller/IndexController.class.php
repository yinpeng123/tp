<?php

namespace Wechat\Controller;

use Basic\ModelU\CenterModel;
use Think\Controller;
use Basic\Cnsts\WECHAT;
use Basic\Service\WechatService;
use Basic\ModelU\UserModel;
use Basic\Service\UuserService;
use Basic\Service\FortuneService;

class IndexController extends WechatController
{

    function __construct()
    {
        parent::__construct();
    }

    //提交用户基本信息,openid,nickname,avatar
    public function index()
    {
        $user = new UuserService();
        $where = ['openid' => I('openid')];
        $uid = $user->getUserInfoByFactory($where);
        if (empty($uid)) {
            $this->doResponse(1, "没有该用户", $where);
        }
        $this->doResponse(0, "ok", $user->getUserPage($uid));
    }

    //获取运势
    public function fortune()
    {
        $user = new UuserService();
        $day= $user->getFortuneByOpenid(I('openid'));
        if(!$day){
            $this->$this->doResponse(-1, "该用户未设置星座");
        }
        $info= (new FortuneService())->getFortuneAll($day);
        foreach($info as $key=>$val){
            $info[$key]['score_info']=json_decode($info[$key]['score_info'],true);
            $info[$key]['content']=json_decode($info[$key]['content'],true);
        }
       list($today,$tomorow,$week,$month)=$info;

       $data=[
           'today'=>$today,
           'tomorrow'=>$tomorow,
           'week'=>$week,
           'month'=>$month
       ];
      $this->doResponse(0, "ok",$data );


    }

    //设定星座
    public function fortuneSet()
    {
        $user = new UuserService();
        $where = ['openid' => I('openid')];
        if (empty(I('days'))) {
            $this->doResponse(2, "缺少days参数");
        }
        $info = ['day_fortune' => I('days')];
        try {
            $user->upUser($where, $info);
            $this->doResponse(0, "ok");
        } catch (ExceptionNew $e) {
            $this->doResponse(2, "err", $e->getMessage());
        }

    }

    //星座插入DEMO
    public function fortuneAdd(){
        $demo = [
            'total_score' => 60,
            'score_info' => [
                'whole' => 80,
                'learning' => 70,
                'feeling' => 50,
                'finance' => 60,
                'healthy' => 99,
                'luckyNumber' => 2,
                'luckyColor' => "红色",

            ],
            'content' => [
                'whole' => "今日白羊座的整体运势大体尚可，很好哟 加油！ 
今日白羊座的整体运势大体尚可，很好哟 加油！
今日白羊座的整体运势大体尚可，很好哟 加油！",
                'learning' => "好好学习天天向上",
                'feeling' => "这个季节不是谈恋爱",
                'finance' => "省点花吧，你快没钱了",
                'healthy' => "最近去医院太勤了点，身体状况好，不过吃喝要适量，小心吃撑了。",
            ],
        ];
        $data=[
            'fid'=>12,
            'type'=>1,
            'days'=>day(),
            'total_score'=>$demo['total_score'],
            'score_info'=>json_encode($demo['score_info']),
            'content'=>json_encode($demo['content'] ),
        ];
        $model = new CenterModel("u_fortune");
        $model->add($data);
    }

    //拒绝赏金
    public  function  closeReward(){
        $model= new CenterModel("u_plan");
        $id=I("planId");
        $userPlan=$model->get($id,"uid");
        if(!$userPlan){
            $this->doResponse(-1, "该计划不存在" );
        }
        $uid=$userPlan['uid'];
        $info=[
            'is_money'=>2
        ];
        $model->update($id,$info);
        UuserService::addMessage($uid,5);
        $this->doResponse(0, "ok" );
    }

    //支付计划赏金
    public  function  payReward(){
        $model= new CenterModel("u_plan");
        $id=I("planId");
//        $info=[
//            'is_money'=>2
//        ];
//        $model->update($id,$info);
        $data="支付参数";
        $this->doResponse(0, "ok" ,$data);
    }

    public function test(){
        $res=$this->sendCode(17535216243,12346);
        p($res);
    }

}
