<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;

class MenuController extends AdminSessionController {

    public function __construct() {
        parent::__construct();

        // 权限检查
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::SYS_MENU) ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }
    }

    /**
     * 菜单列表
     */
    public function index() {
        $cond = $this->prepareSearchCond(array('search_pid'));

        $menu_model = D('Menu');
        $list = $menu_model->searchMenu($cond);
        //print_r($list);exit;

        // 获取一级菜单列表
        $menu_arr = $menu_model->searchMenu(['pid' => 0]);

        $this->assignAll($cond);

        $this->assignAll(array(
            'title'   => '菜单列表',
            'list'    => $list,
            'menu_arr'=> $menu_arr,
        ));
        $this->display('menu_list');
    }

    /**
     * 获取返回列表的链接
     * @param $refer
     */
    protected function _backToListUrl($refer) {
        if ( !empty($refer) && 0 === strpos($refer, U('menu/index', '', '', TRUE)) ) {
            return $refer;
        } else {
            return U('menu/index', '', '', TRUE);
        }
    }

    /**
     * 添加菜单
     */
    public function add() {
        $menu_model = D('Menu');
        $menu_arr = $menu_model->genMenuSelectArray();

        $menu = array(
            'id'        => 0,
            'pid'       => 0,
            'name'      => '',
            'url'       => '',
            'icon'      => '',
            'desc'      => '',
            'list'      => '',
        );

        $this->assignAll(array(
            'act'       => 'add',
            'form_action' => '/menu/doAdd',
            'title'     => '添加菜单',
            'menu'      => $menu,
            'menu_arr'  => $menu_arr,
            'back_to_list_url' => $this->_backToListUrl($this->_refer),
        ));
        $this->display('menu_info');
    }


    /**
     * 保存菜单信息
     */
    public function doAdd() {
        // 验证令牌
        $this->checkFormToken();

        $name = I('name', '');
        $cn_len = cnstrlen($name);
        if ( $cn_len < 4 ) {
            $this->admin_error('菜单名格式不正确！');
            return;
        }

        $menu_model = D('Menu');
        $pid = I('pid/d', 0);
        $url = I('url', '');
        $icon = I('icon');
        $desc = I('desc');
        $list = I('list/d', 0);
        if ( $list == 0 ) {
            $list = $menu_model->getMaxList() + 1;
        }

        $menu_id = $menu_model->addMenu(array(
            'pid'     => $pid,
            'name'    => $name,
            'url'     => $url,
            'icon'    => $icon,
            'desc'    => $desc,
            'list'    => $list,
            'ctime'   => datetime(),
        ));

        // 如果是超级管理员则删除会话缓存
        if ( $this->_manager_id == 1 ) {
            session('menu_list', NULL);
        }

        // 添加操作日志
        $menu_service = D('Menu', 'Service');
        $menu_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => $menu_id,
            'action'        => 'add',
            'desc'          => "添加新菜单：$name",
        ));

        $this->admin_success('添加菜单成功！');
    }

    /**
     * 编辑菜单
     */
    public function edit($id) {
        $id = (int)$id;
        if ( !$id ) {
            $this->admin_error('ID不正确！');
            return;
        }

        $menu_model = D('Menu');
        $menu = $menu_model->getMenu($id);
        if ( !$menu ) {
            $this->admin_error('菜单不存在！');
            return;
        }

        $menu_arr = $menu_model->genMenuSelectArray();

        $this->assignAll(array(
            'act'     => 'edit',
            'form_action' => '/menu/doEdit',
            'title'   => '编辑菜单',
            'id'      => $id,
            'menu'    => $menu,
            'menu_arr'=> $menu_arr,
            'back_to_list_url' => $this->_backToListUrl($this->_refer),
        ));
        $this->display('menu_info');
    }

    /**
     * 提交编辑菜单信息
     */
    public function doEdit() {
        // 验证令牌
       // $this->checkFormToken();

        $id = I('id/d');
        if ( !$id ) {
            $this->admin_error('ID不正确！');
            return;
        }

        $name = I('name');
        $cn_len = cnstrlen($name);
        if ( $cn_len < 4 ) {
            $this->admin_error('菜单名格式不正确！');
            return;
        }

        $menu_model = D('Menu');
        $pid = I('pid/d');
        $url = I('url');
        $icon = I('icon');
        $desc = I('desc');
        $list = I('list/d');
        if ( $list == 0 ) {
            $list = $menu_model->getMaxList() + 1;
        }

        $menu_model->updateMenu($id, array(
            'pid'     => $pid,
            'name'    => $name,
            'url'     => $url,
            'icon'    => $icon,
            'desc'    => $desc,
            'list'    => $list,
            'mtime'   => datetime(),
        ));

        // 如果是超级管理员则删除会话缓存
        if ( $this->_manager_id == 1 ) {
            session('menu_list', NULL);
        }

        // 添加操作日志
        $menu_service = D('Menu', 'Service');
        $menu_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => $id,
            'action'        => 'edit',
            'desc'          => "编辑菜单：$name",
        ));

        $this->admin_success('编辑菜单成功！');
    }

    /**
     * 删除菜单
     * @param $id
     */
    public function delete($id) {
        $id = (int)$id;
        if ( !$id ) {
            $this->admin_error('ID不正确！');
            return;
        }

        $menu_model = D('Menu');
        $menu = $menu_model->getMenu($id);
        if ( empty($menu) ) {
            $this->admin_error('菜单不存在！');
            return;
        }

        $menu_model->deleteMenu($id);

        // 如果是超级管理员则删除会话缓存
        if ( $this->_manager_id == 1 ) {
            session('menu_list', NULL);
        }

        // 添加操作日志
        $menu_service = D('Menu', 'Service');
        $menu_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => $id,
            'action'        => 'delete',
            'desc'          => "删除菜单：".$menu['name'],
        ));

        $this->admin_success('删除菜单成功！');
    }

    /**
     * 批量删除
     */
    public function deleteAll() {
        // 验证令牌
        $this->checkFormToken();

        $ids = I('ids');
        if ( empty($ids) ) {
            $this->admin_error('ID不正确！');
            return;
        }

        $menu_model = D('Menu');
        $menu_model->deleteMenu($ids);

        // 如果是超级管理员则删除会话缓存
        if ( $this->_manager_id == 1 ) {
            session('menu_list', NULL);
        }

        // 添加操作日志
        $menu_service = D('Menu', 'Service');
        $menu_service->addOperLog(array(
            'manager_id'    => $this->_manager_id,
            'object_id'     => implode(',', $ids),
            'action'        => 'delete',
            'desc'          => "批量删除菜单",
        ));

        $this->admin_success('批量删除菜单成功！');
    }


}