<?php
return [
    'SESSION_OPTIONS'       => array('name' => 'twpt_wechat_sid', 'expire' => 3600, 'cookie_lifetime' => 0),
    'SESSION_TYPE'          => 'Mysqli', //'db',
    'SESSION_TABLE'         => 'tp_session', // 必须设置成这样，如果不加前缀就找不到数据表，这个需要注意

    'USER_SESSION_NAME_WECHAT'      => 'wechat_user',
    'USER_SESSION_NAME_TWPT'        => 'wx_twpt_userinfo',
    'USER_SESSION_NAME_SESSION_ID'  => 'wx_sessionid_',
    
    'LOAD_EXT_CONFIG' => 'pay',
];

?>