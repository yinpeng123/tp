<?php
namespace Client\Controller;
//namespace Admin\Controller;

use Common\Controller\SessionController;

class DemoController extends SessionController {

    public function __construct() {
        if (!APP_DEBUG) {
            return false;
        }
        parent::__construct();
    }

    public function index() {
        $this->assign('name','user_name');
//        $this->testForeach();//循环中留下悬浮指针
//        $this->testMerge();
//        $this->testCount();
        $this->testStrpos();
    }

    /**
     * foreach中留下悬浮指针
     */
    public function testForeach() {
        $array = [1,2,3,4];
        foreach ( $array as &$v) {
            $v = $v *2;
        }
        $array = [1, 2, 3];
        foreach ( $array as &$v) {
            dump($array);
        }
//        unset($v);
        foreach ($array as $v) {
        }

        dump($array);
    }



    public function testMerge() {

        $array1 = array( 'a' => 1, 'b' => 2, 'c' =>3 );

        $array2 = array('d'=>4, 'e'=>5);

        $array3 = null;

        $merge_arr1 = array_merge($array1, $array2);

        $merge_arr2 = array_merge($array1, $array3);

        $merge_arr3 = array_merge($array3, $array1);

        dump($merge_arr1,'array_1');
        dump($merge_arr2,'array_2');
        dump($merge_arr3,'array_3');
    }

    public function testCount() {
        dump('空数组'.count([])); //0
        dump(count(NULL),'NULL'); //0
        dump(count('aaaa'),'字符串'); //1
        dump(count(''),'空字符串'); //1
        dump(count(false),'false'); //1
        dump(explode(',',''));//array(1) {[0] => string(0) ""}
    }

    public function testStrpos() {

        $str = 'abc';
//        dump(strpos($str, 'a'));
        //dump(in_array("abc",[0, 1])); //0=="abc";

        dump(in_array("abc",[0, 1],true));
    }


    public function testFloat() {
        $f = 0.56;
        echo (int)($f * 100);

        $f2 = 0.57;
        echo (int)($f2 * 100);
    }
}

