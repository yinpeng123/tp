<?php
namespace Admin\Service;


class AuthService {

    /**
     * 密码登录
     * @param username string 用户名
     * @param password string 密码
     *
     * @return 返回 [<code>, <message>, <manager info array>]
     */
    public function doLoginPassword($username, $password) {
        if ( empty($username) ) {
            return array(-1, '请输入账号！', []);
        }
        if ( empty($password) ) {
            return array(-2, '密码不能为空！', []);
        }

        $login_log_model = D('Admin/LoginLog', 'Model');
        $fail_count = $login_log_model->getLoginFailNum($username, day());
        if ( $fail_count >= C('MAX_LOGIN_FAIL_NUMBER') ) {
            return array(-1, "您今日已经达到错误登陆的次数上限，每天最多 ".C('MAX_LOGIN_FAIL_NUMBER')." 次", []);
        }

        $manager_model = D('Admin/Manager', 'Model');
        $manager = $manager_model->getManagerByUsername($username);
        if ( empty($manager) ) {
            return array(-1, '账号不存在！', []);
        }

        $log = array('username' => $username, 'password' => $password, 'ip' => get_client_ip(),
                     'ctime' => datetime());
        if ( !password_verify($password, $manager['password']) ) {
            $log['result'] = 'fail';
            $log['message'] = '密码不正确';
            $login_log_model->addManagerLoginLog($log); // 添加登录日志

            // TODO 用户当日输入密码错误超过一定次数则冻结账号

            return array(-2, $log['message'], []);
        }

        // IP地址检查
        if ( !empty($manager['allow_ip'])
            && !$this->isIpAllow(get_client_ip(), $manager['allow_ip']) ) {
            $log['result'] = 'fail';
            $log['message'] = 'IP地址被限制登录';
            $login_log_model->addManagerLoginLog($log);

            return array(-1, $log['message'], []);
        }

        // 添加登录日志
        $log['result'] = 'success';
        $log['message'] = '登录成功';
        $login_log_model->addManagerLoginLog($log);

        // 账号未激活算登录成功
        if ( $manager['active'] != 'Y' ) {
            return array(-1, '账号未激活！', []);
        }

        return array(0, '登录成功！', $manager);
    }

    // 检查用户IP是否允许访问
    public function isIpAllow($client_ip, $allow_ip) {
        return true;
    }

}