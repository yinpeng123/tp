<?php

namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\AuthService;
use Basic\ModelU\CenterModel;
use Admin\Service\PageService;

class VipController extends AdminSessionController
{
    public function __construct()
    {
        parent::__construct();

    }

    public function index()
    {
        $curr_page = I('path.2/d', 1);
        $model = new CenterModel('u_plan');
        $where = [];
        $list = $model->getListBy($where, "*", "id desc", $curr_page, 15);
        $total = $model->getListTotal();
        $page_service = new PageService($total, 15);
        $page_nav = $page_service->show();
        $this->packData($list);
        $this->assignAll(array(
            'title' => '能力评估编辑',
            'list' => $list,
            'page_nav' => $page_nav
        ));
        $this->display('index');
    }

    public function show($id = 0)
    {
        $model = new CenterModel("u_plan");
        $list = $model->get($id);
        $info = (new CenterModel("u_plan_info"))->getListBy(['pid' => $id]);
        $user = (new CenterModel("u_user"))->get($list['uid']);
        $this->assignAll(array(
            'title' => '计划详情',
            'list' => $list,
            'info' => $info,
            'user' => $user,
            'day' => day()
        ));
        $this->display('edit');
    }
    //教练编辑
    public function trainer()
    {

    }

}