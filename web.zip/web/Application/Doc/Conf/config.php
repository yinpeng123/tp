<?php
return [
    'USER_SESSION_NAME_WECHAT'  => 'wechat_user_api',
    
    'LOAD_EXT_CONFIG'           => 'doc',
];

?>