<?php

namespace Wechat\Controller;

use Basic\ModelU\CenterModel;
use Think\Controller;
use Basic\Cnsts\WECHAT;
use Basic\Service\WechatService;
use Basic\ModelU\UserModel;
use Basic\Service\UuserService;
use Basic\Service\PlanService;

class UserController extends WechatController
{

    function __construct()
    {
        parent::__construct();
    }

    //我的页面
    public function page()
    {
        $model = new UuserService();
        $openid = I('openid');
        $user = $model->getUserByOpenid($openid);
        $msgTotal = (new CenterModel("u_user_message"))->getListTotal(['uid' => $user['id'], 'is_read' => 'N']);
        $planInfo = [
            'now' => PlanService::getThisPlanOnUid($user['bind_uid']),
            'last' => PlanService::getlastPlanOnUid($user['bind_uid'])
        ];
        $autoPay= (new CenterModel('u_user_auto'))->getBy(['uid'=>$this->user->id]);
        $info = [
            'name' => $user['name'],
            'avatar' => $user['avatar'],
            'bind_uid' => $user['bind_uid'] ? $user['bind_uid'] : null,
            'level' => $user['level'],
            'levelColor' => $user['levelColor'],
            'levelName' => $user['levelName'],
            'point' => $user['point'],
            'msgTotal' => $msgTotal,
            'is_member' => $user['is_member'],
            'member_time'=>$user['member_time'],
            'my_invcode' => 'plan' . $user['id'],
            'qrcode' => "",
            'amount' => $user['amount'],
            'holiday' => $user['holiday'],
            'is_vip' => $user['is_vip'],
            'vip_time'=>$user['vip_time'],
            'planInfo' => $planInfo,
            'autoPay'=>$autoPay?'Y':'N',

        ];
        switch ($user['role']) {
            case 0:  //没有完善资料的用户
                $info['userType'] = 0;
                break;
            case 1:   //家长
                $info['userType'] = 1;

                break;
            default:  //学生
                $info['userType'] = 2;
                $info['is_sign'] = $this->getSignStart();


        }

        $this->doResponse(0, "ok", $info);
    }

    //完善资料
    public function set()
    {
        $openid = I('openid');
        $name = I('name');
        if (empty($name)) {
            $this->doResponse(-1, "姓名不能为空");
        }
        $tel = I('tel');
        if (!is_mobile($tel)) {
            $this->doResponse(-1, "手机号格式不正确");
        }

        $code = I('code');
        $role = I('role', 0);
        if ($role == 0) {
            $this->doResponse(-1, "请选择学生角色");
        }
        $invitaCode = I('invitaCode');
        $volunteer = I('volunteer', 0);  //志愿
        if ($role > 1 && $volunteer == "") {
            $this->doResponse(-1, "学生志愿不能为空");
        }
        $model = new CenterModel("u_user");
        $where = ['openid' => $openid];
        $info = [
            'name' => $name,
            'tel' => $tel,
            'role' => $role,
            'volunteer' => $volunteer,
        ];

        $model->updateBy($where, $info);

        $this->doResponse(0, "资料完善成功");
    }


    //绑定学生
    public function addStudent()
    {
        $openid = I('openid');
        $name = I('name');
        if (empty($name)) {
            $this->doResponse(-1, "姓名不能为空");
        }
        $tel = I('tel');
        if (!is_mobile($tel)) {
            $this->doResponse(-1, "手机号格式不正确");
        }
        $user = (new UuserService())->getUserByOpenid($openid);
        if ($user['bind_uid']) {
            $this->doResponse(-1, "您已经绑定了一个学生");
        }

        $model = new CenterModel("u_user");
        $student = $model->getBy(['tel' => $tel]);
        if (!$student) {
            $this->doResponse(-1, "请使用该学生账号登录本平台");
        }
        $data = [
            'bind_uid' => $student['id'],
            'role' => 1
        ];
        $model->update($user['id'], $data);
        $this->doResponse(0, "绑定学生成功");
    }

    //个人信息修改
    public function upPersonal()
    {
        $type = I("type");
        $data = I("data");
        if (!in_array($type, ["name", "avatar", "holiday", "volunteer", "userType"])) {
            $this->doResponse(-1, "type参数错误");
        }
        if (empty($data)) {
            $this->doResponse(-1, "data参数错误");
        }
        if ($type == "userType") {
            $type = "role";
        }
        $con = ['openid' => $this->openid];
        $param = [
            $type => $data
        ];
        (new CenterModel("u_user"))->updateBy($con, $param);
        $this->doResponse(0, "修改成功");
    }

    //获取地址列表
    public function getAddress()
    {
        $user = (new UuserService())->getUserByOpenid($this->openid);
        $where = [
            'uid' => $user['id'],
            'is_del' => 'N'
        ];

        $data = (new CenterModel("u_user_address"))->getListBy($where, "id,name,tel,province,city,area,content",
            "id desc");
        $this->doResponse(0, "ok", $data ? $data : null);
    }

    //修改地址
    public function upAddress()
    {
        $id = I("id");
        $name = I("name");
        $tel = I("tel");
        $content = I("content");
        $province = I("province");
        $city = I("city");
        $area = I("area");
        if (empty($id)) {
            $this->doResponse(-1, "ok");
        }
        $info = [
            'name' => $name,
            'tel' => $tel,
            'province' => $province,
            'city' => $city,
            'area' => $area,
            'content' => $content,
        ];

        (new CenterModel("u_user_address"))->update($id, $info);
        $this->doResponse(0, "ok");
    }

    //添加地址
    public function addAddress()
    {
        $name = I("name");
        $tel = I("tel");
        $province = I("province");
        $city = I("city");
        $area = I("area");
        $content = I("content");
        $user = (new UuserService())->getUserByOpenid($this->openid);
        $info = [
            'uid' => $user['id'],
            'name' => $name,
            'tel' => $tel,
            'province' => $province,
            'city' => $city,
            'area' => $area,
            'content' => $content,
        ];

        $data = (new CenterModel("u_user_address"))->add($info);
        $this->doResponse(0, "ok", ['id' => $data]);
    }
    //删除地址
    public function delAddress()
    {
        $id = I("id");
        $data = (new CenterModel("u_user_address"))->delete($id);
        $this->doResponse(0, "ok", ['id' => $data]);
    }
    //获取用户消息
    public function getAllMessage()
    {
        $page = I("page");
        $user = (new UuserService())->getUserByOpenid($this->openid);
        $where = [
            'uid' => $user['id'],
            'is_del' => 'N'
        ];
        $data = (new CenterModel("u_user_message"))->getListBy($where, "*", "id desc", $page, $this->pageSize);
        //标记已读
        $info = array_column($data, "id");
        $cond = [
            'id' => ["in", $info],
        ];
        (new CenterModel("u_user_message"))->updateBy($cond, ['is_read' => 'Y']);
        foreach ($data as $key => $val) {
            $data[$key]['mtime'] = day(strtotime($val['ctime']));
            if (in_array($val['type'], [14, 15])) {
                $data[$key]['param'] = explode(",", $val['param']);
            }
        }
        $this->doResponse(0, "ok", $data);
    }
    //用户自动续费开关
    public function autoPay(){
        $model= new CenterModel("u_user_auto");
        if($info=$model->getBy(['uid'=>$this->user->id])){
            $model->delete($info['id']);
        }else{
            $info=[
                'uid'=>$this->user->id,
            ];
            $model->add($info);
        }
        $this->doResponse(0, "ok");
    }

    //获取名片
    public function getCard()
    {
        $uid = I('uid');
        $model = new UuserService();
        if ($uid) {
            $user = $model->getOpenIdByUid($uid);
        } else {
            $user = $model->getUserByOpenid($this->openid);
            $uid = $user['id'];
        }

        $info = [
            'uid' => $uid,
            'name' => $user['name'],
            'avatar' => $user['avatar'],
            'level' => $user['level'],
            'levelColor' => $user['levelColor'],
            'is_vip' => $user['is_vip'],
            'levelName' => $user['levelName'],
            'role' => $user['role'] == 1 ? "家长" : "学生",
            "ce_point" => $user['ce_point'],
            'volunteer' => $this->getVolunteer($user['volunteer']),
            'point' => $user['point'],
            'is_member' => $user['is_member'],
            'my_invcode' => 'plan' . $user['id'],
            'holiday' => $user['holiday'],
            'qrcode' => "",
            'stat' => [60, 70, 75, 80, 65, 90],
            'daysPlan' => [60, 30],
        ];
        $planTotal = (new PlanService())->getPlanTotalByUid($uid);
        $this->doResponse(0, "ok", array_merge($info, $planTotal));
    }

    //我的账户
    public function account()
    {
        $model = new CenterModel("u_user");
        $where = [
            'id' => $this->user->id,
        ];
        $amount = $model->getBy($where, "amount");
        $model = new CenterModel("u_finance_log");
        $mlist = [];
        $where = [
            'uid' => $this->user->id,
            'status'=>1
        ];
        $info = $model->getListBy($where, "*", "id desc");
        if ($info) {
            foreach ($info as $key) {
                $msg = "";
                switch ($key['type']) {
                    case "recharge":
                        $msg = "充值" . $key['amount'] . "元";
                        break;
                    case "qiye":
                        $msg = "体现" . $key['amount'] . "元";
                        break;
                    case "reward":
                        $msg = "计划达成奖励" . $key['amount'] . "元";
                        break;
                    default:
                        $msg = "支付" . $key['amount'] . "元";
                        break;
                }
                $mlist[] = ['id'=>$key['id'],'title'=>$msg, 'ctime'=>$key['ctime']];
            }
        }
        $where=[
            'uid'=>$this->user->id,
            'type'=>'qiye',
            'ctime'=>['gt',day()],
        ];
        $payCount= (new CenterModel("u_finance_log"))->getListTotal($where);

        $data = [
            'amount' => $amount['amount']."元",
            'drawing'=>2-$payCount,
            'logList' => $mlist
        ];
        $this->doResponse(0, "ok", $data);

    }

    //我的勋章
    public function getMedal()
    {
        $where = [
            'uid' => $this->user->uid,
        ];
        //等级
        //坚持天数
        $daysTotal = M('u_plan')->where($where)->sum('count');
        $model = new CenterModel("u_medal");
        $where = [
            'type' => 2,
            //  'point' => ["elt", $daysTotal],
        ];
        $dmedal = $model->getListBy($where, "point,name,pic,color");
        foreach ($dmedal as $key => $val) {
            $dmedal[$key]['is_have'] = ($val['point'] <= $daysTotal) ? 'Y' : 'N';
        }
        $where = [
            'type' => 1,
            //  'id' => ["elt", $this->user->id],
        ];

        $pmedal = $model->getListBy($where, "point,name,pic,color");
        foreach ($pmedal as $key => $val) {
            $pmedal[$key]['is_have'] = ($val['point'] <= $this->user->point) ? 'Y' : 'N';
        }
        $data = [
            "level" => $pmedal,
            "medal" => $dmedal
        ];
        $this->doResponse(0, "ok", $data);
    }

    //我的课程表
    public function getSchedule()
    {
        $where = ['uid' => $this->user->id];
        $model = new CenterModel("u_schedule");
//        $demo=[
//            1=>["语文","语文","语文","语文","语文","语文"],
//            2=>["数学","数学","数学","数学","数学","数学","数学","数学","数学"],
//            2=>["英语","数学","数学","数学","数学","数学"],
//        ];
//        $model->add(['uid'=>$this->user->id,'content'=>t_json_encode($demo)]);
        $info = $model->getBy($where);
        $data = null;
        if ($info) {
            $data = t_json_decode($info['content']);
        }
        $this->doResponse(0, "ok", $data);
    }

    //修改我的课程表
    public function upSchedule()
    {
        $model = new CenterModel("u_schedule");
        if (empty(I("data"))) {
            $this->doResponse(-1, "data参数缺少");
        }
        $data = json_decode(html_entity_decode(I("data")), true);
        $info = $model->getBy(['uid' => $this->user->id]);

        if ($info) {
            $model->update($info['id'], ['content' => t_json_encode($data)]);
        } else {
            $model->add(['uid' => $this->user->id, 'content' => t_json_encode($data)]);
        }
        $this->doResponse(0, "ok");
    }

    //获取我的假期
    public function getHoliday()
    {
        $holiday = $this->user->holiday;
        if ($holiday == "") {
            $this->doResponse(-1, "还没有设定假期");
        }
        $data = (strtotime($holiday) - strtotime(day())) / (60 * 60 * 24);
        $this->doResponse(0, "ok", ['holiday' => $holiday ? $holiday : null]);
    }

    //积分页面
    public function pointPage()
    {
        $this->doResponse(0, "ok", $this->user);
    }

    //获取积分渠道
    public function getPoint()
    {
        //完成身份验证
        //每日签到
        //每日发布社区内容
        //开通VIP
        //每日计划打卡
        //邀请好友
        //WECHAT::addPoint($this->user->id,"identity");

        $model = new CenterModel("u_point_log");
        $uid = $this->user->id;
        $identInfo = $model->getBy(['type' => 'identity', 'uid' => $uid]);
        $where = [
            'uid' => $uid,
            'type' => 'daySign'
        ];
        $sign = (new CenterModel("u_sign"))->getBy(['uid'=>$uid,'days'=>day()]);
        $where = [
            'uid' => $this->user->id,
            'type' => 'push',
            'ctime' => ['gt', day()],
        ];
        $push=$model->getListTotal($where);
        $where=[
            'uid'=>$this->user->id,
            'ctime'=>['gt',day()],
            'type'=>'card'
        ];
        $canPlan= $model->getBy($where);
        $where = [
            'uid' => $this->user->id,
            'type' => 'push',
            'ctime' => ['gt', day()],
        ];
        $data = [
            "is_member" => $this->user->is_member,
            'member_time' => NULL,
            'canIdentity' => $identInfo ? "N" : "Y",
            'canSign' => $sign ? "Y" : "N",
            'canPush' => "{$push}/3",
            'canVip' => $this->user->is_vip,
            'canPlan' => $canPlan?"Y":"N",
            'canInvite' => $identInfo ? "N" : "Y",
            'my_invcode' => 'plan' . $uid,
        ];
        $this->doResponse(0, "ok", $data);
    }

    //日志记录
    public function pointLog()
    {
        $model = new CenterModel("u_point_log");
        $where = [
            'uid' => $this->user->id
        ];
        $info = $model->getListBy($where, "content,point,ctime","id desc");
        $data = [
            'point' => $this->user->point,
            'list' => $info
        ];
        $this->doResponse(0, "ok", $data);
    }


    public function mall()
    {
        $model = new CenterModel("u_mall");
        $info = $model->getListBy(['status' => 1], "*", "id desc");
        $data = [
            'point' => $this->user->point_use,
            'list' => $info ? $info : null,
        ];
        $this->doResponse(0, "ok", $data);
    }

    //兑换礼品
    public function exchangeGoods()
    {
        $id = I("gid");
        $address_id = I("adr_id");
        $model = new CenterModel("u_mall");
        $info = $model->get($id, "amount");
        $amount=$info['amount'];
        $address = (new CenterModel("u_user_address"))->get($address_id);
        if (!$info) {
            $this->doResponse(-1, "没有该产品");
        }
        if (!$address) {
            $this->doResponse(-1, "请选择正确的地址");
        }
        if ($info['amount'] > $this->user->point_use) {
            $this->doResponse(-1, "积分不够");
        }
        $info = [
            'point_use' => $this->user->point_use - $info['amount'],
        ];
        (new CenterModel("u_user"))->update($this->user->id, $info);
        $info = [
            'uid' => $this->user->id,
            'good_id' => $id,
            'address_id' => $address_id
        ];
        (new CenterModel("u_mall_order"))->add($info);
        $model = new CenterModel("u_point_log");
        $points=[
            'uid' => $this->user->id,
            'content' => "兑换商品消耗积分",
            'point' => $amount,
            'type' => "mall",
            'in_out' => 2,
        ];
        $model->add($points);
       // (new CenterModel("u_mall_order"))->add($info);
        $info=[
            'uid' => $this->user->id,
            'title'=>"您的商品已兑换成功，请等待发货",
            "content"=>"发货后会通过资讯信息告知您",
            'type'=>20
        ];
        (new CenterModel("u_user_message"))->add($info);
        $this->doResponse(0, "兑换成功");


    }

    //我的计划页面
    public function getMyPlan()
    {
        $data = null;
        $day = I("days", day());
        $myMedal = UuserService::getMedal($this->user->id);//我的勋章
        $model = (new CenterModel("u_target"));
        $where = [
            'uid' => $this->user->id,
            'etime' => ["gt", datetime()]
        ];
        $target = $model->getListBy($where, "title,type,etime", "type desc");
        foreach ($target as $key => $val) {
            $target[$key]['still'] = ceil((strtotime($val['etime']) - time()) / (3600 * 24));
        }
        $model = new PlanService();
        $dayPlan = $model->getPlanOnDay($this->user->id, $day);
        $data = [
            'medal' => $myMedal,
            'target' => $target ? $target : null,
            'dayPlan' => $dayPlan ? $dayPlan : null,
        ];
        $this->doResponse(0, "ok", $data);
    }

    //添加目标
    public function addTarget()
    {
        $type = I("type");
        $name = I("name");
        $endTime = I("endTime");
        if(strtotime($endTime)+24*3600<time()){
            $this->doResponse(-1, "目标日期错误，请选择一个较长的日期。");
        }
        if ($this->filter_Emoji($name) != $name) {
            $this->doResponse(-1, "内容不能包含特殊字符");
        }
        if($this->replaceSpecialChar($name) !=$name){
            $this->doResponse(-1, "内容不能包含特殊字符");
        }
        if (empty($type) || empty($name) || empty($endTime)) {
            $this->doResponse(-1, "缺少参数");
        }
        $model = new CenterModel("u_target");
        $where = [
            'uid'=>$this->user->id,
            'type' => $type,
            'etime' => ["egt", day()]
        ];
        if ($info=$model->getBy($where)) {
            $data=[
                'title'=>$name,
                'etime'=>datetime(strtotime($endTime)+24*3600),
            ];
            $model->update($info['id'],$data);
            $this->doResponse(0, "修改计划成功");
        }
        $endTime=datetime(strtotime($endTime)+24*3600);
        $info = [
            'uid' => $this->user->id,
            'type' => $type,
            'etime' => $endTime,
            'title' => $name
        ];
        (new CenterModel("u_target"))->add($info);
        $this->doResponse(0, "ok");
    }

    private function getSignStart()
    {
        $model= new CenterModel("u_sign");
        $info=[
            'uid'=>$this->user->id,
            'days'=>day(),
        ];
        $m=$model->getBy($info);
        return $m?"Y":"N";
    }

    public function delUser()
    {
        $debug = I("debug");
        if ($debug == "true") {
            $res = (new CenterModel("u_user"))->delete($this->user->id);
            $this->doResponse(0, "delete:" . $this->openid, $res);
        }
        $this->doResponse(-1, "?");
    }
    private function getVolunteer($id){
        $info=(new CenterModel("u_school"))->get($id,"name");
        $tag="未说明";
        if($info){
            $tag=$info['name'];

        }
        return $tag;

    }

}
