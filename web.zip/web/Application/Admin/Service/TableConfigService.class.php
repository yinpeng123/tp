<?php
namespace Admin\Service;

use Basic\Cnsts\DICT;

class TableConfigService {


    public static $cargo_order_list = [
        //说明title <th>中的列标题，twpt_attr td的表示, class 样式，  callback 调用的函数 如果配置了 callback 则class无效
        'header' => [
            'check_box'         => ['title' => '选择框', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'feed_id'          => ['title' => '货源ID', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'order_id'          => ['title' => '运单ID', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'net_no'          => ['title' => '发布人网号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'account'          => ['title' => '发货人账号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'telephone'         => ['title' => '手机号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'user_name'         => ['title' => '发货人姓名', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'company_name'         => ['title' => '发货人公司', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'start_name'        => ['title' => '出发城市', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'to_name'           => ['title' => '到达城市', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'good_type_desc'    => ['title' => '货物类型', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'car_type_desc'     => ['title' => '所需车型', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'car_length_desc'   => ['title' => '所需车长', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'data_from_desc'          => ['title' => '发布渠道', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'publish_time'      => ['title' => '发布日期', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'bidding_desc'      => ['title' => '是否竞价', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'is_trade_desc'      => ['title' => '是否成交', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'grab_price'        => ['title' => '成交价格', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'carry_user_id'     => ['title' => '承运人用户ID', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'car_num'          => ['title' => '承运车牌号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'track'            => ['title' => '承运车辆轨迹', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'open_ticket_desc'      => ['title' => '是否开票', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'order_status_desc' => ['title' => '运单状态', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'op'                => ['title' => '操作', 'sum_able' => FALSE, 'show' => TRUE,],
        ],
        //title 搜索标题，type
        'filter' => [
            'login_account'    => ['title' => '网号/账号/手机号', 'type' => 'text', 'default' => '', 'id' => ''],
            'data_from'     => ['title' => '发布渠道', 'type' => 'select', 'default' => ''],
            'order_status' => ['title' => '运单状态', 'type' => 'select', 'default' => ''],
            'user_name' => ['title' => '发货人姓名', 'type' => 'text', 'default' => ''],
            'company_name' => ['title' => '发货人公司', 'type' => 'text', 'default' => ''],
            'start_province_city'   => ['title' => '出发城市', 'type' => 'text', 'default' => '' ,'id' => 'start_province_city'],
            'to_province_city'      => ['title' => '到达城市', 'type' => 'text', 'default' => '','id' => 'to_province_city'],
            'bidding'      => ['title' => '是否竞价', 'type' => 'select', 'default' => ''],
            'is_trade'     => ['title' => '是否成交', 'type' => 'select', 'default' => ''],
            'open_ticket'     => ['title' => '是否开票', 'type' => 'select', 'default' => ''],
//            'publish_time' => ['title' => '发布时间', 'type' => 'date', 'default' => ''],
        ],

        'enum'    => [
            'data_from' => [
                0 => '请选择',
                10 => 'PC客户端',
                20 => 'APP',
                30 => 'PC网页版',
            ],
            'order_status' => DICT::ORDER_STATUS,
            'bidding' => [
                '0' => '请选择',
                '1' => '是',
                '2' => '否',
            ],
            'is_trade' => [
                '0' => '请选择',
                '1' => '是',
                '2' => '否',
            ],
            'open_ticket' => [
                '0' => '请选择',
                '1' => '是',
                '2' => '否',
            ],
        ],
        'data_id' => 'feed_id',
    ];

    public static $truck_order_list = [
        //说明title <th>中的列标题，twpt_attr td的表示, class 样式，  callback 调用的函数 如果配置了 callback 则class无效
        'header' => [
            'check_box'         => ['title' => '选择框', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'feed_id'          => ['title' => '车源ID', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'order_id'          => ['title' => '运单ID', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'net_no'          => ['title' => '发布人网号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'account'          => ['title' => '发货人账号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'telephone'         => ['title' => '手机号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'start_name'        => ['title' => '出发城市', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'to_name'           => ['title' => '到达城市', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'good_type_desc'    => ['title' => '需要货物', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'car_type_desc'     => ['title' => '车型', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'car_length_desc'   => ['title' => '车长', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'data_from_desc'          => ['title' => '发布渠道', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'publish_time'      => ['title' => '发布日期', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'op'                => ['title' => '操作', 'sum_able' => FALSE, 'show' => TRUE,],
        ],
        //title 搜索标题，type
        'filter' => [
            'login_account'    => ['title' => '网号/账号/手机号', 'type' => 'text', 'default' => '', 'id' => ''],
            'data_from'     => ['title' => '发布渠道', 'type' => 'select', 'default' => ''],
            'car_type'     => ['title' => '车型', 'type' => 'select', 'default' => ''],
            'car_length'     => ['title' => '车长', 'type' => 'select', 'default' => ''],
            'start_province_city'   => ['title' => '出发城市', 'type' => 'text', 'default' => '' ,'id' => 'start_province_city'],
            'to_province_city'      => ['title' => '到达城市', 'type' => 'text', 'default' => '','id' => 'to_province_city'],
            'good_type'     => ['title' => '货物类型', 'type' => 'select', 'default' => ''],
        ],
        'enum'    => [
            'data_from' => [
                0 => '请选择',
                10 => 'PC客户端',
                20 => 'APP',
                30 => 'PC网页版',
            ],
            'car_type'   => DICT::CAR_TYPE,
            'car_length' => DICT::CAR_LENGTH,
            'good_type'  => DICT::CARGO_TYPE,
        ],
        'data_id' => 'feed_id',
    ];

    public static $grab_info = [
        //说明title <th>中的列标题，twpt_attr td的表示, class 样式，  callback 调用的函数 如果配置了 callback 则class无效
        'header' => [
//            'check_box'         => ['title' => '选择框', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'net_no'          => ['title' => '网号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'account'          => ['title' => '账号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'telephone'         => ['title' => '手机号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'user_name'         => ['title' => '姓名', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'company_name'         => ['title' => '公司名', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'grab_price'           => ['title' => '报价(元)', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'create_time'     => ['title' => '报价时间', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'grab_status_desc'      => ['title' => '中标状态', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'remark'     => ['title' => '备注', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
        ],
        //title 搜索标题，type
        'filter' => [

        ],
        'enum'    => [

        ],
        'data_id' => 'feed_id',
    ];

//    public static $truck_order_list = [
//        'header' => [
//            'order_id'         => ['title' => '货源ID', 'twpt_attr' => 'order_id'],
//            'start_city'       => ['title' => '出发城市', 'twpt_attr' => ''],
//            'to_city'          => ['title' => '到达城市', 'twpt_attr' => ''],
//            'good_type_desc'   => ['title' => '货物类型', 'twpt_attr' => ''],
//            'order_count_desc' => ['title' => '数量', 'twpt_attr' => ''],
//            'price_rate_desc'  => ['title' => '运费单价', 'twpt_attr' => ''],
//            'car_length_desc'  => ['title' => '所需车长', 'twpt_attr' => ''],
//            'car_type_desc'    => ['title' => '所需车型', 'twpt_attr' => ''],
//            'publish_time'     => ['title' => '发布日期', 'twpt_attr' => ''],
//            'user_name'        => ['title' => '发布人姓名', 'twpt_attr' => ''],
//            'user_id'          => ['title' => '发布人ID', 'twpt_attr' => ''],
//            'telephone'        => ['title' => '联系方式', 'twpt_attr' => ''],
//            'channel'          => ['title' => '发布渠道', 'twpt_attr' => ''],
//            'op'               => ['title' => '操作', 'twpt_attr' => 'op'],
//        ],
//
//        'filter' => [
//            'user_name'    => ['title' => '发布人姓名', 'type' => 'text', 'default' => '',],
//            'telephone'    => ['title' => '联系方式', 'type' => 'text', 'default' => ''],
//            'start_city'   => ['title' => '出发城市', 'type' => 'text', 'default' => ''],
//            'to_city'      => ['title' => '到达城市', 'type' => 'text', 'default' => ''],
//            'car_type'     => ['title' => '所需车型', 'type' => 'select', 'default' => ''],
//            'car_length'   => ['title' => '所需车长', 'type' => 'select', 'default' => ''],
//            'good_type'    => ['title' => '货物类型', 'type' => 'select', 'default' => ''],
//            'publish_time' => ['title' => '发布时间', 'type' => 'date', 'default' => []],
//        ],
//
//        'enum'    => [
//            'car_type'   => DICT::CAR_TYPE,
//            'car_length' => DICT::CAR_LENGTH,
//            'good_type'  => DICT::CARGO_TYPE,
//        ],
//        'data_id' => 'order_id',
//    ];

    public static $user_list = [
        'header' => [
            'nick_name'        => ['title' => '用户名', 'twpt_attr' => 'nick_name'],
            'net_no'           => ['title' => '用户号', 'twpt_attr' => ''],
            'channel_desc'     => ['title' => '渠道', 'twpt_attr' => ''],
            'member_type_desc' => ['title' => '用户属性', 'twpt_attr' => ''],
            'cert_status_desc' => ['title' => '认证状态', 'twpt_attr' => ''],
            'product'          => ['title' => '付费产品标志', 'twpt_attr' => ''],
            'telephone'        => ['title' => '联系方式', 'twpt_attr' => ''],
            'member_end_time'  => ['title' => '网员到期日', 'twpt_attr' => ''],
            'city'             => ['title' => '注册地', 'twpt_attr' => ''],
            'last_login_city'  => ['title' => '登录地', 'twpt_attr' => ''],
            'op'               => ['title' => '操作', 'twpt_attr' => 'op'],
        ],

        'filter' => [
            'nick_name'        => ['title' => '用户名', 'type' => 'text', 'default' => '',],
            'net_no'           => ['title' => '用户号', 'type' => 'text', 'default' => ''],
            'telephone'        => ['title' => '联系方式', 'type' => 'text', 'default' => ''],
            'member_type_desc' => ['title' => '用户属性', 'type' => 'select', 'default' => ''],
            'cert_status_desc' => ['title' => '认证状态', 'type' => 'select', 'default' => ''],
            'product'          => ['title' => '产品标志', 'type' => 'select', 'default' => ''],
            'channel_id'       => ['title' => '所属渠道', 'type' => 'text', 'default' => ''],
            'company_name'     => ['title' => '公司名称', 'type' => 'text', 'default' => '',],
            'is_channel'       => ['title' => '渠道标识', 'type' => 'select', 'default' => ''],
            'is_abnormal'      => ['title' => '注册地登录异常', 'type' => 'select', 'default' => ''],
            'member_end_time'  => ['title' => '网员到期日', 'type' => 'date', 'default' => []],
        ],

        'enum'    => [
            'member_type_desc' => \Basic\Cnsts\DICT::MEMBER_TYPE,
            'cert_status_desc' => \Basic\Cnsts\DICT::CERT_STATUS_LIST,
            'product'          => [],
            'is_channel'       => [
                0 => '全部',
                1 => '是',
                2 => '否',
            ],
            'is_abnormal'      => [
                0 => '全部',
                1 => '是',
                2 => '否',
            ],
        ],
        'data_id' => 'user_id',
    ];

    /**
     * 开票列表
     */
    public static $ticket_config = [
        // 说明title <th>中的列标题，twpt_attr td的表示, class 表头样式，  callback表格样式
        'header' => [
            'ticket_id'     => ['title' => '开票单号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'fee_type_desc'      => ['title' => '发票服务名称', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'ticket_status_desc' => ['title' => '开票状态', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'confirm_time_ymd'  => ['title' => '开票日期', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'owner_company'  => ['title' => '开票公司', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'ticket_type_desc'  => ['title' => '发票类型', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'invoice_no'    => ['title' => '发票票号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'ticket_amount' => ['title' => '发票金额', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'payment_source' => ['title' => '收款来源', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'express_type_text' => ['title' => '寄送方式', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'mail_time_ymd'  => ['title' => '寄票日期', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'net_account'      => ['title' => '网号/账号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'app_telephone'      => ['title' => 'APP账号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'agent_id'      => ['title' => '所属渠道', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'company_name'  => ['title' => '公司名称', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'invoice_info'  => ['title' => '开票信息', 'sum_able' => FALSE, 'show' => TRUE, 'class' => 'max-column-width-90', 'callback' => ['class' => 'Admin\Service\TicketService', 'method' => 'getInvoiceInfoClass']],


            'order_ids_text'     => ['title' => '关联工/运单号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],


            'is_extra_open'      => ['title' => '补开发票', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'creator'      => ['title' => '创建人', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'create_time'      => ['title' => '创建日期', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'update_time'      => ['title' => '完成日期', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'op'            => ['title' => '操作', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
        ],
        //title 搜索标题，type
        'filter' => [
            'ticket_id'     => ['title' => '开票单号', 'type' => 'text', 'default' => '', 'id' => 'ticket_no'],
            'company_name'  => ['title' => '公司名称', 'type' => 'text', 'default' => '', 'id' => 'company_name'],
            'phone'         => ['title' => 'APP账号', 'type' => 'text', 'default' => '', 'id' => 'telephone'],
            'username'      => ['title' => '网号/账号', 'type' => 'text', 'default' => '', 'id' => 'user_name'],
            'confirm_time'  => ['title' => '确认日期', 'type' => 'date', 'default' => '', 'id' => 'confirm_time'],
            'fee_type'      => ['title' => '发票服务名称', 'type' => 'select', 'default' => '', 'id' => 'fee_type'],
            'ticket_status' => ['title' => '开票状态', 'type' => 'select', 'default' => '', 'id' => 'ticket_status'],
            'rebilling_ticket_type' => ['title' => '补开发票', 'type' => 'select', 'default' => '', 'id' => 'ticket_status'],
            'owner_company' => ['title' => '开票公司', 'type' => 'select', 'default' => '', 'id' => 'ticket_status'],
            'express_type' => ['title' => '寄送方式', 'type' => 'select', 'default' => '', 'id' => 'ticket_status'],
        ],
        'enum'   => [
            'ticket_status' => DICT::TICKET_STATUS_CRM,
            'fee_type'      => DICT::FEE_TYPE_LIST,
            'rebilling_ticket_type' => DICT::REBILLING_TICKET_LIST,
            'owner_company' => DICT::OWNER_COMPANY_LIST,
            'express_type' => DICT::EXPRESS_TYPE_LIST,
        ],
    ];

    /**
     * 开票编辑
     */
    public static $ticket_edit_config = [
        // 说明title <th>中的列标题，twpt_attr td的表示, class 表头样式，  callback表格样式
        'header' => [
            'id'         => ['title' => '运/工单号', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'type'       => ['title' => '费用名称', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'price_real' => ['title' => '金额(元)', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
        ],
        //title 搜索标题，type
        'filter' => [
            'ticket_id'       => ['title' => '开票单号', 'type' => 'text', 'default' => '', 'id' => 'ticket_id'],
            'account'       => ['title' => '账号/网号', 'type' => 'text', 'default' => '', 'id' => 'account'],
            'ticket_status'   => ['title' => '开票状态', 'type' => 'select', 'default' => '', 'id' => 'ticket_status'],
            'confirm_time'    => ['title' => '开票日期', 'type' => 'text', 'default' => '', 'id' => 'confirm_time'],
            'owner_company'        => ['title' => '开票公司', 'type' => 'select', 'default' => '', 'id' => 'owner_company'],
            'fee_type'        => ['title' => '发票服务名称', 'type' => 'select', 'default' => '', 'id' => 'fee_type'],
            'ticket_amount'   => ['title' => '发票金额(元)', 'type' => 'text', 'default' => '', 'id' => 'ticket_amount'],
            'express_no'      => ['title' => '快递单号', 'type' => 'text', 'default' => '', 'id' => 'express_no'],
            'create_time'     => ['title' => '创建日期', 'type' => 'text', 'default' => '', 'id' => 'create_time'],
            'mail_fee'        => ['title' => '快递费用(元)', 'type' => 'text', 'default' => '', 'id' => 'mail_fee'],
            'username'        => ['title' => '开票申请人', 'type' => 'text', 'default' => '', 'id' => 'username'],
            'phone'           => ['title' => '申请人电话', 'type' => 'text', 'default' => '', 'id' => 'phone'],
//            'remark'           => ['title' => '备注', 'type' => 'text', 'default' => '', 'id' => 'phone'],
        ],
        'enum'   => [
            'ticket_status' => DICT::TICKET_STATUS_CRM,
            'fee_type'      => DICT::FEE_TYPE_LIST,
            'owner_company' => DICT::OWNER_COMPANY_LIST,
            'express_company'      => DICT::EXPRESS_COMPANY_LIST,
            'express_type'      => DICT::EXPRESS_TYPE_LIST,
        ],
    ];
}