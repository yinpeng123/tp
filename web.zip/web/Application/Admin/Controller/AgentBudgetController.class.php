<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Basic\Cnsts\AGENT_CHARGE;
use Admin\Service\PageService;
use Basic\Cnsts\DICT;
use Basic\Model\StatsAgentFinanceModel;
use Basic\Model\UserModel;
use Basic\Service\AgentChargeService;

class AgentBudgetController extends AdminSessionController
{
    private $__agent_model = null;
    private $__user_model = null;
    private $__cs_work_sheet_model = null;

    public function __construct()
    {
        parent::__construct();

        $this->__agent_model         = D('Basic/Agent');
        $this->__user_model          = D('User');
        $this->__cs_work_sheet_model = D('Basic/CSWorkSheet');

        // 权限检查
        if (!\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id,
            \Admin\Cnsts\PRIVILEGE::AGENT_FINANCE)
        ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }
    }

    public function index()
    {
//        $this->runtime();
        //获取渠道类型
        $agent_style_arr = $this->getAgentStyle();
        //获取渠道状态
        $agent_status_arr = $this->getAgentStatus();

        $agentId         = I('agentId');
        $name            = I('name');
        $director        = I('director');
        $mobile          = I('mobile');
        $type            = I('type');
        $agent_status    = I('agent_status');
        $search_from_day = I('start_day');
        $search_to_day   = I('end_day');

        $search_agent_id = I('search_agent_id');

        if (!empty($agentId)) {
            $cond['agent.id'] = ['eq', $agentId];
        }
//        if (!empty($name)) {
//            $cond['agent.name'] = ['like', '%' . $name . '%'];
//        }
        if (!empty($search_agent_id)) {
            $cond['agent.id'] = ['eq', $search_agent_id];
        }
        if (!empty($director)) {
            $cond['agent.director'] = ['like', '%' . $director . '%'];
        }
        if (!empty($mobile)) {
            $cond['agent.mobile'] = ['like', '%' . $mobile . '%'];
        }
        if (!empty($type)) {
            $cond['agent.type'] = ['eq', $type];
        }
        if (!empty($agent_status)) {
            $cond['agent.agent_status'] = ['eq', $agent_status];
        }

        $cond['agent.is_done'] = 1;
        $per_page        = C('TABLE_PER_PAGE');
        $curr_page       = I('path.2/d', 1);
        $ret             = $this->__agent_model->searchAgentList($cond, $curr_page, $per_page);
//p($ret['data']);die;
        // 全部已完成渠道数据
        $res = $this->__agent_model->getAllAgentList($fields = NULL, $where = [] );

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();

        /** @var UserModel $user_model */
        $user_model = D('Basic/User', 'Model');
        /** @var StatsAgentFinanceModel $stats_agent_model */
        $stats_agent_model = D('Basic/StatsAgentFinance', 'Model');
        $total_income = 0;
        $total_outcome = 0;
        for ($i = 0; $i < count($ret['data']); $i++) {
            // 周期处理
            if (!empty($search_from_day) && !empty($search_to_day)) {
                $ret['data'][$i]['cyc_time'] = $search_from_day.'---'.$search_to_day;
            } elseif (!empty($search_from_day)) {
                $ret['data'][$i]['cyc_time'] = $search_from_day;
            } elseif (!empty($search_to_day)) {
                $ret['data'][$i]['cyc_time'] = $search_to_day;
            } else {
                $ret['data'][$i]['cyc_time'] = date('Y').'-'.date('m');
            }

            // 用户数量统计
            $where                         = [
                'channel_id' => $ret['data'][$i]['id'],
            ];
            $ret['data'][$i]['user_num'] = $user_model->getSqlFoundRows($where);

            if (!empty($search_from_day) && !empty($search_to_day)) {
                $start_month = $this->_formatmonth($search_from_day);
                $to_month = $this->_formatmonth($search_to_day);
                $where = [
                    'month' => [['egt', $start_month], ['elt', $to_month]],
                    'agent_id' => ['eq', $ret['data'][$i]['id']],
                ];
                $ret['data'][$i]['income'] = $stats_agent_model->getAllIncome($where);
                $ret['data'][$i]['outcome'] = $stats_agent_model->getAllOutcome($where);
            } elseif (!empty($search_from_day)) {
                $start_month = $this->_formatmonth($search_from_day);
                $where = [
                    'month' => [['egt', $start_month]],
                    'agent_id' => ['eq', $ret['data'][$i]['id']],
                ];
                $ret['data'][$i]['income'] = $stats_agent_model->getAllIncome($where);
                $ret['data'][$i]['outcome'] = $stats_agent_model->getAllOutcome($where);
            } elseif (!empty($search_to_day)) {
                $to_month = $this->_formatmonth($search_to_day);
                $where = [
                    'month' => [['egt', $to_month]],
                    'agent_id' => ['eq', $ret['data'][$i]['id']],
                ];
                $ret['data'][$i]['income'] = $stats_agent_model->getAllIncome($where);
                $ret['data'][$i]['outcome'] = $stats_agent_model->getAllOutcome($where);
            } else {
                $where = [
                    'month' => ['eq', date('Y').date('m')],
                    'agent_id' => ['eq', $ret['data'][$i]['id']],
                ];
                $ret['data'][$i]['income'] = $stats_agent_model->getAllIncome($where);
                $ret['data'][$i]['outcome'] = $stats_agent_model->getAllOutcome($where);
            }
            $total_income += $ret['data'][$i]['income'];
            $total_outcome += $ret['data'][$i]['outcome'];
        }
        $total_come = [
            'total_income' => $total_income == 0? '0.00':$total_income,
            'total_outcome' => $total_outcome == 0? '0.00' : $total_outcome,
        ];
//        p($ret['data']);die;

        $this->assignAll([
            'list'             => $ret['data'],
            'total_come'    => $total_come,
            'agent_list'    => $res,
            'agent_style_arr'  => $agent_style_arr,
            'agent_status_arr' => $agent_status_arr,
            'title'            => '渠道收支',
            'page_nav'         => $page_nav,
            'agentId'          => $agentId,
            'name'             => $name,
            'director'         => $director,
            'mobile'           => $mobile,
            'type'             => $type,
            'agent_status'     => $agent_status,
            'start_day'        => $search_from_day,
            'end_day'          => $search_to_day,
            'search_agent_id' => $search_agent_id,
//            'run_time' => $this->runtime(1),
        ]);
        $this->display('budget_index');
    }

    /**
     *  获取渠道类型
     */
    protected function getAgentStyle()
    {
        $agent_style_arr  = [];
        $agent_style_list = DICT::AGENT_STYLE_LIST;
        $agent_style_keys = array_keys($agent_style_list);
        foreach ($agent_style_keys as $i => &$r) {
            $agent_style_arr[] = ['id' => $r, 'text' => $agent_style_list[$r]];
        }

        return $agent_style_arr;
    }

    /**
     * 获取渠道状态
     */
    protected function getAgentStatus()
    {
        $agent_status_arr  = [];
        $agent_status_list = DICT::AGENT_STATUS_LIST;
        $agent_status_keys = array_keys($agent_status_list);
        foreach ($agent_status_keys as $i => &$r) {
            $agent_status_arr[] = ['id' => $r, 'text' => $agent_status_list[$r]];
        }

        return $agent_status_arr;
    }

    /**
     * @param $day 待转换的日期时间 格式 2017-12-18
     *
     * @return mixed 转换后的日期 格式 201712
     */
    private function _formatmonth($day) {
        $str = substr($day, 0, 7);
        $date = str_replace('-', '', $str);
        return $date;
    }

    // 计时函数 (计算脚本执行时间)
    public function runtime($mode = 0) {
        static $t;
        if(!$mode) {
            $t = microtime();
            return;
        }
        $t1 = microtime();
        list($m0,$s0) = explode(" ",$t);
        list($m1,$s1) = explode(" ",$t1);
        return sprintf("%.3f ms",($s1+$m1-$s0-$m0)*1000);
    }


}