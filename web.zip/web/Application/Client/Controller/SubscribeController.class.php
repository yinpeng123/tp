<?php
namespace Client\Controller;

use Basic\Service\OrderFeedService;
use Basic\Service\SubscribeService;
use Common\Controller\SessionController;
use Common\Cnsts\ERRNO;

class SubscribeController extends SessionController {

    public function __construct() {
        parent::__construct();
    }

    /**
     * 添加或修改订阅线路
     */
    public function saveSubscribe() {
        /** @var SubscribeService $subscribe_service */
        $subscribe_service = D('Basic/Subscribe', 'Service');
        $subscribe_id = $this->req['subscribe_id'];
        list($chk_errno, $chk_errmsg, $chk_ret) = $subscribe_service->checkParam($this->req);
        if ($chk_errno != ERRNO::SUCCESS) {
            return $this->doResponse($chk_errno, $chk_errmsg, null);
        }
        $max_subscribe_num = \Basic\Cnsts\ORDER::MAX_SUBSCRIBE_NUM;
        $desc = '最多添加'.$max_subscribe_num.'条常用线路';
        $list = $subscribe_service->getSubscribe($this->user_id);
        $added_num = count($list);
        if ( $added_num >= $max_subscribe_num  && empty($subscribe_id) ) {
            return $this->doResponse(ERRNO::INPUT_PARAM_ERRNO, $desc, null);
        }
        $save_data = $subscribe_service->getSaveData($this->req);
        $save_data['uid'] = $this->user_id;
        if ( empty($subscribe_id) ) {
            list($errno, $errmsg, $ret_data) = $subscribe_service->addSubscribe($save_data);
            $can_add_num = ($errno == 0) ? $max_subscribe_num - $added_num - 1 : $max_subscribe_num - $added_num;
        } else {
            $subscribe = $subscribe_service->getSubscribeById($subscribe_id);//判断是否是本人
            if ( $subscribe['uid'] != $this->user_id ) {
                return $this->doResponse(ERRNO::DATA_NOT_EXISTS, '数据不存在', null);
            }
            list($errno, $errmsg, $ret_data) = $subscribe_service->updateSubscribeById($subscribe_id, $save_data);
            $can_add_num =  $max_subscribe_num - $added_num;
        }

        $ret_data['can_add_num'] = $can_add_num;
        $ret_data['desc'] = $desc;
        return $this->doResponse($errno, $errmsg, $ret_data);
    }

    /**
     * @return bool
     * 常用线路列表
     */
    public function subscribeList() {
        /** @var SubscribeService $subscribe_service */
        $subscribe_service = D('Basic/Subscribe', 'Service');
        $list = $subscribe_service->getSubscribe($this->user_id);
        $max_subscribe_num = \Basic\Cnsts\ORDER::MAX_SUBSCRIBE_NUM;
        $subscribe_service->fmtSubList($list);
        $data = [
            'list' => $list,
            'can_add_num' => $max_subscribe_num - count($list),
            'desc' => '最多添加'.$max_subscribe_num.'条常用线路',
        ];
        return $this->doResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), $data);
    }

    /**
     *
     */
    public function intervalSubscribeList() {
        $uid = $this->user_id;
        /** @var SubscribeService $subscrive_service */
        $subscrive_service = D('Basic/Subscribe', 'Service');
        $subscribe_list = $subscrive_service->getSubscribe($uid);
        /** @var OrderFeedService $order_feed_service */
        $order_feed_service = D('Basic/OrderFeed', 'Service');
        foreach($subscribe_list as &$sub) {
            $sub_where = $subscrive_service->getSubWhere($sub);
            $co_num = $order_feed_service->getSqlFoundRows($sub_where);
            $sub['co_num'] = $co_num;
        }
        $subscrive_service->fmtSubList($subscribe_list);
        $ret_data = [
            'can_add_num' => \Basic\Cnsts\ORDER::MAX_SUBSCRIBE_NUM - count($subscribe_list),
            'desc' => '最多添加3条常用线路',
            'remind_frequency' => \Basic\Cnsts\ORDER::REMIND_FREQUENCY,
            'list' => $subscribe_list,
        ];
        return $this->doResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), $ret_data);
    }

    /**
     *删除订阅货源
     */
    public function delSubscribe() {
        /** @var SubscribeService $subscribe_service */
        $subscribe_service = D('Basic/Subscribe', 'Service');
        $subscribe_id = (int)($this->req['subscribe_id']);
        if (empty($subscribe_id) ) {
            return $this->doResponse(ERRNO::INPUT_PARAM_ERRNO,ERRNO::e(ERRNO::INPUT_PARAM_ERRNO), null);
        }
        $subscribe = $subscribe_service->getSubscribeById($subscribe_id);
        if ( $subscribe['uid'] != $this->user_id ) {
            return $this->doResponse(ERRNO::DATA_NOT_EXISTS, '数据不存在！', null);
        }
        $up_data = [
            'is_delete' => 1,
        ];
        list($errno, $errmsg, $ret_data) = $subscribe_service->updateSubscribeById($subscribe_id, $up_data);
        return $this->doResponse($errno, $errmsg, $ret_data);
    }

    /**
     * 重新计算订阅货源的数目
     * 更新对应订阅的缓存的feed_id
     */
    public function resetInterval() {
        $sub_id = $this->req['subscribe_id'];
        if ( empty($sub_id) ) {
            return $this->doResponse(ERRNO::INPUT_PARAM_ERRNO, ERRNO::e(ERRNO::INPUT_PARAM_ERRNO));
        }
        $uid = $this->user_id;
        /** @var SubscribeService $subscribe_service */
        $subscribe_service = D('Basic/Subscribe', 'Service');
        $sub_list = $subscribe_service->getSubscribe($uid);
        $sub_where = [];
        foreach ($sub_list as $sub) {
            if ($sub_id == $sub['id'] ) {
                $sub_where = $subscribe_service->getSubWhere($sub);
                break;
            }
        }
        if ( !empty($sub_where) ) {
            /** @var OrderFeedService $order_feed_service */
            $order_feed_service = D('Basic/OrderFeed', 'Service');
            $list = $order_feed_service->orderFeedList($sub_where, 'id desc', 1, ['id']);
            $last_feed_id = !empty($list) ? $list[0]['id'] : $sub_where['id'][1];
            $subscribe_service->setSubConfig($sub_id, $last_feed_id);
        }
        return $this->doResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), null);
    }

}