<?php

return [
    'commands' => [
        'Artisan\Console\Commands\OilFix',
        'Artisan\Console\Commands\OilImport',
        'Artisan\Console\Commands\TPSample',

    ],
];
