<?php
// 公共缓存Redis配置，存放如线上线下环境需要公用的access_token等数据
return [
    'PUBLIC_REDIS_CONF' => 'redis://:127.0.0.1',
    'PUBLIC_REDIS_HOST' => '127.0.0.1',
    'PUBLIC_REDIS_PORT' => 6379,
    'PUBLIC_REDIS_PASSWORD' => '',
    'PUBLIC_REDIS_DBINDEX'  => 1,
];

?>