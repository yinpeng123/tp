<?php
namespace Admin\Controller;

use Basic\Service\SysNoticeService;
use Think\Controller;

class ScriptController  extends Controller {

    public function __construct() {
        parent::__construct();
        if ( !APP_DEBUG && !IS_CGI ) {
            exit('不允许当前操作');
        }
    }

    /***
     *系统消息轮询
     */
    public function sysNoticeRoll() {
        //设置缓存，防止上次轮询未完成，进行第二次轮询,程序结束后清除缓存【待解决问题,程序出错,缓存已经设置】
        if ( $this->isRollAgain() ) {
            echo '轮询未结束!';
            return;
        }
        if ( !APP_DEBUG ) {
            $this->setPreventCache();
        }
        /** @var SysNoticeService $sys_notice_s */
        $sys_notice_s = D('Basic/SysNotice', 'Service');
        $un_push_where = [
            'publish_time' => ['elt', datetime()],
            'push_status' => 0,
        ];

        //1.查找消息公告列表
        $list = $sys_notice_s->getSysNoticeList($un_push_where);
        if ( empty($list) ) {
            echo "success";
        } else {
            //2.每条公告对应的link_ids
            $is_success = 'success';
            foreach ( $list as $v) {
                $sys_link_where = [
                    'sys_notice_id' => $v['id'],
                ];
                $sys_links = $sys_notice_s->getSysLinks($sys_link_where);
                $link_ids = array_column($sys_links,'link_id');
                $data = [
                    'title' => $v['title'],
                    'content' => $v['content'],
                    'platform' => $v['platform'],
                    'to_type' => $v['to_type'],
                    'publish_time' => $v['publish_time'] ? : '',
                    'sys_notice_id' => $v['id'],
                ];
                //3.推送消息
                $sys_notice_s->pushSysNotice($link_ids,$data);
                //4.把当前的消息标记为已推送状态，//防止第一次请求没有完成，又发生第二次请求
                $up_data = [
                    'push_status' => 1,
                ];
                $up_where = [
                    'id' => $v['id'],
                ];
                $up_res = $sys_notice_s->updateSysByWhere($up_where, $up_data);
                if ( !$up_res ) {
                    cmm_log('内部消息发送轮询失败,数据：'.json_encode($data));
                    $is_success = false;
                }
            }
            if ( !$is_success ) {
                echo "fail";
            } else {
                echo "success";
            }
        }
        $this->removePreventCache();
    }

    //设置防止重复轮询的缓存
    public function setPreventCache() {
        S(\Basic\Cnsts\CACHE_PREFIX::PREVENT_SYS_ROLL_AGAIN, true);
    }

    //移除重复轮询的缓存
    public function removePreventCache() {
        S(\Basic\Cnsts\CACHE_PREFIX::PREVENT_SYS_ROLL_AGAIN, false);
    }

    //判断是否重复轮询
    public function isRollAgain() {
        return S(\Basic\Cnsts\CACHE_PREFIX::PREVENT_SYS_ROLL_AGAIN);
    }

}