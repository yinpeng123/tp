<?php

namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\AuthService;
use Basic\ModelU\CenterModel;
use Admin\Service\PageService;

class MallController extends AdminSessionController
{
    public function __construct()
    {
        parent::__construct();

    }

    public function index()
    {
        $where=[
            'is_del'=>'N',
        ];
        if(I("net_no")){
            $key="%".I("net_no")."%";
            $where['name']= array('like',$key);
        }
        $model = new CenterModel('u_mall');
        $list = $model->getListBy($where, "*", "id desc");
        $this->assignAll(array(
            'title' => '商品列表',
            'list' => $list,
        ));
        $this->display('index');
    }

    public function edit($id = 0)
    {
        $model = new CenterModel('u_mall');
        $list = [];
        if ($id) {
            $list = $model->get($id);
        }
        $this->assignAll(array(
            'title' => '添加商品',
            'list' => $list,
        ));
        $this->display('edit');
    }

    public function order()
    {

        $curr_page = I('path.2/d', 1);
        $model = new CenterModel('u_mall_order');
        $where = [];
        if(I("net_no")){
            $ws=['name'=>["like",'%'.I("net_no").'%']];
            $goods=(new CenterModel("u_mall"))->getBy($ws);
            $where['good_id']=$goods?$goods['id']:0;
        }
        $list = $model->getListBy($where, "*", "id desc", $curr_page, 15);
        $total = $model->getListTotal($where);
        $page_service = new PageService($total, 15);
        $page_nav = $page_service->show();
        $this->packData($list);
        $this->assignAll(array(
            'title' => '兑换记录',
            'list' => $list,
            'page_nav' => $page_nav
        ));
        $this->display('orderlist');
    }

    public function doEdit()
    {

        $id = I("id", 0);
        $info = [
            'name' => I('name'),
            'amount' => I("point"),
            'pic' => implode(",", I("identity_photo")),
        ];
        if(strlen(I("point"))>10){
            $this->admin_error("积分格式超范围");
            exit;
        }


        $model = new CenterModel("u_mall");
        if ($id) {
            $model->update($id, $info);
            $msg = "修改文章成功";
        } else {
            $model->add($info);
            $msg = "添加文章成功";
        }
        $this->admin_success($msg, "/mall/index");

    }

//删除所有
    public function delete()
    {
        $ids = I("ids");
        if (is_array($ids)) {
            $where = 'id in(' . implode(',', $ids) . ')';
        } else {
            $where = 'id=' . $ids;
        }  //dump($where);
        M("u_mall")->where($where)->delete();
        $this->admin_success("删除成功");
    }

    //增加快递
    public function addExpress()
    {
        $info = [
            'fild1' => I("fild1"),
            'fild2' => I("fild2"),
        ];
        $id=I("id");
        $model = new CenterModel("u_mall_order");
        $model->update($id,['remark'=>t_json_encode($info)]);
        $tmp=$model->get($id,"*");
        $goods= (new CenterModel("u_mall"))->get($tmp['good_id']);
        $info=[
            'uid' => $tmp['uid'],
            'title'=>"您的".$goods['name']."订单号为",
            "content"=>I("fild1")."  ".I("fild2"),
            'type'=>20
        ];
        (new CenterModel("u_user_message"))->add($info);

        $this->doResponse(0,"ok");
    }

    private function packData(&$data)
    {
        $u_model = new CenterModel("u_user");
        $a_model = new CenterModel("u_user_address");
        $g_model = new CenterModel("u_mall");
        foreach ($data as $key => $val) {
            $data[$key]['name'] = $u_model->get($val['uid'], "name")['name'];
            $data[$key]['goods'] = $g_model->get($val['good_id'], "name")['name'];
            $data[$key]['point'] = $g_model->get($val['good_id'], "amount")['amount'];
            $data[$key]['address'] = $a_model->get($val['address_id'], "*")['content'];
            $data[$key]['province'] = $a_model->get($val['address_id'], "*")['province'];
            $data[$key]['city'] = $a_model->get($val['address_id'], "*")['city'];
            $data[$key]['area'] = $a_model->get($val['address_id'], "*")['area'];
            if ($val['remark']) {
                $data[$key]['remark'] = t_json_decode($val['remark']);
            }
        }
    }


}