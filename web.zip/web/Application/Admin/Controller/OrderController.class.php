<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\ManagerService;
use Admin\Service\TableConfigService;
use Admin\Service\TableService;
use Basic\Model\CityModel;
use Basic\Model\CoOrderModel;
use Basic\Model\ShippingOrderModel;
use Basic\Model\UserModel;
use Basic\Service\CityService;
use Basic\Service\GrabService;
use Basic\Service\OrderService;
use Basic\Cnsts\DICT;
use Basic\Service\SignService;
use Basic\Service\UserFinanceService;
use Basic\Service\UserService;
use Common\Cnsts\ERRNO;
use Admin\Service\PageService;

class OrderController extends AdminSessionController {
    public function __construct() {
        parent::__construct();
    }

    public function cargoOrderList() {

        $cargo_configs = TableConfigService::$cargo_order_list;
        $filters_fields = $cargo_configs['filter'];
        $cond = $this->prepareSearchCond(array_keys($filters_fields));
        $cond['start_province'] = I('start_province');
        $cond['start_city'] = I('start_city');
        $cond['start_district'] = I('start_district');
        $cond['to_province'] = I('to_province');
        $cond['to_city'] = I('to_city');
        $cond['to_district'] = I('to_district');
        $page_size = C('TABLE_PER_PAGE');
        $page_num = I('path.2/d', 1);
        $where = $this->_getOrderListWhere($cond);
        $where['order_type'] = DICT::ORDER_TYPE_CARGO;
        $limit = ($page_num -1) * $page_size.','.$page_size;
        $order_by = 'publish_time desc';
        /** @var \Admin\Service\OrderService $order_service */
        $order_service = D('Admin/Order', 'Service');
        $list = $order_service->getOrderFeedList($where, $order_by, $limit);
        $total = $order_service->getSqlFoundRows($where);
        $page_service = new PageService($total, $page_size);
        $page_nav = $page_service->show();
        $this->_formatCargoList($list);
        $table_service = new \Admin\Service\TableService($cargo_configs);

        //表格内容，包含head 和body
        $table_content = $table_service->getTableContent($list);
        //搜索栏内容
        $filters = $table_service->getFilterContent($cond);

        $cond = $cond ? :[];
        $this->assignAll($cond);
        $this->_assignStartToName();
        $this->assignAll(array(
            'title'   => '货源列表',
            'filters'   => $filters,
            'table_content' => $table_content,
            'list'    => $list,
            'page_nav' => $page_nav,
            'action' => '/Order/cargoOrderList',

        ));
        $this->display('cargo_order_list');
    }

    protected function _assignStartToName() {
        $start_province = I('start_province');
        $start_city = I('start_city');
        $start_district = I('start_district');
        /** @var OrderService $order_service */
        $start_province_city = '';
        if ($start_province) {
            $start_province_city = $this->__getCityNameById($start_province);
        }
        if ($start_city) {
            $start_province_city .= $this->__getCityNameById($start_city);

        }
        if ($start_district) {
            $start_province_city .= $this->__getCityNameById($start_city);
        }
        $start_province_city = $start_province_city.'-'.$this->__getCityNameById($start_district);

        $to_province_city = '';
        $to_province = I('to_province');
        $to_city = I('to_city');
        $to_district = I('to_district');
        if ($to_province) {
            $to_province_city = $this->__getCityNameById($to_province);

        }

        if ($to_city) {
            $to_province_city = $to_province_city.'-'.$this->__getCityNameById($to_city);

        }
        if ($to_district) {
            $to_province_city = $to_province_city.'-'.$this->__getCityNameById($to_district);
        }
        $this->assign('start_province_city',$start_province_city);
        $this->assign('to_province_city',$to_province_city);
        $this->assignAll(
            array(
                'start_province' => $start_province,
                'start_city' => $start_city,
                'start_district' => $start_district,
                'to_province' => $to_province,
                'to_city' => $to_city,
                'to_district' => $to_district,
            )
        );
    }

    private function __getCityNameById($id) {
        $city_model_s = new \Basic\Model\CityModel('slave', TRUE);
        $city = $city_model_s->get($id);
        return $city['name'];
    }

    protected function _getOrderListWhere($cond) {
        $where = [];
        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');

        if ( !$manager_service->isWLManager($this->_manager) ) {
            $where['user.channel_id'] = $this->_manager['agent_id'];
        }
        if ( $cond['login_account'] ) {
            $where['_complex'] = [
                'user.net_no' => ['like', "%{$cond['login_account']}%"],
                'user.telephone' => ['like', "%{$cond['login_account']}%"],
                'user.account' => ['like', "%{$cond['login_account']}%"],
                '_logic' => 'or',
            ];
        }
        if ($cond['data_from']) {
            $where['co_order_feed.data_from'] = $cond['data_from'];
        }
//        if ($cond['order_status']) {
//            $where['co_order_feed.order_status'] = $cond['order_status'];
//        }

        if ( $cond['user_name'] ) {
            $where['user.user_name'] = ["like","%{$cond['user_name']}%"];
        }


        if ( $cond['company_name'] ) {
            $where['user.company_name'] = ["like","%{$cond['company_name']}%"];
        }

        /** @var OrderService $order_service */
        $order_service = D('Basic/Order', 'Service');
        $start = $order_service->getSearchStart($cond);
        $to = $order_service->getSearchTo($cond);
        if ( !empty($start) ) {
            $where['start_code'] = ['like',"$start%"];
        }

        if ( !empty($to) ) {
            $where['to_code'] = ['like',"$to%"];
        }

        if ( $cond['bidding'] ) {
            switch ($cond['bidding']) {
                case 1 :
                    $where['co_order_feed.bidding'] = $cond['bidding'];
                    break;
                case 2:
                    $where['co_order_feed.bidding'] = 0;
                    break;
                default :
                    break;
            }
        }

        if ($cond['publish_time'][0] && $cond['publish_time'][1]) {
            $where['co_order.publish_time'] = ['between',[$cond['publish_time'][0].' 00:00:00',$cond['publish_time'][1].' 23:59:59']];
        } else {
            if ($cond['publish_time'][0]) {
                $where['co_order.publish_time'] = ['egt',$cond['publish_time'][0].' 00:00:00'];
            }
            if ($cond['publish_time'][1]) {
                $where['co_order.publish_time'] = ['elt',$cond['publish_time'][1].' 23:59:59'];
            }
        }

        if ( $cond['open_ticket'] == 1 ) { //是否开票
            $where['shipping_order.ticket_id'] = ['gt', 0];
        } else if ( $cond['open_ticket'] == 1 ) {
            $where['shipping_order.ticket_id'] = 0;
        } else {

        }

        if ( $cond['is_trade'] == 1 ) { //是否成交
            $where['shipping_order.payment_id'] = ['gt', 0];
        } else if ( $cond['open_ticket'] == 1 ) {
            $where['shipping_order.payment_id'] = 0;
        } else {

        }
        $where['co_order_feed.status'] = 1;
        return $where;
    }

    protected function _formatCargoList(&$list) {
        /** @var OrderService $order_service */
        $order_service = D('Basic/Order','Service');
        /** @var \Admin\Service\OrderService $admin_order_service */
        $admin_order_service = D('Admin/Order','Service');
        $grab_ids = array_column($list, 'grab_id', 'order_id');
        $grab_list = [];
        if ( !empty($grab_ids) ) {
            $where ['id'] = [
                'in', $grab_ids,
            ];
            /** @var GrabService $grab_service */
            $grab_service = D('Basic/Grab', 'Service');
            $grab_list = $grab_service->getGrabList($where);
        }
        $grab_format = array_column($grab_list, 'car_num', 'order_id');
        foreach ($list as $key => &$value) {
            $order_unit = DICT::getDictValue($value['order_unit'],'order_unit');
//            $order_status_desc = DICT::getDictValue($value['order_status'],'order_status');
            $good_type_desc = DICT::getDictValue($value['good_type'],'good_type');
            $car_type_desc = DICT::getDictValue($value['car_type'],'car_type');
            $car_length_desc = DICT::getDictValue($value['car_length'],'car_length');
            $value['order_count_desc'] = $value['order_count'].$order_unit;
//            $value['order_status_desc'] = $order_status_desc;
            $value['good_type_desc'] = $good_type_desc;
            $value['car_type_desc'] = $car_type_desc;
            $value['car_length_desc'] = $car_length_desc;
        //@todo 改成常量
            switch ( $value['data_from'] ) {
                case DICT::DATA_FROM_WLZG :
                case DICT::DATA_FROM_WLZG_BJ :
                case DICT::DATA_FROM_WL_PC :
                    $value['data_from_desc'] = 'PC客户端';
                    break;
                case DICT::DATA_FROM_APP :
                    $value['data_from_desc'] = 'APP';
                    break;
                case DICT::DATA_FROM_PC :
                    $value['data_from_desc'] = 'PC网页版';
                    break;
                default :
                    break;
            }
            if ( $admin_order_service->canCloseOrder($value)) {
                $value['op'] = '<a href="javascript:void(0)" class="op_edit_close" op_data_id='.$value['feed_id']
                    .'>关闭</a>';
            } else if ( $value['order_status'] === DICT::ORDER_STATUS_CLOSE) {
                $value['op'] = '<a href="javascript:void(0)" class="op_edit_close_reason" op_data_id="'.$value['feed_id']
                    .'" closed_remark="'.$value['closed_remark'].'">关闭原因</a>';
            } else {
                $value['op'] = '<a href="javascript:void(0)" class="op_edit_none" op_data_id='.$value['feed_id'];
            }
            $value['bidding_desc'] = $this->_biddingDesc($value['bidding'], $value['order_id']);
            $value['is_trade_desc'] = $this->_tradeDesc($value['payment_id']);
            $value['open_ticket_desc'] = $this->_openTicketDesc($value['ticket_id']);
            $value['grab_price'] = $value['grab_price'];
            $value['track'] = $this->_track($value['order_id']);
//            $value['order_status_desc'] = DICT::getDictValue($value['order_status'], 'business_order_status');
            $value['car_num'] = !empty($grab_format[$value['order_id']]) ? $grab_format[$value['order_id']] : '';
            $pcd = $order_service->_addrCodeToPCD($value['start_code'],$value['to_code']);
            $value['start_name'] = $pcd['start_name'];
            $value['to_name'] = $pcd['to_name'];
        }
    }

    protected function _biddingDesc($bidding,$order_id) {
        switch( $bidding ) {
            case 0 :
                $desc = '否';
                break;
            case 1 :
                if ( $order_id ) {
                    $desc = '<a href="/Order/grabInfo?order_id='.$order_id.'" style="color:blue">是</a>';
                } else {
                    $desc = '<span>是</span>';
                }
                break;
        }
        return $desc;
    }

    protected function _tradeDesc($payment_id) {
        if ( $payment_id > 0 ) {
            $is_trade_desc = '是';
        } else {
            $is_trade_desc = '否';
        }
        return $is_trade_desc;
    }

    protected function _openTicketDesc($ticket_id) {
        if ( $ticket_id > 0 ) {
            $open_ticket_desc = '是';
        } else {
            $open_ticket_desc = '否';
        }
        return $open_ticket_desc;
    }

    //@todo 车辆轨迹
    protected function _track($order_id) {
        return '';
    }

    public function grabInfo() {
        $order_id = I('order_id');
        /** @var OrderService $order_service */
        $order_service = D('Basic/Order', 'Service');
        $order_info = $order_service->getOrderMergeShipInfo($order_id);
        $order_service->appengDataFromDesc($order_info);
        /** @var UserService $user_service */
        $user_service = D('Basic/User','Service');
        $user_info = $user_service->getUserInfo($order_info['user_id']);
        $grab_configs = TableConfigService::$grab_info;
        /** @var GrabService $grab_service */
        $grab_service = D('Basic/Grab', 'Service');
        $grab_where = [
            'order_id' => $order_id,
        ];
        $list = $grab_service->getGrabList($grab_where);
        $grab_service->fmtBeGrabList($list);
        $table_service = new \Admin\Service\TableService($grab_configs);
        //表格内容，包含head 和body
        $table_content = $table_service->getTableContent($list);
        //搜索栏内容
        $this->assignAll(array(
            'order_info' => $order_info,
            'user_info' => $user_info,
            'table_content' => $table_content,
            'action' => '/Order/truckOrderList',
        ));
        $this->display('grab_info');
    }

    public function truckOrderList() {
        $truck_configs = TableConfigService::$truck_order_list;
        $filters_fields = $truck_configs['filter'];
        $cond = $this->prepareSearchCond(array_keys($filters_fields));
        $cond['start_province'] = I('start_province');
        $cond['start_city'] = I('start_city');
        $cond['start_district'] = I('start_district');
        $cond['to_province'] = I('to_province');
        $cond['to_city'] = I('to_city');
        $cond['to_district'] = I('to_district');
        $page_size = C('TABLE_PER_PAGE');
        $page_num = I('path.2/d', 1);
        $where = $this->_getTruckListWhere($cond);
        $limit = ($page_num -1) * $page_size.','.$page_size;
        $order_by = 'publish_time desc';
        /** @var \Admin\Service\OrderService $order_service */
        $order_service = D('Admin/Order', 'Service');
        $list = $order_service->getOrderFeedList($where, $order_by, $limit);
        $total = $order_service->getSqlFoundRows($where);
        $page_service = new PageService($total, $page_size);
        $page_nav = $page_service->show();
        $this->_formatTruckList($list);
        $table_service = new \Admin\Service\TableService($truck_configs);

        //表格内容，包含head 和body
        $table_content = $table_service->getTableContent($list);
        //搜索栏内容
        $filters = $table_service->getFilterContent($cond);

        $cond = $cond ? :[];
        $this->assignAll($cond);
        $this->_assignStartToName();
        $this->assignAll(array(
            'title'   => '车源列表',
            'filters'   => $filters,
            'table_content' => $table_content,
            'list'    => $list,
            'page_nav' => $page_nav,
            'action' => '/Order/truckOrderList',
        ));
        $this->display('cargo_order_list');
    }

    //获取车源列表筛选条件
    protected function _getTruckListWhere($cond) {

        $where = [];
        $where['order_type'] = DICT::ORDER_TYPE_TRUCK;
        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');

        if ( !$manager_service->isWLManager($this->_manager) ) {
            $where['user.channel_id'] = $this->_manager['agent_id'];
        }
        if ( $cond['login_account'] ) {
            $where['_complex'] = [
                'user.net_no' => ['like', "%{$cond['login_account']}%"],
                'user.telephone' => ['like', "%{$cond['login_account']}%"],
                'user.account' => ['like', "%{$cond['login_account']}%"],
                '_logic' => 'or',
            ];
        }
        if ($cond['data_from']) {
            $where['co_order_feed.data_from'] = $cond['data_from'];
        }

        if ( $cond['car_type'] ) {
            $where['co_order_feed.car_type'] = $cond['car_type'];
        }

        if ( $cond['car_length'] ) {
            $where['co_order_feed.car_length'] = $cond['car_length'];
        }

        if ( $cond['good_type'] ) {
            $where['co_order_feed.good_type'] = $cond['good_type'];
        }

        /** @var OrderService $order_service */
        $order_service = D('Basic/Order', 'Service');
        $start = $order_service->getSearchStart($cond);
        $to = $order_service->getSearchTo($cond);
        if ( !empty($start) ) {
            $where['start_code'] = ['like',"$start%"];
        }

        if ( !empty($to) ) {
            $where['to_code'] = ['like',"$to%"];
        }

        if ( $cond['bidding'] ) {
            switch ($cond['bidding']) {
                case \Basic\Cnsts\ORDER::BIDDING_Y :
                    $where['co_order_feed.bidding'] = $cond['bidding'];
                    break;
                case 2 :
                    $where['co_order_feed.bidding'] = \Basic\Cnsts\ORDER::BIDDING_N;//@todo
                    break;
                default :
                    break;
            }
        }

        if ($cond['publish_time'][0] && $cond['publish_time'][1]) {
            $where['co_order.publish_time'] = ['between',[$cond['publish_time'][0].' 00:00:00',$cond['publish_time'][1].' 23:59:59']];
        } else {
            if ($cond['publish_time'][0]) {
                $where['co_order.publish_time'] = ['egt',$cond['publish_time'][0].' 00:00:00'];
            }
            if ($cond['publish_time'][1]) {
                $where['co_order.publish_time'] = ['elt',$cond['publish_time'][1].' 23:59:59'];
            }
        }

        if ( $cond['open_ticket'] == 1 ) { //是否开票
            $where['shipping_order.ticket_id'] = ['gt', 0];
        } else if ( $cond['open_ticket'] == 1 ) {
            $where['shipping_order.ticket_id'] = 0;
        } else {

        }

        if ( $cond['is_trade'] == 1 ) { //是否成交
            $where['shipping_order.payment_id'] = ['gt', 0];
        } else if ( $cond['open_ticket'] == 1 ) {
            $where['shipping_order.payment_id'] = 0;
        } else {

        }
        $where['co_order_feed.status'] = 1;
        return $where;
    }

    //转化车源列表
    protected function _formatTruckList(&$list) {
        /** @var OrderService $order_service */
        $order_service = D('Basic/Order', 'Service');
        /** @var \Admin\Service\OrderService $admin_order_service */
        $admin_order_service = D('Admin/Order','Service');
        foreach ($list as $key => &$value) {
            $order_status_desc = DICT::getDictValue($value['order_status'],'order_status');
            $good_type_desc = DICT::getDictValue($value['good_type'],'good_type');
            $car_type_desc = DICT::getDictValue($value['car_type'],'car_type');
            $car_length_desc = DICT::getDictValue($value['car_length'],'car_length');
            $value['order_status_desc'] = $order_status_desc;
            $value['good_type_desc'] = $good_type_desc;
            $value['car_type_desc'] = $car_type_desc;
            $value['car_length_desc'] = $car_length_desc;

            switch ( $value['data_from'] ) {
                case 10 :
                    $value['data_from_desc'] = 'PC客户端';
                    break;
                case 20 :
                    $value['data_from_desc'] = 'APP';
                    break;
                case 30 :
                    $value['data_from_desc'] = 'PC网页版';
                    break;
                default :
                    break;
            }

            if ( $admin_order_service->canCloseOrder($value)) {
                $value['op'] = '<a href="javascript:void(0)" class="op_edit_close" op_data_id='.$value['feed_id']
                    .'>关闭</a>';
            } else if ( $value['order_status'] === DICT::ORDER_STATUS_CLOSE) {
                $value['op'] = '<a href="javascript:void(0)" class="op_edit_close_reason" op_data_id='.$value['feed_id']
                    .' closed_remark='.$value['closed_remark'].'>关闭原因</a>';
            } else {

                $value['op'] = '<a href="javascript:void(0)" class="op_edit_none" op_data_id='.$value['feed_id']
                    .' closed_remark="'.$value['close_remark'].'"></a>';
            }
            $value['order_status_desc'] = DICT::getDictValue($value['order_status'], 'order_status');
            $pcd = $order_service->_addrCodeToPCD($value['start_code'],$value['to_code']);
            $value['start_name'] = $pcd['start_name'];
            $value['to_name'] = $pcd['to_name'];
        }
    }

    //关闭车源 //货源
    public function closeOrder() {
        $order_id = (int) I('order_id');
        $manager_id = $this->_manager_id;
        $close_reason =  I('close_reason');
        if ($order_id <= 0) {
            return ;
        }
        /** @var \Admin\Service\OrderService $order_service */
        $order_service = D('Admin/Order', 'Service');
        list($errno, $message,$data) = $order_service->closeOrder($order_id,$close_reason,$manager_id);
        $this->doResponse($errno,$message,[]);
        return;
    }

    /**
     * crm  运单管理
     *
     *      列表页
     */
    public function orderList() {

        $search_ftime_from = I('search_ftime_from');
        $search_ftime_to = I('search_ftime_to');
        $search_user = I('search_user');
        $search_order_id = I('search_order_id');
        $search_car_num = I('search_car_num');
        $search_type = I('search_type');
        $search_status = I('search_status');

        $cond = [];
        if (!empty($search_ftime_from) && !empty($search_ftime_to)) {
            $cond["shipping_order.ctime"] = [
                ['egt', $search_ftime_from . ' 00:00:00'],
                ['elt', $search_ftime_to . ' 23:59:59']
            ];
        } else {
            if (!empty($search_ftime_from)) {
                $cond["shipping_order.ctime"] = [['egt', $search_ftime_from . ' 00:00:00']];
            } else {
                if (!empty($search_ftime_to)) {
                    $cond["shipping_order.ctime"] = [['elt', $search_ftime_to . ' 23:59:59']];
                }
            }
        }
        if (!empty($search_order_id)) {
            $cond['shipping_order.id'] = ['eq', $search_order_id];
        }
        if (!empty($search_car_num)) {
            $cond['shipping_order.car_num'] = ['eq', $search_car_num];
        }
        if (!empty($search_type) && $search_type == DICT::GET_ORDER ){
            $cond['co_order.carry_user_id'] = ['egt', 0];
        } elseif (!empty($search_type) && $search_type == DICT::GOODS_ORDER) {
            $cond['co_order.carry_user_id'] = ['eq', 0];
        } else {

        }
        if (!empty($search_status)) {
            $cond['co_order.order_status'] = ['eq', $search_status];
        }
        if (!empty($search_user)) {
            $search_user_name['co_order.carry_user_id'] = ['eq', $search_user];
            $search_user_name['co_order.user_id'] = ['eq', $search_user];
            $search_user_name['_logic'] = 'OR';
        } else {
            $search_user_name['co_order.carry_user_id'] = ['neq', ''];
            $search_user_name['co_order.user_id'] = ['neq', ''];
            $search_user_name['_logic'] = 'OR';
        }

        $cond['_complex'] = $search_user_name;
        $search_param = [
            'search_ftime_from' => $search_ftime_from,
            'search_ftime_to' => $search_ftime_to,
            'search_order_id' => $search_order_id,
            'search_car_num' => $search_car_num,
            'search_type' => $search_type,
            'search_status' => $search_status,
            'search_user' => $search_user,
        ];

        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
//p($cond);die;
        /** @var ShippingOrderModel $shipping_order_model */
        $shipping_order_model = D('Basic/ShippingOrder', 'Model');
        $co_order_list = $shipping_order_model ->crmCoOrderList($cond, $curr_page, $per_page);
//p($co_order_list);die;
        $order_list = $this->_formateInfo($co_order_list['data']);

        $page_service = new PageService($co_order_list['count'], $per_page);
        $page_nav = $page_service->show();

        $user_model = new \Admin\Model\UserModel('slave');
        $user_list = $user_model->getUserList (['is_delete' => 0, 'status' => 1], 'id desc', $limit = '', 'id, account', $join = '');

        $this->setTrackByList(array_column($order_list,'order_id'));
//        p($cond);die;
        $this->assignAll(array(
            'title' => '运单管理',
            'list' => $order_list,
            'page_nav' => $page_nav,
            'search_list' => $user_list,
            'form_action' => 'orderList',
            'search_param' => $search_param,
            'type_arr' => $this->getOrderStatus(),
            'status_arr' => $this->getOrderSearchStatus(),
        ));
        $this->display('order_list_index');
    }

    private function _formateInfo ($list) {
        /** @var CityService $city_service */
        $city_service = D('Basic/City', 'Service');

        /** @var UserService $user_service */
        $user_service = D('Basic/User', 'Service');
        foreach($list as &$v) {
            // 起点->终点
            $v['order_start_text'] = $city_service->getAreaFullName($v['start_code'], $sep = '');
            $v['order_to_text'] = $city_service->getAreaFullName($v['to_code'], $sep = '');
            // 货主信息
            $info = $user_service->getUserInfoWithExtra($v['user_id']);
            $v['user_name'] = $info['user_name'];
            $v['user_net_no'] = $info['net_no'];
            // 车主信息
            $carry_info = $user_service->getUserInfoWithExtra($v['carry_user_id']);
            $v['carry_user_name'] = $carry_info['user_name'];
            $v['carry_user_net_no'] = $carry_info['net_no'];
            // 运单状态
            $v['order_status_text'] = DICT::ORDER_SEARCH_STATUS_WITHOUT_ALL[$v['order_status']];

        }
        return $list;
    }

    /**
     * 获取货运类型
     */
    protected function getOrderStatus()
    {
        $order_arr = [];
        $order_list = DICT::FREIGHT_TYPE;
        $order_keys = array_keys($order_list);
        foreach ($order_keys as $i => &$r) {
            $order_arr[] = ['id' => $r, 'text' => $order_list[$r]];
        }

        return $order_arr;
    }

    /**
     * 获取运单状态
     */
    protected function getOrderSearchStatus()
    {
        $order_arr = [];
        $order_list = DICT::ORDER_SEARCH_STATUS_WITHOUT_ALL;
        $order_keys = array_keys($order_list);
        foreach ($order_keys as $i => &$r) {
            $order_arr[] = ['id' => $r, 'text' => $order_list[$r]];
        }

        return $order_arr;
    }

    /**
     * @note :根据orderid list获取定位数据
     * @param  :
     * @return :
     */
    private function setTrackByList($ids){
        $res=[];

        if($ids){
            $track = D('Basic/Track', 'Model') ;
            $is_auto=D('Basic/CoAutoLocaltion', 'Model');
            foreach($ids as $order_id){
                $track_where = ['order_id' => $order_id ];
                $total=$track->getListTotal($track_where);
                $auto_track=$is_auto->getBy($track_where);
                $tmp="";
                if($auto_track  && $auto_track['status']==1){
                    $tmp= "授权失败";
                }
                $res[$order_id]=[
                    'total'=>$total>=1?"有轨迹":"",
                    'aoto_track'=>$tmp,
                    'status'=>$auto_track['status'],
                    'track'=>$total>1?"有轨迹":"",
                ];
            }

        }
        $this->assignAll(['track_list'=>$res]);

    }

    public function getSign() {
        $order_id = I('order_id');
        $times = time();
        $info=I();
        unset($info['times']);
        /** @var SignService $sign_service */
        $sign_service = D('Basic/Sign', 'Service');
        $sign = $sign_service->genSignature($times, $info);

        $this->ajaxResponse(ERRNO::SUCCESS, '', ['sign' => $sign, 'times' => $times]);
    }
}