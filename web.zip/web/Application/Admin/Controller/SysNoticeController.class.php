<?php
namespace Admin\Controller;

use Admin\Service\ManagerService;
use Basic\Model\SysNoticeModel;
use Basic\Service\AgentService;
use Basic\Service\SysNoticeService;
use Basic\Service\UserService;
use Basic\Service\WLSendService;
use Common\Cnsts\ERRNO;
use Admin\Service\PageService;
use Think\Exception;

class SysNoticeController extends AdminSessionController {

    const TO_TYPE_AGENT = 'agent'; //按渠道发送
    const TO_TYPE_USER = 'user'; //按用户发送
    protected $_is_hrb_manager_agent = null;
    protected $_manager_agent_id = null;

    public function __construct() {
        parent::__construct();
        $this->_manager_agent_id = $this->_manager['agent_id'];
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::SYS_NOTICE  ) ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }
    }

    /**
     * 添加公告管理页面
     */
    public function addNotice() {
        $sys_notice_id = I('sys_notice_id', 0, 'int');
        $sys_notice = [];
        if ($sys_notice_id) {
            /** @var SysNoticeModel $sys_notice_serice */
            $sys_notice_serice = D('Basic/SysNotice', 'Service');
            $sys_notice = $sys_notice_serice->getSysNoticeById($sys_notice_id);
            $this->_formatSysNotice($sys_notice);
        }

        /** @var AgentService $agent_service */
        $agent_service = D('Basic/Agent', 'Service');
        $agent_list = $agent_service->getFormatAgent();
        if ( $this->_manager_agent_id ) {
            $agent_list =[$this->_manager_agent_id =>$agent_list[$this->_manager_agent_id]];
        }
        $this->assignAll(
            array(
                'sys_notice_id' => $sys_notice_id,
                'sys_notice'  => $sys_notice,
                'title' => '新建公告',
                'form_action' => '/SysNotice/doAdd',
                'agent_list' => $agent_list,
                'platform_arr' => [
                    'all' => '全部',
                    'pc' => 'pc',
                    'app' => 'app',
                ],
            )
        );
        $this->display('add_sys_notice');
    }

    /**
     * @param 转换公告
     */
    protected function _formatSysNotice(&$sys_notice) {
        if ($sys_notice['to_type'] == self::TO_TYPE_AGENT) {
            /** @var SysNoticeService $sys_notice_service */
            $sys_notice_service = D('Basic/SysNotice', 'Service');
            $where = [
                'sys_notice_id' => $sys_notice['id'],
            ];
            $sys_links = $sys_notice_service->getSysLinks($where);
            $sys_link_ids = array_column($sys_links,'link_id');
            $sys_notice['agents'] = $sys_link_ids;
            $sys_notice['sys_notice_id'] = $sys_notice['id'];
        }
    }

    /**
     * 添加系统公告
     * @todo 添加系统公告
     */
    public function doAdd() {
        $data = [
            'title' => I('title',''),
            'content' => I('content',''),
            'platform' => I('platform',''),
            'to_type' => I('to_type',''),
            'agents' => I('agents'),
            'publish_time' => I('publish_time',''),
            'attachment' => $this->uploadAttachment(),
        ];
        $this->_checkV2($data);
        $add_data = $this->_getAddData($data);
        $link_ids = $this->_getLinkIds($data);//@todo 异步发送 附件上传也改成异步推送
        /** @var SysNoticeService $sys_notice_service */
        $sys_notice_service = D('Basic/SysNotice', 'Service');

        list($errno,$errmsg,$add_res) = $sys_notice_service->addSysNotice($add_data);
        if ($errno != ERRNO::SUCCESS) {
            $this->admin_error($errmsg);
            return;
        }

        list($errno, $errmsg,$add_res ) = $this->_addSysLink($link_ids,$add_res['sys_notice_id']); //添加关联表的记录

        if ($errno != ERRNO::SUCCESS) {
            $this->admin_error($errmsg);
            return;
        }
        $this->admin_success('添加公告成功',"/SysNotice/getSysNoticeList");
    }

    /**
     * 检验参数是否正确
     */
    protected function _checkV2($data) {
        if (empty($data['title'])) {
            $this->admin_error('请填写公告名');
            exit();
        }
        if (empty($data['content'])) {
            $this->admin_error('请填写公告内容');
            exit();
        }
        if (empty($data['platform'])) {
            $this->admin_error('请选择可见类型');
            exit();
        }
        if (empty($data['to_type'])) {
            $this->admin_error('请选择推送类型');
            exit();
        }
        if ($data['to_type'] == self::TO_TYPE_AGENT) {
            $agents = I('agents');
            if (empty($agents)) {
                $this->admin_error('请选择渠道');
                exit();
            }
        } else if ($data['to_type'] == self::TO_TYPE_USER) {
            if (empty($_FILES['attachment'])) {
                $this->admin_error('请上传附件');
                exit();
            }
        }
    }

    public function _getAddData($data) {
        $add_data = [
            'category' => \Basic\Cnsts\NOTICE::CATEGORY_SYS_NOTICE,
            'type' => \Basic\Cnsts\NOTICE::NOTICE_TYPE_SYS_NOTICE,
            'platform' => $data['platform'],
            'to_type' => $data['to_type'],
            'title'  => $data['title'],
            'content' => $data['content'],
            'publish_time' => $data['publish_time'] ? $data['publish_time'] : datetime(),
//            'push_status' => ($data['publish_time'] <= datetime()) ? 1 : 0,
            'create_by' => $this->_manager_id,
            'attachment' => json_encode($data['attachment'],JSON_UNESCAPED_UNICODE),
        ];
        return $add_data;
    }

    protected function _addSysLink($link_ids,$sys_notice_id) {
        $sys_notice_link_data = [];
        foreach ($link_ids as $lid){
            $sys_notice_link_data[] = [
                'sys_notice_id' => $sys_notice_id,
                'link_id' => $lid,
            ];
        }
        /** @var SysNoticeService $sys_notice_service */
        $sys_notice_service = D('Basic/SysNotice', 'Service');
        list($errno,$errmsg,$add_link_res) = $sys_notice_service->mulitiAddLink($sys_notice_link_data);
        return [$errno,$errmsg,$add_link_res];
    }

    /**
     *获取link_ids
     */
    protected function _getLinkIds($data) {
        $link_ids = [];
        if ( $data['to_type'] == self::TO_TYPE_AGENT ) {
            $link_ids = $data['agents'];
        } else if ( $data['to_type'] == self::TO_TYPE_USER ) {
            $link_ids = $this->_getLinkIdsByUpFile($data);
        }
        return $link_ids;
    }

    /**
     * 根据上传文件获取
     */
    protected function _getLinkIdsByUpFile($data) {
        $attachment = $data['attachment'];
        $root_dir = C('FILE_PATH')[$attachment['type']];
        $file = $root_dir.$attachment['path'].'/'.$attachment['name'];
        $service = new \Vendor\ImportExcel\ExcelParser();
        $origin_data = $service->getData($file);
        if (trim($origin_data[0][0]) == '手机号' && trim($origin_data[0][1]) =='网号' &&  trim($origin_data[0][2]) == '账号') {
            unset($origin_data[0]);
            $link_ids = $this->_formatOriginData($origin_data);
        } else {
            $this->admin_error('文件模板不正确');
            exit();
        }
        return $link_ids;
    }

    /**
     * @param $origin_data
     * 获取数据的id
     */
    protected function _formatOriginData($origin_data){
        $telephones = $id_tel = [];
        $net_nos = $id_no = [];
        $accounts = $id_acc = [];
        foreach($origin_data as $key => $value) {
            if (!empty($value[0])) {
                $telephones[] = $value[0];
            }
            if (!empty($value[1])) {
                $net_nos[] = $value[1];
            }
            if (!empty($value[2])) {
                $accounts[] = $value[2];
            }
        }
        /** @var UserService $user_service */
        $fields = ['id','telephone'];
        $user_service = D('Basic/User','Service');
        if ($telephones) {
            $user1 = $user_service->getListBy(['telephone'=>['in',$telephones]],$fields);
            $id_tel = array_column($user1,'id');
        }
        if ($net_nos) {
             $user2 = $user_service->getListBy(['net_no'=>['in',$net_nos]],$fields);
            $id_no = array_column($user2,'id');
        }
        if ($accounts) {
            $user3 = $user_service->getListBy(['account'=>['in',$accounts]], $fields);
            $id_acc = array_column($user3,'id');
        }
        $ids = array_unique(array_merge($id_tel,$id_no,$id_acc));
        return $ids ? :[];
    }


    //上传附件
    public function uploadAttachment() {
        $root_dir = C('FILE_PATH')['crm_file'];
        $sub_dir = day();
        $attachment = array();
        if ( !empty($_FILES['attachment']) && $_FILES['attachment']['size'] > 0 ) { // 头像
            list($errcode, $errmsg) = uploadFile('attachment', $root_dir, $sub_dir, $attachment, 'crm_file');
            if ( $errcode != ERRNO::SUCCESS ) {
                $this->admin_error('文件上传失败！'.$errmsg);
                return false;
            }
        }
        return $attachment;
    }

    /**
     * 系统消息列表
     */
    public function getSysNoticeList() {
        $configs = $this->getTableConfigs();
        $cond = $this->prepareSearchCond(array_keys($configs['filter']));
        $page_size = C('TABLE_PER_PAGE');
        $page_num = I('path.2/d', 1);
        $where = $this->_getSysNoticeWhere($cond);
        $fields = $this->_getSysNoticeField();
        $limit = ($page_num -1) * $page_size.','.$page_size;
        $order_by = 'id desc';
        /** @var SysNoticeService $sys_notice_service */
        $sys_notice_service = D('Basic/SysNotice', 'Service');
        $list = $sys_notice_service->getSysNoticeList($where,$fields,$order_by,$limit);
        $total = $sys_notice_service->getSysNoticeListTotal($where);
        $page_service = new PageService($total, $page_size);
        $page_nav = $page_service->show();
        $this->_formatList($list);

        $table_service = new \Admin\Service\TableService($configs);
        $table_content = $table_service->getTableContent($list);//表格内容，包含head 和body
        $filters = $table_service->getFilterContent($cond); //搜索栏内容
        $cond = $cond ? :[];
        $this->assignAll($cond);
        $this->assignAll(array(
            'title'   => '公告管理',
            'filters'   => $filters,
            'table_content' => $table_content,
            'page_nav' => $page_nav,
        ));
        $this->display('sys_notice_list');
    }

    /**
     * 获取表格的配置
     */
    protected function getTableConfigs() {
        $configs = \Basic\Cnsts\SYS_NOTICE::SYS_TABLE_CONFIG;
        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');
        $format_manager_list = $manager_service->getFormatManger();
        $new_manager_list = [
            0 => '请选择',
        ];
        foreach ( $format_manager_list as $key => $manager ) {
            $new_manager_list[$key] = $manager;
        }
        $configs['enum']['create_by'] = $new_manager_list;
        return $configs;
    }

    /**
     *获取消息内部消息的搜索条件
     */
    protected function _getSysNoticeWhere($cond) {
        $where = [
            'status' => 1,
            'crm_show_flag' => 1,
        ];
        if ($cond['title']) {
            $where['title'] = ['like',"%{$cond['title']}%"];
        }
        if ($cond['create_by']) {
            $where['create_by'] = $cond['create_by'];
        }

        return $where;
    }

    /**
     * 获取消息公告字段
     */
    protected function _getSysNoticeField() {
        $fields = [];
        return $fields;
    }

    /**
     * 转换消息公告列表
     */
    protected function _formatList(&$list) {
        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');
        $format_manager_list = $manager_service->getFormatManger();
        foreach($list as &$v) {
            $v['sys_notice_id'] = $v['id'];
            $v['create_by_desc'] = !empty($v['create_by'])? ($format_manager_list[$v['create_by']]) : '';
            if ($v['platform'] == 'all') {
                $v['platform'] = '全部';
            }
            $v['title'] = '<a style="text-decoration:underline" href="/SysNotice/addNotice?sys_notice_id='
                .$v['sys_notice_id'].'">' .$v['title'] .'</a>';
        }
    }

    public function deleteAll(){
        $ids = I('ids');
        if (empty($ids)) {
            $this->admin_error('请选择要删除的记录');
            return ;
        }
        /** @var SysNoticeService $sys_notice_service */
        $sys_notice_service = D('Basic/SysNotice','Service');
        $where = [
            'id' => ['in',$ids],
        ];
        $data = [
            'crm_show_flag' => 0
        ];
        list($errno,$errmsg,$data)= $sys_notice_service->updateSysByWhere($where,$data);
        if ($errno == ERRNO::SUCCESS) {
            try{
                foreach ( $ids as $id ) {
                    /** @var WLSendService $wl_send_service */
                    $wl_send_service = D('Basic/WLSend', 'Service');
                    $wl_send_service->syncBulletin($id, 'delete');
                }
            } catch (Exception $e) {

            }

            $this->admin_success($errmsg);
        } else {
            $this->admin_error($errmsg);
        }
        return;
    }
    public function delete(){
        $sys_notice_id = I('sys_notice_id');
        if (empty($sys_notice_id)) {
            $this->admin_error('请选择要删除的记录');
            return ;
        }
        /** @var SysNoticeService $sys_notice_service */
        $sys_notice_service = D('Basic/SysNotice','Service');
        $where = [
            'id' => $sys_notice_id,
        ];
        $data = [
            'crm_show_flag' => 0
        ];
        list($errno,$errmsg,$data)= $sys_notice_service->updateSysByWhere($where,$data);
        if ($errno == ERRNO::SUCCESS) {
            /** @var WLSendService $wl_send_service */
            $wl_send_service = D('Basic/WLSend', 'Service');
            $wl_send_service->syncBulletin($sys_notice_id, 'delete');
            $this->admin_success($errmsg);
        } else {
            $this->admin_error($errmsg);
        }
        return;
    }
}