<?php
namespace Admin\Controller;

use Admin\Service\InnerNoticeService;
use Admin\Service\ManagerService;
use Common\Cnsts\ERRNO;
use Admin\Service\PageService;

class InnerNoticeController extends AdminSessionController {

    const _ALL_ = '_ALL_'; //全部

    public function __construct() {
        parent::__construct();
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::MESSAGE  ) ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }
    }

    /**
     * 添加公告管理页面
     */
    public function addInnerNotice() {
        $inner_notice_id = I('inner_notice_id',0,'int');
        $act = I('act','add');
        $format_manager_list = $this->_getSysFormatManList();
        $inner_notice = [];
        $receive_list = [];
        if ($inner_notice_id) {
            /** @var InnerNoticeService $inner_notice_serice */
            $inner_notice_serice = D('Admin/InnerNotice', 'Service');
            $inner_notice = $inner_notice_serice->getInnerNoticeById($inner_notice_id);
            $inner_notice['attachment'] = $inner_notice['attachment'] ?  json_decode($inner_notice['attachment'], JSON_UNESCAPED_UNICODE) :[];
            $where = [
                'inner_notice_id' => $inner_notice_id,
            ];
            if (I('from' == 'receive')) {
                $this->tagReadMyNotice($inner_notice_id);
            }
            if ($inner_notice['receive_type'] == self::_ALL_) {
                $receive_list[] = [
                    'id' => self::_ALL_,
                    'text' => '全部',
                ];
            } else {
                $notice_links = $inner_notice_serice->getInnerNoticeLinks($where);
                $manager_ids = array_column($notice_links,'manager_id');
                foreach ($manager_ids as $mid) {
                    $receive_list[] = [
                        'id' => $mid,
                        'text' => $format_manager_list[$mid],
                    ];
                }
            }
        }
        $this->assignAll(
            array(
                'format_manager_list' => $format_manager_list,
                'inner_notice_id' => $inner_notice_id,
                'receive_list' => $receive_list,
                'inner_notice'  => $inner_notice,
                'title' => '消息管理',
                'act'   => $act,
                'form_action' => '/InnerNotice/doAdd',
            )
        );
        $this->display('add_inner_notice');
    }
    protected function _getSysFormatManList() {
        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');
        $format_manager_list[self::_ALL_] = '全部';
        $manager_list = $manager_service->getFormatManger();
        foreach($manager_list as $key=> $value) {
            $format_manager_list[$key] = $value;
        }
        return $format_manager_list;
    }

    protected function tagReadMyNotice($inner_notice_id) {

        $where = [
            'inner_notice_id' => $inner_notice_id,
            'manager_id' => $this->_manager_id,
        ];
        $data = [
            'read_status' => 1,
        ];
        /** @var InnerNoticeService $inner_notice_service */
        $inner_notice_service = D('Admin/InnerNotice', 'Service');
        list($errno,$errmsg,$up_data) = $inner_notice_service->upNoticeLink($where,$data);
        return [$errno,$errmsg,$up_data];
    }

    //获取下载图片
    public function getFile() {
        $file_info = array();
        $req = I('req','','htmlspecialchars_decode');
        $req = json_decode($req,JSON_UNESCAPED_UNICODE);
        getFile($req['type'], $req['path'], $req['name'], $file_info);
        $full_path = $file_info['full_path'];
        header("Content-Type: application/octet-stream");
        header("Content-type:text/html;charset=utf-8");
        header("Accept-Ranges: bytes");
        header("Accept-Length: ".filesize($full_path));
        header("Cache-Control: private, max-age=604800, must-revalidate");
        header('Pragma: private');
        header('Last-Modified: '.gmdate('D, d M Y H:i:s', filemtime($full_path)).' GMT');
        header('Expires: '.gmdate('D, d M Y H:i:s', time()+604800).' GMT');
        header("Content-Disposition: attachment; filename={$req['name']}");
        echo fread($file_info['file'],filesize($full_path));

    }

    //添加系统内部公告
    public function doAdd() {
        $title = I('title','');
        $content = I('content');
        $receive = I('receive','','htmlspecialchars_decode');
        $receive = json_decode($receive,JSON_UNESCAPED_UNICODE);
        $is_all = 0;
        if (in_array(self::_ALL_,$receive)) {
            $manager_service = D('Admin/Manager', 'Service');
            $format_manager_list = $manager_service->getFormatManger();
            $receive = array_keys($format_manager_list);
            $is_all = 1;
        }
        if (empty($title)) {
            $this->admin_error('请填写公告名');
            return;
        }
        if (empty($content)) {
            $this->admin_error('请填写公告内容');
            return;
        }
        if (empty($receive)) {
            $this->admin_error('请填写收件人');
            return;
        }
        $attachment = $this->uploadAttachment();
        //添加消息
        $inner_notice_data = [
            'title' =>$title,
            'content' => $content,
            'attachment' => json_encode($attachment,JSON_UNESCAPED_UNICODE),
            'push_status' => 1,
            'create_by' => $this->_manager_id,
        ];
        $inner_notice_data['receive_type'] = $is_all ? self::_ALL_: '';
        /** @var InnerNoticeService $inner_notice_service */
        $inner_notice_service = D('Admin/InnerNotice', 'Service');
        list($errno,$errmsg,$add_res) = $inner_notice_service->addInnerNotice($inner_notice_data);
        if ($errno != ERRNO::SUCCESS) {
            $this->admin_error($errmsg);
            return;
        }
        $inner_notice_id = $add_res['inner_notice_id'];

        $this->addInnerNoticeLink($receive,$inner_notice_id);

        $push_content = [
            'category' => 'inner_notice',
            'data' => [
                'title' => $title,
                'content' => $content,
                'inner_notice_id' => $inner_notice_id,
                'read_status' => 0,
                'create_time' => datetime(),
            ]
        ];
        $targets = [];
        foreach($receive as $rev) {
            $targets[] = 'crm_'.$rev;
        }
        $this->admin_success('添加消息成功','/InnerNotice/getInnerNoticeList');
        fastcgi_finish_request();
        ws_notify($targets,$push_content);
    }

    protected function addInnerNoticeLink($receive,$inner_notice_id) {

        $inner_notice_link_data = [];
        foreach ($receive as $mid){
            $inner_notice_link_data[] = [
                'inner_notice_id' => $inner_notice_id,
                'manager_id' => $mid,
            ];
        }
        /** @var InnerNoticeService $inner_notice_service */
        $inner_notice_service = D('Admin/InnerNotice', 'Service');
        list($errno,$errmsg,$add_link_res) = $inner_notice_service->mulitiAddLink($inner_notice_link_data);

        if ($errno != ERRNO::SUCCESS) {
            $this->admin_error($errmsg);
            return;
        }
    }

    //上传附件
    public function uploadAttachment() {
        $root_dir = C('FILE_PATH')['crm_file'];
        $sub_dir = day();
        $attachment = array();
        if ( !empty($_FILES['attachment']) && $_FILES['attachment']['size'] > 0 ) { // 头像
            list($errcode, $errmsg) = uploadFile('attachment', $root_dir, $sub_dir, $attachment, 'crm_file');
            if ( $errcode != ERRNO::SUCCESS ) {
                $this->admin_error('文件上传失败！'.$errmsg);
                return;
            }
        }
        return $attachment;
    }

    //获取系统消息详情
    public function getInnerNoticeById() {

    }
    //系统消息列表
    public function getInnerNoticeList() {
        $configs = \Admin\Cnsts\INNER_NOTICE::INNER_NOTICE_TABLE_CONFIG;
        /** @var ManagerService $manager_service */
        $filters_fields = $configs['filter'];
        $cond = $this->prepareSearchCond(array_keys($filters_fields));
        $page_size = 20;
        $page_num = I('path.2/d', 1);
        $where = $this->_getInnerNoticeWhere($cond);
        $fields = $this->_getInnerNoticeField();
        $limit = ($page_num -1) * $page_size.','.$page_size;
        $order_by = 'id desc';
        /** @var InnerNoticeService $inner_notice_service */
        $inner_notice_service = D('Admin/InnerNotice', 'Service');
        $list = $inner_notice_service->getInnerNoticeList($where,$fields,$order_by,$limit);
        $total = $inner_notice_service->getSqlFoundRows($where);
        $page_service = new PageService($total, $page_size);
        $page_nav = $page_service->show();

        $this->_formatList($list);
        $table_service = new \Admin\Service\TableService($configs);
        $table_content = $table_service->getTableContent($list); //表格内容，包含head 和body
        $filters = $table_service->getFilterContent($cond); //搜索栏内容
        $cond = $cond ? :[];
        $this->assignAll($cond);

        $this->assignAll(array(
            'title'   => '消息管理',
            'filters'   => $filters,
            'table_content' => $table_content,
            'page_nav' => $page_nav,
        ));
        $this->display('inner_notice_list');
    }


    protected function _getInnerNoticeWhere($cond) {
        $where = [
            'status' => 1,
            'crm_show_flag' => 1,
        ];
        if ($cond['title']) {
            $where['title'] = ['like',"%{$cond['title']}%"];
        }
        if ($cond['create_by']) {
            $where['create_by'] = $cond['create_by'];
        }
        return $where;
    }

    //获取公告字段
    protected function _getInnerNoticeField() {
        $fields = [];
        return $fields;
    }

    //获取列表
    protected function _formatList(&$list) {
        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');
        $format_manager_list = $manager_service->getFormatManger();
        foreach($list as &$v) {
            $v['inner_notice_id'] = $v['id'];
            $v['create_by_desc'] = !empty($v['create_by'])? ($format_manager_list[$v['create_by']]) : '';
            $v['title'] = '<a style="text-decoration:underline" href="/InnerNotice/addInnerNotice?inner_notice_id='
                .$v['id'].'&act=view">' .$v['title'] .'</a>';
        }
    }

    //发布人批量删除
    public function deleteAll(){
        $ids = I('ids');
        if (empty($ids)) {
            $this->admin_error('请选择要删除的记录');
            return ;
        }
        $ids = array_filter($ids);
        /** @var InnerNoticeService $inner_notice */
        $inner_notice = D('Admin/InnerNotice','Service');
        $where = [
            'id' => ['in',$ids],
        ];
        $data = [
            'crm_show_flag' => 0
        ];
        list($errno,$errmsg,$data)= $inner_notice->upInnerByWhere($where,$data);
        if ($errno == ERRNO::SUCCESS) {
            $this->admin_success($errmsg);
        } else {
            $this->admin_error($errmsg);
        }
        return;
    }
    public function delete(){
        $inner_notice_id = I('inner_notice_id');
        if (empty($inner_notice_id)) {
            $this->admin_error('请选择要删除的记录');
            return ;
        }
        /** @var InnerNoticeService $inner_notice */
        $inner_notice = D('Admin/InnerNotice','Service');
        $where = [
            'id' => $inner_notice_id,
        ];
        $data = [
            'crm_show_flag' => 0
        ];
        list($errno,$errmsg,$data)= $inner_notice->upInnerByWhere($where,$data);
        if ($errno == ERRNO::SUCCESS) {
            $this->admin_success($errmsg);
        } else {
            $this->admin_error($errmsg);
        }
        return;
    }

    //我的消息列表
    public function myNoticeList() {
        $configs = \Admin\Cnsts\INNER_NOTICE::MY_NOTICE_TABLE_CONFIG;
        /** @var ManagerService $manager_service */
        $filters_fields = $configs['filter'];
        $cond = $this->prepareSearchCond(array_keys($filters_fields));
        $page_size = 20;
        $page_num = I('path.2/d', 1);
        $where = $this->_getMyNoticeWhere($cond);
        $fields = $this->_getMyNoticeField();
        $limit = ($page_num -1) * $page_size.','.$page_size;
        $order_by = 'inner_notice_link.inner_notice_id desc';
        $join = $this->_getMyNoticeJoin();
        /** @var InnerNoticeService $inner_notice_service */
        $inner_notice_service = D('Admin/InnerNotice', 'Service');
        $list = $inner_notice_service->getInnerNoticeList($where,$fields,$order_by,$limit,$join);
        foreach ($list as &$value) {
            $attachment = $value['attachment'] ? json_decode($value['attachment'],JSON_UNESCAPED_UNICODE) : [];
            if ($attachment) {
                $value['attachment_down'] = "<a href='/InnerNotice/getFile?req={\"type\":\"{$attachment['type']}\",
                \"name\":\"{$attachment['name']}\",\"path\":\"{$attachment['path']}\"}'>下载附件</a>";
            } else {
                $value['attachment_down'] = '';
            }
            if ($value['read_status'] == 1) {
                $value['read_status_desc'] = '是';
            } else {
                $value['read_status_desc'] = '否';
            }
            $value['title'] = '<a style="text-decoration:underline" href="/InnerNotice/addInnerNotice?inner_notice_id='
                .$value['inner_notice_id'].'&act=view&from=receive">' .$value['title'] .'</a>';
            $value['op'] = '<a href="/InnerNotice/deleteMyNotice?notice_link_id='
                .$value['notice_link_id'].'">' .'删除' .'</a>
                <a  href="/InnerNotice/addInnerNotice?inner_notice_id='
                .$value['inner_notice_id'].'&act=view&from=receive">' .'查看' .'</a>';
        }
        $total = $inner_notice_service->getSqlFoundRows($where,$join);
        $page_service = new PageService($total, $page_size);
        $page_nav = $page_service->show();
        $table_service = new \Admin\Service\TableService($configs);
        //表格内容，包含head 和body
        $table_content = $table_service->getTableContent($list);
        //搜索栏内容
        $filters = $table_service->getFilterContent($cond);
        $cond = $cond ? :[];
        $this->assignAll($cond);
        $this->assignAll(array(
            'title'   => '我的消息',
            'filters'   => $filters,
            'table_content' => $table_content,
            'page_nav' => $page_nav,
        ));
        $this->display('my_notice_list');
    }

    public function newInnerNotice() {
        $where = [
            'inner_notice_link.read_status' => 0,
            'inner_notice_link.crm_show_flag' => 1,
            'inner_notice_link.manager_id'  => $this->_manager_id,
        ];
        $fields = $this->_getMyNoticeField();
        $limit = 4;
        $order_by = 'inner_notice_link.inner_notice_id desc';
        $join = $this->_getMyNoticeJoin();
        /** @var InnerNoticeService $inner_notice_service */
        $inner_notice_service = D('Admin/InnerNotice', 'Service');
        $list = $inner_notice_service->getInnerNoticeList($where,$fields,$order_by,$limit,$join);
        $manager_service = D('Admin/Manager', 'Service');
        $manager_list = $manager_service->getFormatManger();
        foreach($list as &$value) {
            $value['create_by_name'] = $manager_list[$value['create_by']];
        }
        $total = $inner_notice_service->getSqlFoundRows($where,$join);
        $data = [
            'total' => $total,
            'list'  => $list,
        ];
        $this->doResponse(ERRNO::SUCCESS,ERRNO::e(ERRNO::SUCCESS),$data);
    }

    protected function _getMyNoticeWhere($cond,$type = null) {
        $where = [
            'inner_notice_link.crm_show_flag' => 1,
        ];
        if ($cond['title']) {
            $where['title'] = ['like',"%{$cond['title']}%"];
        }
        $where['manager_id'] = $this->_manager_id;
        if ($type == 'un_read') {
            $where['read_status'] = 0;
        }
        return $where;
    }

    protected function _getMyNoticeField() {
        $fields = [
            'inner_notice_link.id as notice_link_id',
            'inner_notice_link.read_status as read_status',
            'inner_notice_link.manager_id as manager_id',
            'inner_notice_link.inner_notice_id as inner_notice_id',
            'inner_notice.title as title',
            'inner_notice.content as content',
            'inner_notice.attachment as attachment',
            'inner_notice.push_status as push_status',
            'inner_notice.receive_type as receive_type',
            'inner_notice.create_by as create_by',
            'inner_notice.status as status',
            'inner_notice.create_time as create_time',
        ];

        return $fields;
    }

    protected function _getMyNoticeJoin() {
        $join = [
            'left join inner_notice_link on inner_notice.id=inner_notice_link.inner_notice_id',
        ];
        return $join;
    }

    //内部公告标记已读
    public function tagRead() {
        $ids = I('ids');
        if (empty($ids)) {
            $this->admin_error('请选中记录');
        }
        $where = [
            'inner_notice_id' => ['in',$ids],
            'manager_id' => $this->_manager_id,
        ];
        $data = [
            'read_status' => 1,
        ];
        /** @var InnerNoticeService $inner_notice_service */
        $inner_notice_service = D('Admin/InnerNotice', 'Service');
        list($errno,$errmsg,$up_data) = $inner_notice_service->upNoticeLink($where,$data);
        if ($errno == ERRNO::SUCCESS) {
            $this->admin_success('标记已读成功');
        } else {
            $this->admin_success('标记已读失败');
        }
        return;
    }

    public function deleteMyNotice(){
        $notice_link_id = I('notice_link_id');
        if (empty($notice_link_id)) {
            $this->admin_error('请选择要删除的记录');
            return ;
        }
        /** @var InnerNoticeService $inner_notice */
        $inner_notice = D('Admin/InnerNotice','Service');
        $where = [
            'id' => $notice_link_id,
            'manager_id' => $this->_manager_id,
        ];
        $data = [
            'crm_show_flag' => 0
        ];
        list($errno,$errmsg,$data)= $inner_notice->upNoticeLink($where,$data);
        if ($errno == ERRNO::SUCCESS) {
            $this->admin_success($errmsg);
        } else {
            $this->admin_error($errmsg);
        }
        return;
    }

    public function deleteMyAll(){
        $ids = I('ids');
        if (empty($ids)) {
            $this->admin_error('请选择要删除的记录');
            return ;
        }
        $ids = array_filter($ids);
        /** @var InnerNoticeService $inner_notice */
        $inner_notice = D('Admin/InnerNotice','Service');
        $where = [
            'inner_notice_id' => ['in',$ids],
            'manager_id' => $this->_manager_id,
        ];
        $data = [
            'crm_show_flag' => 0
        ];
        list($errno,$errmsg,$data)= $inner_notice->upNoticeLink($where,$data);
        if ($errno == ERRNO::SUCCESS) {
            $this->admin_success($errmsg);
        } else {
            $this->admin_error($errmsg);
        }
        return;
    }



}