<?php
namespace Common\Behavior;

use Think\Behavior;
use Think\Log;

class profileLogHeadBehavior extends Behavior
{
    // 行为扩展的执行入口必须是run
    public function run(&$params)
    {
        $log_content   = [
            'uid=' . session('user_id'),
            'gid=' .I('server.REMOTE_ADDR'),
            str_replace(' ', '', I('server.HTTP_X_FORWARDED_FOR')),
            PATH_INFO,
            'post=' . json_encode(I('post.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
            'get=' . json_encode(I('get.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
            'refer=' . I('server.HTTP_REFERER'),
            'ua=\'' . I('server.HTTP_USER_AGENT') . '\'',
            'cookie=' . json_encode($_COOKIE) ,
            'sid=' . session_id(),
        ];
        Log::write(implode(' ', $log_content), 'PROFILE_HEAD');
    }
}

?>
