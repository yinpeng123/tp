<?php
namespace Admin\Service;

use Admin\Model\UserModel;
use Common\Cnsts\ERRNO;
use Basic\Cnsts\DICT;

class UserService {

    /**
     * 添加操作日志 @todo 废弃
     */
    public function addOperLog($info) {
        $log_model = D('OperLog');
        $oper_info = array(
            'manager_id'    => $info['manager_id'],
            'module'        => '用户管理',
            'resource'      => '用户',
            'object_id'     => $info['object_id'],
            'action'        => $info['action'],
            'desc'          => $info['desc'],
            'ctime'         => datetime(),
        );
        $log_model->add($oper_info);
    }

    /**
     * @param $data
     *
     * @return array
     * CRMM 添加用户
     */
    public function addUser($data) {
        $user_model_m = new \Basic\Model\UserModel('master');
        $uid = $user_model_m->add($data);
        if ($uid) {
            return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), ['user_id'=> $uid]];
        } else {
            return [ERRNO::SQL_UPDATE_ERRNO, ERRNO::e(ERRNO::SQL_UPDATE_ERRNO), ['user_id'=> $uid]];
        }
    }

    public function checkBasicParam($data, $is_check_telephone) {
        $rules = $this->_getCheckBasicParam($is_check_telephone);
        /** @var \Basic\Model\UserModel $user_model */
        $user_model = D('Basic/User','Model');
        $check_ret = $user_model->validate($rules, $data);
        if ( $check_ret !== NULL ) { // 验证未通过
            return [ERRNO::INPUT_PARAM_ERRNO, ERRNO::e(ERRNO::INPUT_PARAM_ERRNO).': '.$check_ret, []];
        }
        return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), []];
    }

    /**
     * @param $is_check_telephone 是否需要按照渠道的设置校验手机号
     *
     * @return array
     * 检查添加/修改用户时的参数
     */
    protected function _getCheckBasicParam($is_check_telephone) {
        $ret_data = [
            ['channel_id', 'number', '请选择渠道', \Think\Model::MUST_VALIDATE,],
            ['province', 'require', '请选择地址省份', \Think\Model::MUST_VALIDATE],
            ['city', 'require', '请填写地址城市', \Think\Model::MUST_VALIDATE],
            ['card_num', '/^(\d{18,18}|\d{15,15}|\d{17,17}[xX])$/', '请填写身份证号', \Think\Model::VALUE_VALIDATE, 'regex'],
            ['user_name', 'require', '用户名格式不正确', \Think\Model::MUST_VALIDATE],
            ['telephone', 'is_mobile', '手机号格式不正确', \Think\Model::MUST_VALIDATE, 'function'],
        ];
        if ( $is_check_telephone ) {
            $ret_data[] = ['phone1', 'is_mobile', '联系方式1格式不正确', \Think\Model::VALUE_VALIDATE, 'function'];
            $ret_data[] = ['phone2', 'is_fixed_phone', '联系方式2只能填写电话(非手机号)', \Think\Model::VALUE_VALIDATE, 'function'];
            $ret_data[] = ['phone3', 'is_fixed_phone', '联系方式3只能填写电话(非手机号)', \Think\Model::VALUE_VALIDATE, 'function'];
        } else {
            $ret_data[] = ['phone1', 'is_linkphone', '联系方式1格式不正确', \Think\Model::VALUE_VALIDATE, 'function'];
            $ret_data[] = ['phone2', 'is_linkphone', '联系方式2格式不正确', \Think\Model::VALUE_VALIDATE, 'function'];
            $ret_data[] = ['phone3', 'is_linkphone', '联系方式3格式不正确', \Think\Model::VALUE_VALIDATE, 'function'];
        }
        return $ret_data;
    }


    //组合app会员属性的搜索条件
    public function getWhereByMemberType($member_type) {
        $where = [];
        $today = datetime();
        switch($member_type) {
            case DICT::MEMBER_TYPE_REGISTER :
                $where = [
                    'member_end_time' => ['exp','is null'],
                    'try_mem_end_time' => ['exp','is null'],
                    'is_pause' => ['eq',0],
                    'is_inner' => ['eq',0],
                ];
                break;
            case DICT::MEMBER_TYPE_PROBATION :

                $where['_string'] .= 'and (member_end_time <"'.$today.'" and member_start_time > 0 or member_end_time
                 is null)';
                $where['try_mem_start_time'] = ['gt',0];
                $where['try_mem_end_time'] = ['gt',$today];
                $where['is_inner'] = ['eq',0];
                $where['is_pause'] = ['eq',0];
                break;
            case DICT::MEMBER_TYPE_VIP :
                $where = [
                    'member_end_time' => ['gt',$today],
                    'member_start_time' => ['lt',$today],
                    'is_pause' => ['eq',0],
                    'is_inner' => ['eq',0],
                ];
                break;
            case DICT::MEMBER_TYPE_VIP_PAUSE :
                $where['is_pause'] = 1;
                break;
            case DICT::MEMBER_TYPE_INNER :
                $where['is_inner'] = 1;
                break;
            case DICT::MEMBER_TYPE_PROBATION_EXPIRE :
                $where = [
                    'member_start_time' => ['exp','is null'],
                    'member_end_time' => ['exp','is null'],
//                    'try_mem_start_time' => ['gt',0],
                    'try_mem_end_time' => ['lt',$today],
                    'is_pause' => ['eq',0],
                    'is_inner' => ['eq',0],
                ];
                break;
            case DICT::MEMBER_TYPE_VIP_EXPIRE :
                $where = [
                    'member_start_time' => ['gt', 0],
                    'member_end_time' => ['lt',$today],
                    'try_mem_end_time' => ['exp', 'is null'],
                    'is_pause' => ['eq',0],
                    'is_inner' => ['eq',0],
                ];
                break;
        }
        return $where;
    }

    /**
     * @param $member_type
     * @return array
     *PC MemberType搜索
     */
    public function getWhereByPcMemberType($member_type) {
        $where = [];
        $today = datetime();
        switch($member_type) {
            case DICT::MEMBER_TYPE_REGISTER :
                $where = [
                    'pc_member_end_time' => ['exp','is null'],
                    'try_pc_end_time' => ['exp','is null'],
                    'pc_is_pause' => ['neq',1],
                    'pc_is_inner' => ['neq',1],
                ];
                break;
            case DICT::MEMBER_TYPE_PROBATION :

                $where['_string'] .= 'and (pc_member_end_time <"'.$today.'" and pc_member_start_time > 0
                or pc_member_end_time is null)';
                $where['try_pc_start_time'] = ['gt',0];
                $where['try_pc_end_time'] = ['gt',$today];
                $where['is_inner'] = ['eq',0];
                $where['is_pause'] = ['eq',0];
                break;
            case DICT::MEMBER_TYPE_VIP :
                $where = [
                    'pc_member_end_time' => ['gt',$today],
                    'pc_member_start_time' => ['lt',$today],
                    'pc_is_pause' => ['eq',0],
                    'pc_is_inner' => ['eq',0],
                ];
                break;
            case DICT::MEMBER_TYPE_VIP_PAUSE :
                $where['pc_is_pause'] = 1;
                break;
            case DICT::MEMBER_TYPE_INNER :
                $where['pc_is_inner'] = 1;
                break;
            case DICT::MEMBER_TYPE_PROBATION_EXPIRE :
                $where = [
                    'pc_member_start_time' => ['exp','is null'],
                    'pc_member_end_time' => ['exp','is null'],
                    'try_pc_start_time' => ['gt',0],
                    'try_pc_end_time' => ['lt',$today],
                    'pc_is_pause' => ['eq',0],
                    'pc_is_inner' => ['eq',0],
                ];
                break;
            case DICT::MEMBER_TYPE_VIP_EXPIRE :
                $where = [
                    'pc_member_start_time' => ['gt',0],
                    'pc_member_end_time' => ['lt',$today],
                    'pc_is_pause' => ['eq',0],
                    'pc_is_inner' => ['eq',0],
                ];
                $where['_string'] .=  'and (try_pc_end_time is null or try_pc_end_time < "'.$today.'")';

                break;
        }
        return $where;
    }


    public function getUserCertList($where, $order_by = null, $limit = null) {
        if (empty($fields)) {
            $fields = [
                'user.id as user_id',
                'user.account',
                'user.net_no',
                'user.telephone',
                'user.user_name',
                'user.card_num',
                'user.channel_id',
                'user.cert_status',
                'user.company_cert_status',
                'user.product',
                'user.apply_cert_time',
                'user.cert_time',
                'user.is_pause',
                'user.is_inner',
                'user.member_start_time',
                'user.member_end_time',
                'user.try_mem_start_time',
                'user.try_mem_end_time',
                'user.apply_company_cert_time',
                'user.company_cert_time',
                'user.city',
                'user.last_login_city',
                'user.company_name',
//                'apply_cert.cert_info',
            ];
        }

//        $join = [
//            'left join apply_cert on user.id= apply_cert.user_id'
//        ];
        if (empty($order_by)) {
            $order_by = 'user.id desc';
        }
        $user_model_s = new \Admin\Model\UserModel('slave');
        $list = $user_model_s->getUserList($where, $order_by, $limit, $fields, '');
        return $list;
    }

    public function getSqlFoundRows($where, $join=[]) {
        $user_model_s = new \Admin\Model\UserModel('slave');
        return $user_model_s->getSqlFoundRows($where, $join);
    }

    /**
     * 根据网号、账号或手机号查询用户信息
     * @param string $certain_id 网号、账号或手机号
     * @return array 查询结果和数据 [errno, errmsg, data], 具体返回值见下:
     *   [0, 'null', []]  用户不存在
     *   [1, 'success', $user] 用户存在且仅1条记录
     *   [n, 'list', $user_list] 用户存在且为多条记录
     */
    public function searchUserProfile($certain_id) {
        /* @var \Admin\Model\UserModel $user_model */
        $user_model = D('User');

        // 先检查是否手机号
        if ( is_mobile($certain_id) ) {
            //$user = $user_model->getUserByTelephone($certain_id);
            $user_list = $user_model->getListBy(['telephone' => $certain_id /*, 'is_delete' => 0*/], '', $order = 'id ASC');
            if ( count($user_list) > 1 )
                return [count($user_list), 'list', $user_list];
            elseif ( count($user_list) == 1 )
                $user = $user_list[0];

        } elseif ( is_net_no($certain_id) ) { // 网号
            //$user = $user_model->getUserByField(['net_no' => $certain_id]);
            $user_list = $user_model->getListBy(['net_no' => $certain_id /*, 'is_delete' => 0*/], '', $order = 'id ASC');
            if ( count($user_list) > 1 )
                return [count($user_list), 'list', $user_list];
            elseif ( count($user_list) == 1 )
                $user = $user_list[0];

        } else { // 账号
            $user = $user_model->getUserByField(['account' => $certain_id]);
        }

        return empty($user) ? [0, 'null', []] : [1, 'success', $user];
    }

}