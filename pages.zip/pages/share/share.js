var openid = getUrlParam('openid');

$(document).ready(function () {
    $.ajax({
        url: 'http://www.htown.xyz/Home/index/challenge_complete',
        type: 'POST',
        data: {
            openid: openid
        },
        success: function (data) {
            console.log(data);
            $('.avatar').css('background-image', 'url(' + data.user_info.headimg + ')');
            $('.name').text(data.user_info.nickname);
        }
    })
})

$('.share-icon').click(function(){
    //分享
    alert('分享开发中！')
})