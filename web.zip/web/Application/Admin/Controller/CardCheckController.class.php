<?php
namespace Admin\Controller;

use Admin\Service\ManagerService;
use Basic\Model\CardCheckLogModel;
use Basic\Service\CardCheckService;
use Common\Cnsts\ERRNO;
use Admin\Service\PageService;


class CardCheckController extends AdminSessionController {

    private $check_list = [
        '-1' => '未知',
        '0' => '未核查',
        '1' => '一致',
        '2' => '不一致',
        '3' => '库中无此号',
    ];

    private $check_type_arr = [
        '1' => '本地查询--不收费',
        '2' => '付费查询--收费',
        '3' => '付费查询--不收费',
    ];
    public function __construct() {
        parent::__construct();
    }

    /**
     * 身份证验证接口
     * user_name  用户名  card_num 身份证号 type 调用接口类型 loacl 本地
     */
    public function check() {
        $user_name = I('user_name');
        $card_num = I('card_num');
        $type = I('type');
        if (empty($card_num) || strlen($card_num) != 18) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO,'身份证格式不正确',[]);
            return;
        }
        if (empty($user_name)) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO,'用户名格式不正确',[]);
            return;
        }
        /** @var CardCheckService $card_service */
        $card_service = D('Basic/CardCheck', 'Service');
        if ($type == \Basic\Cnsts\IDENTITY::CHECK_BY_FEE) {
            list($errno,$errmsg,$check_data) = $card_service->checkByFee($card_num,$user_name);
        } else {
            list($errno,$errmsg,$check_data) = $card_service->checkLocal($card_num,$user_name);
        }
        $this->doResponse($errno,$errmsg,$check_data);
        fastcgi_finish_request();
        $log_data = [
            'card_num' => $card_num,
            'user_name' => $user_name,
            'type' => $type,
            'check_status' => $check_data['check_status'],
            'c_manager_id' => $this->_manager_id,
        ];
        $card_service->addCheckLog($log_data);
    }

    /**
     * 身份证核查历史记录
     */
    public function cardLog() {
        $card_num = I('card_num');
        $user_name = I('user_name');

        if (empty($card_num) || strlen($card_num) != 18) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO,'身份证格式不正确',[]);
            return;
        }
        if (empty($user_name)) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO,'用户名格式不正确',[]);
            return;
        }
        /** @var CardCheckService $card_service */
        $card_service = D('Basic/CardCheck', 'Service');
        $log_list = $card_service->checkLogList($card_num,$user_name);
        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');
        $format_manager_list = $manager_service->getFormatManger();
        foreach($log_list as &$value) {
            $value['check_desc'] = $card_service->getCheckResDesc($value['check_status']);
            $value['c_manager_name'] = $format_manager_list[$value['c_manager_id']];
        }
        $this->doResponse(ERRNO::SUCCESS,'成功',$log_list);
    }

    public function cardCheckLogs() {
        $search_card_num = I('search_card_num');
        $search_user_name = I('search_user_name');
        $search_type = I('search_type');
        $search_ftime_from = I('search_ftime_from');
        $search_ftime_to = I('search_ftime_to');

        $cond = [];
        if (!empty($search_card_num)) {
            $cond['card_num'] = ['eq', $search_card_num];
        }
        if (!empty($search_user_name)) {
            $cond['user_name'] = ['eq', $search_user_name];
        }
        if (!empty($search_ftime_from) && !empty($search_ftime_to)) {
            $cond['create_time'] = [['egt', $search_ftime_from . ' 00:00:00'], ['elt', $search_ftime_to . ' 23:59:59']];
        } else if (!empty($search_ftime_from)) {
            $cond['create_time'] = ['egt', $search_ftime_from . ' 00:00:00'];
        } else if (!empty($search_ftime_to)) {
            $cond['create_time'] = ['elt', $search_ftime_to . ' 23:59:59'];
        }
        if (!empty($search_type)) {
            switch ($search_type)
            {
                case 1:
                    $cond['type'] = ['eq', 'local'];
                    break;
                case 2:
                    $map['type'] = ['eq', 'by_fee'];
                    $map['check_status'] = ['in', '1,2'];
                    $map['_logic'] = 'and';
                    $cond['_complex'] = $map;
                    break;
                case 3:
                    $map['type'] = ['eq', 'by_fee'];
                    $map['check_status'] = ['not in', '1,2'];
                    $map['_logic'] = 'and';
                    $cond['_complex'] = $map;
                    break;
                default:

            }
        }

        $search_param = [
            'search_card_num' => $search_card_num,
            'search_user_name' => $search_user_name,
            'search_type' => $search_type,
            'search_ftime_from' => $search_ftime_from,
            'search_ftime_to' => $search_ftime_to,
        ];

        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);

        /** @var CardCheckLogModel $card_check_log_model */
        $card_check_log_model = D('Basic/CardCheckLog', 'Model');
        $res = $card_check_log_model->cardCheckLogsList($cond, $curr_page, $per_page);

        foreach ($res['data'] as &$v) {
            $v['result'] = $this->check_list[$v['check_status']];
            $check_type_color = 0;
            if ($v['type'] == 'local') {
                $check_type = '本地查验--不收费';
            } else {
                if ($v['check_status'] == 1 || $v['check_status'] == 2) {
                    $check_type = '付费查询--收费';
                    $check_type_color = 1;
                } else {
                    $check_type = '付费查询--不收费' . '（' . $v['result'] . '）';
                }
            }
            $v['check_type'] = $check_type;
            $v['check_type_color'] = $check_type_color;
        }
        $page_service = new PageService($res['count'], $per_page);
        $page_nav = $page_service->show();

        $this->assignAll(array(
            'title' => '身份查验记录',
            'list' => $res['data'],
            'search_param' => $search_param,
            'form_action' => '/CardCheck/cardCheckLogs',
            'page_nav' => $page_nav,
            'search_type_arr' => $this->check_type_arr,
        ));
        $this->display('card_check_logs');
    }

    /**
     * 导出查验记录
     */
    public function exportCardCheckLog() {
        $search_card_num = I('search_card_num');
        $search_user_name = I('search_user_name');
        $search_type = I('search_type');
        $search_ftime_from = I('search_ftime_from');
        $search_ftime_to = I('search_ftime_to');

        $cond = [];
        if (!empty($search_card_num)) {
            $cond['card_num'] = ['eq', $search_card_num];
        }
        if (!empty($search_user_name)) {
            $cond['user_name'] = ['eq', $search_user_name];
        }
        if (!empty($search_ftime_from) && !empty($search_ftime_to)) {
            $cond['create_time'] = [['egt', $search_ftime_from . ' 00:00:00'], ['elt', $search_ftime_to . ' 23:59:59']];
        } else if (!empty($search_ftime_from)) {
            $cond['create_time'] = ['egt', $search_ftime_from . ' 00:00:00'];
        } else if (!empty($search_ftime_to)) {
            $cond['create_time'] = ['elt', $search_ftime_to . ' 23:59:59'];
        }

        if (!empty($search_type)) {
            switch ($search_type)
            {
                case 1:
                    $cond['type'] = ['eq', 'local'];
                    break;
                case 2:
                    $map['type'] = ['eq', 'by_fee'];
                    $map['check_status'] = ['in', '1,2'];
                    $map['_logic'] = 'and';
                    $cond['_complex'] = $map;
                    break;
                case 3:
                    $map['type'] = ['eq', 'by_fee'];
                    $map['check_status'] = ['not in', '1,2'];
                    $map['_logic'] = 'and';
                    $cond['_complex'] = $map;
                    break;
                default:

            }
        }

        // 先查看交易记录总数是否超过导出限制
        $max_export_record_num = 10000;
        $per_page = 1000;
        $curr_page = 1;

        /** @var CardCheckLogModel $card_check_log_model */
        $card_check_log_model = D('Basic/CardCheckLog', 'Model');
        $ret = $card_check_log_model->cardCheckLogsList($cond, $curr_page, $per_page);
        if ( $ret['count'] > $max_export_record_num ) {
            $this->admin_error('导出记录数超过上限，请缩小时间范围分批导出！');
            return;
        }

        $filename = '身份查验记录.csv';

        // 输出Excel文件头
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        header('Cache-Control: max-age=0');

        // 打开PHP文件句柄，php://output 表示直接输出到浏览器
        $fp = fopen('php://output', 'a');

        // 输出Excel列名信息
        $head = array('ID', '身份证号', '姓名', '查验结果', '查询方式', '查验日期');
        foreach ($head as $i => $v) {
            // CSV的Excel支持GBK编码，一定要转换，否则乱码
            $head[$i] = iconv('utf-8', 'gb2312', $v);
        }
        // 将数据通过fputcsv写到文件句柄
        fputcsv($fp, $head);

        // 输出数据内容
        while (1) {
            $this->_doExportCardCheckLog($fp, $ret['data']);
            if ( $curr_page >= $ret['page_number'] )
                break;

            /** @var CardCheckLogModel $card_check_log_model */
            $card_check_log_model = D('Basic/CardCheckLog', 'Model');
            $ret = $card_check_log_model->cardCheckLogsList($cond, ++$curr_page, $per_page);
        }

        // 关闭句柄
        fclose($fp);
    }

    /**
     * 分批身份查验记录
     * @param $fp
     * @param $data
     */
    protected function _doExportCardCheckLog($fp, $data) {

        foreach ( $data as &$v ) {

            $v['result'] = $this->check_list[$v['check_status']];
            if ($v['type'] == 'local') {
                $check_type = '本地查验--不收费';
            } else {
                if ($v['check_status'] == 1 || $v['check_status'] == 2) {
                    $check_type = '付费查询--收费';
                } else {
                    $check_type = '付费查询--不收费' . '（' . $v['result'] . '）';
                }
            }
            $v['check_type'] = $check_type;

            $row = [
                $v['id'],
                $v['card_num'],
                conv_to_gb2312($v['user_name']),
                conv_to_gb2312($v['result']),
                conv_to_gb2312($v['check_type']),
                $v['create_time'],
            ];
            fputcsv($fp, $row);
        }
    }

}