<?php
namespace Admin\Model;

use Basic\Model\BasicModel;

class ProductStatusLogModel extends BasicModel {
    protected $_product_status_log = null;
    public function __construct($db_type = 'master', $enable_cache = FALSE) {
        parent::__construct('product_status_log', '', $db_type);
        $this->_enable_cache = $enable_cache;
        $this->_product_status_log = $this->_model;
    }

    /**
     * @param $data
     *添加系统公告
     */
    public function addLog($data) {
        return $this->_product_status_log->add($data);
    }

    //根据条件查询内部公告消息
    public function getLogList($where, $field= [], $limit=[],$order_by = 'id desc',$join = []) {
        return $this->_product_status_log->where($where)->field($field)->join($join)->order($order_by)->limit($limit)->select();
    }
}