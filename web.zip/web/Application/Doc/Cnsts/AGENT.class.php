<?php
namespace Open\Cnsts;

class AGENT {

    /**
     * 签名有效期
     */
    const SIGN_SECONDS = 0;
    
    /**
     * 代理商列表
     */
    const AGENT_LIST = [
        'OG49D4qOhMqd8SFP' => [
            'appid'             => 'OG49D4qOhMqd8SFP',
            'secret'            => 'sdPWD5epmakEXXvtJ71yv6pasFpM99Qh',
            'name'              => '代理商',
            'discount'          => 95,
            'notify_url'        => 'http://goodvw.cn/index.php/User/orderCallbacks.html',
            'return_url'        => 'http://www.goodvw.cn/index.php',
            'allowed_ip'        => null,//["61.148.62.66"],
            'oil_rechrge_intro' => '<p></p>',
        ],
    ];

    const AGENT_LIST_NAME = [
        '代理商' => 'OG49D4qOhMqd8SFP',
    ];

    /**
     * 生成签名
     * @param  [type] $appid     [description]
     * @param  [type] $timestamp [description]
     * @param  [type] $keys      [description]
     * @return [type]            [description]
     */
    public static function genSignature($appid, $timestamp, $keys){
        unset($keys['timestamp']);
        unset($keys['appid']);
        $tmpArr = array_merge([AGENT::AGENT_LIST[$appid]['secret'], $timestamp],$keys);
        sort($tmpArr, SORT_STRING);
        return sha1(implode($tmpArr));
    }

    /**
     * 检查签名
     * @param  [type] $appid     [description]
     * @param  [type] $signature [description]
     * @param  [type] $timestamp [description]
     * @param  [type] $keys      [description]
     * @return [type]            [description]
     */
    public static function checkSignature($appid, $signature, $timestamp, $keys){
        if (AGENT::SIGN_SECONDS && ($timestamp > time() || (time() - $timestamp) > AGENT::SIGN_SECONDS)) {
            return false;
        }
        if (!$appid || !AGENT::AGENT_LIST[$appid]['secret']) {
            return false;
        }
        unset($keys['appid']);
        unset($keys['timestamp']);
        unset($keys['signature']);
        $tmpArr = array_merge($keys,[AGENT::AGENT_LIST[$appid]['secret'], $timestamp]);
        sort($tmpArr, SORT_STRING);
        if ( sha1(implode($tmpArr)) == $signature ) {
            return true;
        } else {
            return false;
        }
    }
}

?>