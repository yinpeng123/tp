<?php
namespace Admin\Controller;

use Admin\Model\UserEventModel;
use Admin\Service\ManagerService;
use Common\Cnsts\ERRNO;
class UserEventController extends AdminSessionController {
    protected $_user_event_m = null;
    public function __construct() {
        parent::__construct();
        $this->_user_event_m = new UserEventModel();
    }


    /**
     * 添加记事
     */

    public function addUserEvent() {
        $add_data = $this->_getUserEventData();
        $add_data['manager_id'] = $this->_manager_id;
        $event_id = $this->_user_event_m->add($add_data);
        if ( $event_id ) {
            return $this->ajaxResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS));
        } else {
            return $this->ajaxResponse(ERRNO::SQL_UPDATE_ERRNO, '添加记事失败');
        }
    }

    /**
     * 编辑记事
     */
    public function editUserEvent() {
        $event_id = I('event_id');
        $up_data = $this->_getUserEventData();
        $up_data['m_manager_id'] = $this->_manager_id;
        if ( $event_id ) {
            $up_res = $this->_user_event_m->update($event_id, $up_data);
            if ( $up_res === false ) {
               return $this->ajaxResponse(ERRNO::SQL_UPDATE_ERRNO, '参数错误');
            } else {
                return $this->ajaxResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS));
            }
        } else {
            return $this->ajaxResponse(ERRNO::SQL_UPDATE_ERRNO, '参数错误');
        }

    }

    /**
     * 获取用户添加/编辑记事数据
     */
    protected function _getUserEventData() {
        $content = trim(I('content'));
        $ext = [
            'content' => $content,
        ];
        $event_data = [
            'event_type' => I('event_type'),
            'uid' => I('uid'),
            'ext' => json_encode($ext, JSON_UNESCAPED_UNICODE),
        ];
        return $event_data;
    }

    /**
     * 用户记事详情
     */
    public function userEventDetail() {
        $event_id = I('event_id');
        $event_detail = $this->_user_event_m->get($event_id);
        $event_detail['event_id'] = $event_detail['id'];
        $ext = json_decode($event_detail['ext'],JSON_UNESCAPED_UNICODE);
        $content = $ext['content'];
        $event_detail['content'] = $content ? : '';
        return $this->ajaxResponse(ERRNO::SUCCESS,'success',$event_detail);
    }

    /**
     * 获取记事列表
     */
    public function userEventList() {
//        $per_page = C('TABLE_PER_PAGE');
//        $curr_page = I('path.2/d', 1);
        $uid = I('uid', 0, 'int');
        $event_type = I('event_type');
        if ( !$uid ) {
            return $this->ajaxResponse(ERRNO::SQL_UPDATE_ERRNO, '参数错误');
        }
        $cond = [
            'uid' => $uid,
            'is_delete' => 0,
        ];
        if ( $event_type ) {
            $cond['event_type'] = $event_type;
        }
        $list = $this->_user_event_m->getListBy($cond, '', 'id desc');

        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');
        $manager_list = $manager_service->getFormatManger();
        foreach ( $list as &$value) {
            $ext = json_decode($value['ext'],JSON_UNESCAPED_UNICODE);
            $value['content'] = !empty($ext['content']) ? $ext['content'] : '';
            $manager_id = $value['manager_id'];
            $value['cname'] = !empty($manager_list[$manager_id]) ? $manager_list[$manager_id] : '';
            $m_manager_id = $value['m_manager_id'];
            $value['mname'] = !empty($manager_list[$m_manager_id]) ? $manager_list[$m_manager_id] : '';
        }
        return $this->ajaxResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS),$list);
    }

    /**
     * 删除
     */
    public function delUserEvent() {
        $event_id = I('event_id');

        if ( !$event_id ) {
            return $this->ajaxResponse(ERRNO::SQL_UPDATE_ERRNO, '参数错误');
        }
        $up_data = [
            'is_delete' => 1,
            'm_manager_id' => $this->_manager_id,
        ];
        $up_res = $this->_user_event_m->update($event_id, $up_data);
        if ( $up_res === false ) {
            return $this->ajaxResponse(ERRNO::SQL_UPDATE_ERRNO, '参数错误');
        } else {
            return $this->ajaxResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS));
        }
    }

}