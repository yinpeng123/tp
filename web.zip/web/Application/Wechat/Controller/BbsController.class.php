<?php

namespace Wechat\Controller;

use Basic\ModelU\CenterModel;
use Basic\Service\UuserService;
use Think\Controller;
use Basic\Cnsts\WECHAT;
use Basic\Service\WechatService;
use Basic\ModelU\UserModel;
use Basic\ModelU\ArticleModel;
use Basic\Service\BbsService;
use Admin\Service\PageService;
use Think\Model;

class BbsController extends WechatController
{

    function __construct()
    {
        parent::__construct();
    }

    //提交用户基本信息,openid,nickname,avatar
    public function index()
    {

        $this->blist();
    }

    //社区首页
    public function blist()
    {
        $openid = I("openid");
        $model = new BbsService();
        $page = I("page", 0);
        $this->doResponse(0, "ok", $model->getIndexByOpenId($openid, $page));
    }

    //社区详细页
    public function bpage()
    {
        $model = new BbsService();
        $fid = I("tid", 0);
        if (empty($fid)) {
            $this->doResponse(-1, "tid参数错误");

        }
        $this->doResponse(0, "ok", $model->getInfoById($fid, $this->user->id));

    }

    //评论列表，分页
    public function comment()
    {
        $page = I('page', 0);
        $fid = I('fid');
        if (empty($fid)) {
            $this->doResponse(-1, "fid参数错误");

        }
        $model = new BbsService();
        $this->doResponse(0, "ok", $model->getCommnet($fid, $page, $this->user->id));
    }

    //某个用户的社区内容
    public function byUser()
    {
        $uid = I('uid');
        $page = I("page", 0);
        $model = new BbsService();
        $myId=$this->user->id;
        $info = $model->getIndexByUid($uid, $page,$myId);
        if (!$info) {
            $this->doResponse(-1, "用户不存在");
        }
        $this->doResponse(0, "ok", $info);
    }

    //添加新内容
    public function addNew()
    {
        $openid = I('openid');
        $title = I('title');
        $content = I('content');
        if (empty($title) || empty($content)) {
            $this->doResponse(-1, "内容或者标题不能为空");
        }
        $user = (new UuserService())->getUserByOpenid($openid);
        $pic = I('pic');
        $model = new CenterModel('u_bbs');
        $info = [
            'uid' => $user['id'],
            'title' => $title,
            //  'name'=>$user['name'],
            'describe' => mb_substr($content, 0, 20, 'utf-8'),
            'content' => $content,
            'pic' => $pic,
            'group'=>$this->user->volunteer,
        ];
        $model->add($info);
        $model = new CenterModel("u_point_log");
        $where = [
            'uid' => $this->user->id,
            'type' => 'push',
            'ctime' => ['gt', day()],
        ];
        if ($model->getListTotal($where) < 3) {
            $info = [
                'uid' => $this->user->id,
                'type' => 'push',
                'point' => 1,
                'content' => "社区发布内容",

            ];
            $model->add($info);
            $data = [
                'point' => $this->user->point + 1,
                'point_use' => $this->user->point_use + 1,
            ];
            (new CenterModel("u_user"))->update($this->user->id, $data);
        }
        $this->doResponse(0, "发布成功", []);
    }

    //点赞操作
    public function doFabulous()
    {
        $openid = I('openid');
        $fid = I('tid');
        if (empty($fid)) {
            $this->doResponse(-1, "帖子ID不能为空");
        }
        $user = (new UuserService())->getUserByOpenid($openid);
        $model = new CenterModel('u_bbs_fabulous');
        $info = [
            'fid' => $fid,
            'uid' => $user['id'],
        ];
        if ($model->getBy($info)) {
            $this->doResponse(-1, "您已经点过赞了", []);
        }
        $model->add($info);
        M('u_bbs')->where('id=' . $fid)->setInc('fabulous');
        $this->doResponse(0, "点赞成功", []);

    }

    //评论点赞
    public function doCommentFabulous()
    {
        $openid = I('openid');
        $fid = I('cid');
        if (empty($fid)) {
            $this->doResponse(-1, "评论ID不能为空");
        }
        $model = new CenterModel('u_bbs_comment_fabulous');
        $info = [
            'cid' => $fid,
            'uid' => $this->user->id,
        ];
        if ($model->getBy($info)) {
            $this->doResponse(-1, "您已经点过赞了", []);
        }
        $model->add($info);
        M('u_bbs_comment')->where('id=' . $fid)->setInc('fabulous');
        $this->doResponse(0, "点赞成功", []);
    }

    //评论操作
    public function doComment()
    {
        $openid = I('openid');
        $content = I('content');
        $fid = I('tid');
        $pid = I("pid");
        if (empty($content) || empty($fid)) {
            $this->doResponse(-1, "内容或者帖子ID不能为空");
        }
        $user = (new UuserService())->getUserByOpenid($openid);
        $model = new CenterModel('u_bbs_comment');
        $info = [
            'fid' => $fid,
            'uid' => $user['id'],
            'name' => $user['name'],
            'content' => $content,
        ];
        if ($pid) {
            $info['parent_id'] = $pid;
        }
        $model->add($info);
        M('u_bbs')->where('id=' . $fid)->setInc('comment');
        $this->doResponse(0, "评论成功", []);
    }

}
