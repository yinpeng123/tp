<?php
namespace Admin\Model;

use Basic\Cnsts\CACHE_PREFIX;
use Basic\Model\BasicModel;

class GoodsModel extends BasicModel {

    private $__user_model = NULL;


    public function __construct($table='goods',$db_type = 'master', $enable_cache = TRUE) {
        parent::__construct($table, CACHE_PREFIX::USER, $db_type);
        $this->_enable_cache = $enable_cache;
        $this->__user_model = $this->_model;

    }
    //@todo ����
    public function add($user) {
        $user_id = $this->__user_model->add($user);
        return $user_id;
    }

    // ����user����     //@todo ����
    public function updateUserById($user_id, $info) {
        $res = $this->__user_model->where(['id' => $user_id])->save($info);
        return $res;
    }


    //@todo ����
    public function getUserById($user_id) {
        return $this->__user_model->where(['id' => $user_id])->find();
    }

    //@todo ����
    public function getUserByTelephone($telephone) {
        return $this->__user_model->where(['telephone' => $telephone])->find();
    }

    //@todo ����
    public function getUserByField($where) {
        return $this->__user_model->where($where)->find();
    }

 

    /**
     * @param $where
     * @param $order_by
     * @param $limit
     * @param $fields
     * @param $join
     * ��ȡ�û��б�
     */
    public function getUserList ($where, $order_by, $limit, $fields, $join) {
        return $this->__user_model->where($where)->field($fields)->join($join)->order($order_by)->limit($limit)
            ->select();
    }

    /***
     * @return mixed ��ȡ������
     */
    public function getSqlFoundRows($where,$join = null) {
        $total = $this->__user_model->join($join)->where($where)->count();
        return $total;
    }

    public function getUserByChannelId($where) {
        return $this->__user_model->where($where)->select();
    }

}