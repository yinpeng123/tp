<?php
namespace Client\Controller;

use Basic\Model\TestDbModel;
use Basic\Service\OrderService;
use Basic\Service\WLSendService;
use Common\Controller\SessionController;
use Driver\Service\SendNoticeService;
use Think\Controller;


class TestController extends DebugController  {

    public function __construct() {
        session('user_id',6);
        parent::__construct();

    }

    public function multiSheetWork() {
        exit();
        $user_name = I('user_name');
        $password = I('password');
        if ($user_name == 'liuchaoqun' && $password == 'wl_multi_cs') {
            
        } else {
            exit("not allown");
        }
        $user_cond = [
            'factory_id' => ['gt',0]
        ];
        $user_m = new \Basic\Model\UserModel();
        $user_list = $user_m->getListBy($user_cond,'id');
        if (count($user_list) != 57) {
            exit('厂仓数量不是57个！');
        }
        $ac_id = 276;//@todo 需要更改
        $ac_info = (new \Basic\Model\AgentChargeModel())->getAgentChargeInfo($ac_id);

        foreach($user_list as $user) {
            $uid = $user['id'];
            $ret = (new \Basic\Service\CSWorkSheetService())->createFinishedWorkSheet($uid,$ac_info);
            echo "uid:".$uid."   ws_id:".$ret."<br/>";
        }
    }

    public function dumpIp() {
        $ip = get_client_ip();
        echo $ip;
    }

    public function testSaveSub() {
//        "subscribe_id"://订阅货源的ID,修改时传
//    "start_province":"", //始发地-省编码
//    "start_city":"", //始发地-市(用户始发地选择)
//    "start_district":"", //始发地-区县编码
//    "to_province":"", //目的地-省编码
//    "to_city":"", //目的地-市编码
//    "to_district":"", //目的地-区县编码
//    "good_type":"",//货物类型 参考字典 good_type_all 字段
//    "car_length":"", //车长 参考字典
//    "car_type":"", //车型
    }

    public function testSetting() {
        $notice_ser = new \Basic\Service\NoticeService();
        $res = $notice_ser->setNotice(9837, 'grab_remind', 1);

    }

    public function testAddSetting() {
        $notice_ser = new \Basic\Service\SendNoticeService();
        $res = $notice_ser->addNotice(9837,'grab_succ_huo', []);

    }

    public function testCoSync() {
        $feed_id = 4;
        //同步货源信息
        /** @var WLSendService $wl_send_service */
        $wl_send_service = D('Basic/WLSend', 'Service');
        $wl_send_service->sycCoOrder($feed_id);
    }

    public function testDate() {
        $date = day();
        $today_last_time = strtotime($date.' 23:59:59');
        echo $today_last_time;
        echo "<hr/>";
        echo time();
    }

    public function testExtra() {

        $uid = 9855;
        $user_service = new \Basic\Service\UserService();
        $user_service->getUserInfoWithExtra($uid);
    }

    public function checkCardNum() {
        $card_num = '11010119990101891';
        echo $card_num;
        $is_card_num = is_card_num($card_num);
        var_dump($is_card_num);
    }

    public function other() {

        echo 11;
        echo "<hr/>";
        echo session('user_id');
        echo "<hr/>";
        echo 22;
    }

    /**
     *
     */
    public function testDriverPush() {
        /** @var SendNoticeService $send_service */
        $send_service = D('Basic/SendNotice','Service');
        $driver_id = 28;
        $res = $send_service->addNotice($driver_id,\Driver\Cnsts\NOTICE::NOTICE_TYPE_DRIVER_CERT_SUCC,
            []);
        dump($res);
    }

    public function testPush() {
        $push_service = new \Basic\Service\SendNoticeService();
        $telephone = I('telephone');
        $user_service = new \Basic\Model\UserModel();
        $cond = [
            'telephone' => $telephone,
        ];
        $user = $user_service->getBy($cond);
        $user_id = $user['id'];
        $data['ship_id'] = '00000001';
        $data['order_id'] = '00000002';
        $push_service->addNotice($user_id, 'driver_change',$data);
        echo "已发送";
    }



    public function carerCert() {
        $data = [
            'user_name'=> 24324,
            'channel_id' => 120,
            'card_num'=> '412724198803296976',
//            'telephone' => 15136056072,
            'phone1' => '15136056072',
            'phone2' => '0371-36056072',
            'phone3' => '36056072',
            'card_photo'      => [
                'name' => 'certificate_59c24d596ed3a.jpg',
                'path' => '2017-09-20',
                'type' => 'certificate',
            ],
            'card_photo_back' => [
                'name' => 'certificate_59c24d6050978.jpg',
                'path' => '2017-09-20',
                'type' => 'certificate',
            ],
            'motor_num' => 123,
            'car_num' => '京F12345',
            'car_type' => 100,
            'car_length' => 100,
            'motor_num' => 22432,
            'driver_license' => [
                'name' => 'certificate_59c2594707bf1.jpg',
                'path' => '2017-09-20',
                'type' => 'certificate',
            ],
            'road_license' => [
                'name' => 'certificate_59c2594fa6b8d.jpg',
                'path' => '2017-09-20',
                'type' => 'certificate',
            ],
            'operation_license' => [
                'name' => 'certificate_59c2594fa6b8d.jpg',
                'path' => '2017-09-20',
                'type' => 'certificate',
            ],
            'car_photo' => [
                'name' => 'certificate_1496239921.jpg',
                'path' => '2017-05-31',
                'type' => 'certificate',
            ],
        ] ;
        $this->req = array_merge($this->req,$data);
        parent::carerCert();
    }
    public function companyCert() {
        $data = [
            'user_name'=> '24324',
            'channel_id' => 120,
            'card_num'=> '412724198803296976',
            'phone1' => '15136056072',
            'phone2' => '0371-36056022',
            'phone3' => '36056072',
            'card_photo'      => [
                'name' => 'certificate_59c24d596ed3a.jpg',
                'path' => '2017-09-20',
                'type' => 'certificate',
            ],
            'card_photo_back' => [
                'name' => 'certificate_59c24d6050978.jpg',
                'path' => '2017-09-20',
                'type' => 'certificate',
            ],
            'company_name' => '我的公司',
            'register_num' => '22234343',
            'province' => 11,
            'city' => 1101,
            'district' => 110101,
            'addr' => '公司详细地址',
            'work_photo' => [
                'name' => 'certificate_1496239921.jpg',
                'path' => '2017-05-31',
                'type' => 'certificate',
            ],
            'business_photo' => [
                'name' => 'certificate_59c24d7707b90.jpg',
                'path' => '2017-09-20',
                'type' => 'certificate',
            ],
            'avatar' => [
                'name' => 'certificate_59ba7d8d2da7c.jpeg',
                'path' => '2017-09-14',
                'name' => 'certificate',
            ]
        ] ;
        $this->req = array_merge($this->req,$data);
        parent::companyCert();
    }

    public function saveSubscribe() {
        $data = [
            '_user_id'=> 7,
            'start_city'=> '天津',
            'subscribe_id' => 3
        ] ;
        $this->req = array_merge($this->req,$data);
        return parent::saveSubscribe(); // TODO: Change the autogenerated stub
    }
    public function subscribeList() {
        $this->req['_user_id'] = 7;
        parent::subscribeList(); // TODO: Change the autogenerated stub
    }


    public function delSubscribe() {
        $this->req = [
            '_user_id'=> 7,
            'subscribe_id' => 1,
        ];
        return parent::delSubscribe(); // TODO: Change the autogenerated stub
    }



    public function coOrder() {
        $start = [110101,110541,211005,220102,301004,410102,440117,510404];
        $rand1 = rand(0,7);
        $rand2 = rand(0,8);
        $start_pro = substr($start[$rand1], 0, 2);
        $start_city = substr($start[$rand1], 0, 4);
        $to_pro = substr($start[$rand2], 0, 2);
        $to_city = substr($start[$rand2], 0, 4);
        $data = [
            "user_id" => 9830,
            "_user_id" => 9830,
            "order_type"     => "100",
            "start_province" => $start_pro,
            "start_city"     => $start_city,
            "start_district" => $start[$rand1],
            "start_addr" => "start北京诺安基金大厦大傻子",
            "to_province"    => $to_pro,
            "to_city"        => $to_city,
            "to_district"    => $start[$rand2],
            "to_addr" => "to北京诺安基金大厦大傻子",
            "link_phone" => [
                '15136056072',
                '0371-1234567',
            ],
            "start_time" => '2017-10-11 13:56:23',
            "good_type"      => "普货",
            "car_length"     => "5.3",
            "car_type"       => "厢式货车",
            "order_count"    => "1",
            "order_unit"     => "吨",
            "remark"         => "随时发车",
            "carry_type" => 'all_car',
            "bidding" => \Basic\Cnsts\ORDER::BIDDING_Y,
            "truck_id" => 199,
            "car_num" => '京HE56NR',
            "content" => '这是预览信息大傻子',
        ];
        $max = 1;
        for ( $i = 0; $i < $max; $i++ ) {
            $this->req = array_merge($this->req ,$data);
            \Client\Controller\OrderController::coOrder();
        }

         // TODO: Change the autogenerated stub
    }

    public function sycShip() {
        $ship_m = new \Basic\Model\ShippingOrderModel();
        $cond = [
            'carry_info' => ['exp', 'is null'],
        ];
        $list = $ship_m->getListBy($cond);
        $grab_service = new \Basic\Service\GrabService();
        $user_service = new \Basic\Service\UserService();
        $truck_service = new \Basic\Service\TruckService();
        foreach ($list as $v) {
            $grab_id = $v['grab_id'];
            if ($grab_id) {
                $grab = $grab_service->getGrabById($grab_id);
                $carry_user_info = $user_service->getUserInfoById($grab['user_id']);
                $truck_id = $grab['truck_id'];
                $truck_info = $truck_service->getTruckById($truck_id);
                $carry_info = [
                    'car_num' => $grab['car_num'],
                    'driver_name' => $grab['driver_name'],
                    'driver_phone' => $grab['driver_phone'],
                    'carry_name' => $carry_user_info['user_name'],
                    'carry_phone' => $carry_user_info['telephone'],
                    'car_length' => $truck_info['car_length'],
                    'car_type' => $truck_info['car_type'],
                ];
                $up_data = [
                    'driver_name' => $grab['driver_name'],
                    'driver_phone' => $grab['driver_phone'],
                    'car_num' => $grab['car_num'],
                    'carry_info' => t_json_encode($carry_info),
                ];
                $res = $ship_m->update($v['id'], $up_data);
            }
        }
    }


    public function testOrderOp() {
        $data = [
            'user_id' => 9642,
            'order_id' => 201804271932541996,
            'order_status' => 7000,
        ];
        /** @var OrderService $order_service */
        $order_service = D('Basic/Order', 'Service');
        $order_service->orderOP($data);
    }



    public function testDbIsSame() {
        /** @var TestDbModel $model */
        $model = D('Basic/TestDb','Model');
        $model->testDbIsSame();
    }

    public function testSync() {
        $feed_id = 29;
        $ser = new \Basic\Service\WLSendService();
        $ser->sycCoOrder($feed_id);
    }



}