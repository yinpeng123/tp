<?php
namespace Doc\Controller;

use Think\Controller;
use Basic\Cnsts\WECHAT;
use Open\Cnsts\AGENT;
use Open\Cnsts\ERRCODE;

class V1Controller extends Controller{

    function __construct(){
        readfile(__DIR__.'/../View/'.CONTROLLER_NAME.'/'.ACTION_NAME.'.html');
        exit;
    }

}
