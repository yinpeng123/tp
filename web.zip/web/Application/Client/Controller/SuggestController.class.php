<?php
namespace Client\Controller;

use Common\Controller\SessionController;
use Common\Cnsts\ERRNO;

class SuggestController extends SessionController {

    public function __construct() {
        parent::__construct();
    }

    //添加意见建议
    public function add() {
        if (empty($this->req['content'])) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO, '请输入建议内容', []);
            return;
        }
        if (mb_strlen($this->req['content']) > 100) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO, '请输入100个以内汉字', []);
            return;
        }
        $add_data = [
            'content' => $this->req['content'],
            'uid' => $this->req['_user_id'],
            'source' => 1, // 来源 1：app 0：pc
            'ctime' => datetime(), // 添加时间
        ];
        $res = M('suggest')->add($add_data);
        if ($res) {
            $this->doResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), []);
        } else {
            $this->doResponse(ERRNO::SQL_UPDATE_ERRNO, ERRNO::e(ERRNO::SQL_UPDATE_ERRNO), []);
        }
    }

}