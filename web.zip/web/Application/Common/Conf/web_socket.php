<?php
if ( !APP_DEBUG ) {
    $servers = [
        [
            'fe' => [
                'domain'     => '//47.93.117.167',
                'http_port'  => 5000,
                'https_port' => 15000,
                'socket_url'     => 'http://47.93.117.167:5000',
            ],
            'be' => 'http://47.93.117.167:5100',
        ],
    ];
} else {
    $servers = [
        [
            'fe' => [
                'domain'     => '//47.94.52.67',
                'http_port'  => 5000,
                'https_port' => 16789,
                'socket_url' => 'http://47.94.52.67:5000',
            ],
            'be' => 'http://47.94.52.67:5100',
        ],
    ];
}
return [
    'WSS' => $servers,
];
