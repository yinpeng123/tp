<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\RoleService;
use Basic\Cnsts\AGENT_CHARGE;
use Admin\Service\PageService;
use Basic\Cnsts\DICT;
use Admin\Service\ManagerService;
use Basic\Model\KvStoreModel;
use Basic\Model\SettingModel;
use Basic\Service\AgentChargeService;
use Admin\Cnsts\MANAGER;

class KeyWordController extends AdminSessionController
{

    const KEY = 'forbid_keyword';
    private $__manager_service = null;

    public function __construct()
    {
        parent::__construct();
        $this->__manager_service = D('Manager', 'Service');
//        // 权限检查
//        if (!\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::SYS_ROLE)) {
//            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
//            exit;
//        }
    }

    public function setKW() {
        /** @var KvStoreModel $kv_store_model */
        $kv_store_model = D('Basic/KvStore', 'Model');
        $kv_value = $kv_store_model->getKey(self::KEY);
        $this->assignAll(array(
            'title' => '敏感字过滤',
            'key' => self::KEY,
            'form_action' => '/KeyWord/doSet',
            'value' => str_replace('|', '，', $kv_value['k_v']),
        ));
        $this->display('index');
    }

    public function doSet() {
        /** @var KvStoreModel $kv_store_model */
        $kv_store_model = D('Basic/KvStore', 'Model');
        $data = [
            'twpt_key' => I('key'),
            'twpt_value' => t_json_encode(['k_v' => preg_replace('/,|，/', '|', I('keyword'))]), // 入库的数据保持一致，json
            'update_by' => $this->_manager_id,
            'status' => 1,
        ];
        $set_id = $kv_store_model->setKey(self::KEY,$data);

        // 添加操作日志
        $this->__manager_service->addOperLog([
            'manager_id' => $this->_manager_id,
            'object_id'  => $set_id,
            'action'     => 'setKeyWord',
            'desc'       => "添加关键字",
        ]);
        redirect(U('/KeyWord/setKW'));
    }
}