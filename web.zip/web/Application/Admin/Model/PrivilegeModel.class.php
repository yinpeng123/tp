<?php
namespace Admin\Model;

use Basic\Model\BasicModel;

class PrivilegeModel extends BasicModel {

    private $__privilege_model = NULL;

//    public function __construct() {
//        $this->__privilege_model = M('admin_privilege');
//    }

    /**
     * 构造函数, 缺省为连接主库并不使用缓存!
     *
     * @param string     $db_type 指定主、从数据库, 值分别为: master/slave
     * @param bool|FALSE $enable_cache 是否启用缓存
     */
    public function __construct($db_type = 'master', $enable_cache = FALSE) {
        parent::__construct('admin_privilege', \Basic\Cnsts\CACHE_PREFIX::ADMIN_PRIVILEGE, $db_type);
        $this->_enable_cache = $enable_cache;

        $this->__privilege_model = $this->_model;
    }


    // 获取指定id数组的权限列表
    public function getList($ids = NULL) {
        if ( empty($ids) ) {
            return $this->__privilege_model->order('id')->select();
        }

        $where = array('id' => array('in', $ids));

        return $this->__privilege_model->where($where)->order('id')->select();
    }

    //获取全部权限
    public function getAllPrivilegeList() {
        return $this->__privilege_model->select();
    }

    public function getInfo($where) {
        return $this->__privilege_model->where($where)->find();
    }

    public function getByName($where) {
        return $this->__privilege_model->where($where)->find();
    }


}