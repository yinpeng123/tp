<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\AuthService;
use Basic\ModelU\CenterModel;

class ArticleController extends AdminSessionController
{
    public function __construct() {
        parent::__construct();

    }

    public function index  (){
        $model = new CenterModel('u_article');
        $list=$model->getListBy('is_del="N"',"*","id desc");
        $this->assignAll(array(
            'title'   => '资讯列表',
            'list'    => $list,
        ));
        $this->display('index');
    }
    public function edit($id=0){
        $this->add($id);
    }
    public function add($id=0){
        $model = new CenterModel('u_article');
        $list=[];
        if($id){
            $list=$model->get($id);
        }
        $this->assignAll(array(
            'title'   => '添加资讯',
            'list'    => $list,
        ));
        $this->display('edit');
    }

    public function doEdit($id){

        $id=I("tid",0);
        $info=[
            'title'=>I('title'),
            'describe'=>mb_substr(I("content"),0,50,'utf-8'),
            'content'=>I("content"),
            'name'=>I("name"),
            'ctime'=>I("ctime")?I("ctime"):datetime(),
            'pic'=>implode(",",I("identity_photo")),
        ];
        $model= new CenterModel("u_article");
        if($id){
            $model->update($id,$info);
            $msg="修改文章成功";
        }else{
            $model->add($info);
            $msg="添加文章成功";
        }
        $this->admin_success($msg,"/article/index");

    }
//删除所有
    public function delete(){
        $ids=I("ids");
        if(is_array($ids)){
            $where = 'id in('.implode(',',$ids).')';
        }else{
            $where = 'id='.$ids;
        }  //dump($where);
       M("u_article")->where($where)->delete();
        $this->admin_success("删除成功");
    }

}