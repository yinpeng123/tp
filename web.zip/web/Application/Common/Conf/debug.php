<?php
// Call this at each point of interest, passing a descriptive string
function profFlag($str)
{
    global $prof_timing, $prof_names, $prof_mem;
    $prof_timing[] = microtime(true);
    $prof_names[]  = $str;
    $prof_mem[]    = memory_get_peak_usage(true);
}

// Call this when you're done and want to see the results
function profPrint()
{
    global $prof_timing, $prof_names, $prof_mem;
    $output_fmt = "%' 12s%' 12s%' 15s%' 15s     %' -20s\n";
    echo '<pre style="font-size: 13px;line-height: 1.5;">';
    echo sprintf($output_fmt, 'time(s)', 'delta', 'mem(byte)', 'delta', 'flag');
    $prof_timing_before = $prof_timing[0];
    $prof_mem_before    = $prof_mem[0];
    $size               = count($prof_timing);
    for ($i = 0; $i < $size; $i++) {
        echo sprintf(
            $output_fmt,
            number_format($prof_timing[$i] - LOG_ID / 1000000, 6),
            number_format($prof_timing[$i] - $prof_timing_before, 6),
            number_format($prof_mem[$i], 0, '.', ','),
            number_format($prof_mem[$i] - $prof_mem_before, 0, '.', ','),
            preg_replace('/\n/', '', $prof_names[$i])
        );
        $prof_timing_before = $prof_timing[$i];
        $prof_mem_before    = $prof_mem[$i];
    }
    echo '</pre>';
}

function profPrintDesc()
{
    global $prof_timing, $prof_names, $prof_mem;
    $output_fmt = "%' 12s%' 12s%' 15s%' 15s     %' -20s\n";
    $prof_timing_before = $prof_timing[0];
    $prof_mem_before    = $prof_mem[0];
    $size               = count($prof_timing);
    $map = [];
    for ($i = 0; $i < $size; $i++) {
        $map[] = [number_format($prof_timing[$i] - LOG_ID / 1000000, 6),
                  number_format($prof_timing[$i] - $prof_timing_before, 6),
                  number_format($prof_mem[$i], 0, '.', ','),
                  number_format($prof_mem[$i] - $prof_mem_before, 0, '.', ','),
                  preg_replace('/\n/', '', $prof_names[$i])];
        $prof_timing_before = $prof_timing[$i];
        $prof_mem_before    = $prof_mem[$i];
    }
    $column = array_column($map, 1);
    array_multisort($column,SORT_DESC,SORT_NUMERIC,$map);
    echo '<pre style="font-size: 13px;line-height: 1.5;">';
    echo sprintf($output_fmt, 'time(s)', 'delta', 'mem(byte)', 'delta', 'flag');
    for ($i = 0; $i < $size; $i++) {
        echo sprintf(
            $output_fmt,
            $map[$i][0],
            $map[$i][1],
            $map[$i][2],
            $map[$i][3],
            $map[$i][4]
        );
    }
    echo '</pre>';
}

return [
    'SHOW_PAGE_TRACE' => false,
];
