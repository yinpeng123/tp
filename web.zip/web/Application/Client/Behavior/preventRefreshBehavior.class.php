<?php
namespace Client\Behavior;

use Think\Behavior;
use Think\Log;
use Common\Cnsts\ERRNO;

class preventRefreshBehavior extends Behavior
{
    const WHITE_LIST = [
        'client/user/getuserinfo',
        'client/permission/getpermissions',
        'client/order/orderfeedlist',
        'client/paycallback/alipayconfirm',
        'client/paycallback/alipayappconfirm',
        'client/paycallback/wxpayconfirm',
    ];

    // 行为扩展的执行入口必须是run
    public function run(&$params)
    {
        if ( in_array(strtolower(MODULE_NAME . '/' . CONTROLLER_NAME . '/' . ACTION_NAME), self::WHITE_LIST) ) {
            return;
        }
        // 取业务程序处理生成数据用
        ob_start();

        $sid_cookie_name = C('SESSION_OPTIONS')['name'];
        $sid = $_COOKIE[$sid_cookie_name];

        if (empty($_REQUEST['request_id'])) {
            // 完整URL
            $uri = $_SERVER['REQUEST_URI'];

            $fd = file_get_contents('php://input');
            $request_id = md5($sid . $uri . $fd);
            $_REQUEST['request_id'] = $request_id;
        }

        // log 记录请求request_id起始log
        cmm_log('request_id=' . $_REQUEST['request_id'], 'PREVENT_REFRESH');

        $mval = S($_REQUEST['request_id']);
        if (false === $mval) {
            $ot['expire'] = C('REFRESH_MEMCACHE_SET_NULL_TIME');
            S($_REQUEST['request_id'], '#$#', $ot);
        } else {
            if ($mval === '#$#') {
                // log 第一次请求后未处理完时（及缓存数据为空）第二次请求
                $errmsg = ERRNO::e(ERRNO::REQUEST_FREQUENT);
                cmm_log($errmsg, 'PREVENT_REFRESH');

                $resp = [
                    "errno"  => ERRNO::REQUEST_FREQUENT,
                    "errmsg" => $errmsg,
                    "res"    => NULL,
                ];
                cmm_exit(json_encode($resp, JSON_UNESCAPED_UNICODE));

            } else {
                // log
                $log_content = [
                    'sid=' . $sid,
                    'request_id=' . $_REQUEST['request_id'],
                    'message=' . '返回缓存数据',
                ];
                Log::write(implode(' ', $log_content), 'PREVENT_REFRESH');

                tag('app_end');
            }
        }
    }
}

