<?php
namespace Wechat\Service;

use Basic\Cnsts\DICT;
use Basic\Model\UserModel;
use Basic\Service\UserService;
use Common\Cnsts\ERRNO;

//use Client\Cnsts\CHECK;

class LoginService {

    /**
     * 用户短信验证码方式登录
     *
     * @param $data
     */
    public function checkLoginSms($req) {
        if ($req['telephone'] != (string)session('wx_telephone_login')) {
            return [ERRNO::INPUT_PARAM_ERRNO, ERRNO::e(ERRNO::SMS_CODE_ERROR)];
        }
        if ((string)$req['code'] != (string)session('wx_sms_code_login')) {
            return [ERRNO::SMS_CODE_ERROR, ERRNO::e(ERRNO::SMS_CODE_ERROR)];
        }
        return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS),[]];
    }

    /**
     *手机号验证码登录
     * 手机号不存在时返回 -2
     */
    public function checkTelephoneLogin($req) {
        list($errno, $errmsg) = $this->checkLoginSms($req);
        if ($errno != ERRNO::SUCCESS) {
            return [$errno, $errmsg, []];
        }
        $user_model_s = new \Basic\Model\UserModel('slave', TRUE);
        $cond = [
            'telephone' => $req['telephone'],
            'is_delete' => 0,
        ];
        $user_list = $user_model_s->getListBy($cond);
        $count = count($user_list);
        if ( $count == 0 ) {
            list($errno, $errmsg, $user_id) = D('Basic/User', 'Service')->wxRegister($req['telephone'], $req['mp_openid']);
            if ($errno == ERRNO::SUCCESS) {
                $user = $user_model_s->get($user_id);
            }else{
                return [$errno, $errmsg, []];
            }
        } else if ( $count > 1 ) {
            return [ERRNO::OP_NOT_ALLOW, '该手机号有多个账号，请使用账号登录或联系客服！', []];
        } else {
            $user = $user_list[0];
        }
        /** @var UserService $user_serivce */
        $user_serivce = D('Basic/User', 'Service');
        $user_serivce->formatUserInfo($user);
        session(C('USER_SESSION_NAME_TWPT'), $user);
        unset($user['password']);
        if ($user['mp_openid'] && $user['mp_openid'] != $req['mp_openid']) {
            $this->sessionDestory($user['mp_openid']);
        }
        return [$errno, $errmsg, $user];
    }

    /**
     *  帐号、网员号登录 不存在返回-2
     */
    public function checkNameLogin($req) {
        $user_name = $req['username'];
        if (empty($user_name)) {
            return [ERRNO::INPUT_PARAM_ERRNO, ERRNO::e(ERRNO::INPUT_PARAM_ERRNO), []];
        }
        /** @var UserService $user_service */
        $user_service = D('Basic/User','Service');
        $where['_complex'] = [
            'telephone' => $user_name,
            'net_no'    => $user_name,
            'account'   => $user_name,
            '_logic'    => 'or',
        ];
        $where['is_delete'] = 0;
        $user_list = $user_service->getListBy($where);
        $nums = count($user_list);
        if ( $nums == 0 ) {
            return [ERRNO::SYS_NOT_LOGIN, '账号或密码错误，请重新登录！', []];
        } else if ( $nums > 1 ) {
            return [ERRNO::ACCOUNT_EXIST, '存在与你的账号相同的账号，请联系客服',[]];
        } else {
            $user = $user_list[0];
        }
        if ( $user ) {
            $user['user_id'] = $user['id'];
            if ($user['password'] == $req['password']) {
                /** @var UserService $user_serivce */
                $user_serivce = D('Basic/User', 'Service');
                $user_serivce->formatUserInfo($user);
                $telephone = $user['telephone'];
                session(C('USER_SESSION_NAME_TWPT'), $user);
                unset($user['password']);
                return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), $user];
            } else {
                return [ERRNO::PWD_ERRNO, ERRNO::e(ERRNO::PWD_ERRNO), []];
            }
        }
    }

    public function addSuccLoginLog($uid, $account, $data_from) {
        $add_data = [
            'uid' => $uid ? : 0,
            'account' => $account ? : '',
            'data_from' => $data_from,
            'ip' => get_client_ip(),
            'result' => 'success',
        ];

        $user_login_m = new \Basic\Model\UserLoginLogModel('master');

        $login_id = $user_login_m->add($add_data);

        if ($login_id) {
            return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS),[]];
        } else {
            return [ERRNO::SQL_UPDATE_ERRNO, '添加失败！',[]];
        }
    }

    public function addFailLoginLog($uid, $account, $data_from) {
        $add_data = [
            'uid' => $uid ? : 0,
            'account' => $account ? : '',
            'data_from' => $data_from,
            'ip' => get_client_ip(),
            'result' => 'fail',
        ];
        $user_login_m = new \Basic\Model\UserLoginLogModel('master');

        $login_id = $user_login_m->add($add_data);

        if ($login_id) {
            return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS),[]];
        } else {
            return [ERRNO::SQL_UPDATE_ERRNO, '添加失败！',[]];
        }
    }

    public function getListBy($cond, $fields = '', $order = '', $curpage = 0, $perpage = 0) {
        $user_login_s = new \Basic\Model\UserLoginLogModel('slave');
        $login_list = $user_login_s->getListBy($cond, $fields, $order, $curpage, $perpage);
        return $login_list;
    }

    /**
     * 删除某个openID的Session
     * @param  [type] $openid [description]
     * @return [type]         [description]
     */
    public function sessionDestory($openid){
        session(['id' => S(C('USER_SESSION_NAME_SESSION_ID').$openid)]);
        session(C('USER_SESSION_NAME_WECHAT'), null);
        session(C('USER_SESSION_NAME_TWPT'), null);
        session_destroy();
        // S(C('USER_SESSION_NAME_SESSION_ID').$openid, null);
    }
}