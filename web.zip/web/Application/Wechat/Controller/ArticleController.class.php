<?php
namespace Wechat\Controller;

use Think\Controller;
use Basic\Cnsts\WECHAT;
use Basic\Service\WechatService;
use Basic\ModelU\UserModel;
use Basic\ModelU\ArticleModel;
class ArticleController extends WechatController{

    function __construct(){
        parent::__construct();
    }
    //提交用户基本信息,openid,nickname,avatar
    public function index(){

        $model= new ArticleModel();
        $id=I('id');
        if($id){
            header('Content-Type: application/json; charset=utf-8');
            $data=t_json_encode(array('code' => 0, 'message' => 'ok', 'extra' => $model->get($id,'title,pic,ctime,name,content')));
            echo  $data ;
            exit;
        }
        $this->doResponse(-1,"参数错误");
    }

    public function Articlelist(){

        $model= new ArticleModel();
        $page=I('page')?I('page'):0;
        $list=$model->getListBy([],'id,title,ctime,name,content',"id desc",$page,3);
        if($list){
            $this->doResponse(0,"ok",$list);
        }
        $this->doResponse(1,"noData",$list);

    }


    public function trainer(){
        $this->doResponse(0,"ok","教练宣传信息介绍");
    }

}
