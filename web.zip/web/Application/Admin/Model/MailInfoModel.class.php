<?php
namespace Admin\Model;


use Basic\Model\BasicModel;

class MailInfoModel extends BasicModel
{

    private $__mail_info_model = NULL;

    public function __construct($db_type = 'master', $enable_cache = FALSE) {
        parent::__construct('mail_info', '', $db_type);
        $this->_enable_cache = $enable_cache;
        $this->__mail_info_model = $this->_model;

    }

    //获取收件人信息(单条)
    public function searchMailInfo($where) {
        return $this->__mail_info_model->where($where)->find();
    }

    //邮寄地址列表(根据用户id 即user_id查询)
    public function getMailList($where, $limit=null) {
        return $this->__mail_info_model->where($where)->order('id desc')->limit($limit)->select();
    }

    //删除邮寄地址（把status状态值改为0）
    public function updateMailInfo($where, $data) {
        return $this->__mail_info_model->where($where)->setField($data);
    }

    public function addMailInfo($data)
    {
        return $this->__mail_info_model->add($data);
    }
}