<?php
namespace Client\Controller;

use Basic\Model\AgentModel;
use Basic\Service\AgentService;
use Common\Controller\SessionController;
use Common\Cnsts\ERRNO;

class AgentController extends SessionController {

    public function __construct() {
        parent::__construct();
    }

    public function getAgentList() {
        return $this->doResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS),[]);
    }

}