<?php
namespace Client\Controller;

use Basic\Cnsts\CACHE_PREFIX;
use Basic\Cnsts\DICT;
use Basic\Cnsts\ORDER;
use Basic\Service\ShippingOrderService;
use Basic\Service\UserService;
use Common\Cnsts\ERRNO;
use Common\Controller\SessionController;

class LocationController extends SessionController  {

    CONST INTERVAL_TIME = 600;

    public function __construct() {
        parent::__construct();
    }

    /**
     * 上传
     */
    public function uploadLocation() {
        $uid = $this->user_id;
        //防止五分钟内重复上传
        if (!APP_DEBUG ) {
            $now = time();
            $last_time = S(CACHE_PREFIX::LAST_UPLOAD_TIME.'_'.$uid);
            if ( $last_time && ($now - $last_time < self::INTERVAL_TIME/2) ) {
                return $this->doResponse(ERRNO::INPUT_PARAM_ERRNO, '请务频繁上传', null);
            }
            S(CACHE_PREFIX::LAST_UPLOAD_TIME.'_'.$uid, $now);
        }

        /** @var UserService $user_service */
        $user_service = D('Basic/User', 'Service');
        $user_info = $user_service->getUserInfo($uid);
        $telephone = $user_info['telephone'];
        $telephone = $telephone ? : -99;
        //判断是否需要提醒定位
        $need_remind = 0;
        /** @var ShippingOrderService $ship_service */
        $ship_service = D('Basic/ShippingOrder', 'Service');
        $location_desc = '';
        if ( empty($this->req['lat']) ) {
            $need_remind = $ship_service->isNeedRemindLocation($telephone);
            $os_type = $this->app_info['os_type'];
            if ( $os_type == 'ios' ) {
                $location_desc = '定位服务未开启，进入系统【设置】> 【隐私】> 【定位服务】中打开开关，并允许物流之家使用定位服务';
            } else {
                $location_desc = '1.点击设置，进入应用信息页'."\n";
                $location_desc .= '2.选择"定位"'."\n";
                $location_desc .= '3.点按"始终允许"';
            }

        } else {
            $track = [
                'lat' => $this->req['lat'],
                'lng' => $this->req['lng'],
                'location' => $this->req['location'],
                'city' => $this->req['city'],
                'district' => $this->req['district'],
                'province' => $this->req['province'],
                'err_message' => $this->req['err_message'],

            ];
            //添加定位信息 @todo 调用鸿杰方法
            $order_service = new \Basic\Service\OrderService();
            $order_service->writeTrack($telephone, $track, $uid);
        }
        //是否需要定位
        $need_location = $ship_service->isNeedLocation($telephone);
        //轨迹使用统计
        (new \Basic\Service\TrackService())->addStatsTrack($uid);
        $data = [
            'interval_time' => self::INTERVAL_TIME,
            'remind_location' => $need_remind,
            'need_location' => $need_location,
            'location_desc' => $location_desc,
        ];
        return $this->doResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), $data);
    }

}
