<?php
namespace Admin\Controller;

use Admin\Model\TicketModel;
use Admin\Controller\AdminSessionController;
use Admin\Service\PageService;
use Basic\Cnsts\DICT;
use Admin\Service\ManagerService;
use Basic\Model\DriverMailModel;
use Basic\Model\DriverInvoiceModel;
use Basic\Model\DriverModel;
use Basic\Service\DriverService;
use Basic\Service\StatsService;
use Think\Model;
use Common\Cnsts\ERRNO;
use Basic\Service\CityService;
use Basic\Service\DriverMailService;

class DriverController extends AdminSessionController
{
    private $__driver_model = null;
    private $__user_service = null;
    private $__manager_service = null;

    public function __construct()
    {
        parent::__construct();

        $this->__driver_model     = D('Basic/Driver');
        $this->__user_service    = D('User', 'Service');
        $this->__manager_service = D('Manager', 'Service');

//        // 权限检查
//        if (!\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::AGENT)) {
//            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
//            exit;
//        }
    }

    public function index() {
        //获取认证状态
        $driver_status_arr = $this->getDriverStatus();
//p($driver_status_arr);die;
//p(I('id_status'));
        $mobile = I('mobile');
        $name = I('name');
        $identity = I('identity');
        $id_status = I('id_status');

        if (!empty($mobile)) {
            $cond['mobile'] = ['eq', $mobile];
        }
        if (!empty($name)) {
            $cond['name'] = ['eq', $name];
        }
        if (!empty($identity)) {
            $cond['identity'] = ['eq', $identity];
        }
        if (!empty($id_status)) {
            if($id_status == 3) {
                $cond['id_status'] = 0;
            } else {
                $cond['id_status'] = ['eq', $id_status];
            }
        }

        //数据
        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        $ret       = $this->__driver_model->searchDriverList($cond, $curr_page, $per_page);
//p($ret['data']);die;
        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();


        $this->assignAll(array(
            'list' => $ret['data'],
            'title' => '司机管理',
            'mobile' => $mobile,
            'name' => $name,
            'identity' => $identity,
            'id_status' => $id_status,
            'driver_status_arr' => $driver_status_arr,
            'form_action' => '/Admin/Driver/index',
            'page_nav' => $page_nav,
        ));
        $this->display('driver_index');
    }

    public function edit($id) {
        $id = (int)$id;
        if(!$id) {
            $this->admin_error('ID不正确！');
            return;
        }
        //司机信息
        $driver = $this->__driver_model->getInfo($id);
        if( !$driver ) {
            $this->admin_error('司机信息不存在！');
            return;
        }
        //获取车长
        $truck_length_arr = $this->getTruckLength();
        //获取车型
        $truck_type_arr = $this->getTruckType();
        //获取认证状态
        $driver_status_arr = $this->getDriverStatus();

//        p($driver);die;
        //处理图片信息
        $avatar = json_decode($driver['avatar'], true);
        $identity_photo = json_decode($driver['identity_photo'], true);
        $identity_back_photo = json_decode($driver['identity_back_photo'], true);
        $license_photo = json_decode($driver['license_photo'], true);
        $truck_license_photo = json_decode($driver['truck_license_photo'], true);
        $biz_license_photo = json_decode($driver['biz_license_photo'], true);
//p($identity_photo);die;

        //头像处理
        $avatar['url'] = imageUrl($avatar);
        $ret = getImage($avatar['type'], $avatar['path'], $avatar['name'], $info);
        if ($ret == ERRNO::SUCCESS) {
            $avatar['size'] = $info['size'];
            $avatar['initialPreview'] = $avatar['url'];
            $avatar['type'] = 'image';
            $avatar['caption'] = $avatar['name'];
            $avatar['url'] = '/driver/deleteImage/'.$id;
            $avatar['key'] = 'avatar';
        } else {
            $avatar['size'] = 0;
        }
//p($avatar);
        //身份证正面处理
        $identity_photo['url'] = imageUrl($identity_photo);
        $ret = getImage($identity_photo['type'], $identity_photo['path'], $identity_photo['name'], $info);
        if ($ret == ERRNO::SUCCESS) {
            $identity_photo['size'] = $info['size'];
            $identity_photo['initialPreview'] = $identity_photo['url'];
            $identity_photo['type'] = 'image';
            $identity_photo['caption'] = $identity_photo['name'];
            $identity_photo['url'] = '/driver/deleteImage/'.$id;
            $identity_photo['key'] = 'identity_photo';
        } else {
            $identity_photo['size'] = 0;
        }

//        p($identity_photo);die;

        //身份证反面处理
        $identity_back_photo['url'] = imageUrl($identity_back_photo);
        $ret = getImage($identity_back_photo['type'], $identity_back_photo['path'], $identity_back_photo['name'], $info);
        if ($ret == ERRNO::SUCCESS) {
            $identity_back_photo['size'] = $info['size'];
            $identity_back_photo['initialPreview'] = $identity_back_photo['url'];
            $identity_back_photo['type'] = 'image';
            $identity_back_photo['caption'] = $identity_back_photo['name'];
            $identity_back_photo['url'] = '/driver/deleteImage/'.$id;
            $identity_back_photo['key'] = 'identity_back_photo';
        } else {
            $identity_back_photo['size'] = 0;
        }

        //驾照照片处理
        $license_photo['url'] = imageUrl($license_photo);
        $ret = getImage($license_photo['type'], $license_photo['path'], $license_photo['name'], $info);
        if ($ret == ERRNO::SUCCESS) {
            $license_photo['size'] = $info['size'];
            $license_photo['initialPreview'] = $license_photo['url'];
            $license_photo['type'] = 'image';
            $license_photo['caption'] = $license_photo['name'];
            $license_photo['url'] = '/driver/deleteImage/'.$id;
            $license_photo['key'] = 'license_photo';
        } else {
            $license_photo['size'] = 0;
        }

        //行驶证照片处理
        $truck_license_photo['url'] = imageUrl($truck_license_photo);
        $ret = getImage($truck_license_photo['type'], $truck_license_photo['path'], $truck_license_photo['name'], $info);
        if ($ret == ERRNO::SUCCESS) {
            $truck_license_photo['size'] = $info['size'];
            $truck_license_photo['initialPreview'] = $truck_license_photo['url'];
            $truck_license_photo['type'] = 'image';
            $truck_license_photo['caption'] = $truck_license_photo['name'];
            $truck_license_photo['url'] = '/driver/deleteImage/'.$id;
            $truck_license_photo['key'] = 'truck_license_photo';
        } else {
            $truck_license_photo['size'] = 0;
        }

        //营运证照片处理biz
        $biz_license_photo['url'] = imageUrl($biz_license_photo);
        $ret = getImage($biz_license_photo['type'], $biz_license_photo['path'], $biz_license_photo['name'], $info);
        if ($ret == ERRNO::SUCCESS) {
            $biz_license_photo['size'] = $info['size'];
            $biz_license_photo['initialPreview'] = $biz_license_photo['url'];
            $biz_license_photo['type'] = 'image';
            $biz_license_photo['caption'] = $biz_license_photo['name'];
            $biz_license_photo['url'] = '/driver/deleteImage/'.$id;
            $biz_license_photo['key'] = 'biz_license_photo';
        } else {
            $biz_license_photo['size'] = 0;
        }
//p($identity_photo);die;
        $this->assignAll(array(
            'title' => '司机详情',
            'driver' => $driver,
            'user_id' => I('0'),
            'act' => 'edit',
            'avatar' => $avatar,
            'identity_photo' => $identity_photo,
            'identity_back_photo' => $identity_back_photo,
            'license_photo' => $license_photo,
            'truck_license_photo' => $truck_license_photo,
            'biz_license_photo' => $biz_license_photo,
            'truck_type_arr' => $truck_type_arr,
            'driver_status_arr' => $driver_status_arr,
            'truck_length_arr' => $truck_length_arr,
            'form_action' => '/admin/driver/doEdit',
        ));

        $this->display('driver_edit');
    }

    public function doEdit() {
        // 验证令牌
        $this->checkFormToken();
        $data     = I('');
//        p($data);die;
        $driver_id = $data['driver_id'];
        $info = $this->__driver_model->getInfo($driver_id);
//        p($info);die;
        //上传处理
        $root_dir = C('IMAGE_PATH')['certificate'];
        $sub_dir  = day();

        $ajax_avatar = [];
        if(!empty($data['avatar'])) {
            $arr = explode('/', $data['avatar']);
            $ajax_avatar = [
                'name'  =>  $arr[8],
                'path'  =>  $arr[7],
                'type'  =>  'certificate'
            ];
        }
        $avatar_info = $ajax_avatar;

        $ajax_identity_photo = [];
        if(!empty($data['identity_photo'])) {
            $arr = explode('/', $data['identity_photo']);
            $ajax_identity_photo = [
                'name'  =>  $arr[8],
                'path'  =>  $arr[7],
                'type'  =>  'certificate'
            ];
        }
        $identity_photo_info = $ajax_identity_photo;

        $ajax_identity_back_photo = [];
        if(!empty($data['identity_back_photo'])) {
            $arr = explode('/', $data['identity_back_photo']);
            $ajax_identity_back_photo = [
                'name'  =>  $arr[8],
                'path'  =>  $arr[7],
                'type'  =>  'certificate'
            ];
        }
        $identity_back_photo_info = $ajax_identity_back_photo;

        $ajax_license_photo = [];
        if(!empty($data['license_photo'])) {
            $arr = explode('/', $data['license_photo']);

            $ajax_license_photo = [
                'name'  =>  $arr[8],
                'path'  =>  $arr[7],
                'type'  =>  'certificate'
            ];
        }
        $license_photo_info = $ajax_license_photo;

        $ajax_truck_license_photo = [];
        if(!empty($data['truck_license_photo'])) {
            $arr = explode('/', $data['truck_license_photo']);

            $ajax_truck_license_photo = [
                'name'  =>  $arr[8],
                'path'  =>  $arr[7],
                'type'  =>  'certificate'
            ];
        }
        $truck_license_photo_info = $ajax_truck_license_photo;

        $ajax_biz_license_photo = [];
        if(!empty($data['biz_license_photo'])) {
            $arr = explode('/', $data['biz_license_photo']);

            $ajax_biz_license_photo = [
                'name'  =>  $arr[8],
                'path'  =>  $arr[7],
                'type'  =>  'certificate'
            ];
        }
        $biz_license_photo_info = $ajax_biz_license_photo;


        // 处理图片数据
        if (!empty($avatar_info)) {
            $avatar = $avatar_info;
            $fields['avatar'] = json_encode($avatar);
        }
        if (!empty($identity_photo_info)) {
            $identity_photo = $identity_photo_info;
            $fields['identity_photo'] = json_encode($identity_photo);
        }
        if (!empty($identity_back_photo_info)) {
            $identity_back_photo = $identity_back_photo_info;
            $fields['identity_back_photo'] = json_encode($identity_back_photo);
        }
        if (!empty($biz_license_photo_info)) {
            $biz_license_photo = $biz_license_photo_info;
            $fields['biz_license_photo'] = json_encode($biz_license_photo);
        }
        if (!empty($truck_license_photo_info)) {
            $truck_license_photo = $truck_license_photo_info;
            $fields['truck_license_photo'] = json_encode($truck_license_photo);
        }
        if (!empty($license_photo_info)) {
            $license_photo = $license_photo_info;
            $fields['license_photo'] = json_encode($license_photo);
        }

        //同步更新认证状态
        $id_status = 0;
        if(empty($data['identity']) && empty($data['card_status']) ) {
            $id_status = 0;
        }
        if(!empty($data['identity']) && empty($data['card_status'])) {
            $id_status = 1;
        }
        if (!empty($data['card_status'])) {
            $id_status = 2;
        }
        if ($data['card_status'] == 2 || $data['card_status'] == 3 ){
            $id_status = -1;
        }

        if($info['card_status'] != 0) {
            $data['card_status'] = $info['card_status'];
        }

        $fields['truck_no'] = $data['truck_no'];
        $fields['truck_length'] = $data['truck_length'];
        $fields['truck_type'] = $data['truck_type'];
        $fields['card_status'] = $data['card_status'];
        $fields['id_status'] = $id_status;
        $fields['mtime'] = date('Y-m-d H:i:s');
//        p($fields);die;
        $driver_model = new \Basic\Model\DriverModel();
        $res = $driver_model->updateById($data['driver_id'], $fields);
//        p($res);die;
        // 添加操作日志
        $this->__manager_service->addOperLog([
            'manager_id' => $this->_manager_id,
            'object_id'  => I('driver_id'),
            'action'     => 'update',
            'desc'       => "修改司机信息成功",
        ]);
        $this->admin_success('修改司机信息成功！');
    }

    public function resetPass() {
        $user_id = I('user_id');
        $info = $this->__driver_model->getInfo($user_id);
        if($info['identity']) {
            $up_data = [
                'password' => password_hash(substr($info['identity'],-6), PASSWORD_DEFAULT),
            ];
            $res = $this->__driver_model->updateById($user_id, $up_data);
            if ($res) {
                /** @var \Driver\Service\SendNoticeService $sendnotice_service */
                $sendnotice_service = D('Driver/SendNotice', 'Service');
                $sendnotice_service->addNotice($user_id, 'crm_reset_pass', []);
                return $this->doResponse(ERRNO::SUCCESS,ERRNO::e(ERRNO::SUCCESS));
            } else {
                return $this->doResponse(ERRNO::SQL_UPDATE_ERRNO,ERRNO::e(ERRNO::SQL_UPDATE_ERRNO));
            }
        } else {
            $this->doResponse(2,'参数错误');
        }
    }

    public function deleteImage($id) {
//        p(I(''));die;
        /** @var DriverModel $driver_model */
        $driver_model = D('Basic/Driver', 'Model');
        $data = [
            I('key') => '',
        ];
        $driver_model->updateById($id, $data);
        echo '{}';
    }

    /**
     * 校验身份证号是否存在 reviewed
     */
    public function checkCardExists() {
        $card_num = I('card_num');
        if (empty($card_num)) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO,ERRNO::e(ERRNO::INPUT_PARAM_ERRNO),[]);
            return;
        }

        $user_id = (int)I('user_id');
        /** @var \Basic\Service\DriverService $basic_user_service */
        $basic_user_service = D('Basic/Driver','Service');
        if (empty($user_id)) {
            //校验是否存在同样的信息
            $exists = $basic_user_service->checkCardExists($card_num);
        } else {
            //校验除了当前帐户外是否存在同样的信息
            $exists = $basic_user_service->checkCardExists($card_num,$user_id);
        }
        if ($exists) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO,'身份证号已经存在',[]);
        } else {
            $this->doResponse(ERRNO::SUCCESS,ERRNO::e(ERRNO::SUCCESS),[]);
        }
        return;
    }


    // ajax上传图片接口
    public function ajaxUploadImage($id) {
//        p($_FILES);die;
        $key = key($_FILES);
//        p($key);
        if ( empty($_FILES[$key]) || $_FILES[$key]['size'] == 0 ) {
            die("{}");
        }

        $root_dir = C('IMAGE_PATH')['certificate'];
        $sub_dir = day();
        $image_info = array();
        list($errcode, $errmsg) = uploadImage($key, $root_dir, $sub_dir, $image_info, 'certificate');
        if ( $errcode != ERRNO::SUCCESS ) {
            echo json_encode(['error' => $errmsg]);
            exit;
        } else {
            // 前端显示为和初始预览框一样的状态: 移动排序图标, 无进度条
            $res = [
                'initialPreview' => [ imageUrl($image_info) ],
                'initialPreviewConfig' => [
                    [
                        'type'      => 'image',
                        'caption'   => $image_info['name'],
                        'size'      => $_FILES[$key]['size'],
                        'url'       => '/admin/driver/deleteImage/',
                        'key'       => 1,
                    ],
                ]
            ];
//            p($res['initialPreview']);
//            $arr = explode('/', $res['initialPreview'][0]);
//            $info = [
//                'name'  =>  $arr[8],
//                'path'  =>  $arr[7],
//                'type'  =>  'certificate'
//            ];
//            if (!empty($info)) {
//                $identity_photo['identity_photo'] = $info;
//            }
//
//            $fields['identity_photo'] = json_encode($identity_photo);
//            $driver_model = new \Basic\Model\DriverModel();
//            $driver_model->updateById($id, $fields);
            echo json_encode($res);
            exit;
        }
    }

    //开票模块
    public function editInvoice() {

        $data = I('');
//p($data);die;
        if ($data['acti'] === 'agent_id') {
            $driver_id   = $data[0];
            $invoice_id = I('path.3/d', 0);
            if ($invoice_id) { // 编辑状态

            }
            $invoice_model = D('Basic/DriverInvoice');
            $list          = $invoice_model->getInvoiceList(['driver_id' => $driver_id]);

            $num = count($list);
//            $act = I('act', 'edit_invoice');
            $this->assignAll([
                'act'              => 'addInvoice',
                //                'manager_id'=> $manager_id,
                'agent_id'         => $driver_id,
                'list'             => $list,
                'num'             => $num,
            ]);
        } else {
            $driver_id   = $data[0];
            $invoice_id = I('path.3/d', 0);
            if ($invoice_id) { // 编辑状态

            }
            $invoice_model = D('Basic/DriverInvoice');
            $list          = $invoice_model->getInvoiceList(['driver_id' => $driver_id]);
//            p($list);die;
            $num = count($list);
//            $act = I('act', 'edit_invoice');
//            $agent = $this->__agent_model->getAgentById($agent_id);

//            $agent['id'] = $agent_id;
            $this->assignAll([
                'action'           => 'edit',
                'act'              => 'editInvoice',
                'agent_id'         => $driver_id,
                'list'             => $list,
//                'agent'            => $agent,
                'invoice_id'            => $data['invoice_id'],
                'num'   => $num,
            ]);
        }
        $this->assignAll(array(
            'title' => '司机详情',
            'act' => 'editInvoice',
            'user_id' => $driver_id,
        ));
        $this->display('driver_invoice');
    }

    /**
     * 保存提交编辑表格
     */
    public function doEditInvoice()
    {
        // 验证令牌
        $this->checkFormToken();
//        p(I(''));die;
        $agent_id = $_POST['agent_id'];
        $head     = I('head/d', 1);
        $fields   = [
            'driver_id' => $agent_id,
            'head'     => $head,
        ];

        if ($head == 1) { // 个人
            $fields['type']          = 1;
            $fields['company']       = '';
            $fields['taxer_no']      = '';
            $fields['credit_no']     = '';
            $fields['address']       = '';
            $fields['tax_type']      = '';
            $fields['phone']         = '';
            $fields['bank_name']     = '';
            $fields['bank_passport'] = '';

        } else { // 公司
            $type           = I('type/d', 1);
            $fields['type'] = $type;

            if ($type == 1) { // 增值税普通发票
                $fields['company']       = I('company', '');
                $fields['taxer_no']      = '';
                $fields['credit_no']     = '';
                $fields['address']       = '';
                $fields['tax_type']      = '';
                $fields['phone']         = '';
                $fields['bank_name']     = '';
                $fields['bank_passport'] = '';

            } else { // 增值税专用发票
                $fields['company']       = I('company', '');
                $fields['taxer_no']      = I('taxer_no', '');
                $fields['credit_no']     = I('credit_no', '');
                $fields['address']       = I('address', '');
                $fields['tax_type']      = I('tax_type', '');
                $fields['phone']         = I('phone', '');
                $fields['bank_name']     = I('bank_name', '');
                $fields['bank_passport'] = I('bank_passport', '');
            }
        }

        $invoice_model = D('Basic/DriverInvoice');

        $invoice_id = I('invoice_id/d', 0);
        if ($invoice_id > 0) { // 编辑记录
            $fields['mtime'] = datetime();
            $invoice_model->updateInvoice(['id' => $invoice_id], $fields);

            //添加操作日志
            $this->__manager_service->addOperLog([
                'manager_id' => $this->_manager_id,
                'object_id'  => $agent_id,
                'action'     => 'doEditInvoice',
                'desc'       => "修改司机发票成功",
            ]);

            $this->admin_success('修改司机发票信息成功！');

        } else { // 添加记录
            $fields['ctime'] = datetime();
            $invoice_model->addAgentInvoice($fields);

            // 添加操作日志
            $this->__manager_service->addOperLog([
                'manager_id' => $this->_manager_id,
                'object_id'  => $agent_id,
                'action'     => 'addInvoice',
                'desc'       => "添加司机发票成功",
            ]);
        }
        if (I('act') === 'addInvoice') {
            redirect(U('driver/editInvoice/' . $agent_id, '', '').'?acti=agent_id');
        } else {
            $this->redirect('driver/editInvoice/' . $agent_id);
        }
    }

    public function getInvoiceInfo($invoice_id)
    {
        $invoice_id = (int)$invoice_id;
        if (!$invoice_id) {
            $this->ajaxResponse(-1, 'ID不正确！');

            return;
        }

        /** @var DriverMailModel $invoice_model */
        $invoice_model = D('Basic/DriverInvoice', 'Model');
        $invoice       = $invoice_model->getInvoice(['id' => $invoice_id]);
        //print_r($invoice);
        $this->ajaxResponse(0, $invoice);
    }

    public function deleteInvocie($invoice_id)
    {
        $invoice_id = (int)$invoice_id;
        if (!$invoice_id) {
            $this->admin_error('ID不正确！');

            return;
        }

        $invoice_model = D('Basic/DriverInvoice');
        $invoice_model->deleteInvoice($invoice_id);

        // 添加操作日志
        $this->__manager_service->addOperLog([
            'manager_id' => $this->_manager_id,
            'object_id'  => $invoice_id,
            'action'     => 'deleteInvoice',
            'desc'       => "删除发票成功",
        ]);
        redirect(U('driver/editInvoice/' . I('agent_id'), '', '') . '?acti=agent_id');
//        $this->admin_success('删除发票成功！');
    }

    /**
     * 批量删除
     */
    public function deleteInvoiceAll()
    {
        $ids = I('ids');
        if (empty($ids)) {
            $this->admin_error('ID不正确！');

            return;
        }

        /** @var DriverMailModel $invoice_model */
        $invoice_model = D('Basic/DriverInvoice', 'Model');
        $invoice_model->deleteInvoice($ids);

        // 添加操作日志
        $this->__manager_service->addOperLog([
            'manager_id' => $this->_manager_id,
            'object_id'  => implode(',', $ids),
            'action'     => 'deleteInvoiceAll',
            'desc'       => "批量删除发票",
        ]);

        $this->admin_success('批量删除发票成功！');
    }

    public function editMail() {
        $data = I('');
//        p(I(''));die;
        $driver_id = $data[0];

        if($data['actn'] == 'add_mail') {
            /** @var CityService $city_service */
            $city_service = D('Basic/City', 'Service');
            //省列表
            $province_list = $city_service->getCitiesByWhere(['parent_id'=> -1],'id asc');
            $cities = $city_service->getFormaltAllCity();
            $list = $this->getMailList($driver_id);

            $num = count($list);
            $this->assignAll([
                'act'              => 'addMail',
                //                'manager_id'=> $manager_id,
                'title' => '司机详情',
                'province_list'      => $province_list,
                'agent_id'         => $driver_id,
                'list'  =>  $list,
                'num'  =>  $num,
            ]);
        } else {
            /** @var CityService $city_service */
            $city_service = D('Basic/City', 'Service');
            //省列表
            $province_list = $city_service->getCitiesByWhere(['parent_id'=> -1],'id asc');
            $cities = $city_service->getFormaltAllCity();
            $list = $this->getMailList($driver_id);
//p($list);die;
            $num = count($list);
//            $agent = $this->__agent_model->getAgentById($data[0]);
            foreach ($list as $key => &$value) {
                $value['province_name'] = $cities[$value['province']]['name'] ? : '';
                $value['city_name'] = $cities[$value['city']]['name'] ? : '';
                $value['district_name'] = $cities[$value['district']]['name'] ? : '';
                if ($value['is_default'] == 1) {
                    $value['is_default_desc'] = '是';
                } else {
                    $value['is_default_desc'] = '否';
                }
            }

            $this->assignAll(array(
//                'agent' =>  $agent,
                'act'     => 'editMail',
                'title'   => '司机详情',
                'driver_id'=> $driver_id,
                'province_list'      => $province_list,
                'list'      => $list,
                'num'      => $num,
                'mail_id'      => $data['mail_id'],
            ));
        }
        $this->assign(array(
            'user_id' => $driver_id,
        ));

        $this->display('driver_mail');
    }

    /**
     * 获取邮寄信息
     */
    public function getMailList($driver_id) {
//        p($driver_id);die;
        if (empty($driver_id)) {
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO,ERRNO::e(ERRNO::INPUT_PARAM_ERRNO),[]);
            return;
        }
        /** @var DriverMailService $address_service */
        $address_service = D('Basic/DriverMail','Service');
        $filter = [
            'status' => 1,
            'driver_id' => $driver_id,
            'page_num' => 1,
            'page_size' => 100,
        ];
        $data = $address_service->getAddressList($filter);
//p($data);die;
        $mail_list = $data['list'];
        return $mail_list;
    }

    /**
     * 添加或更新邮寄信息
     */
    public function doEditMail(){
        $mail_info = $_POST;
        $act = $mail_info['act'];
        unset($mail_info['agent_id']);
//        p($mail_info);die;
        $user_id = $mail_info['user_id'];
        if(empty($mail_info['mail_id'])) {
            unset($mail_info['mail_id']);
        } else {
            $mail_info['id'] = $mail_info['mail_id'];
        }

        /** @var DriverMailService $address_service */
        $address_service = D('Basic/DriverMail', 'Service');
        if ($mail_info['is_default'] == 1) {
            $address_model = new \Basic\Model\DriverMailModel();
            // 取消默认地址
            $cancle_return = $address_model->cancleDefaultAddressById($mail_info['agent_id']);
        }
        if (empty($mail_info['mail_id'])) {
            list($errno, $errmsg,$data) = $address_service->addAddr($mail_info);

        } else {
            list($errno, $errmsg,$data) = $address_service->upAddr($mail_info);

        }
        //@todo 设置默认
        if ($act !== 'edit') {
            $this->admin_success('添加邮寄信息成功');
        } else {
            $this->admin_success('编辑邮寄信息成功');
        }
        return;
    }


    public function deleteMailInfo($mail_id) {
        $mail_id = (int) $mail_id;
        $driver_id = I('driver_id');
        if (!$mail_id) {
            $this->admin_error('邮寄地址ID不正确！');
        }
        /** @var DriverMailService $address_service */
        $address_service = D('Basic/DriverMail', 'Service');
        $up_data = ['id'=> $mail_id,'status' => 0,'driver_id' => $driver_id];
        list($errno, $errmsg,$data) = $address_service->upAddr($up_data);
        if ($errno == ERRNO::SUCCESS) {
            $this->admin_success('删除成功');
        } else {
            $this->admin_error('删除失败');
        }
        return;
    }

    public function deleteMailAll() {
        $ids = I('ids');
        if ( empty($ids) ) {
            $this->admin_error('ID不正确！');
            return;
        }
        /** @var DriverMailService $address_service */
        $address_service = D('Basic/DriverMail', 'Service');
        $where = [
            'id' => ['in', $ids],
        ];
        list($errno,$errmsg,$data) = $address_service->upAddrByWhere($where,['status' => 0]);
        //@todo 添加日志
        if ($errno == ERRNO::SUCCESS) {
            $this->admin_success('删除司机邮寄地址成功！');
        } else {
            $this->admin_error('删除司机邮寄地址失败！');
        }
        return;
    }

    public function getMailInfo($mail_id) {
        $mail_id = (int)$mail_id;
        if ( !$mail_id ) {
            $this->ajaxResponse(-1, 'ID不正确！');
            return;
        }
        /** @var DriverMailService $mail_service */
        $mail_service = D('Basic/DriverMail', 'Service');
        list($errno,$errmsg,$mail_info) = $mail_service->getAddress($mail_id);
        $this->ajaxResponse(0, $mail_info);
    }


    public function verify(){
        $driver_id = I('driver_id');
        if (!$driver_id) {
            return $this->ajaxResponse(ERRNO::INPUT_PARAM_ERRNO, ERRNO::e(ERRNO::INPUT_PARAM_ERRNO));
        }
        $status = I('status');
        if (!in_array($status, ['pass','deny'])) {
            return $this->ajaxResponse(ERRNO::INPUT_PARAM_ERRNO, ERRNO::e(ERRNO::INPUT_PARAM_ERRNO));
        }
        if ($status == 'deny') {
            $reason = I('reason');
            if (!$reason) {
                return $this->ajaxResponse(ERRNO::INPUT_PARAM_ERRNO, ERRNO::e(ERRNO::INPUT_PARAM_ERRNO).'，拒绝原因不能为空');
            }

            if (mb_strlen($reason) > 15) {
                return $this->ajaxResponse(ERRNO::INPUT_PARAM_ERRNO, ERRNO::e(ERRNO::INPUT_PARAM_ERRNO.'，拒绝原因不能多于15字'));
            }

        }
        /** @var Driver\Service\ProfileService $profile_service */
        $profile_service = D('Driver/Profile', 'Service');
        $driver_info = $profile_service->getProfileById($driver_id);
        if ($driver_info['id_status'] != DICT::ATTACT_DOING) {
            return $this->ajaxResponse(ERRNO::INPUT_PARAM_ERRNO, ERRNO::e(ERRNO::INPUT_PARAM_ERRNO).'，认证状态错误。');
        }
        if ($status == 'pass') {
            /** @var CardCheckService $card_service */
            $card_service = D('Basic/CardCheck', 'Service');
            $log_list = $card_service->checkLogList($driver_info['identity'],$driver_info['name'],1);
            if ($log_list[0]['check_status'] != $card_service::SAME) {
                return $this->ajaxResponse(ERRNO::OP_NOT_ALLOW, ERRNO::e(ERRNO::OP_NOT_ALLOW).'，请先核查身份证号。');
            }
        }
        /** @var \Basic\Service\DriverService $driver_service */
        $driver_service = D('Basic/Driver', 'Service');
        $res = $driver_service->changeVerifyStatus($driver_id, $status == 'pass' ? DICT::ATTACT_HAVING : DICT::ATTACT_FAIL, $reason);
        if ($res) {
            if ($status == 'deny') {
                /** @var \Driver\Service\SendNoticeService $sendnotice_service */
                $sendnotice_service = D('Driver/SendNotice', 'Service');
                $sendnotice_service->addNotice($driver_id, 'driver_cert_fail', ['cert_fail_reason' => $reason]);
            }
            return $this->ajaxResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS));
        }
        $this->ajaxResponse(ERRNO::SQL_UPDATE_ERRNO, ERRNO::e(ERRNO::SQL_UPDATE_ERRNO));
    }


    /**
     * 获取认证状态
     */
    protected function getDriverStatus()
    {
        $driver_status_arr  = [];
        $driver_status_list = DICT::DRIVER_STATUS_LIST;
        $driver_status_keys = array_keys($driver_status_list);
        foreach ($driver_status_keys as $i => &$r) {
            $driver_status_arr[] = ['id' => $r, 'text' => $driver_status_list[$r]];
        }

        return $driver_status_arr;
    }

    /**
     * 获取车长
     */
    protected function getTruckLength()
    {
        $driver_status_arr  = [];
        $driver_status_list = DICT::CAR_LENGTH;
        $driver_status_keys = array_keys($driver_status_list);
        foreach ($driver_status_keys as $i => &$r) {
            $driver_status_arr[] = ['id' => $r, 'text' => $driver_status_list[$r]];
        }

        return $driver_status_arr;
    }

    /**
     * 获取车长
     */
    protected function getTruckType()
    {
        $truck_type_arr  = [];
        $truck_type_list = DICT::CAR_TYPE;
        $truck_type_keys = array_keys($truck_type_list);
        foreach ($truck_type_keys as $i => &$r) {
            $truck_type_arr[] = ['id' => $r, 'text' => $truck_type_list[$r]];
        }

        return $truck_type_arr;
    }
}