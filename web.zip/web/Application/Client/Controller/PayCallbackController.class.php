<?php
namespace Client\Controller;

use Think\Controller;
use Think\Log;

/**
 * 在线支付回调接口
 */
class PayCallbackController extends Controller {

    /**
     * 支付宝 - 移动支付回调接口（旧版本）
     */
    public function alipayConfirm() {
        //Log::write('[alipayConfirm] '.print_r(I(''), true), Log::INFO);
        Log::write('[alipayConfirm] '.print_r($_POST, true), Log::INFO);
        echo "success";
        fastcgi_finish_request();

        Vendor('AlipayMobile.alipay_core');
        Vendor('AlipayMobile.alipay_notify');
        Vendor('AlipayMobile.alipay_rsa');

        $alipay_notify = new \AlipayNotify(C('alipay')['data_tpl']);
        Log::write('[alipayConfirm] '.print_r(C('alipay')['data_tpl'], true), Log::INFO);

        if ( $alipay_notify->verifyNotify() ) {
            // 检查交易状态是否为成功支付
            $trade_status = I('trade_status');
            if ($trade_status != 'TRADE_FINISHED' && $trade_status != 'TRADE_SUCCESS') {
                return FALSE;
            }

            /* @var \Basic\Service\AlipayService $alipay_service */
            $alipay_service = D('Basic/Alipay', 'Service');
            return $alipay_service->confirmOrder($_POST);

        } else {
            \Think\Log::write('[alipayConfirm] verify signature FAIL!', 'INFO');
            return FALSE;
        }
    }

    /**
     * 支付宝 - APP支付回调接口
     */
    public function alipayAppConfirm() {
        Log::write('[alipayAppConfirm] '.print_r($_POST, true), Log::INFO);
        echo "success";
        fastcgi_finish_request();

//        Vendor('alipay-sdk.AopSdk');
//        Vendor('alipay-sdk.aop.AopClient');
//        $client = new \AopClient();
//        $client->alipayrsaPublicKey = C('alipay')['data_tpl']['ali_public_key'];
//        $flag = $client->rsaCheckV1($_POST, NULL, "RSA2");
//        \Think\Log::write('[alipayAppConfirm] '.var_dump($flag), 'INFO');
//
//        if ( $flag ) {
//            \Think\Log::write('[alipayAppConfirm] verify signature success!', 'INFO');
//            return TRUE;
//        } else {
//            \Think\Log::write('[alipayAppConfirm] verify signature FAIL!', 'INFO');
//            return FALSE;
//        }

        /* @var \Basic\Service\AlipayAppService $alipay_service */
        $alipay_service = D('Basic/AlipayApp', 'Service');

        if ( $alipay_service->confirmRasCheck($_POST) ) {
            // 检查交易状态是否为成功支付
            $trade_status = I('trade_status');
            if ($trade_status != 'TRADE_FINISHED' && $trade_status != 'TRADE_SUCCESS') {
                return FALSE;
            }

            return $alipay_service->confirmOrder($_POST);

        } else {
            \Think\Log::write('[alipayAppConfirm] verify signature FAIL!', 'INFO');
            return FALSE;
        }
    }


    /**
     * 微信支付回调接口
     */
    public function wxpayConfirm() {
        $post_data = $GLOBALS["HTTP_RAW_POST_DATA"];
        Log::write("[wxpayConfirm] post data:\n".$post_data, Log::INFO);
        echo '<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>';

        Vendor('AppWechatPay.WxPayPubHelper');

        $check_sign_flag = FALSE;
        $notify = new \Notify_pub();
        $notify->saveData($post_data);
        $xml = $notify->getdata();
        if ( !$notify->checkSign() ) {
            $notify->setReturnParameter("return_code", "FAIL");
            $notify->setReturnParameter("return_msg", "签名验证失败");
        } else {
            $check_sign_flag = TRUE;
            $notify->setReturnParameter("return_code", "SUCCESS");
            $notify->setReturnParameter("return_msg", "OK");
        }
        $returnXml = $notify->returnXml();
        Log::write("[wxpayConfirm] return xml:\n".$returnXml, Log::INFO);
        echo $returnXml;
        fastcgi_finish_request();

        if ( $check_sign_flag ) {
            if ( $xml["return_code"] == "SUCCESS" && $xml["result_code"] == "SUCCESS") {
                /* @var \Basic\Service\WxPayService $wxpay_service */
                $wxpay_service = D('Basic/WxPay', 'Service');
                return $wxpay_service->confirmOrder($xml);
            }
        }

        return FALSE;
    }

}