<?php

namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\AuthService;
use Basic\ModelU\CenterModel;
use Admin\Service\PageService;

class ConfigController extends AdminSessionController
{
    public function __construct()
    {
        parent::__construct();

    }

    public function card()
    {
        $curr_page = I('path.2/d', 1);
        $model = new CenterModel('u_card_photo');
        $where = [
            'is_del' => 'N'
        ];
        $list = $model->getListBy($where, "*", "id desc", $curr_page, 12);
        $total = $model->getListTotal($where);
        $page_service = new PageService($total, 12);
        $page_nav = $page_service->show();
        $this->assignAll(array(
            'title' => '名片图片设置',
            'list' => $list,
            'page_nav' => $page_nav
        ));
        $this->display('card');
    }

    public function set()
    {
        $list = (new CenterModel("u_config"))->get(9);

        $this->assignAll(array(
            'title' => '完善资料设置',
            'list' => t_json_decode($list['value']),

        ));
        $this->display('set');
    }

    //教练配置
    public function ability()
    {
        $list = (new CenterModel("u_config"))->get(10);

        $this->assignAll(array(
            'title' => '完善资料设置',
            'list' => t_json_decode($list['value']),

        ));
        $this->display('ability');
    }

    public function abilityScore()
    {
        $list = (new CenterModel("u_config"))->get(11);
        $info = t_json_decode($list['value']);
        $w1 = "point >={$info['a1']} and point <={$info['a2']}";
        $w2 = "point >={$info['a3']} and point <={$info['a4']}";
        $w3 = "point >={$info['a5']} and point <={$info['a6']}";
        $w4 = "point >={$info['a7']} and point <={$info['a8']}";
        $w5 = "point >={$info['a9']} and point <={$info['a10']}";
        $w6 = "point >={$info['a11']} and point <={$info['a12']}";
        $w7 = "point >={$info['a13']} and point <={$info['a14']}";
        $w8 = "point >={$info['a15']} and point <= {$info['a16']}";
        $model = new CenterModel("u_trainer");
        $info = [
            'w1' => $model->getListTotal($w1),
            'w2' => $model->getListTotal($w2),
            'w3' => $model->getListTotal($w3),
            'w4' => $model->getListTotal($w4),
            'w5' => $model->getListTotal($w5),
            'w6' => $model->getListTotal($w6),
            'w7' => $model->getListTotal($w7),
            'w8' => $model->getListTotal($w8),
        ];
        $this->assignAll(array(
            'title' => '完善资料设置',
            'list' => t_json_decode($list['value']),
            'info' => $info,

        ));
        $this->display('abilityScore');
    }

    public function abilityScoreAdd()
    {
        $m = I();
        unset($m["_form_token_"]);
        $model = new CenterModel("u_config");
        $model->update(11, ['value' => t_json_encode($m)]);
        $this->admin_success("ok");
    }

    public function trainerList($mid = '')
    {
        $where = [];
        $fid = $from = $to = "";
        $name = I("name");
        if ($name) {
            $where['name'] = $name;
        }
        if ($mid) {
            list($fid, $from, $to) = explode(",", $mid);
            if ($fid && $from && $to) {
                $where = "point >={$from} and point <={$to}";
            }
        }


        $info = (new CenterModel("u_trainer"))->getListBy($where);
        $this->assignAll(array(
            'title' => '教练' . $fid . '组信息',
            'list' => $info,

        ));
        $this->display('trainer');
    }

    public function trainerDel()
    {
        $id = I("ids");
        if($id){
            (new CenterModel("u_trainer"))->delete($id);
        }
        $this->admin_success();
    }

    public function trainerEdit($id = 0)
    {
        $info = [];
        $title="增加教练";
        if ($id) {
            $title="编辑教练";
            $info = (new CenterModel("u_trainer"))->get($id);
        }
        $this->assignAll(array(
            'title' => $title,
            'list' => $info,

        ));
        $this->display('traineradd');
    }

    public function ajaxDeleteImage(){
        echo '{}';
        exit;
    }

    public function doTrainer()
    {
        $id = I("id");
        $info = [
            'name' => I("name"),
            'pic' => I("identity_photo"),
            'point' => I("point"),
            'content' => I("content"),
            'about' => I("about"),
            'qrcode' => I("identity_photo2")
        ];
        $model = new CenterModel("u_trainer");
        if ($id) {
            $model->update($id, $info);
        } else {
            $model->add($info);
        }
        $this->admin_success("ok");
    }

    public function abilityAdd()
    {
        $m = I();
        unset($m["_form_token_"]);
        $model = new CenterModel("u_config");
        $model->update(10, ['value' => t_json_encode($m)]);
        $this->admin_success("ok");

    }

    public function setAdd()
    {
        $m = I();
        unset($m["_form_token_"]);
        $model = new CenterModel("u_config");
        $model->update(9, ['value' => t_json_encode($m)]);
        $this->admin_success("ok");

    }

    public function version()
    {
        $list = (new CenterModel("u_config"))->getListBy();
        $info = [];
        foreach ($list as $key => $val) {
            $info[$val['name']] = $val['value'];
        }
        $this->assignAll(array(
            'title' => '版本设置',
            'info' => $info,

        ));
        $this->display('version');
    }

    public function addCardPic()
    {
        $model = new CenterModel('u_card_photo');
        if (empty(I("pic"))) {
            $this->ajaxResponse(-1, 'err');
        }
        $model->add(['pic' => I('pic')]);
        $this->ajaxResponse(0, 'ok');
    }

    public function delCardPic()
    {
        $model = new CenterModel('u_card_photo');
        if (empty(I("id"))) {
            $this->ajaxResponse(-1, 'err');
        }
        $model->update(I("id"), ['is_del' => "Y"]);
        $this->ajaxResponse(0, 'ok');
    }

    public function versionEdit()
    {
        $model = new CenterModel("u_config");
        if (I("b_photo_pic")) {
            $info = [
                'value' => I("b_photo_pic"),
            ];
            $model->update(1, $info);
        }
        if (I("name")) {
            $info = [
                'value' => I("name"),
            ];
            $model->update(2, $info);
        }
        if (I("stel")) {
            $info = [
                'value' => I("stel"),
            ];
            $model->update(3, $info);
        }
        if (I("ver")) {
            $info = [
                'value' => I("ver"),
            ];
            $model->update(4, $info);
        }
        if (I("y_photo_pic")) {
            $info = [
                'value' => I("y_photo_pic"),
            ];
            $model->update(5, $info);
        }
        if (I("m_photo_pic")) {
            $info = [
                'value' => I("m_photo_pic"),
            ];
            $model->update(6, $info);
        }
        if (I("v_photo_pic")) {
            $info = [
                'value' => I("v_photo_pic"),
            ];
            $model->update(8, $info);
        }
        if (I("renewals")) {
            $info = [
                'value' => I("renewals"),
            ];
            $model->update(12, $info);
        }
        $this->admin_success("ok");
    }

    //教练编辑
    public function trainer()
    {

    }

}