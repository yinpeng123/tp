<?php
namespace Common\Cnsts;

use Common\Cnsts;

/**
 * 错误码定义
 */
class ERRNO {
    // 系统内置错误码
    const SUCCESS = 0;
    const SYS_NOT_LOGIN = -1;
    const MOBILE_NOT_REG = -2;
    const SYS_RELOGIN = -3;
    const MEMACHINE_NO_NOT_EQ = -99;
    const DB_ERROR = 1;
    const SEND_MSG_FAILED = 2;
    const IMG_CODE_ERROR = 10;
    const SMS_CODE_ERROR = 11;
    const TRY_TO_MOUCH = 12;
    const PHONE_NUM_ERROR = 13;
    const INPUT_PARAM_ERRNO = 14;
    const SQL_UPDATE_ERRNO = 15;
    const SQL_SEARCH_ERRNO = 16;
    const TICKET_ERROR = 17;
    const INPUT_TICKET_ERROR = 18;
    const INPUT_INFO_ERROR = 19;
    const FILE_NOT_EXISTS = 20;
    const PATH_NOT_EXISTS = 21;
    const FILE_TYPE_NOT_SUPPORT = 22;
    const FILE_UPLOAD_ERROR = 23;
    const DATA_NOT_EXISTS = 24;
    const OP_NOT_ALLOW = 25;
    const PAY_ERROR = 26;
    const UPDATE_TICKET_INFO_ERROR = 27;
    const APPLY_TICKET_ERROR = 28;
    const NO_AUTH = 29;
    const USER_DOSE_NOT_EXIST = 30;
    const SMS_SEND_FREQUENT = 31;
    const MOBILE_EXIST = 32;
    const PERSONAL_INFO_ERROR = 33;
    const ACCOUNT_EXIST = 34;
    const PHONE_NOTEXIST = 35;
    const TRUCK_NO_ERROR = 50;
    const PWD_NOT_EQ = 52;
    const PWD_ERRNO = 53;
    const CREATE_PAYMENT_ERROR = 54;
    const SET_PAY_PASSWORD_ERROR = 55;
    const PAY_BY_MONEY_ERROR = 56;
    const BANK_CARD_ERROR = 57;
    const PAY_PASSWORD_ERROR = 58;
    const REQUEST_FREQUENT = 60;
    const IDCARD_EXIST = 61;
    const SOAP_CONNECT_ERROR = 62;
    const DENY_PRIVILEGE = 63;
    const NOT_DENY_PRIVILEGE = 64;

    // 按照模块划分错误码
    const ERRNO_DICTS = [
        // 系统内置错误码
        self::SUCCESS                  => "成功",
        self::DB_ERROR                 => "系统未知错误!",
        self::SYS_NOT_LOGIN            => "用户未登录",
        self::SYS_RELOGIN            => "请重新登录",
        self::IMG_CODE_ERROR           => "图片验证码错误",
        self::SMS_CODE_ERROR           => "短信验证码错误",
        self::TRY_TO_MOUCH             => "重试次数过多",
        self::PHONE_NUM_ERROR          => "手机号码格式错误",
        self::SEND_MSG_FAILED          => "发送短信错误",
        self::INPUT_PARAM_ERRNO        => '参数错误',
        self::SQL_UPDATE_ERRNO         => '数据库更新失败',
        self::SQL_SEARCH_ERRNO         => '数据库查询失败',
        self::TICKET_ERROR             => "发票数据不存在",
        self::INPUT_TICKET_ERROR       => "信息不完整",
        self::INPUT_INFO_ERROR         => "录入信息出错",
        self::FILE_NOT_EXISTS          => '图片不存在',
        self::PATH_NOT_EXISTS          => '图片路径不存在',
        self::FILE_TYPE_NOT_SUPPORT    => '图片格式不正确',
        self::FILE_UPLOAD_ERROR        => '图片上传失败',
        self::DATA_NOT_EXISTS          => '数据不存在',
        self::OP_NOT_ALLOW             => '不允许当前操作',
        self::PAY_ERROR                => '充值错误',
        self::UPDATE_TICKET_INFO_ERROR => '修改开票信息出错',
        self::APPLY_TICKET_ERROR       => '申请发票失败',
        self::NO_AUTH                  => '没有权限',
        self::USER_DOSE_NOT_EXIST      => '用户名或密码错误',
        self::SMS_SEND_FREQUENT        => '短信发送太频繁，请稍后重试',
        self::MOBILE_EXIST              => '该手机号码已注册',
        self::PERSONAL_INFO_ERROR       => '姓名、身份证号必须填写',
        self::ACCOUNT_EXIST             => '账号已经存在，请重新输入',
        self::TRUCK_NO_ERROR            => '车牌号不正确',
        self::MOBILE_NOT_REG            => '该号码尚未注册，请前往注册',
        self::PWD_NOT_EQ                => '两次密码输入不一致，请重新输入',
        self::PWD_ERRNO                 => '密码不正确，请重新输入',
        self::CREATE_PAYMENT_ERROR      => '创建支付订单失败',
        self::SET_PAY_PASSWORD_ERROR    => '设置交易密码失败',
        self::PAY_BY_MONEY_ERROR        => '余额付款失败',
        self::BANK_CARD_ERROR           => '银行卡信息错误',
        self::PAY_PASSWORD_ERROR        => '交易密码错误',
        self::REQUEST_FREQUENT        => '请勿频繁提交请求',
        self::IDCARD_EXIST              => '该身份证号码已被注册',
        self::SOAP_CONNECT_ERROR        => '与服务器连接失败',
        self::DENY_PRIVILEGE             => '禁用权限',
        self::NOT_DENY_PRIVILEGE             => '启用权限',
    ];

    /**
     * 获取错误信息
     *
     * @param[in] $module_name 模块名称
     * @param[in] $errno 模块内错误码
     *
     * @return
     * */
    public static function e($errno) {
        //header("Content-Type:text/html; charset=utf-8");
        if (array_key_exists($errno, self::ERRNO_DICTS)) {
            return self::ERRNO_DICTS[$errno];
        }

        return '不存在的错误码，未知的运行错误！';
    }
}
