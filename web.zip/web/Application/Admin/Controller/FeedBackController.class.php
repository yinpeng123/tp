<?php
namespace Admin\Controller;

use Basic\Cnsts\DICT;
use Basic\Cnsts\POINT;
use Basic\Model\SuggestLogModel;
use Basic\Model\SuggestModel;
use Basic\Service\PageService;
use Basic\Service\UserPointService;
use Common\Cnsts\ERRNO;

class FeedBackController extends AdminSessionController
{
    // 每页显示条数（历史记录）
    private $pageSize;

    public function __construct()
    {
        $this->pageSize = 5;
        parent::__construct();
        if (!\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::ADVERTISE)) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }

    }

    // 列表展示
    public function index()
    {
        $search_account = I('search_account');
        $search_telephone = I('search_telephone');
        $search_style = I('search_style');

        $cond = [];
        if (!empty($search_account)) {
            $cond['user.account'] = ['eq', $search_account];
        }
        if (!empty($search_telephone)) {
            $cond['user.telephone'] = ['eq', $search_telephone];
        }
        if (!empty($search_style)) {
            $cond['suggest.status'] = ['eq', $search_style];
        }
        $cond['suggest.is_delete'] = ['eq', 1]; // 逻辑正常，未删除

        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);

        /** @var SuggestModel $feed_model */
        $feed_model = D('Basic/Suggest', 'Model');
        $list = $feed_model->searchSuggest($cond, $curr_page, $per_page);
//p($list);die;
        $page_service = new \Admin\Service\PageService($list['count'], $per_page);
        $page_nav     = $page_service->show();
//p($list);die;
        $this->assignAll(array(
            'title' => '用户反馈管理',
            'feed_back_style' => DICT::FEED_BACK_STYLE_LIST,
            'feed_back_style_without_all' => DICT::FEED_BACK_STYLE_LIST_WITHOUT_ALL,
            'list' => $list['data'],
            'search_account' => $search_account,
            'search_telephone' => $search_telephone,
            'search_style' => $search_style,
            'page_nav'         => $page_nav,
            'point_list' => POINT::PRESENT_POINT,
        ));
        $this->display('feed_back_index');
    }

    /**
     * 管理员处理反馈
     */
    public function doFeed()
    {
        $data = $_POST;
        /** @var SuggestLogModel $log_model */
        $log_model = D('Basic/SuggestLog', 'Model');
        $add_info = [
            's_id' => $data['sid'],
            'manager_id' => $this->_manager_id,
            'content' => $data['content'],
            'status' => $data['suggest_style'],
            'ctime' => datetime(),
        ];
        $log_model->add($add_info);

        // 同步修改suggest表记录状态
        /** @var SuggestModel $suggest_model */
        $suggest_model = D('Basic/Suggest', 'Model');
        $update_info = [
            'status' => $data['suggest_style'],
            'mtime' => datetime(),
        ];
        $suggest_model->update($data['sid'], $update_info);

        // 赠送积分
        if (!empty($data['present_point'])) {
            $this->presentPoint($data['point'], $data['uid'], $data['sid']);
        }
        redirect(U('feedBack/index/', '', ''));
    }

    /**
     * 历史记录
     */
    public function logList()
    {
        $id = I('id/d');
        $where = ['suggest_log.s_id' => $id];
        $edit_page_key = I('edit_page_key/d', 1);
        $edit_page_key = $edit_page_key <= 1 ? 0 : $edit_page_key - 1;
        /** @var SuggestLogModel $log_model */
        $log_model = D('Basic/SuggestLog', 'Model');
        $notice_sum = $log_model->getListTotal($where);
        $total_page = ceil($notice_sum/$this->pageSize);
        $limit = $edit_page_key * $this->pageSize . "," . $this->pageSize;
        $log_list = $log_model->getLogList($where, $fields = null, $order_by = null, $limit);

        foreach ($log_list as &$v) {
            $v['text'] = DICT::FEED_BACK_STYLE_LIST[$v['status']];
        }
        return $this->ajaxResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), ['log_list' => $log_list, 'edit_page_key' => $edit_page_key + 1, 'total_page' => $total_page,]);
    }

    /**
     * 用户反馈赠送积分
     * @param $point 赠送积分
     * @param $uid
     * @param $sid 反馈记录id
     */
    public function presentPoint($point, $uid, $sid) {
        // 添加积分记录日志
        /** @var UserPointService $user_point_log_service */
        $user_point_log_service = D('Basic/UserPoint', 'Service');
        $log_id = $user_point_log_service->addPointLog($uid, $point, $inout = 1, $type, $sid, $status = 1);

        if (!$log_id) {
            cmm_log2('记录赠送积分流水失败,参数：'.t_json_decode(['uid' => $uid, 'point' => $point, 'certain_id' => $sid]), 'ERRNO');
        }

        // 更新用户积分
        $res = $user_point_log_service->upUserPoint($uid, $log_id);

        if (!$res) {
            cmm_log2('更新用户积分失败,参数：'.t_json_decode(['uid' => $uid, 'point' => $point, 'certain_id' => $sid, 'log_id' => $log_id]), 'ERRNO');
        }

    }

}