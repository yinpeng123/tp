<?php
namespace Admin\Service;

class PageService {
    public $firstRow; // 起始行数
    public $listRows; // 列表每页显示行数
    public $parameter; // 分页跳转时要带的参数
    public $totalRows; // 总行数
    public $totalPages; // 分页总页面数
    public $rollPage = 11; // 分页栏每页显示的页数
    public $num_links = 2; // 当前页左右两侧显示的分页数

    private $p       = 'p'; //分页参数名
    private $url     = ''; //当前链接URL
    private $nowPage = 1;

    // 分页显示定制
    private $config = array(
        'header' => '<span class="rows">共 %TOTAL_ROW% 条记录</span>',
        'prev'   => '上一页',
        'next'   => '下一页',
        'first'  => '1...',
        'last'   => '...%TOTAL_PAGE%',
        'theme'  => '%FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END%',
    );

    /**
     * 架构函数
     * @param array $totalRows  总的记录数
     * @param array $listRows  每页显示记录数
     * @param array $parameter  分页跳转的参数
     */
    public function __construct($totalRows, $listRows = 20, $parameter = array())
    {
        C('VAR_PAGE') && $this->p = C('VAR_PAGE'); //设置分页参数名称
        /* 基础设置 */
        $this->totalRows = $totalRows; //设置总记录数
        $this->listRows  = $listRows; //设置每页显示行数
        $this->parameter = empty($parameter) ? $_GET : $parameter;
        unset($this->parameter[0]); // 下标0是页码

        $this->nowPage   = I('path.2/d', 1);
        $this->nowPage   = $this->nowPage > 0 ? $this->nowPage : 1;
        $this->firstRow  = $this->listRows * ($this->nowPage - 1);
    }

    /**
     * 定制分页链接设置
     * @param string $name  设置名称
     * @param string $value 设置值
     */
    public function setConfig($name, $value)
    {
        if (isset($this->config[$name])) {
            $this->config[$name] = $value;
        }
    }

    /**
     * 生成链接URL
     * @param  integer $page 页码
     * @return string
     */
    private function url($page)
    {
        //return str_replace(urlencode('[PAGE]'), $page, $this->url);
        $u = '';
        if ( $page > 0 )
            $u = $this->url.'/'.$page;
        else
            $u = $this->url;

        if ( !empty($this->parameter) )
            $u .= '?'.http_build_query($this->parameter);

        return $u;
    }

    /**
     * 组装分页链接
     * @return string
     */
    public function show()
    {
        if (0 == $this->totalRows) {
            return '';
        }

        /* 生成URL */
        //$this->parameter[$this->p] = '[PAGE]';
        $this->url                 = U(ACTION_NAME, '', '', TRUE);//$this->parameter);

        /* 计算分页信息 */
        $this->totalPages = ceil($this->totalRows / $this->listRows); //总页数
        if (!empty($this->totalPages) && $this->nowPage > $this->totalPages) {
            $this->nowPage = $this->totalPages;
        }

        if ( $this->totalPages <= 1 )
            return '';

        /* 计算分页临时变量 */
        $now_cool_page      = $this->rollPage / 2;
        $now_cool_page_ceil = ceil($now_cool_page);

        $start	= (($this->nowPage - $this->num_links) > 0) ? $this->nowPage - ($this->num_links - 1) : 1;
        $end	= (($this->nowPage + $this->num_links) < $this->totalPages) ? $this->nowPage + $this->num_links : $this->totalPages;

        // 计算实际显示的链接数
        $min_display_links = $this->num_links*2+1; // 最少显示的分页链接数
        if ( $start == 1 ) { // 实际显示的分页链接数
            $display_links = $end;
        } else {
            $display_links = $end - ($start-1) + 1;
        }
        //printf("start:%d, end:%d, display_links:%d, min_display_links:%d <br>\n", $start, $end, $display_links, $min_display_links);

        // 显示的数字太少，则向前或者先后扩展
        if ( $display_links < $min_display_links ) {
            if ( $this->nowPage < $this->num_links + 1  ) { // 在尾部扩展
                $end = $end + ($min_display_links - $display_links);
                $end = min($end, $this->totalPages);
            } else { // 在头部扩展
                $start = $start - ($min_display_links - $display_links);
                $start = max($start, 1);
            }
        }

        // 如果起始的页码小于等于3,则直接将第1、2页显示出来
        if ( $start > 1 && $start - 1 <= 3 ) {
            $start = 1;
        }
        // 如果结束的页码是倒数第2页,则直接将末页显示出来
        if ( $end == $this->totalPages - 1 ) {
            $end = $this->totalPages;
        }
//    printf("start:%d, end:%d, cur_page:%d, num_pages:%d<br>\n", $start, $end, $this->nowPage, $this->totalPages);
//    printf("base_url:%s, prefix:%s, suffix:%s <br>\n", $base_url, $this->prefix, $this->suffix);

        $output = '';

        // 上一页
        $up_row  = $this->nowPage - 1;
        $up_page = '<div class="btn-group pn_group">'."\n";
        if ( $up_row > 0 ) {
            $up_page .= '<a rel="prev" class="btn btn-default" data-ci-pagination-page="'.$up_row.'" href="' . $this->url($up_row) . '">' . $this->config['prev'] . "</a>\n";
        } else {
            $up_page .= '<a rel="prev" class="btn btn-default disabled" data-ci-pagination-page="0" href="' . $this->url($up_row) . '">' . $this->config['prev'] . "</a>\n";
        }
        $up_page .= "</div>\n";
        $output .= $up_page;

        // 增加显示分页头部区(第1、2页) [edwardlost]
        if ( $start - 1 >= 4 ) {
            $output .= '<div class="btn-group pn_group">'."\n";
            for ( $i = 1; $i <= 2; $i++ ) {
                $output .= '<a class="btn btn-default" data-ci-pagination-page="'.$i.'" href="'. $this->url($i) . '">'.$i."</a>\n";
            }
            $output .= "</div>\n".'<div class="pn_more">...</div>'."\n";
        }

        // 数字连接
        $link_page = '<div class="btn-group pn_group">'."\n";
        for ($i = $start - 1; $i <= $end; $i++) {
            if ( $i <= 0 ) continue;

            if ( $i ==  $this->nowPage ) { // 当前页
                $link_page .= '<a class="btn btn-info curr_page">' . $i . "</a>\n";
            } elseif ( $i == 1 ) { // 第一页
                // First page
                $link_page .= '<a rel="start" class="btn btn-default" data-ci-pagination-page="'.$i.'" href="' . $this->url($i) . '">'.$i."</a>\n";
            } else {
                $link_page .= '<a class="btn btn-default" data-ci-pagination-page="'.$i.'" href="'.$this->url($i).'">'.$i."</a>\n";
            }
        }
        $link_page .= "</div>\n";
        $output .= $link_page;

        // 如果尾部分页链接未显示完则添加"..."
        if ( $end < $this->totalPages ) {
            $output .= '<div class="pn_more">...</div>'."\n";
        }

        // 下一页
        $down_row  = $this->nowPage + 1;
        $down_page = '<div class="btn-group pn_group">'."\n";
        if ( $down_row <= $this->totalPages ) {
            $down_page .= '<a rel="next" class="btn btn-default" data-ci-pagination-page="'.$down_row.'" href="'. $this->url($down_row) . '">' . $this->config['next'] . "</a>\n";
        } else {
            $down_page .= '<a rel="next" class="btn btn-default disabled" data-ci-pagination-page="'.$this->totalPages.'" href="'. $this->url($this->totalPages) . '">' . $this->config['next'] . "</a>\n";
        }
        $down_page .= "</div>\n";
        $output .= $down_page;

        // 跳转到输入框的缺省值
        if ( $this->nowPage < $this->totalPages )
            $page_no = $this->nowPage  ;
        else
            $page_no = $this->nowPage  ;

        $output .= '<div class="pn_goto">到第 <input type="text" id="page_no" name="page_no" value="'.$page_no.'" class="" min="1" max="'.$this->totalPages.'" required="required" style="width:40px;"> ' . '/' . $this->totalPages . ' 页' .
            '，共'. $this->totalRows .'条记录' .
            '<button id="pngotobtn" type="button" class="btn btn-default btn-xs" style="margin-left:8px;">确定</button>';
        $output .= "</div>\n";

        return "<div class=\"pn_bar\">{$output}</div>\n";
    }
}
