<?php
namespace Admin\Controller;
use Admin\Model\ManagerModel;
use Admin\Model\MenuModel;
use Basic\Model\UserModel;
use Basic\Service\UserService;

/**
 * 面向客服呼叫中心的接口
 * User: edward
 * Date: 2017/9/25
 * Time: 下午2:49
 */
class CallCenterApiController extends AdminCommonController {

    //@todo 安全机制
    const SUCCESS = 0;
    const ERRNO = -1;
    const NO_RESULT = 1;
    const NO_AUTH = 401;
    public function __construct() {
        parent::__construct();
    }

    /**
     * 检测是否登录
     */
    protected function _checkIsLogin() {
        if (!session('manager_id')) {
            $this->_twptJsonEncode(401,'请先登录',[]);
            exit();
        }
        return;
    }

    /**
     * 呼叫中心登录
     */
    public function login() {
        $op = I('Op');
        $password = I('Password');
        if (empty($op)) {
            $this->_twptJsonEncode(self::ERRNO,'员工号码不能为空',[]);
            return;
        }
        if (empty($password)) {
            $this->_twptJsonEncode(self::ERRNO,'密码不能未空',[]);
            return;
        }
        /** @var ManagerModel $model */
        $model = D('Admin/Manager','Model');
        $manager = $model->getManagerByWorksn($op);

        if ($manager) {
            if ( !password_verify($password, $manager['password']) ) {
                $this->_twptJsonEncode(self::ERRNO,'密码不正确',[]);
            } else {
                $data = $this->_loginResData($manager);
                session('manager', $manager);
                session('manager_id', $manager['manager_id']);
                session('menu_list', NULL);
                $this->_twptJsonEncode(self::SUCCESS,'登录成功',$data);
            }
        } else {
            $this->_twptJsonEncode(self::NO_RESULT,'没有查到你要找的数据',[]);
        }
        return;
    }

    //json 格式返回
    protected function _twptJsonEncode($code,$msg,$result) {
        echo json_encode(
            [
                'code' => $code,
                'msg' => $msg,
                'result' => $result
            ],JSON_UNESCAPED_UNICODE
        );
        return;
    }

    protected function _loginResData($origin_data){
        $data = [
            'Op' => $origin_data['net_no'] ? : '',
            'Name' => $origin_data['username'] ? : '',
            'Password' => $origin_data['password'] ? : '',
            'Sex' => '',
            'BirthDate' => '',
            'WorkPhone' => $origin_data['username'] ? : '',
            'Fax' => '',
            'Mobile' => '',
            'Email' => $origin_data['email'] ? : '',
            'TypeId' => $origin_data['role_id'] ? : '',
            'LevelId' => '',
        ];
        return $data;
    }

    /**
     * 查询菜单列表
     */
    public function getMenuList() {
        $this->_checkIsLogin();
        $op = I('Op');
        if (empty($op)) {
            $this->_twptJsonEncode(self::ERRNO,'员工号码不能为空',[]);
            return;
        }

        $role_model = D('Role');
        $manager_id = session('manager_id');
        $manager = session('manager');
        $menu_ids = array();
        if ( $manager_id != 1 && $manager['role_id'] ) {
            // 获取角色的权限
            $role_info = $role_model->get($manager['role_id']);
            $privilege_arr = array();
            if ( strlen($role_info['privileges']) > 2 ) {
                $privilege_arr = json_decode($role_info['privileges'], true);
            }

            // 获取权限对应访问的菜单
            $priv_service = D('Privilege', 'Service');
            $menu_ids = $priv_service->getPrivilegeMenuIdList($privilege_arr);
        }
        //print_r($menu_ids);

        $menu_model = D('Menu');
        if ( $manager_id == 1 ) { // 返回所有菜单
            $menu_list = $menu_model->searchMenu();
        } else {
            if ( !empty($menu_ids) ) {
                $menu_list = $menu_model->searchMenu(array('id_list' => $menu_ids));
            } else {
                $menu_list = array();
            }
        }

        $format_menu_list = array_column($menu_list,'name','id');

        $menu = [];
        foreach($menu_list as $value) {
            $menu[] = [
                'MenuId' => $value['id'],
                'Url' => $value['url'] ? $this->getServerHost().'/'.$value['url'] : '',
                'MenuName' => $value['name'] ?  : '',
                'MenuGroupName' => $value['pid'] ? $format_menu_list[$value['pid']] : '',
            ];
        }
        $this->_twptJsonEncode(self::SUCCESS,'success',$menu);
    }

    public function getCustomerInfo() {
        $this->_checkIsLogin();
        $telephone = I('Tele');
        $net_no = (int)I('User');
        if (empty($telephone)&&  empty($net_no)) {
            $this->_twptJsonEncode(self::ERRNO,'电话号码和网员号至少填写一个',[]);
            return;
        }

        if ($telephone && $net_no) {
            $where['_complex'] = [
                'telephone' => $telephone,
                'net_no' => $net_no,
                '_logic' => 'or',
            ];
        } else if($telephone) {
            $where = [
                'telephone' => $telephone,
            ];
        } else if ($net_no) {
            $where = [
                'net_no' => $net_no,
            ];
        } else {
            return;
        }
        /** @var UserService $user_service */
        $user_service = D('Basic/User','Service');
        $users = $user_service->getListBy($where, [], 'id desc', 0, 1);
        if ($users) {
            $data = $this->_customerData($users[0]);
            $this->_twptJsonEncode(self::SUCCESS,'success',$data);
        } else {
            $this->_twptJsonEncode(self::NO_RESULT,'没有查到你要找的数据',[]);
        }
        return;
    }

    protected function _customerData($origin_data) {
        if (!empty($origin_data['member_start_time'])) {
            $ser_limit = $origin_data['member_start_time'].'-'.$origin_data['mem_end_time'];
        } else if (!empty($origin_data['try_mem_start_time'])) {
            $ser_limit = $origin_data['try_mem_start_time'].'-'.$origin_data['try_mem_end_time'];
        } else {
            $ser_limit = '';
        }

        /** @var UserService $user_service */
        $user_service = D('Basic/User','Service');
        $data = [
            'User' => $origin_data['net_no'] ? : '',
            'LoginName' => $origin_data['net_no'] ? : '',
            'Area' => $origin_data['province_name'] ? : '',
            'City' => $origin_data['city_name'] ? : '',
            'InfoCity' => $origin_data['city_name'] ? : '',
            'State' => '',
            'InfoNet' => '',
            'OpCity' => '',
            'Register' => $origin_data['create_time'] ? : '',
            'SerLimit' => $ser_limit,
            'Reserved' => '',
            'Func' => $user_service->getIntersectProduct($origin_data['channel_id'],$origin_data['id'])[1],
            'Tele' => $origin_data['telephone'] ? : '',
            'TelePhone' => $origin_data['telephone'] ? : '',
            'MobileTele' => $origin_data['telephone'] ? : '',
            'CallTele' => $origin_data['telephone'] ? : '',
            'LsCity' => $origin_data['city_name'] ? : '',
            'UserName' => $origin_data['user_name'] ? : '',
            'LinkMan' => $origin_data['user_name'] ? : '',
            'Idcard' => $origin_data['card_num'] ? : '',
            'CoName' => $origin_data['company_name'] ? : '',
            'Addr' => $origin_data['addr'] ? : '',
        ];
        return $data;
    }

    /**
     * 获取呼叫中心需要跳转的模块
     */
    public function getModule() {
        $this->_checkIsLogin();
        $telephone = I('Tele');
        if (empty($telephone)) {
            $this->_twptJsonEncode(self::ERRNO,'电话号码不能为空',[]);
            return;
        }

        $user_model_s = new \Basic\Model\UserModel('slave', TRUE);
        $cond = [
            'telephone' => $telephone,
        ];
        $user_info = $user_model_s->getBy($cond);
        if($user_info) {
            $data = [
                'MenuId' => '1',
                'Url' => $this->getServerHost().'/user/index/'.'?telephone='.$telephone,
                'MenuName' => '查看用户',
                'MenuGroupName' => '用户管理',
            ];
        } else {
            $data = [
                'MenuId' => '2',
                'Url' => $this->getServerHost().'/CSConsultComplain/index?cs_telephone='.$telephone,
                'MenuName' => '新增用户',
                'MenuGroupName' => '用户管理',
            ];
        }
        $this->_twptJsonEncode(self::SUCCESS,'success',$data);
    }

    protected function getServerHost() {
        $server_host = 'http://'.$_SERVER['HTTP_HOST'];
        return $server_host;
    }
}