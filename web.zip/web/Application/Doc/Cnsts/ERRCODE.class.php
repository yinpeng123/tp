<?php
namespace Open\Cnsts;

class ERRCODE {
    
    const SUCCESS           = 0;
    const UNAUTHERIZED_SIGN = 401;
    const UNAUTHERIZED_IP   = 403;
    const AUTHERIZE_TIMEOUT = 405;
    const PARAM_ERROR       = 406;
    const RECORD_ERROR      = 407;
    const DB_ERROR          = 500;


    const ERRMSG = [
        self::SUCCESS           => '成功',
        self::UNAUTHERIZED_SIGN => '授权失败(SIGN)',
        self::UNAUTHERIZED_IP   => '授权失败(IP)',
        self::AUTHERIZE_TIMEOUT => '请求超时',
        self::PARAM_ERROR       => '参数错误',
        self::RECORD_ERROR      => '数据错误',
        self::DB_ERROR          => '添加失败',
    ];

    public static function r($code, $msg = '', $data = null){
        return [
            'code' => $code,
            'msg'  => (self::ERRMSG[$code] ?: '') . $msg,
            'data' => $data,
        ];
    }
}

?>