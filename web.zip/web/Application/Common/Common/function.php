<?php

//use Book\Utils;
use Common\Cnsts\ERRNO;

/**
 * 封装ThinkPHP自带的U函数, 返回带域名的完整url地址。
 * 如果url带有参数, 则需要将参数传入 $params 变量中, 不能直接加到 $uri 后面, 否则无法生成正确的 url
 * @param string    $uri
 * @param string|array    $params
 * @return string
 */
function UU($uri, $params = '') {
    $str_param = is_array($params) ? http_build_query($params) : $params;
    return U($uri, '', false, true) . ($str_param ? '?'.$str_param : '');
}

/**
 * 程序运行日志记录函数
 * @param mixed  $message
 * @param string $level
 * @return boolean
 */
function cmm_log($message, $level = 'debug') {
    if ( strtoupper(MODULE_NAME) == 'ADMIN' ) {
        return admin_cmm_log($message, $level);
    }
    if ( strtoupper(MODULE_NAME) == 'DRIVER' ) {
        return driver_cmm_log($message, $level);
    }

    // 记录Client、Web模块日志
    if (is_array($message)) {
        $message = json_encode($message, JSON_UNESCAPED_UNICODE);
    }

    $user = session('user_info');
    $log_content = [
        round(microtime($get_as_float = true) - I('server.REQUEST_TIME_FLOAT'), 4),
        'uid=' . $user['id'],
        'account=' . $user['account'],
        'telephone=' . $user['telephone'],
        'ip=' . I('server.REMOTE_ADDR'),
        str_replace(' ', '', I('server.HTTP_X_FORWARDED_FOR')),
        PATH_INFO,
        'post=' . json_encode(I('post.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
        'get=' . json_encode(I('get.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
        'refer=' . I('server.HTTP_REFERER', '', 'url'),
        'ua=\'' . I('server.HTTP_USER_AGENT') . '\'',
        'cookie=' . json_encode($_COOKIE),
        'sid=' . session_id(),
        'rid=' . $_REQUEST['request_id'],
//        'message=' . $message,
    ];
    Think\Log::write(implode(' ', $log_content).' | '.$message, strtoupper($level));
}

/**
 * Admin模块日志记录函数
 * @param mixed  $message
 * @param string $level
 * @return boolean
 */
function admin_cmm_log($message, $level = 'debug') {
    if (is_array($message)) {
        $message = json_encode($message, JSON_UNESCAPED_UNICODE);
    }

    $manager = session('manager');
    $log_content = [
        //round(microtime($get_as_float = true) - I('server.REQUEST_TIME_FLOAT'), 4),
        'manager_id=' . $manager['manager_id'],
        'role_id=' . $manager['role_id'],
        'agent_id=' . $manager['agent_id'],
        'ip=' . I('server.REMOTE_ADDR'),
        str_replace(' ', '', I('server.HTTP_X_FORWARDED_FOR')),
        PATH_INFO,
        'post=' . json_encode(I('post.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
        'get=' . json_encode(I('get.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
        'refer=' . I('server.HTTP_REFERER', '', 'url'),
        'ua=\'' . I('server.HTTP_USER_AGENT') . '\'',
        'cookie=' . json_encode($_COOKIE),
        'sid=' . session_id(),
        'rid=' . $_REQUEST['request_id'],
        //'message=' . $message,
    ];

    Think\Log::write(implode(' ', $log_content).' | '.$message, strtoupper($level));
    return TRUE;
}

/**
 * Driver模块日志记录函数
 * @param mixed  $message
 * @param string $level
 * @return boolean
 */
function driver_cmm_log($message, $level = 'debug') {
    if (is_array($message)) {
        $message = json_encode($message, JSON_UNESCAPED_UNICODE);
    }

    $driver = session('driver_info');
    $log_content = [
        //round(microtime($get_as_float = true) - I('server.REQUEST_TIME_FLOAT'), 4),
        'driver_id=' . $driver['id'],
        'mobile=' . $driver['mobile'],
        'ip=' . I('server.REMOTE_ADDR'),
        str_replace(' ', '', I('server.HTTP_X_FORWARDED_FOR')),
        PATH_INFO,
        'post=' . json_encode(I('post.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
        'get=' . json_encode(I('get.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
        'refer=' . I('server.HTTP_REFERER', '', 'url'),
        'ua=\'' . I('server.HTTP_USER_AGENT') . '\'',
        'cookie=' . json_encode($_COOKIE),
        'sid=' . session_id(),
        'rid=' . $_REQUEST['request_id'],
        //'message=' . $message,
    ];

    Think\Log::write(implode(' ', $log_content).' | '.$message, strtoupper($level));
    return TRUE;
}



// 清爽版日志记录
function cmm_log2($message, $level = 'debug') {
    if (is_array($message)) {
        $message = json_encode($message, JSON_UNESCAPED_UNICODE);
    }
    Think\Log::write($message, strtoupper($level));
}

/**
 * 以json"友好"格式打印$var变量值
 * @param $var
 */
function jdump($var) {
    header('Content-Type: application/json');
    echo json_encode($var, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
}

/**
 * 计算两坐标点距离公式
 * param:$s= array(116.350506,39.843706) $e=array(116.350506,39.843706),
 */
function calc_distance($s, $e) {
    //地球半径
    $r = 6378137;
    //经度
    $lat1 = $s[1] * pi() / 180;
    $lat2 = $e[1] * pi() / 180;
    $a = $lat1 - $lat2;
    $b = ($s[0] - $e[0]) * pi() / 180;
    $sa2 = sin($a / 2);
    $sb2 = sin($b / 2);
    $distance = 2 * $r * asin(sqrt($sa2 * $sa2 + cos($lat1) * cos($lat2) * $sb2 * $sb2));
    return $distance;
}

// 返回文件名的后缀
function get_file_ext($name) {
    return substr(strrchr($name, '.'), 1);
}

/**
 * 获取上传图片或者文件的详细信息, 注: 图片和非图片文件返回的字段不完全一致
 *
 * @param string    $type 图片应用的业务类型 如车辆 签收 电子回单
 * @param string    $sub_path  图片保存的子目录
 * @param string    $name  图片的名称
 * @param array     $image_info 保存上传图片或文件的详细信息
 *
 * @return int      错误代码
 */
function getImage($type, $sub_path, $name, &$image_info) {
    $root_path = C('IMAGE_PATH')[$type];
    $full_path = $root_path . "/" . $sub_path . "/" . $name;
    $full_path = realpath($full_path);

    if ($full_path === false) {
        return ERRNO::FILE_NOT_EXISTS;
    }


    if (!file_exists($full_path)) {
        return ERRNO::PATH_NOT_EXISTS;
    }

    $ext = substr(strrchr($name, '.'), 1);
    if ( is_file_image($ext) ) { // 图片
        $image = getimagesize($full_path);
        if ($image === false) {
            return ERRNO::FILE_TYPE_NOT_SUPPORT;
        }

        $mime = image_type_to_mime_type($image[2]);
        $file_type = substr(strstr($mime, '/'), 1);

        $image_info = [
            'file_type' => $file_type,
            'full_path' => $full_path,
            'width'     => $image[0],
            'height'    => $image[1],
            'size'      => filesize($full_path),
        ];

    } else { // 非图片
        $image_info = [
            'file_type' => $ext,
            'full_path' => $full_path,
            'size'      => filesize($full_path),
        ];
    }

    return ERRNO::SUCCESS;
}

// 生成上传图片的名称
function gen_upload_image_name($key) {
    return $key.'_'.uniqid();
}

/**
 * 上传单张图片
 *
 * @param string $file_key 表单输入框名称
 * @param string $root_path 图片保存的根目录
 * @param string $sub_path  图片保存的子目录
 * @param array $image_info 包括name和path
 * @param string $key
 * return ERRNO
 */
function uploadImage($file_key, $root_path, $sub_path, &$image_info, $key) {
    $files = $_FILES;
    $upload = new \Think\Upload(); // 实例化上传类
    $upload->maxSize = 5 * 1024 * 1024; // 设置附件总上传大小, 对于多文件上传来说，是所有附件之和 1 * 1MB
    $upload->exts = array('jpg', 'gif', 'png', 'jpeg'); // 设置附件上传类型
    $upload->rootPath = $root_path; // 设置附件上传根目录
    $upload->autoSub = true; // 开启子目录保存
    $upload->replace = true;

    $upload->saveName = gen_upload_image_name($key); // 上传文件名
    $file_ext = explode('/', $files[$file_key]['type']);
    $upload->saveExt = isset($file_ext[1]) ? $file_ext[1] : '';

    $upload->subName = "" . $sub_path;

    $info_raw = $upload->uploadOne($files[$file_key]);
    $err_msg = $upload->getError();
    if ($err_msg) {
        \Think\Log::write('图片上传失败:'.$err_msg);
        return [ERRNO::FILE_UPLOAD_ERROR, ERRNO::e(ERRNO::FILE_UPLOAD_ERROR).$err_msg, []];
    }

    if ($info_raw) {
        $image_info = [
            'name' => $info_raw['savename'],
            'path' => $sub_path,
            'type' => $key,
        ];
    }
    return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), []];
}

function uploadFile($file_key, $root_path, $sub_path, &$file_info, $key) {
    $files = $_FILES;
    $upload = new \Think\Upload(); // 实例化上传类
    $upload->maxSize = 5 * 1024 * 1024; // 设置附件总上传大小, 对于多文件上传来说，是所有附件之和 1 * 1MB
    $upload->rootPath = $root_path; // 设置附件上传根目录
    $upload->autoSub = true; // 开启子目录保存
    $upload->replace = true;

    $upload->saveName = gen_upload_image_name($key); // 上传文件名
    $upload->subName = "" . $sub_path;

    $info_raw = $upload->uploadOne($files[$file_key]);
    $err_msg = $upload->getError();
    if ($err_msg) {
        \Think\Log::write('文件上传失败:'.$err_msg);
        return [ERRNO::FILE_UPLOAD_ERROR, ERRNO::e(ERRNO::FILE_UPLOAD_ERROR).$err_msg, []];
    }

    if ($info_raw) {
        $file_info = [
            'name' => $info_raw['savename'],
            'path' => $sub_path,
            'type' => $key,
        ];
    }

    return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), []];
}

function getFile($type, $sub_path, $name, &$file_info) {
    $root_path = C('FILE_PATH')[$type];
    $full_path = $root_path . "/" . $sub_path . "/" . $name;
    $full_path = realpath($full_path);
    if ($full_path === false) {
        return ERRNO::FILE_NOT_EXISTS;
    }

    $base_dir = dirname(dirname($full_path));
    $exp_base_dir = realpath($root_path);
    if (!file_exists($full_path)) {
        return ERRNO::FILE_NOT_EXISTS;
    }
    if ($base_dir != $exp_base_dir) {
        return ERRNO::PATH_NOT_EXISTS;
    }
    $file = fopen($full_path,"r");
    if ($file) {
        $file_info = [
            'file_type' => substr(strrchr($name, '.'), 1),
            'full_path' => $full_path,
            'size'      => filesize($full_path),
            'file'      => $file,
        ];
    }

    return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), []];
}

/**
 * 批量上传图片
 *
 * @param string $file_key 表单输入框名称
 * @param string $root_path 图片保存的根目录
 * @param string $sub_path  图片保存的子目录
 * @param array $image_info 包括name和path
 * @param string $key
 * return ERRNO
 */
function uploadImageMulti($file_key, $root_path, $sub_path, &$image_info, $key) {
    if ( empty($_FILES[$file_key]) ) {
        return [ERRNO::INPUT_PARAM_ERRNO, ERRNO::e(ERRNO::INPUT_PARAM_ERRNO), []];
    }

    $files = [$file_key => $_FILES[$file_key]]; // 只处理指定的图片上传框数据
    //print_r($files);
    $upload = new \Think\Upload(); // 实例化上传类
    $upload->maxSize = max(count($files[$file_key]), 1) * 1024 * 1024; // 设置附件总上传大小, 对于多文件上传来说，是所有附件之和 3 * 500K
    $upload->exts = array('jpg', 'gif', 'png', 'jpeg'); // 设置附件上传类型
    $upload->rootPath = $root_path; // 设置附件上传根目录
    $upload->autoSub = true; // 开启子目录保存
    $upload->replace = true;

    $upload->saveName = array('gen_upload_image_name', $key);
    $upload->subName = $sub_path;
    $info_raw = $upload->upload($files);
    //print_r($info_raw);exit;
    if ( !$info_raw ) {
        \Think\Log::write('图片上传失败: ' . $upload->getError());
        return [ERRNO::FILE_UPLOAD_ERROR, ERRNO::e(ERRNO::FILE_UPLOAD_ERROR), []];
    }

    foreach ( $info_raw as $v ) {
        $item = [
            'name'      => $v['savename'],
            'path'      => $sub_path,
            'type'      => $key,
        ];
        $image_info[] = $item;
    }

    return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), []];
}

/**
 * 获取图片在本地存储的路径
 */
function imageFilePath($image_info) {
    $root_path = C('IMAGE_PATH')[$image_info['type']];
    return realpath( $root_path . "/" . $image_info['path'] . "/" . $image_info['name'] );
}

/**
 * 生成图片或文件的外部访问url地址
 * @param array $image_info 上传图片返回的图片信息
 * @return string
 */
function imageUrl($image_info) {
    if ( empty($image_info) ) {
        return '';
    } else {
        return sprintf("http://%s/basic/image/view/%s/%s/%s", $_SERVER['HTTP_HOST'], $image_info['type'], $image_info['path'], $image_info['name']);
    }
}

function imageUrlToArray($url) {
    $image_info = [];
    if ($url) {
        $arr = explode('/',$url);
        $len = count($arr);
        $image_info = [
            'name' => $arr[$len-1],
            'path' => $arr[$len-2],
            'type' => $arr[$len-3],
        ];
    }
    return $image_info;
}

function datetime($ts = 0) {
    if (empty($ts)) $ts = time();
    return date("Y-m-d H:i:s", $ts);
}
function datetimeI($ts = 0) {
    if (empty($ts)) $ts = time();
    return date("Y-m-d H:i", $ts);
}
function day($ts = 0) {
    if (empty($ts)) $ts = time();
    return date("Y-m-d", $ts);
}

// 判断日期值是否为空
function is_null_datetime($dt) {
    return empty($dt) || $dt == '0000-00-00' || $dt == '0000-00-00 00:00:00' ? TRUE : FALSE;
}

function date_time_to_day($date_time) {
    if ( !is_null_datetime($date_time) ) {
        $day = date('Y-m-d', strtotime($date_time));
    } else {
        $day = '';
    }
    return $day;
}
function is_work_sn($sn) {
    return preg_match("/^\d{3,}$/", $sn);
}



//是否为固话,且不能为手机号
function is_fixed_phone($phone) {
    if (is_phone($phone) && !is_mobile($phone)) {
        return true;
    } else {
        return false;
    }
}

function is_qq($qq) {
    return preg_match("/^\d{5,}$/", $qq);
}

function is_email($email) {
    return strlen($email) > 6 && preg_match("/^[\w\-\.]+@[\w\-\.]+(\.\w+)+$/", $email);
}

function is_url($url) {
    return preg_match("/^(https?|ftp|file):\/\//i", $url);
}

// 判断身份证号格式是否正确
function is_identity_number($number) {
    return preg_match("/^(\d{15}$|^\d{18}$|^\d{17}(\d|X|x))$/", $number);
}

// 判断是否网号
function is_net_no($no) {
    return preg_match("/^\d{6}$/", $no);
}

function is_phone($phone) {
    return strlen($phone) > 6 && preg_match("/^([\d\-\+]+)$/", $phone);
}

function is_mobile($mobile) {
    return preg_match("/^(0|86)?1[0-9]{10}$/", $mobile);
}

/**
 * 检查是否为手机号码
 * @return boolean
 */
function is_mobilephone($mobilephone) {
    if (preg_match("/^((\(\d{2,3}\))|(\d{3}\-))?1[3,4,5,7,8]\d{9}$/", $mobilephone)) {
        return true;
    }
    return false;
}

//是否为联系电话 手机号或者电话
function is_linkphone($phone) {
    if ( preg_match("/^(\d{3,4}-)?\d{7,8}$/", $phone) || preg_match("/^(\d{3,4})?\d{7,8}$/", $phone) || is_mobilephone($phone) ) {
        return true;
    }
    return false;
}

/**
 * @param $card_num
 *
 * @return bool
 * 检测是否为身份证号
 */
function is_card_num($card_num) {

    $len = strlen($card_num);
    if($len != 18) {
        return false;
    }

//    if ( APP_DEBUG ) {
//        return true;
//    }
    $a=str_split($card_num,1);
    $w=array(7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2);
    $c=array(1,0,'X',9,8,7,6,5,4,3,2);
    $sum = 0;
    for($i=0;$i<17;$i++){
        $sum= $sum + $a[$i]*$w[$i];
    }
    $r=$sum%11;
    $res=$c[$r];
    //echo "校验位是: ".$res;
    if ($res == strtoupper($a[17])) {
        return true;
    } else {
        return false;
    }
}

/**
 * @param $car_num
 * @return bool
 * 检测是否为车牌号
 */
function is_car_num($car_num) {
    if (preg_match("/^(京|津|渝|沪|冀|晋|辽|吉|黑|苏|浙|皖|闽|赣|鲁|豫|鄂|湘|粤|琼|川|贵|云|陕|秦|甘|陇|青|台|蒙|桂|宁|新|藏|澳|军|海|航|警)[a-zA-Z][0-9a-zA-Z]{5}$/", $car_num)) {
        return true;
    }
    return false;
}

// 验证银行卡卡号格式是否正确(弱验证)
function is_bank_card_no($no) {
    // 不低于16位数字, 第1位不能为0
    return preg_match("/^([1-9]{1})(\d{15,})$/", $no) ? TRUE : FALSE;
}
//检查是否是图片格式
function is_photo($photo) {
    if ( is_array($photo) && !empty($photo) ) {
        return true;
    } else {
        return false;
    }
}

// 根据文件后缀名判断是否图片
function is_file_image($ext) {
    return in_array($ext, ['jpg', 'gif', 'png', 'jpeg']);
}

/**
 * 含中文字符的字符串长度，一个中文字符算2个字符
 */
function cnstrlen($str) {
    $rstr = preg_replace('/[\x{4e00}-\x{9fa5}]/su', "**", $str);
    return strlen($rstr);
}

/**
 * 计算指定月份的天数
 * @param int  $year 年份
 * @param int  $month 月份
 *
 * @return int
 */
function cal_days_of_month($year, $month) {
    return date('t', mktime(0, 0, 0, $month+1, 1, $year) - 60);
}

// 后台运行程序记录日志, 默认输出到终端
function daemon_log($format, ...$args) {
    $str = vsprintf($format, $args);
    printf("[%s] %s\n", datetime(), $str);
}

function before_now($create_time) {
    $create_time = strtotime($create_time);
    $time = time();
    $diff_times = $time - $create_time;
    if ($diff_times < 60) {
        $before_now = '刚刚';
    } else if ($diff_times < 60 * 60) {
        $before_now = (int) ($diff_times/60);
        $before_now .= '分钟前';
    } else if ($diff_times < 60 * 60 * 24) {
        $before_now = (int) ($diff_times/(60 * 60));
        $before_now .= '小时前';
    } else  {
        $before_now = (int) ($diff_times/(60 * 60 * 24));
        $before_now .= '天前';
    }
    return $before_now;
}

// for test
function __check_password($pwd) {
    echo "__check_password() called! $pwd\n";
    return preg_match('/^\w{6}$/', $pwd) ? TRUE: FALSE;
}

/**
 * @param $url
 * @param null $params
 * @param string $method
 * @param int $max_retry
 * @return array|mixed
 */
function request($url, $params = null, $method = 'GET', $max_retry = 3)
{
    if (!function_exists('urlGetContents')) {
        function urlGetContents($url, $params, $method)
        {
            if (!in_array($method, ['GET', 'POST'])) {
                return [
                    'errno'   => 1001,
                    'message' => __FUNCTION__ . ": Unknown method '$method'",
                ];
            }
            if ($method == 'GET') {
                if (is_array($params) && count($params) > 0) {
                    if ($params === array_values($params)) {
                        return [
                            'errno'   => 1002,
                            'message' => __FUNCTION__ . ": Numerical array recieved for argument '\$params' (assoc array expected)",
                        ];
                    } else {
                        $url .= '?' . http_build_query($params);
                    }
                } elseif (!is_null($params)) {
                    return [
                        'errno'   => 1003,
                        'message' => __FUNCTION__ . ": If you're making a GET request, argument \$params must be null or assoc array.",
                    ];
                }
            }
            $ch = curl_init($url);
            curl_setopt_array(
                $ch,
                [
                    CURLOPT_HEADER         => false,
                    CURLOPT_RETURNTRANSFER => true,
                ]
            );
            if ($method == 'POST') {
                curl_setopt($ch, CURLOPT_POST, true);
                if (is_string($params)) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
                } elseif (is_array($params)) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
                } else {
                    return [
                        'errno'   => 1004,
                        'message' => __FUNCTION__ . ": Argument \$params should be an array of parameters or (if you want to send raw data) a string",
                    ];
                }
            }
            $contents  = curl_exec($ch);
            $errno     = curl_errno($ch);
            $message   = curl_error($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if (!$errno) {
                if ($http_code >= 400) {
                    $errno = 1000 + $http_code;
                } else {
                    //dump($contents);
                    $rspns = @json_decode($contents, true);
                    if ($rspns === null && json_last_error() !== JSON_ERROR_NONE) {
                        return [
                            'errno'   => 1015,
                            //                        'message' => 'json decode error.',
                            'message' => $contents,
                        ];
                    } else {
                        return $rspns;
                    }
                }
            }

            return [
                'errno'   => $errno,
                'message' => $message,
                'data'    => $contents,
            ];
        }
    }

    $retry = 1;
    $rspns = urlGetContents($url, $params, $method);
    while ($retry < $max_retry && $rspns['errno']) {
        $retry += 1;
        $rspns = urlGetContents($url, $params, $method);
    }

    return $rspns;
}

/** web socket notify
 * @param $targets
 * @param $content
 * @return array|mixed
 */
function ws_notify($targets, $content, $type = 'publish')
{
    $TARGET_ALL = '_ALL_';

    $ws_servers = C('WSS');
    if (is_array($content)) {
        $content = json_encode($content,JSON_UNESCAPED_UNICODE);
    }
    $post_data = [
        'type'    => $type,
        'content' => $content,
        'to'      => null,
    ];
    if (!is_array($targets) and $targets !== $TARGET_ALL) {
        $targets = [$targets];
    }
    $result = [];
    if (is_array($targets)) {
//        $targets = array_unique(array_diff(array_map('intval', $targets), [0]));
        if ($targets) {
            // chunk by ws server index
            $targets_chunk   = [];
            $ws_server_count = count($ws_servers);
            foreach ($targets as $target) {
                $targets_chunk[$target % $ws_server_count][] = $target;
            }
            foreach ($targets_chunk as $index => $chunk) {
                $url = $ws_servers[$index]['be'];
                if ($chunk) {
                    $target          = implode(',', $chunk);
                    $post_data['to'] = $target;
                    $sub_result      = request($url, $post_data, 'POST');
                    if ($sub_result['errno'] == 0) {
                        $result = array_merge($result, $sub_result);
                    }
                }
            }
        }
    } elseif ($targets === $TARGET_ALL) {
        foreach ($ws_servers as $ws_server) {
            $url        = $ws_server['be'];
            $sub_result = request($url, $post_data, 'POST');
            if ($sub_result['errno'] == 0) {
                $result = array_merge($result, $sub_result);
            }
        }
    }
    return $result;
}

/**
 * @param $files
 * array('/local/storage/twpt_test/certificate/2017-09-05/')
 */
function zip_file($files) {
    $zip = new \ZipArchive;
    //压缩文件名
    $root_dir = C('DOWNLOAD_PATH')['download'];
    if (!file_exists($root_dir)) {
        mkdir($root_dir);
    }
    $filename =$root_dir.'/'.uniqid().'_download.zip';
        //新建zip压缩包
    $open = $zip->open($filename,\ZipArchive::CREATE |\ZipArchive::OVERWRITE);
    if ($open !== true) {
        die('打开文件失败!');
    }

    foreach($files as $v) {
        if (file_exists($v)) {
            $ad_res = $zip->addFile($v,basename($v));
            !$ad_res ? die('添加文件失败') : '';
        }
    }
    //打包zip
    $c_res = $zip->close();
    !$c_res ? '打包文件失败' : '';
    //下载
    header("Cache-Control: public");
    header("Content-Description: File Transfer");
    header('Content-disposition: attachment; filename='.basename($filename)); //文件名
    header("Content-Type: application/force-download");
    header("Content-Transfer-Encoding: binary");
    header('Content-Length: '. filesize($filename)); //告诉浏览器，文件大小
    readfile($filename);
}

function cmm_exit($content = '')
{
    // todo: add hook
    tag('app_end');
    header("Content-Type: application/json; charset=utf-8");
    exit($content);
}

//判断是否是AJAX 请求
function is_ajax() {
    $ajax = (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) ==
        'xmlhttprequest') || !empty($_POST[C('VAR_AJAX_SUBMIT')]) || !empty($_GET[C('VAR_AJAX_SUBMIT')]) ?
        true : false;
    return $ajax;
}

function is_online_stage() {
    return in_array(APOLLO_ENV_STAGE, ['prod', 'gamma']);
}

// 将UTF-8编码字符串转换成GB2312
function conv_to_gb2312($str) {
    return iconv('utf-8', 'gb2312//IGNORE', $str);
}


function t_json_decode($content) {
    if (empty($content)) {
        $json_content = null;
    }else {
        if ( is_array($content) ) {
            $json_content = $content;
        } else {
            $content = json_decode($content ,true);
            $json_content = !empty($content) ? $content : null;
        }
    }
    return $json_content;
}

function t_json_encode($array) {
    if (empty($array)) {
        $json_content = NULL;
    } else {
        $json_content = json_encode($array, JSON_UNESCAPED_UNICODE);
    }
    return $json_content;
}

/**
 * 避免日志Notice错误
 */
function avoidNotice($content, $default = null) {
    if (!empty($content)) {
        return $content;
    } else {
        return $default;
    }
}

/**
 * @param $num1
 * @param $num2
 *
 * @return int
 * 与strcmp 类似比较两个数组
 */
function numcmp($num1, $num2) {
    if ( $num1 < $num2) {
        return -1;
    } else if ($num1 > $num2) {
        return 1;
    } else {
        return 0;
    }
}

/**
 * @param        $tow_dime_array 二维数组
 * @param        $sort_filed 排序的字段
 * @param string $sort_type 排序类型  asc  desc
 *
 * @return mixed
 * @throws Exception
 * 物流之家二维数组排序
 */
function t_multisort(&$tow_dime_array, $sort_filed, $sort_type = 'asc') {
    $count = count($tow_dime_array);
    $first_array = $tow_dime_array[0];
    if( !is_array($first_array) ) {
        return false;
    }
    if ( !isset($first_array[$sort_filed]) ) {
        return false;
    }
    if ($count < 2) {
        return true;
    }
    if ( is_numeric($first_array[$sort_filed]) ) {
        $sort_func = 'numcmp';
    } else {
        $sort_func = 'strcmp';
    }
    if ( $sort_type == 'asc' ) {
        usort($tow_dime_array, function($x, $y) use($sort_filed,$sort_func) {
            return $sort_func($x[$sort_filed], $y[$sort_filed]);
        });
    } else {
        usort($tow_dime_array, function($x, $y) use($sort_filed, $sort_func) {
            return $sort_func($y[$sort_filed], $x[$sort_filed]);
        });
    }
    return true;
}

//返回以数组中的以某个键为结构的数组
function t_array_columns($array, $index_key, $columns = []) {
    $len = count($array);
    if ($len == 0 ) {
        return [];
    }
    if (!is_array($array) || !is_array($array[0])) {
        return [];
    }

    $keys = array_keys($array[0]);
    if ( $index_key && !in_array($index_key, $keys) ) {
        return [];
    }
    if ( $index_key && !in_array($index_key, $keys) ) {
        return [];
    }
    $tmp_arr = [];
    if ( $columns ) {
        $arr_diff = array_diff($columns, $keys);
        if ( $arr_diff ) {
            return [];
        }
        foreach($array as $k => $v) {
            $tmp = [];
            foreach ($columns as $ck => $cv) {
                $tmp[$cv] = $v[$cv];
            }
            if ( $index_key ) {
                $index = $v[$index_key];
                $tmp_arr[$index] = $tmp;
            } else {
                $tmp_arr[] = $tmp;
            }
        }
    } else {
        foreach($array as $k => $v) {
            if ( $index_key ) {
                $index = $v[$index_key];
                $tmp_arr[$index] = $v;
            } else {
                $tmp_arr[] = $v;
            }
        }
    }

    return $tmp_arr;
}