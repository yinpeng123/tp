<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\PageService;

class LoginLogController extends AdminSessionController {

    private $__log_model = NULL;

    public function __construct() {
        parent::__construct();

        // 权限检查
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::HISTORY_LOG) ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }

        $this->__log_model = D('LoginLog');
    }

    /**
     * 操作列表
     */
    public function index() {
        $manager_model = D('Manager');

        $search_name = I('search_username');
        $search_manager_id = 0;
        if ( $search_name ) {
            $manager = $manager_model->getManagerByUsername($search_name);
            if ( $manager ) {
                $search_manager_id = $manager['manager_id'];
            }
        }

        if ( empty($search_name) || $search_manager_id > 0 ) {
            $per_page = C('TABLE_PER_PAGE');
            $curr_page = I('path.2/d', 1);

            $cond = $search_manager_id ? array('username' => $search_name) : array();
            $ret = $this->__log_model->searchLog($cond, $curr_page, $per_page);


            foreach ( $ret['data'] as $i => &$r ) {
                $r['manager_name'] = $manager['username'];
            }

            $page_service = new PageService($ret['count'], $per_page);
            $page_nav = $page_service->show();
            //echo $page_nav;

            $this->assignAll(['list' => $ret['data'], 'page_nav' => $page_nav]);
        } else {
            $this->assignAll(['list' => array(), 'page_nav' => '']);
        }

        $this->assignAll(array(
            'title'         => '登录日志',
            'search_name'   => $search_name,
        ));
        $this->display('login_log_list');
    }

}