<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;

class ProductController extends AdminSessionController {

    public function __construct() {
        parent::__construct();
    }

    /**
     * 菜单列表
     */
    public function index() {
        $product_model = D('Basic/Product');
        $list = $product_model->getAllProductList(); // 显示全部产品功能力列表
        //print_r($list);exit;

        $this->assignAll(array(
            'title'   => '产品功能列表',
            'list'    => $list,
        ));
        $this->display('product_list');
    }

    /**
     * 获取返回列表的链接
     * @param $refer
     */
    protected function _backToListUrl($refer) {
        if ( !empty($refer) && 0 === strpos($refer, U('menu/index', '', '', TRUE)) ) {
            return $refer;
        } else {
            return U('menu/index', '', '', TRUE);
        }
    }




}