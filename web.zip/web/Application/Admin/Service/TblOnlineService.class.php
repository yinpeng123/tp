<?php
namespace Admin\Service;

class TblOnlineService {

    public function getOtherProgram($wl_id) {
        $m = M('wl_tblonline');
        $where = [
            'intUserId' => $wl_id,
        ];
        $field = [
            'charOtherProgram',
        ];

        $program =  $m->field($field)->where($where)->find();
        if ( $program ) {
            $program_s = trim($program['charOtherProgram'],'RunProces:');
            $other_program = explode(' ',$program_s);
            $other_program = $other_program ? : [];
        } else {
            $other_program = [];
        }
        return $other_program;
    }
}