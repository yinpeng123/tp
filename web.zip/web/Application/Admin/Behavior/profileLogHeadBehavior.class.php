<?php
namespace Admin\Behavior;

use Think\Behavior;
use Think\Log;

class profileLogHeadBehavior extends Behavior
{
    // 行为扩展的执行入口必须是run
    public function run(&$params)
    {
        $manager = session('manager');
        $log_content   = [
            'manager_id=' . $manager['manager_id'],
            'role_id=' . $manager['role_id'],
            'agent_id=' . $manager['agent_id'],
            'ip=' . I('server.REMOTE_ADDR'),
            str_replace(' ', '', I('server.HTTP_X_FORWARDED_FOR')),
            PATH_INFO,
            'post=' . json_encode(I('post.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
            'get=' . json_encode(I('get.', '', 'htmlspecialchars_decode'), JSON_UNESCAPED_UNICODE),
            'refer=' . I('server.HTTP_REFERER', '', 'url'),
            'ua=\'' . I('server.HTTP_USER_AGENT') . '\'',
            'cookie=' . json_encode($_COOKIE),
            'sid=' . session_id(),
            'rid=' . $_REQUEST['request_id'],
        ];
//        $shape_shifter = session('shape_shifter');
//        if ($shape_shifter) {
//            $log_content[] = 'shape_shifter=' . $shape_shifter;
//        }
//        $company_group = session('company_group');
//        if ($company_group) {
//            $log_content[] = 'company_group=' . $company_group;
//        }
        Log::write(implode(' ', $log_content), 'PROFILE_HEAD');
    }
}

