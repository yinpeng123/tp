<?php
namespace Admin\Controller;

use \Basic\Cnsts\DICT;
use Basic\Model\StatsOilCardModel;
use Basic\Model\UserOnlineLogModel;

class StatsController extends AdminSessionController {

    private $__stats_service = NULL;

    public function __construct() {
        parent::__construct();

        $this->__stats_service = D('Basic/Stats', 'Service');
    }


    /**
     * 用户数统计
     */
    public function statsUser() {
        //        // 权限检查
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::STATS_USER) ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }

        $stats = $this->__stats_service->statsUser(); // 生成当前实时数据

        // 计算比例
        if ( $stats['user_num'] > 0 ) {
            $stats['truck_owner_ratio'] = sprintf("%.2f", $stats['truck_owner_num']*100 / $stats['user_num']);
            $stats['goods_owner_ratio'] = sprintf("%.2f", $stats['goods_owner_num']*100 / $stats['user_num']);
            $stats['both_ratio'] = sprintf("%.2f", $stats['both_num']*100 / $stats['user_num']);
        }

        // 较上年增长
        $stats_user_model = M('stats_user');
        $prev_stats = $stats_user_model->where(['year' => date('Y')-1])->find();
        if ( !empty($prev_stats) ) {
            if ( $prev_stats['truck_owner_num'] > 0 ) {
                $stats['truck_owner_growth_ratio'] = sprintf("%.2f", ($stats['truck_owner_num'] - $prev_stats['truck_owner_num'])*100 / $prev_stats['truck_owner_num']);
            }

            if ( $prev_stats['goods_owner_num'] > 0 ) {
                $stats['goods_owner_growth_ratio'] = sprintf("%.2f", ($stats['goods_owner_num'] - $prev_stats['goods_owner_num'])*100 / $prev_stats['goods_owner_num']);
            }

            if ( $prev_stats['both_num'] > 0 ) {
                $stats['both_growth_ratio'] = sprintf("%.2f", ($stats['both_num'] - $prev_stats['both_num'])*100 / $prev_stats['both_num']);
            }
        }

        $this->assignAll(array(
            'title'     => '车货主比例',
            'stats'     => $stats,
        ));
        $this->display('stats_user');
    }

    /**
     * 竞价成交统计
     */
    public function statsBidOrder() {
        // 权限检查
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::STATS_BID_ORDER) ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }

        $year = intval(I('year', date('Y')));
        $year_arr = [];
        for ( $i = 2017; $i <= (int)date('Y'); $i++ ) {
            $year_arr[] = $i;
        }

        $stats_model = M('stats_bid_order');
        $stats = $stats_model->where(sprintf("month>=%04d01 AND month<=%04d12", $year, $year))->select();

        $grab_stats = [];
        $success_stats = [];
        $ratio_stats = [];
        $ratio_text = [];
        foreach ( $stats as $s ) {
            $m = intval($s['month'] % 100);
            $grab_stats[$m] = $s['grab_num'];
            $success_stats[$m] = $s['success_num'];
            $ratio_stats[$m] = $s['grab_num'] > 0 ? sprintf("%.2f", $s['success_num']*100/$s['grab_num']) : 0;
            $ratio_text[$m] = $ratio_stats[$m].'%';
        }

        //print_r($grab_stats);exit;
        $this->assignAll(array(
            'title'         => '竞价成交率',
            'year'          => $year,
            'year_arr'      => $year_arr,
            'grab_stats'    => $grab_stats,
            'success_stats' => $success_stats,
            'ratio_stats'   => $ratio_stats,
            'ratio_text'    => $ratio_text,
        ));
        $this->display('stats_bid_order');

    }

    /**
     * 竞价成交统计
     */
    public function statsFinance() {
        // 权限检查
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::STATS_FINANCE) ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }

        $year = intval(I('year', date('Y')));
        $year_arr = [];
        for ( $i = 2016; $i <= (int)date('Y'); $i++ ) {
            $year_arr[] = $i;
        }

        $stats_model = M('stats_finance');
        $stats = $stats_model->where(sprintf("month>=%04d01 AND month<=%04d12", $year, $year))->select();

        $app_new_stats = [];
        $app_renew_stats = [];
        $pc_new_stats = [];
        $pc_renew_stats = [];
        $advertise = [];
        $identity = [];
        $agent = [];

        foreach ( $stats as $s ) {
            $m = intval($s['month'] % 100);

            $app_new_stats[$m] = $s['app_new'];
            $app_renew_stats[$m] = $s['app_renew'];
            $pc_new_stats[$m] = $s['pc_new'];
            $pc_renew_stats[$m] = $s['pc_renew'];
            $advertise[$m] = $s['advertise'];
            $identity[$m] = $s['identity'];
            $agent[$m] = $s['agent'];

            //$ratio_stats[$m] = $s['grab_num'] > 0 ? sprintf("%.2f", $s['success_num']*100/$s['grab_num']) : 0;
            //$ratio_text[$m] = $ratio_stats[$m].'%';
        }

        //print_r($grab_stats);exit;
        $this->assignAll(array(
            'title'             => '平台收款',
            'year'              => $year,
            'year_arr'          => $year_arr,
            'app_new_stats'     => $app_new_stats,
            'app_renew_stats'   => $app_renew_stats,
            'pc_new_stats'      => $pc_new_stats,
            'pc_renew_stats'    => $pc_renew_stats,
            'advertise'         => $advertise,
            'identity'          => $identity,
            'agent'             => $agent,
        ));
        $this->display('stats_finance');

    }

    /**
     * 开票率
     */
    public function statsInvoice() {
        // 权限检查
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::STATS_INVOICE) ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }

        $year = intval(I('year', date('Y')));
        $year_arr = [];
        for ( $i = 2016; $i <= (int)date('Y'); $i++ ) {
            $year_arr[] = $i;
        }

        $stats_model = M('stats_invoice');
        $stats = $stats_model->where(['year' => $year])->find();
        if ( $stats ) {
            // 总收入
            $stats['sum_income'] = $stats['service_sum'] + $stats['shipping_sum'];
            // 已开票总额
            $stats['sum_invoiced'] = $stats['shipping_invoiced'] + $stats['service_invoiced'];
            // 未开票总额
            $stats['sum_not_invoiced'] = $stats['sum_income'] - $stats['sum_invoiced'];

            // 百分比
            if ( $stats['sum_income'] > 0 ) {
                $stats['sum_invoiced_rate'] = sprintf("%.2f", $stats['sum_invoiced'] * 100/ $stats['sum_income']);
                $stats['sum_not_invoiced_rate'] = sprintf("%.2f", $stats['sum_not_invoiced'] * 100/ $stats['sum_income']);
            }
            if ( $stats['service_sum'] > 0 ) {
                $stats['service_invoiced_rate'] = sprintf("%.2f", $stats['service_invoiced'] * 100/ $stats['service_sum']);
                $stats['service_not_invoiced_rate'] = sprintf("%.2f", $stats['service_not_invoiced'] * 100/ $stats['service_sum']);
            }
            if ( $stats['shipping_sum'] > 0 ) {
                $stats['shipping_invoiced_rate'] = sprintf("%.2f", $stats['shipping_invoiced'] * 100/ $stats['shipping_sum']);
                $stats['shipping_not_invoiced_rate'] = sprintf("%.2f", $stats['shipping_not_invoiced'] * 100/ $stats['shipping_sum']);
            }
        }

        $this->assignAll(array(
            'title'             => '开票率',
            'year'              => $year,
            'year_arr'          => $year_arr,
            'stats'             => $stats,
        ));
        $this->display('stats_invoice');
    }

    /**
     * 车型统计
     */
    public function statsTruck() {
        // 权限检查
        if ( !\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::STATS_TRUCK) ) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }

        $year = intval(I('year', date('Y')));
        $year_arr = [];
        for ( $i = 2017; $i <= (int)date('Y'); $i++ ) {
            $year_arr[] = $i;
        }

        $month = intval(I('month', date('m')));

        $stats_model = M('stats_truck');
        $stats = $stats_model->fetchSql(FALSE)->where(sprintf("month=%04d%02d", $year, $month))->find();
        if ( $stats ) {
            $stats['type_arr'] = json_decode($stats['type_data'], TRUE);
            $stats['length_arr'] = json_decode($stats['length_data'], TRUE);
        }
        //print_r($stats);exit;

        $this->assignAll(array(
            'title'         => '货源统计',
            'year'          => $year,
            'year_arr'      => $year_arr,
            'month'         => $month,
            'car_type_arr'  => DICT::CAR_TYPE,
            'car_length_arr'=> DICT::CAR_LENGTH,
            'stats'         => $stats,
        ));
        $this->display('stats_truck');

    }

    /**
     * 货源线路统计
     */
    public function statsRoute() {
        $year = intval(I('year', date('Y')));
        $year_arr = [];
        for ( $i = 2017; $i <= (int)date('Y'); $i++ ) {
            $year_arr[] = $i;
        }

        $month = intval(I('month', date('m')));

        $stats_model = M('stats_truck');
        $stats = $stats_model->fetchSql(FALSE)->where(sprintf("month=%04d%02d", $year, $month))->find();
        if ( $stats ) {
            $stats['type_arr'] = json_decode($stats['type_data'], TRUE);
            $stats['length_arr'] = json_decode($stats['length_data'], TRUE);
        }
        //print_r($stats);exit;

        $this->assignAll(array(
            'title'         => '货源统计',
            'year'          => $year,
            'year_arr'      => $year_arr,
            'month'         => $month,
            'car_type_arr'  => DICT::CAR_TYPE,
            'car_length_arr'=> DICT::CAR_LENGTH,
            'stats'         => $stats,
        ));
        $this->display('stats_truck');

    }

    public function statsOilCards() {
        //分页
        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);

        /** @var StatsOilCardModel $stats_oil_card_model */
        $stats_oil_card_model = D('Basic/StatsOilCard', 'Model');
        $res = $stats_oil_card_model->searchStatsOilCardList($cond = [], $curr_page, $per_page);
        foreach ($res['data'] as &$v) {
            $v['amount'] = number_format($v['amount'],2,".","");
            $v['income'] = number_format($v['income'],2,".","");
            $v['deposit'] = number_format($v['deposit'],2,".","");
            $v['recharge_amount'] = number_format($v['recharge_amount'],2,".","");
            $v['recharge_income'] = number_format($v['recharge_income'],2,".","");

            $v['day_text'] = $this->_formateDay($v['day']);
        }
        $this->assignAll(array(
            'list' => $res['data'],
            'title' => '油卡销售统计',
        ));
        $this->display('stats_oil_cards');
    }

    /**
     * 转换时间格式
     * @param $day
     *
     * @return string
     */
    private function _formateDay($day) {
        $year = substr($day, 0, 4);
        $month = substr($day, 4, 2);
        $days = substr($day,-2);
        $text = $year . '-' . $month . '-'. $days;
        return $text;
    }


    public function statsOnline(){
        $months = intval(I('months'))?:12;
        $days = intval(I('days'))?:365;
        /** @var UserOnlineLogModel $onlinemodel */
        $onlinemodel = D('Basic/UserOnlineLog');  
        $daydata   = $onlinemodel->getDayOnline(date('Y-m-d'), $days);
        $monthdata = $onlinemodel->getMonthOnline(date('Y-m-d'), $months);
        $this->assignAll(array(
            'title'  => '活跃统计',
            'data'   => ['month' => $monthdata, 'day' => $daydata],
            'days'   => $days,
            'months' => $months
        ));
        $this->display('stats_online');
    }
}