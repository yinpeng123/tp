<?php
namespace Client\Controller;

use Basic\Cnsts\DICT;
use Basic\Service\AppVersionService;
use Basic\Service\UserService;
use Client\Service\LoginService;
use Common\Service\CommonService;
use Common\Controller\CommonController;
use Common\Cnsts\ERRNO;
use Basic\Service\EvaluateService;

class LoginController extends CommonController {

    public function __construct() {
        parent::__construct();
    }

    //登录接口
    public function login() {
        $this->req['app_info'] = $this->app_info;
        $login_service = new \Client\Service\LoginService;
        if ( !empty($this->req['login_flag']) && $this->req['login_flag'] == 1 ) {
            if (!is_mobilephone($this->req['telephone'])) {
                return $this->doResponse(ERRNO::PHONE_NUM_ERROR, ERRNO::e(ERRNO::PHONE_NUM_ERROR));
            }
            // 手机号快捷登录登录
            $account = $this->req['telephone'];
            list($errno, $errmsg, $user_info) = $login_service->checkTelephoneLogin($this->req);
        } else {
            //手机号/账号/网号登录
            $account = $this->req['username'];
            list($errno, $errmsg, $user_info) = $login_service->checkNameLogin($this->req);
        }
        if ( empty($user_info) ) {
            $user_info = null;
        }
        /** @var CommonService $common_service */
        $common_service = D('Common/Common','Service');
        if ( $errno == ERRNO::SUCCESS ) {

            if ( empty($this->app_info['memachine_no']) && !APP_DEBUG ) {
                 list($errno, $errmsg,  $user_info ) = [ERRNO::MEMACHINE_NO_NOT_EQ, '未获取到您的设备号，请到权限设置修改，信任此应用', null];
            }
            if ( !$common_service->checkAppMemachineNo(session('user_id'), $this->app_info) ) {
                 list($errno, $errmsg,  $user_info ) = [ERRNO::MEMACHINE_NO_NOT_EQ, '每个账号只允许在一台设备上登录，更换设备请联系客服', null];
            }
        } else {
            return $this->doResponse($errno, $errmsg, null);
        }
        $this->doResponse($errno, $errmsg, $user_info);
        fastcgi_finish_request();
        if ( $errno != ERRNO::SUCCESS ) {
            //记录登录失败日志
            $login_service->addFailLoginLog($user_info['id'], $account, \Basic\Cnsts\DICT::DATA_FROM_APP);
            return false;
        } else {
            $login_service->addSuccLoginLog($user_info['id'], $account, \Basic\Cnsts\DICT::DATA_FROM_APP);
        }
        $up_extra = [
            'app_version' => $this->app_info['app_version_name'],
            'data_from' => \Basic\Cnsts\DICT::DATA_FROM_APP,
            'is_login' => 1,
        ];
        $user_extra_service = new \Basic\Service\UserExtraService();
        $user_extra_service->saveExtraByUid($user_info['id'], $up_extra);
        return true;
    }

    //注册会员 @todo 删除
    public function doRegister() {
        $this->req['app_info'] = $this->app_info;
        /** @var LoginService $login_service */
        $login_service = D('Client/Login','Service');
        list($chk_err, $chk_msg, $chk_res) = $login_service->checkLoginSms($this->req);
        if ($chk_err != ERRNO::SUCCESS) {
            return $this->doResponse($chk_err, $chk_msg, $chk_res);
        }


        /** @var UserService $user_serive */
        $user_serive = D('Basic/User','Service');
        $telephone = $this->req['telephone'];
        if ( empty($telephone) ) {
            return $this->doResponse(ERRNO::INPUT_PARAM_ERRNO, '手机号格式不正确！', '');
        }
        $cond = [
            'telephone' => $telephone,
            'is_delete' => 0,
        ];
        $users = $user_serive->getListBy($cond);
        if ( !empty($users) && empty($users[0]['account']) ) {
            //完善信息
            $data = [
                'account' => $this->req['telephone'],
                'register_type' => DICT::DATA_FROM_APP,
                'password' => $this->req['password'],
                'password2' => $this->req['password2'],
                'uid' => $users[0]['id'],
            ];
            return $this->_fillInfo($data);
        } else {
            $rules = [
                ['password2', 'password', '两次输入密码不一致', \Think\Model::MUST_VALIDATE, 'confirm'],
            ];
            list($errno, $errmsg, $data) = $user_serive->register($this->req, $rules, $login = true);
            return $this->doResponse($errno, $errmsg, $data);
        }
    }

    protected function _fillInfo($data) {
        $uid = $data['uid'];
        $password = $data['password'];
        $password2 = $data['password2'];
        if ( $password != $password2 ) {
            return $this->doResponse(ERRNO::INPUT_PARAM_ERRNO, '两次密码不一致！', null);
        }
        $account = $data['account'];
        /** @var UserService $user_service */
        $user_service = D('Basic/User', 'Service');
        $exists = $user_service->checkLoginAccExists($account, $data['uid']);
        if ( $exists ) {
            return $this->doResponse(ERRNO::INPUT_PARAM_ERRNO, '账号已存在！', null);
        }
        $up_data = [
            'account' => $account,
            'password' => $password,
        ];
        list($errno, $errmsg, $up_ret_data) = $user_service->updateUserById($uid, $up_data);
        $user_info = $user_service->_loginAfterReg($uid);
        return $this->doResponse($errno, $errmsg, $user_info);
    }

    //获取APP配置
    public function getConfig() {
        $app_info = $this->app_info;
        $req = $this->req;
        $app_version_name = $app_info['app_version_name'];
        $os_type = $app_info['os_type'];
        /** @var AppVersionService $version_service */
        $version_service = D('Basic/AppVersion', 'Service');
        $update_type = 'Y';
        $update_desc = '';
        if ( $os_type == 'ios' ) {
            $app_version = $req['app_version'];
            $cond = [
                'os_type' => 'ios',
                'version' => $app_version,
            ];
            $down_url = \Basic\Cnsts\VERSION_CONFIG::downIosUrl();
        }  else {
            $os_type = 'android';
            $cond = [
                'os_type' => 'android',
                'version' => $app_version_name,
            ];
            $down_url = \Basic\Cnsts\VERSION_CONFIG::downAndroidUrl();
        }

        $version_info = $version_service->getBy($cond);
        $new_version_info = $version_service->getNewVersion($os_type);

        if ( $version_info ) {
            $update_type = $version_info['update_type'];
            $down_url = $new_version_info['down_url'];
            $update_desc_arr = t_json_decode($new_version_info['update_desc']);
            foreach ($update_desc_arr as $key => $value) {
                $update_desc .= ($key + 1) .".".$value."\n";
            }
        }
        $data = [
            'address_version_info' => \Basic\Cnsts\VERSION_CONFIG::getAddrVersionInfo(),
            'address_search_info'  => \Basic\Cnsts\VERSION_CONFIG::getAddrSearchInfo(),
            'new_app_version'      => [
                'update_type'      => $update_type, //Y 提示更新 F 强制更新  M手动更新  N 不提示
                'download_url'     => $down_url,
                'update_desc'      => $update_desc,
                'app_version_name' => '2.5.0',
                'is_show' => 0,
            ],
            'banner'               => [
                [
                    'pic_url'  => 'http://'.$_SERVER['HTTP_HOST'].'/Public/images/app_banner_oil.jpg',
                    'op_type'  => 'webview',// webview, internal, fix(固定展示无操作)
                    'location' => 'http://'.$_SERVER['HTTP_HOST'].'/Client/OilCard/ad'
                ],
            ],
            'alipay'               => ['desc' => '单笔单日限额3000元'],
            'wxpay'                => ['desc' => '余额限额2万元，银行卡限额3000元'],
            'member_agreement' => [
                'title' => '会员协议',
                'url' => 'http://'.$_SERVER['HTTP_HOST'].'/Client/Login/memberAgreement',
            ],
            'oil_agreement' => [
                'title' => '油卡购买协议',
                'url' => 'http://'.$_SERVER['HTTP_HOST'].'/Client/OilCard/license',
            ],
            'evaluate' => [
                'cargo'  => array_values(EvaluateService::SCORE_MAPPER[EvaluateService::EVALUATE_TYPE_CARGO]),
                'driver' => array_values(EvaluateService::SCORE_MAPPER[EvaluateService::EVALUATE_TYPE_DRIVER]),
            ],
            'interval_time' => \Client\Controller\LocationController::INTERVAL_TIME,
        ];
        return $this->doResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), $data);
    }


    //退出登录
    public function loginOut() {
        session_destroy();
        return $this->doResponse(ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), null);
    }

    /**
     * 获取会员协议
     */
    public function memberAgreement() {
        $this->display('memberAgreement');
    }
}
