<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\PageService;
use Basic\Service\OrderService;
use Common\Cnsts\ERRNO;
use \Basic\Cnsts\DICT;

class BusinessController extends AdminSessionController {
    private $__business_model = NULL;
    private $__user_model = NULL;
    private $__city_model = NULL;

    public function __construct() {
        parent::__construct();

        $this->__business_model = D('Business');
        $this->__user_model = D('User');
        $this->__city_model = D('Basic/City');
    }

    /**
     * 货源管理
     */
    public function goodsIndex() {
        // 权限判断
        $this->__accessControl(100);

        // 默认查询时间为当天
        $cond['publish_time_start'] = date("Y-m-d");
        $cond['publish_time_end'] = date("Y-m-d");
        // 返回数据
        $this->assignAll(array(
            'title'            => '货源管理',
            'cond'             => $cond,
            'province_list'    => $this->__getProvinceList(),
            'data_from_arr'    => $this->__getDataFromArr(),
            'order_status_arr' => $this->__getOrderStatusArr(),
            'car_type_arr'     => $this->__getCarTypeArr(),
            'car_length_arr'   => $this->__getCarLengthArr(),
            'good_type_arr'    => $this->__getGoodsTypeArr(),
            'bonus_arr'        => $this->__getBonusArr(),
        ));
        $this->display('goods_manager');
    }

    /**
     * 货源查询
     */
    public function goodsSearch() {
        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        $cond = $this->__getGoodsCond();
        $fields = $this->__getGoodsField();
        $join = $this->__getGoodsJoin();
        $where = $this->__getGoodsWhere($cond);
        $order = $this->__getOrder();
        $ret = $this->__business_model->searchCoOrderList($fields, $join,
            $where, $order, $curr_page, $per_page);
        $page_service = new PageService($ret['count'], $per_page);
        $page_nav = $page_service->show();

        foreach ($ret['data'] as $i => &$r) {
            $net_no = $r['net_no'];
            $account = $r['account'];
            $telephone = $r['telephone'];
            if ($r['data_from'] != 10) {
                $r['net_no'] = '<a href="/user/editBasic/'.$r['user_id'].'?act=edit&tab=basic">'.$net_no.'</a>';
                $r['account'] = '<a href="/user/editBasic/'.$r['user_id'].'?act=edit&tab=basic">'.$account.'</a>';
                $r['telephone'] = '<a href="/user/editBasic/'.$r['user_id'].'?act=edit&tab=basic">'.$telephone.'</a>';
            }
//            if ($r['car_num']) {
//                $r['car_num'] = '<a href="/truck/index?car_num='.$r['car_num'].'">'.$r['car_num'].'</a>';
//            }
            $r['car_type'] = DICT::getDictValue($r['car_type'], 'car_type');
            $r['car_length'] = DICT::getDictValue($r['car_length'], 'car_length');
            $r['data_from'] = DICT::getDictValue($r['data_from'], 'data_from');
            if ($r['order_status'] == 30000) {
                $r['button'] = $r['closed_remark'];
            } else {
                $r['button'] = '<a href="javascript:void(0);" onclick="closed('.$r['id'].',100);">关闭</a>';
            }
            $r['order_status'] = DICT::getDictValue($r['order_status'], 'business_order_status');
            if ($r['good_type'] == 0) {
                $r['good_type'] = '不限';
            } else {
                $r['good_type'] = DICT::getDictValue($r['good_type'], 'good_type');
            }
            if (!$r['user_name']) {
                if ($r['link_name']) {
                    $r['user_name'] = $r['link_name'];
                } else {
                    $r['user_name'] = '认证用户';
                    $r['link_name'] = '认证用户';
                }
            }
            if (!$telephone) {
                if ($r['link_phone']) {
                    $r['telephone'] = str_replace(" ", "<br>", $r['link_phone']);
                }
            }
//            if ($r['ticket_id'] == 0) {
//                $r['ticket_id'] = '否';
//            } else {
//                $r['ticket_id'] = '是';
//            }
            $start_area = '';
            $to_area = '';
            $r['start_area'] = $start_area;
            $r['to_area'] = $to_area;
            if ($r['is_grab'] == 0) {
                $r['is_grab'] = '否';
            } else {
                $r['is_grab'] = '<a href="/business/grabInfo?id='.$r['id'].'
                &order_status='.$r['order_status'].'
                &car_length='.$r['car_length'].'
                &car_type='.$r['car_type'].'
                &good_type='.$r['good_type'].'
                &data_from='.$r['data_from'].'
                &net_no='.$net_no.'
                &account='.$account.'
                &telephone='.$telephone.'
                &phone1='.$r['phone1'].'
                &phone2='.$r['phone2'].'
                &phone3='.$r['phone3'].'
                &user_name='.$r['user_name'].'
                &company_name='.$r['company_name'].'
                &start_area='.$r['start_area'].'
                &to_area='.$r['to_area'].'
                &remark='.$r['remark'].'">是</a>';
            }
        }

        // 返回数据
        $this->assignAll(array(
            'title'            => '货源管理',
            'cond'             => $cond,
            'province_list'    => $this->__getProvinceList(),
            'data_from_arr'    => $this->__getDataFromArr(),
            'order_status_arr' => $this->__getOrderStatusArr(),
            'car_type_arr'     => $this->__getCarTypeArr(),
            'car_length_arr'   => $this->__getCarLengthArr(),
            'good_type_arr'    => $this->__getGoodsTypeArr(),
            'bonus_arr'        => $this->__getBonusArr(),
            'list'             => $ret['data'],
            'page_nav'         => $page_nav,
        ));
        $this->display('goods_manager');
    }

    /**
     * 货源列表导出
     */
    public function exportGoodsList() {
        // 权限判断
        $this->__accessControl(100);

        $cond = $this->__getGoodsCond();

        $field = ' 
        co_order.id, 
        user.net_no, 
        user.account, 
        user.telephone, 
        user.user_name, 
        user.company_name, 
        co_order.start_province, 
        co_order.start_city, 
        co_order.start_district, 
        co_order.to_province, 
        co_order.to_city, 
        co_order.to_district, 
        co_order.good_type, 
        co_order.car_length, 
        co_order.car_type, 
        co_order.data_from, 
        co_order.publish_time, 
        co_order.is_grab,
        co_order.ticket_id, 
        co_order.order_status';

        // 输出Excel文件头，可把user.csv换成你要的文件名
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="货源信息.csv"');
        header('Cache-Control: max-age=0');

        // 打开PHP文件句柄，php://output 表示直接输出到浏览器
        $fp = fopen('php://output', 'a');

        // 输出Excel列名信息
        $head = array(
            '运单ID', '发布人网号', '发布人帐号', '发布人手机号', '发布人姓名', '发布人公司', '出发省', '出发市', '出发区县', '到达省', '到达市', '到达区县', '货物类型',
            '所需车长', '所需车型', '发布渠道', '发布日期', '是否竞价', '承运人ID', '成交价格', '是否指派车辆', '车牌号', '是否已开票', '运单状态',
        );
        foreach ($head as $i => $v) {
            // CSV的Excel支持GBK编码，一定要转换，否则乱码
            $head[$i] = iconv('utf-8', 'gb2312', $v);
        }

        // 将数据通过fputcsv写到文件句柄
        fputcsv($fp, $head);

        // 计数器
        $cnt = 0;
        // 每隔$limit*$limit_size行，刷新一下输出buffer，不要太大，也不要太小
        $limit = 10;
        // 起始行
        $limit_start = 0;
        // 查询条数
        $limit_size = 10000;
        do {
            $limit_start++;
            $ret = $this->__business_model->exportCoOrderList($field, $this->__getGoodsJoin(),
                $this->__getGoodsWhere($cond),
                $this->__getOrder(), $limit_start, $limit_size);
            $cnt++;
            if ($limit == $cnt) { //刷新一下输出buffer，防止由于数据过多造成问题
                ob_flush();
                flush();
                $cnt = 0;
            }

            foreach ($ret as $i => &$r) {
                $row['id'] = $r['id'];
                $row['net_no'] = $r['net_no'];
                $row['account'] = $r['account'];
                if ($r['telephone']) {
                    $row['telephone'] = $r['telephone'];
                } else {
                    $row['telephone'] = $r['link_phone'];
                }
                if ($r['user_name']) {
                    $row['user_name'] = $r['user_name'];
                } else {
                    if ($r['link_name']) {
                        $row['user_name'] = $r['link_name'];
                    } else {
                        $row['user_name'] = '认证用户';
                        $row['link_name'] = '认证用户';
                    }
                }
                $row['company_name'] = $r['company_name'];
                $row['start_province'] = $this->__getCityNameById($r['start_province']);
                $row['start_city'] = $this->__getCityNameById($r['start_city']);
                $row['start_district'] = $this->__getCityNameById($r['start_district']);
                $row['to_province'] = $this->__getCityNameById($r['to_province']);
                $row['to_city'] = $this->__getCityNameById($r['to_city']);
                $row['to_district'] = $this->__getCityNameById($r['to_district']);
                if ($r['good_type'] == 0) {
                    $row['good_type'] = '不限';
                } else {
                    $row['good_type'] = DICT::getDictValue($r['good_type'], 'good_type');
                }
                $row['car_length'] = DICT::getDictValue($r['car_length'], 'car_length');
                $row['car_type'] = DICT::getDictValue($r['car_type'], 'car_type');
                $row['data_from'] = DICT::getDictValue($r['data_from'], 'data_from');
                $row['publish_time'] = $r['publish_time'];
                if ($r['is_grab'] == 0) {
                    $row['is_grab'] = '否';
                } else {
                    $row['is_grab'] = '是';
                }
                $row['carry_user_id'] = $r['carry_user_id'];
                $row['grab_price'] = $r['grab_price'];
                if ($r['truck_id'] == 0) {
                    $row['truck_id'] = '否';
                } else {
                    $row['truck_id'] = '是';
                }
                $row['car_num'] = $r['car_num'];
                if ($r['ticket_id'] == 0) {
                    $row['ticket_id'] = '否';
                } else {
                    $row['ticket_id'] = '是';
                }
                $row['order_status'] = DICT::getDictValue($r['order_status'], 'business_order_status');
                foreach ($row as $i => $v) {
                    $v = "\t$v";
                    $row[$i] = iconv('utf-8', 'gb2312', $v);
                }
                fputcsv($fp, $row);
            }
        } while ($ret);
        exit;
    }

    /*
     * 竞价详情页面
     */
    public function grabInfo() {
        // 权限判断
        $this->__accessControl(100);

        $cond = $this->prepareSearchCond(array(
            'id', 'order_status', 'car_length', 'car_type', 'good_type', 'data_from', 'net_no', 'account', 'telephone',
            'phone1', 'phone2', 'phone3', 'user_name', 'company_name', 'start_area', 'to_area', 'remark',
        ));
        // 查询竞价详情
        $where['grab_order.order_id'] = $cond['id'];
        $join = [
            'LEFT JOIN user ON grab_order.user_id = user.id',
        ];
        $field = '
        grab_order.price, 
        grab_order.create_time,
        grab_order.remark, 
        grab_order.grab_status, 
        user.net_no, 
        user.account, 
        user.telephone, 
        user.user_name, 
        user.company_name';
        $ret = $this->__business_model->searchGrabList($field, $join, $where);
        foreach ($ret as $i => &$r) {
            $r['grab_status'] = DICT::getDictValue($r['grab_status'], 'grab_status');
        }
        $cond['count'] = count($ret, 0);
        // 返回数据
        $this->assignAll(array(
            'title' => '竞价详情',
            'cond'  => $cond,
            'list'  => $ret,
        ));
        $this->display('grab_info');
    }

    /**
     * 车源管理
     */
    public function truckIndex() {
        // 权限判断
        $this->__accessControl(200);

        // 默认查询时间为当天
        $cond['publish_time_start'] = date("Y-m-d");
        $cond['publish_time_end'] = date("Y-m-d");

        // 返回数据
        $this->assignAll(array(
            'title'          => '车源管理',
            'cond'           => $cond,
            'province_list'  => $this->__getProvinceList(),
            'data_from_arr'  => $this->__getDataFromArr(),
            'car_type_arr'   => $this->__getCarTypeArr(),
            'car_length_arr' => $this->__getCarLengthArr(),
            'good_type_arr'  => $this->__getGoodsTypeArr(),
        ));
        $this->display('truck_manager');
    }

    /**
     * 车源查询
     */
    public function truckSearch() {
        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        $cond = $this->__getTruckCond();

        $ret = $this->__business_model->searchCoOrderList($this->__getTruckField(), $this->__getTruckJoin(),
            $this->__getTruckWhere($cond), $this->__getOrder(), $curr_page, $per_page);
        $page_service = new PageService($ret['count'], $per_page);
        $page_nav = $page_service->show();

        foreach ($ret['data'] as $i => &$r) {
            if ($r['data_from'] != 10) {
                $r['net_no'] = '<a href="/user/editBasic/'.$r['user_id'].'?act=edit&tab=basic">'.$r['net_no'].'</a>';
                $r['account'] = '<a href="/user/editBasic/'.$r['user_id'].'?act=edit&tab=basic">'.$r['account'].'</a>';
                $r['telephone'] = '<a href="/user/editBasic/'.$r['user_id'].'?act=edit&tab=basic">'.$r['telephone'].'</a>';
            }
            $r['car_type'] = DICT::getDictValue($r['car_type'], 'car_type');
            $r['car_length'] = DICT::getDictValue($r['car_length'], 'car_length');
            $r['data_from'] = DICT::getDictValue($r['data_from'], 'data_from');
            if ($r['good_type'] == 0) {
                $r['good_type'] = '不限';
            } else {
                $r['good_type'] = DICT::getDictValue($r['good_type'], 'good_type');
            }
            $start_area = $this->__getCityNameById($r['start_province']);
            if ($r['start_city']) {
                $start_area .= '<br>'.$this->__getCityNameById($r['start_city']);
            }
            if ($r['start_district']) {
                $start_area .= '<br>'.$this->__getCityNameById($r['start_district']);
            }
            $r['start_area'] = $start_area;
            $to_area = $this->__getCityNameById($r['to_province']);
            if ($r['to_city']) {
                $to_area .= '<br>'.$this->__getCityNameById($r['to_city']);
            }
            if ($r['to_district']) {
                $to_area .= '<br>'.$this->__getCityNameById($r['to_district']);
            }
            $r['to_area'] = $to_area;
            if ($r['order_status'] == 30000) {
                $r['button'] = $r['closed_remark'];
            } else {
                $r['button'] = '<a href="javascript:void(0);" onclick="closed('.$r['id'].',200);">关闭</a>';
            }
        }

        // 返回数据
        $this->assignAll(array(
            'title'          => '车源管理',
            'cond'           => $cond,
            'province_list'  => $this->__getProvinceList(),
            'data_from_arr'  => $this->__getDataFromArr(),
            'car_type_arr'   => $this->__getCarTypeArr(),
            'car_length_arr' => $this->__getCarLengthArr(),
            'good_type_arr'  => $this->__getGoodsTypeArr(),
            'list'           => $ret['data'],
            'page_nav'       => $page_nav,
        ));
        $this->display('truck_manager');
    }

    /**
     * 车源列表导出
     */
    public function exportTruckList() {
        // 权限判断
        $this->__accessControl(200);

        $cond = $this->__getTruckCond();

        $field = '
        co_order.id, 
        user.net_no, 
        user.account, 
        user.telephone,
        co_order.start_province, 
        co_order.start_city, 
        co_order.start_district, 
        co_order.to_province, 
        co_order.to_city, 
        co_order.to_district, 
        co_order.good_type, 
        co_order.car_length, 
        co_order.car_type, 
        co_order.data_from, 
        co_order.publish_time';

        // 输出Excel文件头，可把user.csv换成你要的文件名
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="车源信息.csv"');
        header('Cache-Control: max-age=0');

        // 打开PHP文件句柄，php://output 表示直接输出到浏览器
        $fp = fopen('php://output', 'a');

        // 输出Excel列名信息
        $head = array('车源ID', '发布人网号', '发布人帐号', '发布人手机号', '出发省', '出发市', '出发区县', '到达省', '到达市', '到达区县', '货物类型', '所需车长', '所需车型', '发布渠道', '发布日期');
        foreach ($head as $i => $v) {
            // CSV的Excel支持GBK编码，一定要转换，否则乱码
            $head[$i] = iconv('utf-8', 'gb2312', $v);
        }

        // 将数据通过fputcsv写到文件句柄
        fputcsv($fp, $head);

        // 计数器
        $cnt = 0;
        // 每隔$limit*$limit_size行，刷新一下输出buffer，不要太大，也不要太小
        $limit = 10;
        // 起始行
        $limit_start = 0;
        // 查询条数
        $limit_size = 10000;
        do {
            $limit_start++;
            $ret = $this->__business_model->exportCoOrderList($field, $this->__getTruckJoin(),
                $this->__getTruckWhere($cond), $this->__getOrder(), $limit_start, $limit_size);
            $cnt++;
            if ($limit == $cnt) { //刷新一下输出buffer，防止由于数据过多造成问题
                ob_flush();
                flush();
                $cnt = 0;
            }

            foreach ($ret as $i => &$r) {
                $r['start_province'] = $this->__getCityNameById($r['start_province']);
                $r['start_city'] = $this->__getCityNameById($r['start_city']);
                $r['start_district'] = $this->__getCityNameById($r['start_district']);
                $r['to_province'] = $this->__getCityNameById($r['to_province']);
                $r['to_city'] = $this->__getCityNameById($r['to_city']);
                $r['to_district'] = $this->__getCityNameById($r['to_district']);
                if ($r['good_type'] == 0) {
                    $r['good_type'] = '不限';
                } else {
                    $r['good_type'] = DICT::getDictValue($r['good_type'], 'good_type');
                }
                $r['car_length'] = DICT::getDictValue($r['car_length'], 'car_length');
                $r['car_type'] = DICT::getDictValue($r['car_type'], 'car_type');
                $r['data_from'] = DICT::getDictValue($r['data_from'], 'data_from');

                foreach ($r as $i => $v) {
                    $v = "\t$v";
                    $row[$i] = iconv('utf-8', 'gb2312', $v);
                }
                fputcsv($fp, $row);
            }
        } while ($ret);
        exit;
    }

    /**
     * 关闭车/货源信息
     */
    public function closeOrder() {
        // 权限判断
        $this->__accessControl((int)I('type'));

        $order_id = (int)I('order_id');
        $close_reason = I('close_reason');
        if ($order_id <= 0) {
            return;
        }
        /** @var \Admin\Service\OrderService $order_service */
        $order_service = D('Admin/Order', 'Service');
        list($code, $message, $data) = $order_service->closeOrder($order_id, $close_reason);
        if ($code == ERRNO::SUCCESS) {
            $this->admin_success($message);
        } else {
            $this->admin_warn($message);
        }
    }


    private function __getCarTypeArr() {
        $car_type_list = DICT::CAR_TYPE;
        $car_type_keys = array_keys($car_type_list);
        foreach ($car_type_keys as $i => &$r) {
            $car_type_arr[] = array('id' => $r, 'text' => $car_type_list[$r]);
        }
        return $car_type_arr;
    }

    private function __getCarLengthArr() {
        $car_length_list = DICT::CAR_LENGTH;
        $car_length_keys = array_keys($car_length_list);
        foreach ($car_length_keys as $i => &$r) {
            $car_length_arr[] = array('id' => $r, 'text' => $car_length_list[$r]);
        }
        return $car_length_arr;
    }

    private function __getBonusArr() {
        $bonus_list = DICT::BONUS_LIST;
        $bonus_keys = array_keys($bonus_list);
        $bonus_arr[] = array('id' => 0, 'text' => '全部');
        foreach ($bonus_keys as $i => &$r) {
            $bonus_arr[] = array('id' => $r, 'text' => $bonus_list[$r]);
        }
        return $bonus_arr;
    }

    private function __getDataFromArr() {
        $data_from_list = DICT::PUBLISHING_CHANNEL;
        $data_from_keys = array_keys($data_from_list);
        foreach ($data_from_keys as $i => &$r) {
            $data_from_arr[] = array('id' => $r, 'text' => $data_from_list[$r]);
        }
        return $data_from_arr;
    }

    private function __getOrderStatusArr() {
        $order_status_list = DICT::BUSINESS_ORDER_STATUS;
        $order_status_keys = array_keys($order_status_list);
        foreach ($order_status_keys as $i => &$r) {
            $order_status_arr[] = array('id' => $r, 'text' => $order_status_list[$r]);
        }
        return $order_status_arr;
    }

    private function __getGoodsTypeArr() {
        $good_type_list = DICT::CARGO_TYPE;
        $good_type_keys = array_keys($good_type_list);
        $good_type_arr[] = array('id' => 0, 'text' => '全部');
        foreach ($good_type_keys as $i => &$r) {
            $good_type_arr[] = array('id' => $r, 'text' => $good_type_list[$r]);
        }
        return $good_type_arr;
    }

    private function __getProvinceList() {
        return $this->__city_model->getCityList(-1);
    }

    private function __getOrder() {
        return 'co_order_feed.id DESC';
    }

    private function __getGoodsCond() {
        $cond = $this->prepareSearchCond(
            array(
            'net_no', 'account', 'telephone', 'data_from', 'order_status', 'car_length', 'car_type', 'good_type',
            'publish_time_start', 'publish_time_end', 'start_province', 'start_city', 'start_district', 'to_province',
            'to_city', 'to_district', 'is_grab', 'is_truck', 'is_ticket', 'user_name', 'company_name',
            )
        );
        $start_province_city = '';
        $start_province = $cond['start_province'];
        if ($start_province) {
            $start_province_city = $this->__getCityNameById($start_province);
            $start_city = $cond['start_city'];
            if ($start_city) {
                $start_province_city = $start_province_city.'-'.$this->__getCityNameById($start_city);
                $start_district = $cond['start_district'];
                if ($start_district) {
                    $start_province_city = $start_province_city.'-'.$this->__getCityNameById($start_district);
                }
            }
        }
        $to_province_city = '';
        $to_province = $cond['to_province'];
        if ($to_province) {
            $to_province_city = $this->__getCityNameById($to_province);
            $to_city = $cond['to_city'];
            if ($to_city) {
                $to_province_city = $to_province_city.'-'.$this->__getCityNameById($to_city);
                $to_district = $cond['to_district'];
                if ($to_district) {
                    $to_province_city = $to_province_city.'-'.$this->__getCityNameById($to_district);
                }
            }
        }
        $cond['start_province_city'] = $start_province_city;
        $cond['to_province_city'] = $to_province_city;
        return $cond;
    }

    private function __getGoodsField() {
        return 'SQL_CALC_FOUND_ROWS co_order_feed.id as id, 
        co_order_feed.user_id,
        co_order_feed.link_phone, 
        co_order_feed.link_name, 
        co_order_feed.start_code, 
        co_order_feed.to_code, 
        co_order_feed.good_type, 
        co_order_feed.car_length, 
        co_order_feed.car_type, 
        co_order_feed.data_from, 
        co_order_feed.publish_time, 
        co_order_feed.order_status, 
        co_order_feed.closed_remark,
        co_order_feed.remark,
        user.net_no,
        user.account, 
        user.telephone, 
        user.user_name, 
        user.company_name, 
        user.phone1,
        user.phone2,
        user.phone3';
    }

    private function __getGoodsJoin() {
        return 'LEFT JOIN user ON co_order_feed.wl_user_id = user.wl_id';
    }

    private function __getGoodsWhere($cond) {
        $where['user.wl_id'] = ['gt',0];
        $where['co_order_feed.status'] = 1;
        $where['co_order_feed.order_type'] = 100;
        if ($cond['net_no']) {
            $where['user.net_no'] = array('like', '%'.$cond['net_no'].'%');
        }
        if ($cond['account']) {
            $where['user.account'] = array('like', '%'.$cond['account'].'%');
        }
        if ($cond['company_name']) {
            $where['user.company_name'] = array('like', '%'.$cond['company_name'].'%');
        }
        if ($cond['telephone']) {
            $telephone = '(user.telephone LIKE \'%'.$cond['telephone'].'%\') OR (co_order.link_phone LIKE \'%'.$cond['telephone'].'%\')';
            $where['_string'] = $telephone;
        }
        if ($cond['user_name']) {
            $user_name = '(user.user_name LIKE \'%'.$cond['user_name'].'%\') OR (co_order.link_name LIKE \'%'.$cond['user_name'].'%\')';
            $where['_string'] = $user_name;
        }
        if ($telephone && $user_name) {
            $where['_string'] = '('.$telephone.') AND ('.$user_name.')';
        }
        if ($cond['publish_time_start'] && $cond['publish_time_end']) {
            $where['co_order_feed.publish_time'] = array('between', [$cond['publish_time_start'].' 00:00:00',
                $cond['publish_time_end'].' 23:59:59']);
        } else {
            if ($cond['publish_time_start']) {
                $where['co_order_feed.publish_time'] = array('egt', $cond['publish_time_start'].' 00:00:00');
            }
            if ($cond['publish_time_end']) {
                $where['co_order_feed.publish_time'] = array('elt', $cond['publish_time_end'].' 23:59:59');
            }
        }
        if ($cond['data_from'] != 0) {
            $where['co_order_feed.data_from'] = $cond['data_from'];
        }
        if ($cond['car_length'] != 0) {
            $where['co_order_feed.car_length'] = $cond['car_length'];
        }
        if ($cond['car_type'] != 0) {
            $where['co_order_feed.car_type'] = $cond['car_type'];
        }
        if ($cond['good_type'] != 0) {
            $where['co_order_feed.good_type'] = $cond['good_type'];
        }
        if ($cond['order_status'] != 0) {
            $where['co_order.order_status'] = $cond['order_status'];
        }
        /** @var OrderService $order_service */
        $order_service = D('Basic/Order', 'Service');
        $start_code = $order_service->getSearchStart($cond);
        $to_code = $order_service->getSearchTo($cond);

        if ( $start_code ) {
            $where['co_order_feed.start_code'] = ['like',"$start_code%"];
        }

        if ( $to_code ) {
            $where['co_order_feed.to_code'] = ['like',"$to_code%"];
        }


        return $where;
    }

    private function __getTruckCond() {
        $cond = $this->prepareSearchCond(array(
            'net_no', 'account', 'telephone', 'data_from', 'car_length', 'car_type', 'good_type',
            'publish_time_start', 'publish_time_end', 'start_province', 'start_city', 'start_district', 'to_province',
            'to_city', 'to_district',
        ));
        $start_province_city = '';
        $start_province = $cond['start_province'];
        if ($start_province) {
            $start_province_city = $this->__getCityNameById($start_province);
            $start_city = $cond['start_city'];
            if ($start_city) {
                $start_province_city = $start_province_city.'-'.$this->__getCityNameById($start_city);
                $start_district = $cond['start_district'];
                if ($start_district) {
                    $start_province_city = $start_province_city.'-'.$this->__getCityNameById($start_district);
                }
            }
        }
        $to_province_city = '';
        $to_province = $cond['to_province'];
        if ($to_province) {
            $to_province_city = $this->__getCityNameById($to_province);
            $to_city = $cond['to_city'];
            if ($to_city) {
                $to_province_city = $to_province_city.'-'.$this->__getCityNameById($to_city);
                $to_district = $cond['to_district'];
                if ($to_district) {
                    $to_province_city = $to_province_city.'-'.$this->__getCityNameById($to_district);
                }
            }
        }
        $cond['start_province_city'] = $start_province_city;
        $cond['to_province_city'] = $to_province_city;
        return $cond;
    }

    private function __getTruckField() {
        return 'SQL_CALC_FOUND_ROWS 
        co_order.id, 
        co_order.start_province, 
        co_order.start_city, 
        co_order.start_district, 
        co_order.to_province, 
        co_order.to_city, 
        co_order.to_district, 
        co_order.good_type, 
        co_order.car_length, 
        co_order.car_type, 
        co_order.data_from, 
        co_order.publish_time, 
        co_order.order_status,
        co_order.closed_remark,
        user.net_no, 
        user.account, 
        user.telephone';
    }

    private function __getTruckJoin() {
        return 'LEFT JOIN user ON co_order.user_id = user.id';
    }

    private function __getTruckWhere($cond) {
        $where['co_order.status'] = 1;
        $where['co_order.order_type'] = 200;
        if ($cond['net_no']) {
            $where['user.net_no'] = array('like', '%'.$cond['net_no'].'%');
        }
        if ($cond['account']) {
            $where['user.account'] = array('like', '%'.$cond['account'].'%');
        }
        if ($cond['telephone']) {
            $where['_string'] = '(user.telephone LIKE \'%'.$cond['telephone'].'%\') OR (co_order.link_phone LIKE \'%'.$cond['telephone'].'%\')';
        }
        if ($cond['data_from'] != 0) {
            $where['co_order.data_from'] = $cond['data_from'];
        }
        if ($cond['car_length'] != 0) {
            $where['co_order.car_length'] = $cond['car_length'];
        }
        if ($cond['car_type'] != 0) {
            $where['co_order.car_type'] = $cond['car_type'];
        }
        if ($cond['good_type'] != 0) {
            $where['co_order.good_type'] = $cond['good_type'];
        }
        if ($cond['publish_time_start'] && $cond['publish_time_end']) {
            $where['co_order.publish_time'] = array('between', [$cond['publish_time_start'].' 00:00:00', $cond['publish_time_end'].' 23:59:59']);
        } else {
            if ($cond['publish_time_start']) {
                $where['co_order.publish_time'] = array('egt', $cond['publish_time_start'].' 00:00:00');
            }
            if ($cond['publish_time_end']) {
                $where['co_order.publish_time'] = array('elt', $cond['publish_time_end'].' 23:59:59');
            }
        }
        if ($cond['start_province'] != 0) {
            $where['co_order.start_province'] = $cond['start_province'];
        }
        if ($cond['start_city'] != 0) {
            $where['co_order.start_city'] = $cond['start_city'];
        }
        if ($cond['start_district'] != 0) {
            $where['co_order.start_district'] = $cond['start_district'];
        }
        if ($cond['to_province'] != 0) {
            $where['co_order.to_province'] = $cond['to_province'];
        }
        if ($cond['to_city'] != 0) {
            $where['co_order.to_city'] = $cond['to_city'];
        }
        if ($cond['to_district'] != 0) {
            $where['co_order.to_district'] = $cond['to_district'];
        }
        return $where;
    }

    private function __getCityNameById($id) {
        return $this->__city_model->getCity($id)['name'];
    }

    private function __accessControl($type) {
        if ($type == 100) {
            // 权限检查
            if (!\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id,
                \Admin\Cnsts\PRIVILEGE::GOODS_RESOURCE)
            ) {
                $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
                exit;
            }
        } else if ($type == 200) {
            // 权限检查
            if (!\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id,
                \Admin\Cnsts\PRIVILEGE::TRUCK_RESOURCE)
            ) {
                $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
                exit;
            }
        }
    }
}