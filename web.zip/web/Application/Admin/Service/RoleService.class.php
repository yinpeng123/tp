<?php
namespace Admin\Service;

use Admin\Model\RoleModel;
use Admin\Model\PrivilegeModel;

class RoleService
{

    public function getPrivilegeList($id)
    {
        /** @var RoleModel $role_model */
        $role_model        = D('Role', 'Model');
        $role_info         = $role_model->get($id);
        $privilege_checked = json_decode($role_info['privileges'], true);

        $list = [];

        /** @var PrivilegeModel $privilege_model */
        $privilege_model = D('Privilege', 'Model');
        $privilege_list = $privilege_model->getList($privilege_checked);

        for ($i = 0; $i < count($privilege_list); $i++) {
            $list[$i]['id']   = $privilege_list[$i]['id'];
            $list[$i]['pid']  = $privilege_list[$i]['pid'];
            $list[$i]['name'] = $privilege_list[$i]['name'];
        }
        return $list;
    }
}