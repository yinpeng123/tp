<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\UserService;
use Basic\Cnsts\AGENT_CHARGE;
use Admin\Service\PageService;
use Basic\Cnsts\DICT;
use Basic\Service\AgentChargeService;
use Basic\Model\AgentModel;

class InsuranceController extends AdminSessionController
{

    private $__insurance_model = NULL;

    public function __construct ()
    {
        parent::__construct();
        $this->__insurance_model     = D('Basic/Insurance', 'Model');
    }

    public function index() {
        // 渠道列表
        /** @var AgentModel $agent_model */
        $agent_model = D('Basic/Agent');
        $agent_list = $agent_model->getAllAgentList();

        $search_telephone = I('search_telephone');
        $search_account = I('search_account');
        $search_company = I('search_company');
        $search_no = I('search_no');
        $product = I('product');
        $search_buy_day_from = I('search_buy_day_from');
        $search_buy_day_to = I('search_buy_day_to');
        $search_agent_id = I('search_agent_id');
        $insurance_action = I('insurance_action');

        if(!empty($search_telephone)) {
            $cond['user.telephone'] = ['eq', $search_telephone];
        }
        if(!empty($search_account)) {
            $cond['user.account'] = ['eq', $search_account];
        }
        if(session('manager')['agent_id'] ==0 ){
            if(!empty($search_agent_id)) {
                $cond['user.channel_id'] = ['eq', $search_agent_id];
            }
        } else {
            $cond['user.channel_id'] = ['eq', session('manager')['agent_id']];
        }

        if(!empty($insurance_action)) {
            $cond['insurance.status'] = ['eq', $insurance_action];
        }
        if(!empty($search_no)) {
            $cond['insurance.no'] = ['eq', $search_no];
        }
        if(!empty($product)) {
            $cond['insurance.product'] = ['eq', $product];
        }
        if(!empty($search_buy_day_from) && !empty($search_buy_day_to)) {
            $cond['insurance.buy_day'] = [ ['egt', $search_buy_day_from],['elt', $search_buy_day_to] ];
        }
        if(!empty($search_buy_day_from)) {
            $cond['insurance.buy_day'] = ['egt', $search_buy_day_from];
        }
        if(!empty($search_buy_day_to)) {
            $cond['insurance.buy_day'] = ['elt', $search_buy_day_to];
        }

        //分页
        $per_page = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        $ret = $this->__insurance_model->searchInsuranceList($cond, $curr_page, $per_page);
//p($ret['data']);die;
        $page_service = new PageService($ret['count'], $per_page);
        $page_nav = $page_service->show();

        $agent_model = D('Basic/Agent');
        for($i=0; $i<count($ret['data']); $i++) {
            //根据渠道ID获取名称
            $agent_info = $agent_model->getAgentById($ret['data'][$i]['channel_id']);
            $ret['data'][$i]['agent_name'] = $agent_info['name'];
        }
//        p($ret['data']);die;
        // 获取统计金额
        $text = $this->_getTotalFee($ret['data']);
        $this->assignAll(array(
            'search_telephone'         =>  $search_telephone,
            'search_account'         =>  $search_account,
            'search_company'         =>  $search_company,
            'search_no'              =>  $search_no,
            'product'                =>  $product,
            'insurance_action'      =>  $insurance_action,
            'search_buy_day_from'         =>  $search_buy_day_from,
            'search_buy_day_to'         =>  $search_buy_day_to,
            'search_agent_id'     =>    I('search_agent_id'),
            'list'                =>      $ret['data'],
            'title'               =>      '用户保单',
            'agent_list'         =>      $agent_list,
            'product_list'           =>      DICT::INSURANCE_PRODUCT,
            'status'            =>      DICT::INSURANCE_STATUS,
            'identity_action'   =>  DICT::IDENTITY_ACTION,
            'page_nav'           =>      $page_nav,
            'manager_agent_id'  => session('manager')['agent_id'],
            'text' => $text,
        ));
        $this->display('ins_index');
    }

    // 统计当前的保费金额
    /**
     * @param $data 待统计数组
     *
     * @return string 文本信息
     */
    private function _getTotalFee($data) {
        $text = '';
        $company_name = [];
        foreach ($data as $k=>$v) {
            $company_name[] = $v['company'];
        }
        $company = array_unique($company_name);
        $list = [];
        foreach ($company as $k=>$v) {
            foreach ($data as $kk=>$vv) {
                if ($vv['company'] == $v) {
                    $list[$k][] = $vv;
                    $list[$k]['total'] += $vv['fee'];
                }
            }

        }
        foreach ($list as $v) {
            $text .= '保险公司--'. $v[0]['company'] . '保费共计：' . sprintf("%.2f", $v['total']) . '元。';
        }
        return $text;
    }
}