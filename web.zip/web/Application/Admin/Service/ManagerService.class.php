<?php
namespace Admin\Service;


use Admin\Model\BindMemachineLogModel;
use Admin\Model\ManagerModel;

class ManagerService {

    /**
     * 添加操作日志
     */
    public function addOperLog($info) {
        $log_model = D('OperLog');
        $oper_info = array(
            'manager_id'    => $info['manager_id'],
            'module'        => '权限管理',
            'resource'      => '管理员',
            'object_id'     => $info['object_id'],
            'action'        => $info['action'],
            'desc'          => $info['desc'],
            'ctime'         => datetime(),
        );
        $log_model->add($oper_info);
    }

    /**
     * 生成菜单数组
     * @return array
     */
    public function genMenuArr() {
        $menu_model = D('Menu');
        $menu_arr = array();
        $res1 = $menu_model->searchMenu(array('pid' => 0));
        foreach ( $res1 as $r1 ) { // 一级菜单
            $arr2 = array();
            $res2 = $menu_model->searchMenu(array('pid' => $r1['id']));

            foreach ( $res2 as $r2 ) { // 二级菜单
                $arr3 = array();
                $res3 = $menu_model->searchMenu(array('pid' => $r2['id']));

                foreach ( $res3 as $r3 ) { // 三级菜单
                    $arr3[] = array('id' => $r3['id'], 'name' => $r3['name']);
                }

                $arr2[] = array('id' => $r2['id'], 'name' => $r2['name'], 'submenu' => $arr3);
            }
            $menu_arr[] = array('id' => $r1['id'], 'name' => $r1['name'], 'submenu' => $arr2);
        }
        return $menu_arr;
    }

    // 获取父菜单的id
    public function getParentMenuId($id) {
        $menu_model = D('Menu');
        $menu = $menu_model->getMenu($id);
        return $menu['pid'];
    }

    /**
     * 是否为物流中国（即全国网）管理员
     */
    public function isWLManager($manager) {
        return $manager['agent_id'] == 0 ? TRUE : FALSE;
    }

    public function getFormatManger() {
        $manager_model = D('Manager');
        $manager_list = $manager_model->getAllManagerList('manager_id, realname');
        $format_manager = [];
        foreach($manager_list as $value) {
            $manager_id = $value['manager_id'];
            $format_manager[$manager_id] = $value['realname'];
        }
        return $format_manager;
    }



    public function getManagerList($where) {
        /** @var ManagerModel $manager_model */
        $manager_model = D('Admin/Manager','Model');
        $manager_list = $manager_model->getList($where);
        return $manager_list;
    }

    // 获取单条管理员信息（主要是姓名）
    public function get($manager_id, $fields) {
        /** @var ManagerModel $manager_model */
        $manager_model = D('Admin/Manager','Model');
        $info = $manager_model->getManagerById($manager_id, $fields);
        return $info;
    }

}