<?php


use Phinx\Migration\AbstractMigration;

class UserCredit extends AbstractMigration
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $user_credit = $this->table('user_credit', ['signed' => false]);
        $user_credit->addColumn('uid', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => 'UID'])
                ->addColumn('member_score', 'decimal', [
                    'precision' => 4,
                    'scale'     => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '会员分，正式会员5分，非正式会员0分。注册时触发更新'])
                ->addColumn('verify_score', 'decimal', [
                    'precision' => 4,
                    'scale'     => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '完成货主或车主认证中的一项10分，否则0分。认证时触发更新。'])
                ->addColumn('info_score', 'decimal', [
                    'precision' => 4,
                    'scale'     => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '资料完善分，满分5分。完善资料时更新'])
                ->addColumn('year_score', 'decimal', [
                    'precision' => 4,
                    'scale'     => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '年限分，最高2.4分。一次性初始化更新or定时更新'])
                ->addColumn('historical_business_score', 'decimal', [
                    'precision' => 4,
                    'scale'     => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '历史业务分，最高1.6分。一次性初始化更新'])

                ->addColumn('cargo_publish_cnt', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '货主发布货源数'])
                ->addColumn('cargo_ticket_cnt', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '货主发票数'])
                ->addColumn('cargo_insuence_cnt', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '货主保险数'])
                ->addColumn('cargo_money_amount', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '货主交易总额'])
                ->addColumn('cargo_data_score', 'decimal', [
                    'precision' => 4,
                    'scale'     => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '货主认证数据分，满分44， 发布数22+保险4+开票8+交易总额10'])

                ->addColumn('driver_bid_cnt', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '司机投标总数'])
                ->addColumn('driver_car_cnt', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '司机历史维护车辆总数'])
                ->addColumn('driver_order_cnt', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '司机完成运单数'])
                ->addColumn('driver_money_amount', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '司机交易金额总数'])
                ->addColumn('driver_data_score', 'decimal', [
                    'precision' => 4,
                    'scale'     => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '车主数据分，满分44，投标数6+历史车辆数10+完成运单数20+交易总额8'])

                ->addColumn('data_score', 'decimal', [
                    'precision' => 4,
                    'scale'     => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '最高44分。定时更新'])
                ->addColumn('relation_point', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 150,
                    'comment'   => '初始点数150点，收藏+2点，投诉-30点。收藏和投诉时触发更新'])
                ->addColumn('relation_score', 'decimal', [
                    'precision' => 4,
                    'scale'     => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '用户关系分，满分12分。'])
                ->addColumn('evaluate_point', 'decimal', [
                    'precision' => 4,
                    'scale'     => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '用户评价点数。评价时触发更新'])
                ->addColumn('evaluate_score', 'decimal', [
                    'precision' => 4,
                    'scale'     => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '根据点数计算的评价分，满分16分。评价时触发更新'])
                ->addColumn('login_days', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '活跃天数，根据天数计算活跃分。每日第一次登录时登录时触发更新'])
                ->addColumn('login_score', 'decimal', [
                    'precision' => 4,
                    'scale'     => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '日活排名分。满分4分。定时更新。'])
                ->addColumn('sum_score', 'decimal', [
                    'precision' => 5,
                    'scale'     => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '总分，数据变动时更新或定时更新。'])
                ->addColumn('update_time', 'datetime', [
                    'null'      => false,
                    'update'    => 'CURRENT_TIMESTAMP',
                    'default'   => 'CURRENT_TIMESTAMP',
                    'comment'   => '修改时间'])
                ->addColumn('status', 'integer', [
                    'length'    => 2,
                    'default'   => 1,
                    'comment'   => '1 启用 2 不启用'])
                ->addIndex(['uid'], ['unique' => true, 'name' => 'unique_uid'])
                ->create();

        $user_credit_log = $this->table('user_credit_log', ['signed' => false]);
        $user_credit_log->addColumn('uid', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => 'UID'])
                ->addColumn('score_type', 'string', [
                    'length'    => 45,
                    'null'      => false,
                    'comment'   => '更新的积分类型'])
                ->addColumn('score', 'decimal', [
                    'precision' => 5,
                    'scale'     => 2,
                    'signed'    => false,
                    'null'      => false,
                    'default'   => 0,
                    'comment'   => '该项新积分'])
                ->addColumn('remark', 'string', [
                    'length'    => 255,
                    'null'      => false,
                    'default'   => '',
                    'comment'   => '备注，变更原因'])
                ->addColumn('create_time', 'datetime', [
                    'default'   => 'CURRENT_TIMESTAMP',
                    'null'      => false,
                    'comment'   => '更新时间'])
                ->addColumn('certain_id', 'biginteger', [
                    'length'    => 20,
                    'null'      => false,
                    'signed'    => false,
                    'comment'   => '涉及的ID'])
                ->create();

        $user_historical_data = $this->table('user_historical_data', ['signed' => false]);
        $user_historical_data
                ->addColumn('netno', 'integer', [
                    'length'    => 10,
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => '网号'])
                ->addColumn('year', 'integer', [
                    'length'    => 4,
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => '年份'])
                ->addColumn('ordertype', 'integer', [
                    'length'    => 2,
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => '类型 1货源 2 车源'])
                ->addColumn('cnt', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => '数量'])
                ->addColumn('uid', 'integer', [
                    'signed'    => false,
                    'null'      => false,
                    'comment'   => 'UID'])
                ->create();

        $user_online_log = $this->table('user_online_log');
        $user_online_log->addColumn('online_type', 'string', [
                    'length'    => 10,
                    'null'      => false,
                    'default'   => 'Client',
                    'comment'   => '在线模块'])
                ->addIndex(['uid', 'day', 'online_type'], ['unique' => true, 'name' => 'uid-day-type'])
                ->update();

    }
}
