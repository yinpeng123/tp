<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\PageService;
use \Basic\Cnsts\DICT;
use Basic\Model\TruckInfoModel;
use Basic\Model\TruckModel;
use Basic\Service\SendNoticeService;
use Basic\Service\UserService;
use \Common\Cnsts\ERRNO;
use Admin\Service\ManagerService;

class TruckController extends AdminSessionController
{
    private $__truck_model = null;
    private $__manager_service = null;

    public function __construct()
    {
        parent::__construct();

        $this->__truck_model     = D('Truck');
        $this->__manager_service = D('Manager', 'Service');

        // 权限检查
        if (!\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::TRUCK)) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }
    }
//
//    /**
//     * 车辆列表
//     */
//    public function index() {
//        $this->assignAll(array(
//            'title'          => '车辆管理',
//            'bonus_arr'    => $this->__getBonusArr(),
//            'car_type_arr'   => $this->__getCarTypeArr(),
//            'car_length_arr' => $this->__getCarLengthArr(),
//        ));
//        $this->display('truck_list');
//    }
//
//    /**
//     * 车辆列表查询
//     */
//    public function serach() {
//        $per_page = 20;
//        $curr_page = I('path.2/d', 1);
//        $cond = $this->prepareSearchCond(array('car_num', 'driver_name', 'driver_telephone', 'driver_card_num', 'car_type', 'car_length', 'is_cert'));
//
//        $ret = $this->__truck_model->searchTruckList($this->__getField(), $this->__getJoin(), $this->__getWhere($cond),
//            $this->__getOrder(), $curr_page, $per_page);
//        $page_service = new PageService($ret['count'], $per_page);
//        $page_nav = $page_service->show();
//
//        foreach ($ret['data'] as $i => &$r) {
//            $photos = json_decode($r['photos'], JSON_UNESCAPED_UNICODE);
//            $r['truck_photos'] = !empty($photos['truck_photos']) ? $photos['truck_photos'] : [];
//            $r['driver_license_photos'] = !empty($photos['driver_license_photos']) ? $photos['driver_license_photos'] : [];
//            $r['road_license'] = !empty($photos['road_license']) ? $photos['road_license'] : [];
//            $r['car_type'] = DICT::getDictValue($r['car_type'], 'car_type');
//            $r['car_length'] = DICT::getDictValue($r['car_length'], 'car_length');
//            if ($r['cert_status'] == 200) {
//                $r['cert_status'] = '是';
//            } else {
//                $r['cert_status'] = '否';
//            }
//        }
//
//        $this->assignAll(array(
//            'title'          => '车辆列表',
//            'cond'           => $cond,
//            'bonus_arr'    => $this->__getBonusArr(),
//            'car_type_arr'   => $this->__getCarTypeArr(),
//            'car_length_arr' => $this->__getCarLengthArr(),
//            'list'           => $ret['data'],
//            'page_nav'       => $page_nav,
//        ));
//        $this->display('truck_list');
//    }
//
//    /**
//     * 车辆列表导出
//     */
//    public function exportTruckList() {
//        $cond = $this->prepareSearchCond(array('car_num', 'driver_name', 'driver_telephone', 'driver_card_num', 'car_type', 'car_length', 'is_cert'));
//
//        $field = '
//        truck.car_num,
//        truck.driver_name,
//        truck.driver_telephone,
//        truck.driver_card_num,
//        truck.car_type,
//        truck.car_length,
//        user.cert_status';
//
//        // 输出Excel文件头，可把user.csv换成你要的文件名
//        header('Content-Type: application/vnd.ms-excel');
//        header('Content-Disposition: attachment;filename="车辆信息.csv"');
//        header('Cache-Control: max-age=0');
//
//        // 打开PHP文件句柄，php://output 表示直接输出到浏览器
//        $fp = fopen('php://output', 'a');
//
//        // 输出Excel列名信息
//        $head = array('车牌号', '司机姓名', '司机电话', '司机身份证', '车辆类型', '车长', '是否认证');
//        foreach ($head as $i => $v) {
//            // CSV的Excel支持GBK编码，一定要转换，否则乱码
//            $head[$i] = iconv('utf-8', 'gb2312', $v);
//        }
//
//        // 将数据通过fputcsv写到文件句柄
//        fputcsv($fp, $head);
//
//        // 计数器
//        $cnt = 0;
//        // 每隔$limit*$limit_size行，刷新一下输出buffer，不要太大，也不要太小
//        $limit = 10;
//        // 起始行
//        $limit_start = 0;
//        // 查询条数
//        $limit_size = 10000;
//        do {
//            $limit_start++;
//            $ret = $this->__truck_model->exportTruckList($field, $this->__getJoin(), $this->__getWhere($cond), $this->__getOrder(), $limit_start, $limit_size);
//            $cnt++;
//            if ($limit == $cnt) { //刷新一下输出buffer，防止由于数据过多造成问题
//                ob_flush();
//                flush();
//                $cnt = 0;
//            }
//
//            foreach ($ret as $i => &$r) {
//                $r['car_type'] = DICT::getDictValue($r['car_type'], 'car_type');
//                $r['car_length'] = DICT::getDictValue($r['car_length'], 'car_length');
//                if ($r['cert_status'] == 200) {
//                    $r['cert_status'] = '是';
//                } else {
//                    $r['cert_status'] = '否';
//                }
//
//                foreach ($r as $i => $v) {
//                    $v = "\t$v";
//                    $row[$i] = iconv('utf-8', 'gb2312', $v);
//                }
//                fputcsv($fp, $row);
//            }
//        } while ($ret);
//        exit;
//    }
//
//
//
//
//
//    private function __getCarTypeArr() {
//        $car_type_list = DICT::CAR_TYPE;
//        $car_type_keys = array_keys($car_type_list);
//        foreach ($car_type_keys as $i => &$r) {
//            $car_type_arr[] = array('id' => $r, 'text' => $car_type_list[$r]);
//        }
//        return $car_type_arr;
//    }
//
//    private function __getCarLengthArr() {
//        $car_length_list = DICT::CAR_LENGTH;
//        $car_length_keys = array_keys($car_length_list);
//        foreach ($car_length_keys as $i => &$r) {
//            $car_length_arr[] = array('id' => $r, 'text' => $car_length_list[$r]);
//        }
//        return $car_length_arr;
//    }
//
//    private function __getBonusArr() {
//        $bonus_list = DICT::BONUS_LIST;
//        $bonus_keys = array_keys($bonus_list);
//        $bonus_arr[] = array('id' => 0, 'text' => '全部');
//        foreach ($bonus_keys as $i => &$r) {
//            $bonus_arr[] = array('id' => $r, 'text' => $bonus_list[$r]);
//        }
//        return $bonus_arr;
//    }
//
//    private function __getField() {
//        return 'SQL_CALC_FOUND_ROWS
//        truck.car_num,
//        truck.driver_name,
//        truck.driver_card_num,
//        truck.driver_telephone,
//        truck.car_length,
//        truck.car_type,
//        truck.photos,
//        user.cert_status';
//    }
//
//    private function __getWhere($cond) {
//        // 查询条件
//        $where['truck.status'] = 1;
//        if ($cond['car_num']) {
//            $where['truck.car_num'] = array('like', '%'.$cond['car_num'].'%');
//        }
//        if ($cond['driver_name']) {
//            $where['truck.driver_name'] = array('like', '%'.$cond['driver_name'].'%');
//        }
//        if ($cond['driver_telephone']) {
//            $where['truck.driver_telephone'] = array('like', '%'.$cond['driver_telephone'].'%');
//        }
//        if ($cond['driver_card_num']) {
//            $where['truck.driver_card_num'] = array('like', '%'.$cond['driver_card_num'].'%');
//        }
//        if ($cond['car_length'] != 0) {
//            $where['truck.car_length'] = $cond['car_length'];
//        }
//        if (isset($cond['car_type']) && $cond['car_type'] != 0) {
//            $where['truck.car_type'] = $cond['car_type'];
//        }
//        if ($cond['is_cert'] != 0) {
//            if ($cond['is_cert'] == 2) {
//                $where['user.cert_status'] = array('neq', 200);
//            } else {
//                $where['user.cert_status'] = 200;
//            }
//        }
//        return $where;
//    }
//
//    private function __getJoin() {
//        return 'LEFT JOIN user ON truck.user_id = user.id';
//    }
//
//    private function __getOrder() {
//        return 'truck.id DESC';
//    }

    public function index()
    {
        //获取车型
        $car_type_arr = $this->getCarType();
        //获取车长
        $car_length_arr = $this->getLengthType();

        $car_num        = I('car_num');
        $car_length_min = I('car_length_min');
        $car_length_max = I('car_length_max');
        $car_type       = I('car_type');
        $start_day      = I('start_day');
        $end_day        = I('end_day');
//        p($car_length_min);
//p($car_num);
        $car_length_min_value = DICT::CAR_LENGTH_WITHOUT_ALL[$car_length_min];
        $car_length_max_value = DICT::CAR_LENGTH_WITHOUT_ALL[$car_length_max];

        $car_type_value = DICT::CAR_TYPE_WITHOUT_ALL[$car_type];
        if (!empty($car_num)) {
            $cond['car_num'] = ['eq', $car_num];
        }

        if (!empty($car_length_min_value)) {
            $cond['car_length'] = ['egt', $car_length_min_value];
        }
        if (!empty($car_length_max_value)) {
            $cond['car_length'] = ['elt', $car_length_max_value];
        }
        if (!empty($car_length_min_value) && !empty($car_length_max_value)) {
            $cond['car_length'] = [['egt', $car_length_min_value], ['elt', $car_length_max_value]];
        }

        if (!empty($car_type_value)) {
            $cond['car_type'] = ['eq', $car_type_value];
        }
        if (!empty($start_day)) {
            $cond['update_time'] = ['egt', $start_day];
        }
        if (!empty($end_day)) {
            $cond['update_time'] = ['elt', $end_day];
        }
        if (!empty($start_day) && !empty($end_day)) {
            $cond['update_time'] = [['egt', $start_day], ['elt', $end_day]];
        }


        //展示已经认证的车辆信息
        $cond['cert_status'] = 1;

        //数据查询
        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        $ret       = $this->__truck_model->searchTruckList($cond, $curr_page, $per_page);

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();

//        //处理车型、车长数据
//        foreach ($ret['data'] as $i => &$v) {
//            $v['car_type_name']   = DICT::getDictValue($v['car_type'], 'car_type_without_all');
//            $v['car_length_name'] = DICT::getDictValue($v['car_length'], 'car_length_without_all');
//        }
        //处理添加车辆用户
        /** @var UserService $user_info_service */
        $user_info_service = D('Basic/User', 'Service');
        foreach( $ret['data'] as &$v) {
            $user_info = $user_info_service->getUserInfo($v['user_id'], $show_password = false );
            $v['account'] = $user_info['account'];
            $v['road_license_name'] = json_decode($v['photos'], TRUE)['road_license']['name'];
            $v['operation_license_name'] = json_decode($v['photos'], TRUE)['operation_license']['name'];
            $v['car_photo_name'] = json_decode($v['photos'], TRUE)['car_photo']['name'];
        }

//        p($ret['data']);die;
        $this->assignAll([
            'title'          => '车辆管理',
            'list'           => $ret['data'],
            'car_num'        => $car_num,
            'car_length_min' => $car_length_min,
            'car_length_max' => $car_length_max,
            'car_type'       => $car_type,
            'start_day'      => $start_day,
            'end_day'        => $end_day,
            'car_type_arr'   => $car_type_arr,
            'car_length_arr' => $car_length_arr,
            'page_nav'       => $page_nav,
        ]);
        $this->display('truck_index');
    }

    //认证首页
    public function certIndex()
    {
        // 权限检查
        if (!\Admin\Service\PrivilegeService::checkPrivilege($this->_manager_id, \Admin\Cnsts\PRIVILEGE::TRUCK_VERIFY)) {
            $this->admin_error('你无权访问该页面！', U('index/index', '', ''));
            exit;
        }
        $user_name   = I('user_name');
        $car_num     = I('car_num');
        $cert_status = I('cert_status');
        $start_day   = I('start_day');
        $end_day     = I('end_day');
        $post_from   = I('post_from');

        if (!empty($user_name)) {
            $cond['account']         = $user_name;
            $cond['truck_identify.cert_status'] = ['neq', 1];
        }
        if (!empty($car_num)) {
            $cond['car_num']           = $car_num;
            $cond['truck_identify.cert_status'] = ['neq', 1];
        }
        if (!empty($cert_status)) {
            if ($cert_status == 2) {
                $cond['truck_identify.cert_status'] = 0;
            } else {
                $cond['truck_identify.cert_status'] = $cert_status;
            }
        }
        if (!empty($post_from)) {
            if ($post_from == 2) {
                $cond['post_from'] = 0;
            } else {
                $cond['post_from'] = $post_from;
            }
            $cond['truck_identify.cert_status'] = ['neq', 1];
        }
        if (!empty($start_day)) {
            $cond['truck_identify.create_time'] = ['egt', $start_day];
            $cond['truck_identify.cert_status'] = ['neq', 1];
        }
        if (!empty($end_day)) {
            $cond['truck_identify.create_time'] = ['elt', $end_day];
            $cond['truck_identify.cert_status'] = ['neq', 1];
        }
        if (!empty($start_day) && !empty($end_day)) {
            $cond['truck_identify.create_time'] = [['egt', $start_day], ['elt', $end_day]];
            $cond['truck_identify.cert_status'] = ['neq', 1];
        }

        if (empty($user_name) && empty($car_num) && empty($cert_status) && empty($start_day) && empty($end_day) && empty($post_from)) {
            $cond['truck_identify.cert_status'] = ['neq', 1];
        }
//        $cond['truck.cert_status'] = ['neq', 1];
        //数据查询
        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        /** @var TruckInfoModel $truck_identify_model */
        $truck_identify_model = D('Basic/TruckInfo', 'Model');
        $ret = $truck_identify_model->searchTruckCertList($cond, $curr_page, $per_page);
//        $ret       = $this->__truck_model->searchTruckCertList($cond, $curr_page, $per_page);

        $page_service = new PageService($ret['count'], $per_page);
        $page_nav     = $page_service->show();
//        p($ret['data']);die;
//        //处理车型、车长数据
//        foreach ($ret['data'] as $i => &$v) {
//            $v['car_type_name']   = DICT::getDictValue($v['car_type'], 'car_type_without_all');
//            $v['car_length_name'] = DICT::getDictValue($v['car_length'], 'car_length_without_all');
//        }
//        p($ret['data']);die;
        $this->assignAll([
            'title'       => '车辆认证',
            'list'        => $ret['data'],
            'user_name'   => $user_name,
            'car_num'     => $car_num,
            'cert_status' => $cert_status,
            'start_day'   => $start_day,
            'end_day'     => $end_day,
            'post_from'   => $post_from,
            'page_nav'    => $page_nav,
        ]);
        $this->display('truck_cert_index');
    }

    public function edit($id)
    {
        if(!is_numeric($id)) {
            $this->admin_error('车辆id不正确');die;
        }

        /** @var TruckInfoModel $truck_identify_model */
        $truck_identify_model = D('Basic/TruckInfo', 'Model');
        $truck_info = $truck_identify_model->getTruckInfoById($id);
//        $truck_info = $this->__truck_model->getTruckInfo($id);
//        p($info);die;
//        //处理车型、车长数据
//        $truck_info['car_type_name']   = DICT::getDictValue($truck_info['car_type'], 'car_type_without_all');
//        $truck_info['car_length_name'] = DICT::getDictValue($truck_info['car_length'], 'car_length_without_all');
//        p($truck_info);die;

        $photos = json_decode($truck_info['photos'], true);
//p($photos);die;
//        p($photos['car_photo']);die;
        if (!empty($photos['car_photo'])) {
            $photos['car_photo']['url'] = imageUrl($photos['car_photo']);
            $ret                              = getImage($photos['car_photo']['type'],
                $photos['car_photo']['path'], $photos['car_photo']['name'], $info);
            if ($ret == ERRNO::SUCCESS) {
                $photos['car_photo']['size']           = $info['size'];
                $photos['car_photo']['initialPreview'] = $photos['car_photo']['url'];
                $photos['car_photo']['type']           = 'image';
                $photos['car_photo']['caption']        = $photos['car_photo']['name'];
                $photos['car_photo']['url']            = '/truck/deleteImage/' . $id;
                $photos['car_photo']['key']            = 'car_photo';
            } else {
                $photos['car_photo']['size'] = 0;
            }
        }
//        p($photos['car_photo']);die;
        if (!empty($photos['road_license'])) {
            $photos['road_license']['url'] = imageUrl($photos['road_license']);
            $ret                              = getImage($photos['road_license']['type'],
                $photos['road_license']['path'], $photos['road_license']['name'], $info);
            if ($ret == ERRNO::SUCCESS) {
                $photos['road_license']['size']           = $info['size'];
                $photos['road_license']['initialPreview'] = $photos['road_license']['url'];
                $photos['road_license']['type']           = 'image';
                $photos['road_license']['caption']        = $photos['road_license']['name'];
                $photos['road_license']['url']            = '/truck/deleteImage/' . $id;
                $photos['road_license']['key']            = 'road_license';
            } else {
                $photos['road_license']['size'] = 0;
            }
        }
        if (!empty($photos['operation_license'])) {
            $photos['operation_license']['url'] = imageUrl($photos['operation_license']);
            $ret                            = getImage($photos['operation_license']['type'],
                $photos['operation_license']['path'], $photos['operation_license']['name'], $info);
            if ($ret == ERRNO::SUCCESS) {
                $photos['operation_license']['size']           = $info['size'];
                $photos['operation_license']['initialPreview'] = $photos['operation_license']['url'];
                $photos['operation_license']['type']           = 'image';
                $photos['operation_license']['caption']        = $photos['operation_license']['name'];
                $photos['operation_license']['url']            = '/truck/deleteImage/' . $id;
                $photos['operation_license']['key']            = 'operation_license';
            } else {
                $photos['operation_license']['size'] = 0;
            }
        }
//        p($truck_info);die;
        $this->assignAll([
            'title'        => '车辆认证详情',
            'form_action'  => '/truck/doEdit',
            'operation_license' => $photos['operation_license'],
            'road_license' => $photos['road_license'],
            'car_photo'   => $photos['car_photo'],
            'car'          => $truck_info,
        ]);
        $this->display('truck_cert_edit');
    }

    public function doEdit()
    {
//        p(I(''));die;
        $cert_reason = I('cert_reason/s');
        $truck_id    = I('truck_id/d');
        if (!$truck_id) {
            $this->admin_error('车辆ID不正确');
        }
        $cert_status = I('cert/d');
        if (empty($cert_status)) {
            $cert_status = -1;
        } else {
            $cert_status = 1;
        }
        if (!$truck_id) {
            $this->admin_error('车辆ID不正确');
        }
        $data = [
            'cert_reason' => $cert_reason,
            'cert_status' => $cert_status,
            'manager_id' => $this->_manager_id,
        ];

        /** @var TruckInfoModel $truck_identify_model */
        $truck_identify_model = D('Basic/TruckInfo', 'Model');
        $truck_identify_model->upTruckInfoById($truck_id, $data);
//        $this->__truck_model->updateInfo($truck_id, $data);

        // 获取truck_identify表中的truck_id
        $truck_info = $truck_identify_model->getTruckInfoById($truck_id);

        // 修改truck表的认证状态
        /** @var TruckModel $truck_model */
        $truck_model = D('Basic/Truck', 'Model');
        unset($data['manager_id']);
        $truck_model->upTruckById($truck_info['truck_id'], $data);

//        // 获取truck表identify_id字段
//        /** @var TruckModel $truck_model */
//        $truck_model = D('Basic/Truck', 'Model');
//        $info = $truck_model->getTruckInfoById($truck_id);
//
//        // 同步修改车辆认证表
//        /** @var TruckInfoModel $truck_info_model */
//        $truck_info_model = D('Basic/TruckInfo', 'Model');
//        $truck_info_model->upTruckInfoById($info['identify_id'], $data);

        // 同步推送认证成功、失败消息
        /** @var SendNoticeService $send_notice_service */
        $send_notice_service = D('Basic/SendNotice','Service');
        if ($cert_status == -1) {
            $type = 'truck_cert_fail';
        } else {
            $type = 'truck_cert_succ';
        }
        $send_data['fail_reason'] = $data['cert_reason'];
        $send_data['user_id'] = $truck_info['user_id'];
        $send_data['truck_id'] = $truck_info['truck_id'];
        $send_notice_service->addNotice($send_data['user_id'] ,$type, $send_data);

        // 添加操作日志
        $this->__manager_service->addOperLog([
            'manager_id' => $this->_manager_id,
            'object_id'  => $truck_id,
            'action'     => 'doEdit',
            'desc'       => "认证车辆信息成功",
        ]);
        $this->admin_success('认证车辆信息成功！');
    }

    /**
     * 车辆管理列表页图片获取接口
     */
    public function getImage()
    {
        $truck_id    = I('truck_id/d');
        $photos_name = I('photos_name');
        $info        = $this->__truck_model->getTruckInfo($truck_id);
        $photos = json_decode($info['photos'], true);

        if (!empty($photos[$photos_name]['name'])) {
            $photos[$photos_name]['url'] = imageUrl($photos[$photos_name]);
            $ret                            = getImage($photos[$photos_name]['type'],
                $photos[$photos_name]['path'], $photos[$photos_name]['name'], $info);
            if ($ret == ERRNO::SUCCESS) {
                $photos[$photos_name]['size']           = $info['size'];
                $photos[$photos_name]['initialPreview'] = $photos[$photos_name]['url'];
                $photos[$photos_name]['type']           = 'image';
                $photos[$photos_name]['caption']        = $photos[$photos_name]['name'];
                $photos[$photos_name]['url']            = '/truck/deleteImage';
                $photos[$photos_name]['key']            = $photos_name;
            } else {
                $photos[$photos_name]['size'] = 0;
            }
        }
        if (empty($photos[$photos_name])) {
            $photos[$photos_name] = 0;
        }
//        p($photos[$photos_name]);die;
        if (empty($photos[$photos_name]['name'])) { // 没有上传
            $this->doResponse(ERRNO::INPUT_PARAM_ERRNO,ERRNO::e(ERRNO::INPUT_PARAM_ERRNO),$photos[$photos_name]);
        } else {
            $this->doResponse(ERRNO::SUCCESS,ERRNO::e(ERRNO::SUCCESS),$photos[$photos_name]);
        }


    }


    /**
     * 获取车型
     */
    protected function getCarType()
    {
        $car_type_arr  = [];
        $car_type_list = DICT::CAR_TYPE_WITHOUT_ALL;
        $car_type_keys = array_keys($car_type_list);
        foreach ($car_type_keys as $i => &$r) {
            $car_type_arr[] = ['id' => $r, 'text' => $car_type_list[$r]];
        }

        return $car_type_arr;
    }


    /**
     * 获取车长
     */
    protected function getLengthType()
    {
        $car_type_arr  = [];
        $car_type_list = DICT::CAR_LENGTH_WITHOUT_ALL;
        $car_type_keys = array_keys($car_type_list);
        foreach ($car_type_keys as $i => &$r) {
            $car_type_arr[] = ['id' => $r, 'text' => $car_type_list[$r]];
        }

        return $car_type_arr;
    }

}