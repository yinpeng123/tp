laydate.render({
    elem: '#startTime',
    showBottom: false,
    calendar: true,
    eventElem: '#startTime-icon',
    min: 1,
    max: 3,
    trigger: 'click'
});

var openid = getUrlParam("openid");
var type = getUrlParam("type");

$('.button-submit').click(function () {
    let room_name = $('#teamName').val();
    let people_num = $('input[name="teamSize"]:checked').val();
    let start_time = $('#startTime').val();
    let is_display = $('input[name="teamVisibility"]:checked').val();
    $.ajax({
        url: 'http://www.htown.xyz/Home/index/create_team',
        type: 'POST',
        data: {
            room_name: room_name,
            people_num: people_num,
            start_time: start_time,
            is_display: is_display,
            openid: openid,
            type: type
        },
        success: function (data) {
            layer.msg('创建队伍成功！', { time: 1000 })
            window.location.href = '../makingplan/makingplan.html?room_id=' + data.room_id + '&type=' + type + '&openid=' + openid;
        },
        error: function () {

        }
    })
})
