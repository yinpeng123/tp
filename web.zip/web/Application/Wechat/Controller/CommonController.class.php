<?php

namespace Wechat\Controller;

use Basic\Service\PayService;
use Basic\Service\UuserService;
use Think\Controller;
use Basic\Cnsts\WECHAT;
use Basic\Service\WechatService;
use Basic\ModelU\UserModel;
use Basic\ModelU\ArticleModel;
use Basic\ModelU\CenterModel;
use Basic\Service\TrainerService;

class CommonController extends WechatController
{

    function __construct()
    {
        parent::__construct();
    }

    //提交用户基本信息,openid,nickname,avatar
    public function index()
    {

        $model = new ArticleModel();
        $id = I('id');
        $this->doResponse(0, "ok", $model->get($id, 'title,ctime,name,content'));
    }

    public function trainer()
    {
        $this->doResponse(0, "ok", "教练宣传信息介绍");
    }

    //学生能力评估
    public function stuEvaluation()
    {
        $model = new CenterModel("u_config");
        $info = $model->get(9, "value");
        $data = t_json_decode($info['value']);
        $info = [
            [
                'title' => $data['t1'],
                'list' => [$data['t1a'], $data['t1b'], $data['t1c'], $data['t1d']],
            ],
            [
                'title' => $data['t2'],
                'list' => [$data['t2a'], $data['t2b'], $data['t2c'], $data['t2d']],
            ],
            [
                'title' => $data['t3'],
                'list' => [$data['t3a'], $data['t3b'], $data['t3c'], $data['t3d']],
            ],
            [
                'title' => $data['t4'],
                'list' => [$data['t4a'], $data['t4b'], $data['t4c'], $data['t4d']],
            ],
            [
                'title' => $data['t5'],
                'list' => [$data['t5a'], $data['t5b'], $data['t5c'], $data['t5d']],
            ],
            [
                'title' => $data['t6'],
                'list' => [$data['t6a'], $data['t6b'], $data['t6c'], $data['t6d']],
            ],
        ];

        $this->doResponse(0, "ok", $info);
    }

    //vip能力评估
    public function vipEvaluation()
    {
        $model = new CenterModel("u_config");
        $info = $model->get(10, "value");
        $data = t_json_decode($info['value']);
        $info = [
             [
                'title' => $data['t1'],
                'list' => [$data['t1a'], $data['t1b'], $data['t1c'], $data['t1d']],
            ],
            [
                'title' => $data['t2'],
                'list' => [$data['t2a'], $data['t2b'], $data['t2c'], $data['t2d']],
            ],
            [
                'title' => $data['t3'],
                'list' => [$data['t3a'], $data['t3b'], $data['t3c'], $data['t3d']],
            ],
            [
                'title' => $data['t4'],
                'list' => [$data['t4a'], $data['t4b'], $data['t4c'], $data['t4d']],
            ],
             [
                'title' => $data['t5'],
                'list' => [$data['t5a'], $data['t5b'], $data['t5c'], $data['t5d']],
            ],
             [
                'title' => $data['t6'],
                'list' => [$data['t6a'], $data['t6b'], $data['t6c'], $data['t6d']],
            ],
        ];

        $this->doResponse(0, "ok", $info);
    }

    //学生答案提交
    public function stuAnswer()
    {
        $list = I("info");
        $model = new CenterModel("u_config");
        $info=$model->get(9,'value');
        $info=t_json_decode($info['value']);
        $answer=[
            'A'=>$info['score1'],
            'B'=>$info['score2'],
            'C'=>$info['score3'],
            'D'=>$info['score4'],
        ];

        $list = json_decode(html_entity_decode($list), true);
        if (count($list) != 6) {
            $this->doResponse(-1, "答案输入数量不对", "");
        }
        $scoreInfo = [];
        $total = 0;
        foreach ($list as $m => $j) {
            switch (strtoupper($j)) {
                case 'A':
                    $total += $answer['A'];
                    break;
                case 'B':
                    $total += $answer['B'];
                    break;
                case 'C':
                    $total += $answer['C'];
                    break;
                case 'D':
                    $total += $answer['D'];;
                    break;
            }
        }
        (new CenterModel("u_user"))->update($this->user->id,['ce_point'=>$total]);
        $data = [
            'score' => $total,
            'content' => "工作作风上，突出意志力、坚韧力；推进工作执着、有耐心；沟通事项讲方法、求换位。性格温和、沉稳，思维理性、严谨。本人为人诚信开朗，勤奋务实，有较强的适应能力和团体协作能力，富有责任心和正义感，热爱学习，积极进取向上，开拓意识强。热爱集体、公益事业，谦虚谨慎，尊敬师长和领导。"
        ];

        $this->doResponse(0, "ok", $data);
    }

    //vip答案提交
    public function vipAnswer()
    {
        $list = I("info");
        $model = new CenterModel("u_config");
        $info=$model->get(10,'value');
        $info=t_json_decode($info['value']);
        $answer=[
            'A'=>$info['score1'],
            'B'=>$info['score2'],
            'C'=>$info['score3'],
            'D'=>$info['score4'],
        ];
        $list = json_decode(html_entity_decode($list), true);
        if (count($list) != 6) {
            $this->doResponse(-1, "答案输入数量不对", "");
        }
        $scoreInfo = [];
        $total = 0;
        foreach ($list as $m => $j) {
            switch (strtoupper($j)) {
                case 'A':
                    $total += $answer['A'];
                    break;
                case 'B':
                    $total += $answer['B'];
                    break;
                case 'C':
                    $total += $answer['C'];
                    break;
                case 'D':
                    $total += $answer['D'];;
                    break;
            }
        }
        $data = [
            'score' => $total,
         ];
        $this->doResponse(0, "ok", $data);
    }

    //vip获取教练
    public function Coach()
    {
        $score = I("score");
        $info = TrainerService::getTrainerByScore($score);
        if (!$info) {
            $this->doResponse(-1, "没有匹配到合适的教练");
        }
        $this->doResponse(0, "ok", $info);
    }

    //获取教练详情
    public function getCoach()
    {
        $id = I("id");
        $info = (new CenterModel("u_trainer"))->get($id);
        $this->doResponse(0, "ok", $info);
    }

    //选择教练
    public function choiceCoach()
    {
        $gid = I("id");
        if (!$gid) {
            $this->doResponse(-1, "请输入正确的教练ID");
        }
        $model = new CenterModel("u_user");
        $model->update($this->user->id, ['trainer_id' => $gid]);
        $this->doResponse(0, "选择教练成功");

    }

    //作废
    public function SuccessPay()
    {
        return;
        $gid = I("id");
        if (!$gid) {
            $this->doResponse(-1, "请输入正确的教练ID");
        }
        $model = new CenterModel("u_user");
        $info = [
            'trainer_id' => $gid,
            'is_member' => 'Y',
            'is_vip' => 'Y',
            'member_time' => datetime(time() + 30 * 60 * 60 * 24),
            'vip_time' => datetime(time() + 30 * 60 * 60 * 24),
        ];
        $model->update($this->user->id, $info);
        $this->doResponse(0, "选择教练成功");
    }

    //获取版本
    public function getVersion()
    {
        $info = (new CenterModel("u_config"))->getListBy("", "name ,value");
        $data = [];
        foreach ($info as $key => $val) {
            $data[$val['name']] = $val['value'];
        }
        $this->doResponse(0, "ok", $data);
    }

    //获取隐私协议
    public function getPrivacy()
    {
        $data = (new CenterModel("u_config"))->get(5, "name,value");
        $this->doResponse(0, "ok", $data);
    }

    //获取会员协议
    public function getMemberPro()
    {
        $data = (new CenterModel("u_config"))->get(6, "name,value");
        $this->doResponse(0, "ok", $data);
    }

    //每日签到
    public function daysSign()
    {
        $user = (new UuserService())->getUserByOpenid($this->openid);
        $where = [
            'days' => day(),
            'uid' => $user['id']
        ];
        $model = new CenterModel("u_sign");
        $data = $model->getBy($where);
        if ($data) {
            $this->doResponse(-1, "今天已经签过到了");
        }
        $model->add($where);
        UuserService::pointLog($this->user->id, 'sign');
        $this->doResponse(0, "ok");
    }

    //上传图片
    public function addPic()
    {
        $key = key($_FILES);
        if (empty($_FILES[$key]) || $_FILES[$key]['size'] == 0) {
            $this->doResponse(-1, "图片不能为空");
            exit;
        }

        $root_dir = C('IMAGE_PATH')['certificate'];
        $sub_dir = day();
        $image_info = [];
        list($errcode, $errmsg) = uploadImage($key, $root_dir, $sub_dir, $image_info, 'certificate');
        if ($errcode) {
            $this->doResponse($errcode, $errmsg);
            exit;
        }
        $root_path = C('IMAGE_PATH')[$image_info['type']];
        $full_path = C('IMAGE_HOST') . day() . "/" . $image_info['name'];
        $this->doResponse($errcode, $errmsg, ["url" => $full_path]);
        exit;
    }

    //获取验证码
    public function getVerifica()
    {
        $tel = I('tel');
        $memKey = $this->memKey . $tel;
        if (!is_mobile($tel)) {
            $this->doResponse(-1, "手机号不合法");
            exit;
        }
        $code = $this->getRandom();
        S($memKey, $code, 60);
        $this->sendCode($tel, $code);
        $this->doResponse(0, "ok", ['code' => $code]);
    }

    //获取所有地区
    public function getAllRegion()
    {
        $data = (new CenterModel("u_city"))->getListBy("");
        $this->doResponse(0, "ok", $data);
    }

    //根据地区ID获取所有学校
    public function getAllSchool()
    {
        $cid = I("regionId");
        $where = ['region_id' => $cid];
        $data = (new CenterModel("u_school"))->getListBy($where, "id,name");
        if (!$data) {
            $this->doResponse(-1, "该地区下没有学校");
        }
        $this->doResponse(0, "ok", $data);
    }

    //
    public function vipInfo()
    {
        $info = (new CenterModel("u_config"))->get(8, "name ,value");

        $this->doResponse(0, "ok", $info);
    }

    public function getRandom($param = 6)
    {
        $str = "0123456789012345678901234567890";
        $key = "";
        for ($i = 0; $i < $param; $i++) {
            $key .= $str{mt_rand(0, 30)};    //生成php随机数
        }
        return $key;
    }

    public function demo()
    {
        $model = new PayService();
        $fild = $model::type;
        if (!in_array(I("type"), array_keys($fild))) {
            $this->doResponse(-1, "字段不对", $fild);
        }
        $info = [
            'uid' => $this->user->id,
            'type' => I("type"),
        ];
        $model->addMessage($info);
        $this->doResponse(0, "ok", $fild[I("type")]);
    }

}
