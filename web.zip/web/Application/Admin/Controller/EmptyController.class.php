<?php
namespace Admin\Controller;

use Think\Controller;
class EmptyController extends Controller{
    public function index(){
        //根据当前控制器名来判断要执行的操作
        $controllerName = CONTROLLER_NAME;
        $this->controller($controllerName);
    }
    // 本身是 protected 方法
    protected function controller($name){
        $this->redirect('Admin/Auth');
    }
}
