<?php
namespace Admin\Service;

use Basic\Cnsts\DICT;
use Basic\Model\CoOrderFeedModel;
use Basic\Service\GrabService;
use Basic\Service\OperLogService;
use Basic\Service\SendNoticeService;
use Basic\Service\WLSendService;
use Common\Cnsts\ERRNO;
use Basic\Model\CoOrderModel;
use Think\Exception;

class OrderService {

    public function getOrderFeedList($where, $order_by = NULL, $limit = NULL, $fields = NULL, $join = NULL) {
        if (empty($fields)) {
            $fields = [
                'user.user_name as user_name',
                'user.telephone as telephone',
                'user.company_name as company_name',
                'user.net_no as net_no',
                'user.account as account',
                'co_order_feed.id as feed_id',
                'co_order_feed.order_id as order_id',
                'co_order_feed.user_id as user_id',
                'co_order_feed.carry_user_id as carry_user_id',
                'co_order_feed.good_type as good_type',
                'co_order_feed.order_count as order_count',
                'co_order_feed.order_unit as order_unit',
//                'co_order_feed.order_status as order_status',
                'co_order_feed.data_from as data_from',
                'co_order_feed.publish_time as publish_time',
                'co_order_feed.bidding as bidding',
                'co_order_feed.car_type as car_type',
                'co_order_feed.car_length as car_length',
                'co_order_feed.good_type as good_type',
                'co_order_feed.start_code as start_code',
                'co_order_feed.to_code as to_code',
                'co_order_feed.closed_remark as closed_remark',
//                'shipping_order.grab_price as grab_price',
                'shipping_order.grab_id as grab_id',
                'shipping_order.ticket_id as ticket_id',
//                'shipping_order.payment_id as payment_id',
            ];
        }
        if (empty($order_by)) {
            $order_by = 'co_order_feed.publish_time desc';
        }

        if (empty($join)) {
            $join = [
                'left join user on co_order_feed.user_id = user.id',
                'left join shipping_order on shipping_order.order_id = co_order_feed.order_id',
            ];
        }
        /** @var CoOrderFeedModel $co_order_f_m */
        $co_order_f_m = D('Basic/CoOrderFeed', 'Model');
        $list = $co_order_f_m->orderFeedList($where, $order_by, $limit, $fields, $join);
        return $list;
    }

    /**
     * 关闭车源货源 //@todo 精简
     */
    public function closeOrder($feed_id, $close_reason) {
        $feed_model_s = new \Basic\Model\CoOrderModel('slave', TRUE);
        $order_feed_info = $feed_model_s->get($feed_id, TRUE);
        if ( empty($order_feed_info) ) {
            return [ERRNO::OP_NOT_ALLOW, '信息不存在或已经被关闭', []];
        }
        if ( $order_feed_info['order_type'] == DICT::ORDER_TYPE_TRUCK ) {
            list($errno, $errmsg, $close_res) = $this->_closeTruckOrder($order_feed_info, $close_reason);
        } else {
            list($errno, $errmsg, $close_res) = $this->_closeCargoOrder($order_feed_info, $close_reason);
        }
        return [$errno,$errmsg,$close_res];
    }

    //关闭车源
    protected function _closeTruckOrder($order_feed_info, $close_reason) {
        $type = 'truck_close';
        $feed_id = $order_feed_info['id'];
        //首先同步物流中国关闭
        /** @var WLSendService $wl_send_service */
        $wl_send_service = D('Basic/WLSend', 'Service');
        try {
            list($syc_errno, $syc_msg, $syc_res) = $wl_send_service->sycCloseOrder($order_feed_info);

        } catch (Exception $e){
            throw $e;
        }

        if ( $syc_errno !== ERRNO::SUCCESS ) {
            cmm_log(json_encode([$syc_errno, '调用物流中国接口失败,原因：'.$syc_msg, $syc_res]));
            return [ERRNO::SQL_UPDATE_ERRNO, '调用物流中国接口失败,原因：'.$syc_msg, []];
        }

        $up_data = [
            'order_status'  => DICT::ORDER_STATUS_CLOSE,
            'closed_remark' => $close_reason,
        ];
        $feed_model_m = new \Basic\Model\CoOrderModel('master');
        if ( empty($order_feed_info['order_id']) ) {
            $up_res = $feed_model_m->update($feed_id, $up_data);
        } else {
            /** @var \Basic\Service\OrderService $order_service */
            $order_service = D('Basic/Order','Service');
            $up_res = $order_service->upCoOrderByOrderId($order_feed_info['order_id'], $up_data);
        }
        if ($up_res != false) {
            try {
                $order_info['truck_close_reason'] = $close_reason;
                /** @var SendNoticeService $send_notice */
                $send_notice = D('Basic/SendNotice', 'Service');
                $send_notice->addNotice($order_info['user_id'], $type, $order_info); // 发送信息至信息发布者
            } catch (Exception $e) {
                throw $e;
            }
            return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS),[]];
        } else {
            cmm_log('关闭货源失败'.json_encode($order_feed_info));
            return [ERRNO::SQL_UPDATE_ERRNO, ERRNO::e(ERRNO::SQL_UPDATE_ERRNO),[]];
        }
    }

    /**
     * @param $order_feed_info
     * @param $close_reason
     *
     * @return array
     * @throws Exception
     * 关闭货源
     */
    protected function _closeCargoOrder($order_feed_info,$close_reason) {
        $type = 'cargo_close';
        //首先同步物流中国关闭
        /** @var WLSendService $wl_send_service */
        $wl_send_service = D('Basic/WLSend', 'Service');
        if ( !$this->canCloseOrder($order_feed_info) ) {
            return [ERRNO::INPUT_PARAM_ERRNO, '当前运单状态不允许关闭',[]];
        }

        try {
            list($syc_errno, $syc_msg, $syc_res) = $wl_send_service->sycCloseOrder($order_feed_info);
        } catch (Exception $e){
            throw $e;
        }
        if ( $syc_errno !== ERRNO::SUCCESS ) {
            cmm_log(json_encode([$syc_errno,$syc_msg,$syc_res]));
            return [ERRNO::SQL_UPDATE_ERRNO, '调用物流中国接口失败,原因：'.$syc_msg,[]];
        }

        $up_data = [
            'grab_end_time' => datetime(),
            'order_status'  => DICT::ORDER_STATUS_CLOSE,
            'closed_remark' => $close_reason,
        ];

        if ( $order_feed_info['order_id'] ) {
            $order_id = $order_feed_info['order_id'];
            //根据不用的运单状态，进行不同的操作 @todo 是否调用取消运单接口
            /** @var \Basic\Service\OrderService $basic_order_service */
            $basic_order_service = D('Basic/Order','Service');
            $up_res  = $basic_order_service->upCoOrderByOrderId($order_id,$up_data);

            switch ( $order_feed_info['order_status'] ) {
                case DICT::ORDER_STATUS_PUBLISH :
                case DICT::ORDER_STATUS_GRAB_ING :
                    break;
                case DICT::ORDER_STATUS_WAIT_DEPART :
                    //退款操作
//                    $basic_order_service->refundCancelOrder($order_feed_info);
                    break;
                case DICT::ORDER_STATUS_CON_DEPART :
                    return [];
                case DICT::ORDER_STATUS_RECEIVE :
                    return [];
                case DICT::ORDER_STATUS_COMPLETE :
                    return [];
                default :
                    return [ERRNO::OP_NOT_ALLOW, '信息不存在或已经被关闭', []];
                    break;
            }
        } else {
            $feed_model_m = new \Basic\Model\CoOrderFeedModel('master');
            $up_res = $feed_model_m->update($order_feed_info['id'], $up_data);
        }
        if ($up_res === false ) {
            cmm_log2('CRM关闭货源失败feed_id'.$order_feed_info['id']);
            return [ERRNO::SQL_UPDATE_ERRNO, '关闭货源失败',[]];
        } else {
            $order_info['cargo_close_reason'] = $close_reason;
            try {
                /** @var SendNoticeService $send_notice */
                $send_notice = D('Basic/SendNotice', 'Service');
                $send_notice->addNotice( $order_info['user_id'], $type, $order_info );//推送给发布者
                //推送给竞价人
                $grab_model = new \Basic\Model\GrabOrderModel();
                $fail_where = [
                    'order_id' => $order_info['order_id'],
                    'grab_status' => ['in',[DICT::GRAB_ING,DICT::GRAB_WAIT_CON,DICT::GRAB_SUCC,]],
                ];
                $grab_fail_list = $grab_model->getGrabList($fail_where);
                $grab_fail_user_ids = array_column($grab_fail_list,'user_id');
                foreach ($grab_fail_user_ids as $grab_uid) {
                    $send_notice->addNotice($grab_uid ,\Basic\Cnsts\NOTICE::NOTICE_TYPE_ORDER_CARGO_GRABER, $order_info);//推送给发布者
                }
                if ( $order_info['grab_id'] ) {
                    /** @var GrabService $grab_service */
                    $grab_service = D('Basic/Grab', 'Service');
                    $driver_info = $grab_service->getDriverInfoByGrabId($order_info['grab_id']);
                    $driver_id = $driver_info['id'];
                    //推送司机信息
                    $order_info['order_status_desc'] = '已关闭';
                    /** @var \Driver\Service\SendNoticeService $driver_send_ser */
                    $driver_send_ser = D('Driver/SendNotice','Service');
                    $driver_send_ser->addNotice($driver_id, \Driver\Cnsts\NOTICE::NOTICE_TYPE_ORDER_STATUS_CHANGE,$order_info);
                }
            } catch ( Exception $e ) {
                throw $e;
            }
            return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS),[]];
        }
    }

    public function  canCloseOrder($order_info) {
        $can_close = 1;
        if (!in_array($order_info['order_status'],[DICT::ORDER_STATUS_PUBLISH,DICT::ORDER_STATUS_GRAB_ING, DICT::ORDER_STATUS_WAIT_DEPART])) {
            $can_close = 0;
        }
        return $can_close;
    }

    public function getSqlFoundRows($where, $join = NULL) {
        /** @var CoOrderFeedModel $co_order_f_m */
        if (empty($join)) {
            $join = [
                'left join user on co_order_feed.user_id = user.id',
                'left join shipping_order on shipping_order.order_id = co_order_feed.order_id',
            ];
        }
        $co_order_f_m = D('Basic/CoOrderFeed', 'Model');
        return $co_order_f_m->getSqlFoundRows($where, $join);
    }
}