<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2018/7/16
 * Time: 11:05
 */

namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Basic\Service\ComplainService;
use Basic\Service\OrderService;

class ComplainController extends AdminSessionController
{
    public function __construct()
    {
        parent::__construct();
    }

    // 举报列表
    public function index() {
        //分页
        $per_page  = C('TABLE_PER_PAGE');
        $curr_page = I('path.2/d', 1);
        /** @var ComplainService $complain_service */
        $complain_service = D('Basic/Complain', 'Service');
        $res = $complain_service->getlist([], $order = '', $curr_page, $per_page);
        // 获取货源、车源信息
        $data = $this->_getCoOrderInfo($res['data']);
        $this->assignAll(array(
            'title' => '用户举报数据',
            'list'  => $data,
        ));
        $this->display('complain_index');
    }

    /**
     * 车源、货源信息
     * @param $data
     *
     * @return mixed
     */
    private function _getCoOrderInfo($data) {
        /** @var OrderService $co_order_service */
        $co_order_service = D('Basic/Order', 'Service');

        /** @var ComplainService $complain_service */
        $complain_service = D('Basic/Complain', 'Service');
        foreach ( $data as &$v ) {
            $order_info = $co_order_service->getCoOrderById($v['co_id']);
            $v['order_content'] = $order_info['content'];
            $v['order_create_time'] = $order_info['create_time'];

            // 被举报次数
            $v['complain_count'] = $complain_service->getComplainCount($v['type'], $v['co_id']);
        }
        return $data;
    }
}