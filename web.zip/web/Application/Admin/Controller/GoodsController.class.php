<?php
namespace Admin\Controller;

use Admin\Controller\AdminSessionController;
use Admin\Service\PageService;
use Basic\Cnsts\DICT;
use Admin\Model\GoodsModel;

class GoodsController extends AdminSessionController {
	
	private $tags=null;
	private $brand=null;
	private $catalog=null;
    public function __construct() {
        parent::__construct();
		$this->assignAll(array(
			"form_action"=>'/goods/dataSave'
		));
    }

    /**
     * 品牌列表
     */
    public function brand() {
        $model = new GoodsModel('brand');
		$list=$model->getUserList('status>0');
        $this->assignAll(array(
            'title'   => '产品品牌列表',
            'list'    => $list,
        ));
        $this->display('brand');
    }
	    /**
     * 品牌列表
     */
    public function brandEdit($id=0) {
		$list=[];
		$title="添加品牌";
		$type='add';
		if($id){
			$model = new GoodsModel('brand');
			$list=$model->getUserById($id);
			$title='修改品牌';
			$type='edit';
		}
		
        $this->assignAll(array(
            'title'   => $title,
            'list'    => $list,
			'act'=>$type,			 
			'back_to_list_url'=>'/goods/brand?type='.$type
		
        ));
        $this->display('brand_edit');
    }

    /**
     * 菜单列表
     */
    public function Plist() {
		$this->setParam(2);
		$list=(new GoodsModel('goods'))->getUserList('status>0');
		$list=array_map(function($tmp) {
			if($tmp['tags']>0){
				foreach($this->tags as $key){
					if($key['id']==$tmp['tags']){
						$tmp['tags']=$key['name'];
						break;
					}
				}
			}
			if($tmp['catalog']>0){
				foreach($this->catalog as $key){
					if($key['id']==$tmp['catalog']){
						$tmp['catalog']=$key['name'];
						break;
					}
				}
			}
			if($tmp['brand']>0){
				foreach($this->brand as $key){
					if($key['id']==$tmp['brand']){
						$tmp['brand']=$key['name'];
						break;
					}
				}
			}
			return $tmp;
			
		},$list);
        $this->assignAll(array(
            'title'   => '所有产品',
            'list'    => $list,
        ));
        $this->display('list');
    }
    public function goodsEdit($id=0) {
		$this->setParam();
		$list=[];
		$title="添加产品";
		$type='add';
		if($id){
			$model = new GoodsModel('goods');
			$list=$model->getUserById($id);
			$title='修改产品';
			$type='edit';
		}
		
        $this->assignAll(array(
            'title'   => $title,
            'list'    => $list,
			'act'=>$type,			 
			'back_to_list_url'=>'/goods/plist'
		
        ));
        $this->display('goods_edit');
    }
	private function setParam($type=1){
		 if($type==1){
		   $this->assignAll(array(
           		'catalog'=> (new GoodsModel('catalog'))->getUserList('status>0'),
				'tags'=> (new GoodsModel('tags'))->getUserList('status>0'),
				'brand'=>(new GoodsModel('brand'))->getUserList('status>0'),		
		 )); 
		 }
		 else{
			 $this->catalog=(new GoodsModel('catalog'))->getUserList('status>0');
			 $this->tags= (new GoodsModel('tags'))->getUserList('status>0');
			 $this->brand=(new GoodsModel('brand'))->getUserList('status>0');		
		 }
	}
	
	public function delCache(){
		
		@file_put_contents("/data/var/tmp/goods.tmp",'');
		
	}
    /**
     * 菜单列表
     */
    public function catalog() {
        $model = new GoodsModel('catalog');
		$list=$model->getUserList('status>0');
        $this->assignAll(array(
            'title'   => '产品分类',
            'list'    => $list,
        ));
        $this->display('catalog');
    }

    public function catalogEdit($id=0) {
		$list=[];
		$title="添加分类";
		$type='add';
		if($id){
			$model = new GoodsModel('brand');
			$list=$model->getUserById($id);
			$title='修改分类';
			$type='edit';
		}
		
        $this->assignAll(array(
            'title'   => $title,
            'list'    => $list,
			'act'=>$type,			 
			'back_to_list_url'=>'/goods/catalog?type='.$type
		
        ));
        $this->display('catalog_edit');
    }	
    /**
     * 菜单列表
     */
    public function tags() {
        $model = new GoodsModel('tags');
		$list=$model->getUserList('status>0');
        $this->assignAll(array(
            'title'   => '标签列表',
            'list'    => $list,
        ));
        $this->display('tags');
    }
	
    public function tagsEdit($id=0) {
		$list=[];
		$title="添加标签";
		$type='add';
		if($id){
			$model = new GoodsModel('tags');
			$list=$model->getUserById($id);
			$title='修改标签';
			$type='edit';
		}
		
        $this->assignAll(array(
            'title'   => $title,
            'list'    => $list,
			'act'=>$type,			 
			'back_to_list_url'=>'/goods/tags?type='.$type
		
        ));
        $this->display('tags_add');
    }	

    /**
     * 获取返回列表的链接
     * @param $refer
     */
    protected function add($refer) {
        if ( !empty($refer) && 0 === strpos($refer, U('menu/index', '', '', TRUE)) ) {
            return $refer;
        } else {
            return U('menu/index', '', '', TRUE);
        }
    }
	
	public function delPic(){
		$key=I('key');
		$id=explode('-',$key)[0];
		$key=explode('-',$key)[1];
		if($id){
			$model = new GoodsModel('goods');
			$tmp=$model->getUserById($id);
			$list=explode(',',$tmp['thumb']);
			unset($list[$key]); 
			$param=array(
					'pic'=> isset($list[0])?$list[0]:'',
					'thumb'=>implode(',',$list)?implode(',',$list):''
			);
			$model->updateUserById($id, $param);  
		}
		echo json_encode(['id'=>$id,'key'=>$key]);
         exit;
		
		
	}
	/**
	 * 保存数据
	 */
	public function dataSave(){ 
		 $type= I('type');
		 $class=I('class');
		 $id=I('id'); 
		 if( !in_array($class,['brand','tags','goods','catalog'])){
				 return;
		 } 
		 $model = new GoodsModel($class);
		 if($type=='delete'){
			 if(!$id){
				 return;
			 }
			 $model->updateUserById($id, ['status'=>0]);
			 
		 }
		 else if($type=='save'){
			 $info=$this->dataCheck($class);
			 if($id){				 
				 $model->updateUserById($id, $info);
			 }
			 
			 else{
				 $model->add($info);
			 }
		 } 	
		if($class=='goods'){
			$class='plist';
		} 
		redirect(U('goods/'.$class.'/'));
	}
	private function dataCheck($class){
		switch($class) {
			case 'brand' :
				return [
					'name'=>I('name'),
					'status'=>I('status')?I('status'):1,
					'utime'=>date('Y-m-d H:i:s')
				];
				break;
			case 'tags' :
				return [
					'name'=>I('name'),
					'status'=>I('status')?I('status'):1,
					'utime'=>date('Y-m-d H:i:s')
				];
				break;
			case 'catalog' :
				return [
					'name'=>I('name'),
					'status'=>I('status')?I('status'):1,
					'utime'=>date('Y-m-d H:i:s')
				];
				break;
			case 'goods' :
				return [
					'name'=>I('name'),
					'status'=>I('status')?I('status'):1,
					'tags'=>I('tags')?I('tags'):0,
					'price'=>I('price')?I('price'):0,
					'catalog'=>I('catalog')?I('catalog'):0,
					'brand'=>I('brand')?I('brand'):1,
					'content'=>I('content')?I('content'):'',
					'utime'=>date('Y-m-d H:i:s'),
					'unit'=>I('unit'),
					'pic'=>I('identity_photo')[0],
					'thumb'=>implode(',',I('identity_photo'))?implode(',',I('identity_photo')):0
				];
				break;							
			
		}
			
		
		
	}




}