<?php
/**
 * Created by PhpStorm.
 * User: donvan
 * Date: 12/13/16
 * Time: 23:18
 */
if ( !APP_DEBUG ) {

} else {
    return [
        'email' => [
            'retriever' => [
                'username'     => 'alarm@chemanman.com',
                'password'     => '1quietguy',
                'to'           => 'yanrui@chemanman.com',
                'cc'           => 'yanrui@chemanman.com',
                'bcc'          => 'yanrui@chemanman.com',
                'content_type' => 'HTML',
            ],
            'SLOW_SQL'      => [
                'username'     => 'alarm@chemanman.com',
                'password'     => '1quietguy',
                'to'           => null,
                'content_type' => 'HTML',
            ],
        ],
    ];
}