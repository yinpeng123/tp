<?php

namespace Wechat\Controller;

use Basic\Service\UuserService;
use Think\Controller;
use Basic\Cnsts\WECHAT;
use Basic\Service\WechatService;
use Basic\ModelU\CenterModel;
use Basic\Service\PlanService;
use Basic\Service\PayService;

class PlanController extends WechatController
{

    function __construct()
    {
        parent::__construct();
    }

    //提交用户基本信息,openid,nickname,avatar
    public function myList()
    {
        $uid = $this->user->id;
        $page = I("page");
        $model = new CenterModel("u_plan_info");
        $where = [
            'uid' => $uid,
            'type' => 1
        ];
        $info = $model->getListBy($where, "stime,title,status,dtime", "stime desc");
        $data = [];
        foreach ($info as $key) {
            $data[$key['stime']][] = $key;
        }
        $this->doResponse(0, "ok", $data);
    }


    //我的账户奖励中
    public function inReward()
    {
        $where = [
            'uid' => $this->user->id,

            'is_money' => 1
        ];
        $model = new \Basic\ModelU\CenterModel("u_plan");
        $data = $model->getBy($where, "id,money,stime,etime,abidance,count");
        $info = [];
        if (!$data) {
            $this->doResponse(-1, "没有奖励计划");
        }

        $where = [
            'pid' => $data['id']
        ];
        $model = new \Basic\ModelU\CenterModel("u_plan_info");
        $planList = $model->getListBy($where, "id,title,total");
        foreach ($planList as $key => $val) {
            $planList[$key]['calc'] = $val['total'] . "/" . $data['abidance'];
            $planList[$key]['status'] = self::getPlanStatus($val['id']);
        }
        $statA = $data['count'] . "/" . $data['abidance'];
        $statB = intval((time() - strtotime($data['stime'])) / (24 * 3600)) . "/" . $data['abidance'];
        $overTime = intval((((strtotime(date('Y-m-d')) + 3600 * 24 - time()) / 3600) / 24) * 100);
        $data = [
            'info' => $data,
            'stat' => [$statA, $statB, $overTime],
            'list' => $planList
        ];

        $this->doResponse(0, "ok", $data);
    }

    //我的账户奖励中
    public function myReward()
    {
        $where = [
            'uid' => $this->user->id,

            'is_money' => 1
        ];
        $model = new \Basic\ModelU\CenterModel("u_plan");
        $data = $model->getBy($where, "id,money,stime,etime,abidance,count");
        $info = [];
        if (!$data) {
            $this->doResponse(-1, "没有奖励计划");
        }

        $where = [
            'pid' => $data['id']
        ];
        $model = new \Basic\ModelU\CenterModel("u_plan_info");
        $planList = $model->getListBy($where, "id,title,total");
        foreach ($planList as $key => $val) {
            $planList[$key]['calc'] = $val['total'] . "/" . $data['abidance'];
            $planList[$key]['status'] = self::getPlanStatus($val['id']);
        }
        $data = [
            'info' => $data,
            'list' => $planList
        ];

        $this->doResponse(0, "ok", $data);
    }

    private static function getPlanStatus($id)
    {
        $model = new CenterModel("u_plan_log");
        $status = 'N';
        $info = $model->getBy(['info_id' => $id], "status");
        if ($info && $info['status'] == 'Y') {
            $status = 'Y';
        }
        return $status;
    }

    //获取用户可执行计划类型及日期
    public function planStatus()
    {
        $where = [
            'uid' => $this->user->id,
            'status' => 1
        ];
        $canWeekPlan = $canDayPlan = "Y";
        $dayPlanStart = day();
        $planInfo = null;
        $model = new \Basic\ModelU\CenterModel("u_plan");
        $info = $model->getListBy($where);
        $model = new \Basic\ModelU\CenterModel("u_plan_info");
        $planId = null;
        if ($info) {
            foreach ($info as $key) {
                $info = $model->getListBy(['pid' => $key['id']], "id,title,dtime");
                $planInfo = $info;
                $planId = $key['id'];
                if ($key['type'] == 1) {
                    $dayPlanStart = day(strtotime($key['etime']) + 3600 * 24);
                }
                if ($key['type'] == 2) {
                    $dayPlanStart = day(strtotime($key['etime']) + 3600 * 24);
                    $canWeekPlan = "N";
                }
            }
        }
        $bindUser = (new CenterModel("u_user"))->getBy(['bind_uid' => $this->user->id]);
        $data = [
            'planId' => $planId,
            'bind_uid' => $bindUser ? 'Y' : "N",
            'canWeekPlan' => $canWeekPlan,
            'canDayPlan' => $canDayPlan,
            'dayPlanStart' => $dayPlanStart,
            'planInfo' => $planInfo,
        ];
        $this->doResponse(0, "ok", $data);
    }

    //制定计划
    public function addPlan()
    {
        $type = I("type");
        $stime = I("stime");
        $etime = I("etime");
        if (strtotime($etime) < strtotime($stime)) {
            $this->doResponse(-1, "计划开始日期不能小于结束日期");
        }
        $reward = I("reward");
        $list = I("list");
        $abidance = (strtotime($etime) - strtotime($stime)) / 86400 + 1;
        if (empty($type) || empty($stime) || empty($etime)) {
            $this->doResponse(-1, "缺少参数，type 计划类型 ，stime 计划开始时间，etime计划结束时间，list=[title:标题，dtime:打卡时长]");
        }

        $model = new CenterModel("u_plan");
        $where = [
            'uid' => $this->user->id,
            'etime' => ['egt', day()],
            'stime' => ['elt', day()],
        ];
        $info = $model->getBy($where);
        if ($info && $type == 2) {
            $this->doResponse(-1, "当前时间内已有制定计划,不可创建周计划");
        }
        $where = [
            'uid' => $this->user->id,
            'etime' => ['egt', $stime],
        ];
        if ($info) {
            $this->doResponse(-1, "本段时间内已有制定日计划,请选择下个时间段");
        }
        $info = $model->getBy($where);
        $plans = [
            'uid' => $this->user->id,
            'type' => $type,
            'reward' => $reward,
            'stime' => $stime,
            'etime' => $etime,
            'abidance' => $abidance,
        ];
        $planId = $model->add($plans);
        $model = new CenterModel("u_plan_info");
        $tmp = json_decode(html_entity_decode($list), true);
        foreach ($tmp as $key) {
            if ($this->filter_Emoji($key['title']) != $key['title']) {
                $this->doResponse(-1, "计划内容不能包含表情字符");
            }
            if($this->replaceSpecialChar($key['title']) !=$key['title']){
                $this->doResponse(-1, "计划内容不能包含特殊字符");
            }
            $info = [
                'title' => $key['title'],
                'dtime' => $key['dtime'],
                'pid' => $planId
            ];
            $id = $model->add($info);
        }

        $this->doResponse(0, "ok");
    }

    //制定细节添加
    public function addDetails()
    {
        $pid = I("cid");
        $title = I("title");
        $dtime = I("dtime");
        if ($this->filter_Emoji($title) != $title) {
            $this->doResponse(-1, "计划内容不能包含特殊字符");
        }
        if($this->replaceSpecialChar($title) !=$title){
            $this->doResponse(-1, "计划内容不能包含特殊字符");
        }
        $model = new CenterModel("u_plan");
        if (!$model->get($pid)) {
            $this->doResponse(-1, "没有该计划");
        }
        if (!$title) {
            $this->doResponse(-1, "title字段不能为空");
        }
        $model = new CenterModel("u_plan_info");
        $info = [
            'pid' => $pid,
            'title' => $title,
            'dtime' => $dtime,
        ];
        $model->add($info);
        $this->doResponse(0, "添加成功");

    }

    //修改计划打卡时间
    public function upPlan()
    {
        $id = I("cid");
        $dtime = I("dtime");
        $title = I("title");
        if (empty($id)) {
            $this->doResponse(-1, "缺少参数cid  计划时长分钟计算");
        }
        $model = new CenterModel("u_plan_info");
        $info = [
            'dtime' => $dtime,
        ];
        if ($title) {
            $info = [
                'title' => $title,
            ];
        }
        $model->update($id, $info);
        $this->doResponse(0, "修改计划成功");
    }

    //重置计划
    public function resetPlan()
    {
        $planId = I("cid");
        $model = new CenterModel("u_plan");
        $pid = $model->get($planId, "id");
        if (!$pid) {
            $this->doResponse(-1, "没有相关计划");
        }
        $model->delete($planId);
        $model = new CenterModel("u_plan_info");
        $info = $model->getListBy(['pid' => $planId], "id");
        foreach ($info as $key) {
            $model->delete($key['id']);
        }
        $this->doResponse(0, "所有计划已被清空");
    }

    //获取打卡剩余时间
    public function doSign()
    {
        $planId = I("planId");
        $model = new CenterModel("u_plan_info");
        $pid = $model->get($planId);
        if (!$pid) {
            $this->doResponse(-1, "没有相关计划");
        }
        $dtime = $pid['dtime'];
        $status = "N";
        $model = new CenterModel("u_plan_log", "master", false);
        $where = [
            'uid' => $this->user->id,
            'info_id' => $planId,
            'days' => day(),

        ];
        $ctime = datetime();
        $status = 'N';
        $info = $model->getBy($where, "dtime,status,ctime");
        if ($info) {
            $ctime = $info['dtime'];
            $status = $info['status'];
        } else {
            $model->add($where);
        }
        $data = [
            'ctime' => $ctime,
            'dtime' => $dtime,
            'status' => $status,
            'etime' => datetime(strtotime($ctime) + $dtime * 60)
        ];
        $this->doResponse(0, "ok", $data);
    }


    //打卡上传图片
    public function planSignIn()
    {
        $pic = I("pic");
        $planId = I("planId");
        if (empty($pic) || empty($planId)) {
            $this->doResponse(-1, "参数错误");
        }
        $models = new CenterModel("u_plan_info");
        $pid = $models->get($planId);
        if (!$pid) {
            $this->doResponse(-1, "没有该计划");
        }
        $models->update($planId, ['total' => $pid['total'] + 1]);
        $model = new CenterModel("u_plan_log");
        $where = [
            'info_id' => $planId,
            'days' => day(),
            'status' => 'N'
        ];
        $info = $model->getBy($where);
        if (!$info) {
            $this->doResponse(-1, "没有执行该计划");
        }
        $info = [
            'pic' => $pic,
            'status' => 'Y'
        ];
        $model->updateBy($where, $info);
        list($minute, $point) = $this->getDaysInfo();
        $data = [
            'dayTotal' => $pid['total'] + 1,
            'minute' => $minute,
            'point' => $point
        ];
        //$models->update(
        $this->doResponse(0, "打卡成功", $data);

    }

    //修改奖励
    public function upReward()
    {
        $id = I("pid");
        $title = I("title", "");
        if (empty($id)) {
            $this->doResponse(-1, "pid参数不可少");
        }
        $model = new CenterModel("u_plan");
        $model->update($id, ['reward' => $title]);
        $this->doResponse(0, "修改奖励计划成功");
    }

    //判断今日是否完成任务，累积打卡多少天，今日执行了多少分钟
    public function getDaysInfo()
    {
        $model = new CenterModel("u_plan_log");
        $where = [
            'uid' => $this->user->id,
            'days' => day(),
        ];
        $info = $model->getListBy($where, "info_id");
        $total = 0;
        $point = 0;
        if ($info) {
            $model = new CenterModel("u_plan_info");
            $pinfo = $model->get($info[0]['info_id'], "pid");
            if (count($info) == count($model->getListTotal(['pid' => $pinfo['pid']]))) {
                UuserService::pointLog($this->user->id, 'card');
            }
            $where = [
                'id' => ['in', array_column($info, 'info_id')]
            ];
            $total = M('u_plan_info')->where($where)->sum('total');
        }
        return [$total, $point];
    }

    //获取今天打卡详情
    public function getDaysPlan()
    {
        $days = I("days");
        if ($days == '') {
            $days = day();
        }
        $model = new CenterModel("u_plan_log");
        $where = [
            'uid' => $this->user->bind_uid,
            'days' => $days,
        ];
        $data = null;
        $info = $model->getListBy($where, "info_id,pic,status");

        $model = new CenterModel("u_plan_info");
        if ($info) {
            $pid = $model->get($info[0]['info_id'])['pid'];
            $plans = (new CenterModel("u_plan"))->get($pid, "stime,etime,type,abidance,is_money,status");
            foreach ($info as $key => $val) {
                $tmp = $model->get($val['info_id'], 'title,dtime');
                $info[$key]['title'] = $tmp['title'];
                $info[$key]['dtime'] = $tmp['dtime'];
                $info[$key]['total'] = [$tmp['total'], $plans['abidance']];
            }
            $data = [
                'plans' => $plans,
                'list' => $info
            ];
        }
        $this->doResponse(0, "ok", $data);
    }

    //发送赏金请求
    public function sendReward()
    {
        $uid = $this->user->id;
        $user = (new CenterModel("u_user"))->getBy(['bind_uid' => $uid]);
        $pid = 0;
        $where = [
            'uid' => $uid,
            'stime' => ['lt', day()],
            'etime' => ['gt', day()],
        ];
        $res = (new CenterModel("u_plan"))->getBy($where);
        if ($res) {
            $pid = $res['id'];
        }
        $info = [
            'uid' => $user['id'],
            'title' => "收到赏金请求",
            "content" => "您的孩子已提交了新的计划",
            'type' => 5,
            'param' => $pid,
        ];
        (new CenterModel("u_user_message"))->add($info);
        $this->doResponse(0, "ok");
    }

    //确认支付，钱转到用户账上
    public function payReward()
    {
        $planId = I("planId");
        $type = I("type", 'Y');
        if (!in_array($type, ['Y', 'N'])) {
            $this->doResponse(-1, "type参数Y/N");
        }
        if (empty($planId)) {
            $this->doResponse(-1, "planId不能为空");
        }
        $model = new CenterModel("u_plan");
        $info = $model->get($planId);
        if (!$info || $info['is_money'] != 1) {
            $this->doResponse(-1, "该计划异常", $info);
        }
        $status = ($type == 'Y') ? 3 : 2;
        $model->update($planId, ['status' => $status]);
        if ($status == 2) {
            $model = new CenterModel("u_user");
            $user = $model->get($this->user->id);
            $model->update($this->user->id, ['amount' => $user['amount'] + $info['amount']]);
            $info = [
                'uid' => $this->user->id,
                'type' => 17,
            ];
            (new PayService())->addMessage($info);
            $this->doResponse(0, "已拒绝该计划");
        }

        $model = new CenterModel("u_user");
        $user = $model->get($info['uid']);
        $model->update($info['uid'], ['amount' => $user['amount'] + $info['amount']]);
        $info = [
            'uid' => $info['uid'],
            'type' => 16,
        ];
        (new PayService())->addMessage($info);
        $this->doResponse(0, "ok");

    }


}
