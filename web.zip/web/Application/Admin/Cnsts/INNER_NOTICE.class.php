<?php
namespace Admin\Cnsts;

class INNER_NOTICE {
    const INNER_NOTICE_TABLE_CONFIG =  [
        //说明title <th>中的列标题，twpt_attr td的表示, class 样式，  callback 调用的函数 如果配置了 callback 则class无效
        'header' => [
            'check_box'  => ['title' => '选择框', 'sum_able' => FALSE, 'show' => TRUE, 'class' => 'column-width-45'],
            'inner_notice_id' => ['title' => '消息号', 'sum_able'=> false, 'show' => true, 'class'=>'column-width-90'],
            'title' => ['title' => '消息标题','sum_able'=> false, 'show' => true, 'class'=>''],
            'create_time' => ['title' => '发布时间', 'sum_able'=> false, 'show' => true, 'class'=>'column-width-170'],
            'create_by_desc' => ['title' => '创建人', 'sum_able'=> false, 'show' => true, 'class'=>'column-width-90'],
            'op' => ['title' => '操作','sum_able'=> false, 'show' => true,'callback' => ['class'=> '\Admin\Service\InnerNoticeService', 'method' => 'getTableOp']],
        ],
        'filter' => [
            'title' => ['title' => '消息标题', 'type' => 'text','default' => '','id'=> ''],
        ],

//        'enum' => [
//            'create_by' => [],
//        ],
        'data_id' => 'inner_notice_id',
    ];

    const MY_NOTICE_TABLE_CONFIG =  [
        //说明title <th>中的列标题，twpt_attr td的表示, class 样式，  callback 调用的函数 如果配置了 callback 则class无效
        'header' => [
            'check_box'         => ['title' => '选择框', 'sum_able' => FALSE, 'show' => TRUE, 'class' => ''],
            'inner_notice_id' => ['title' => '消息号', 'sum_able'=> false, 'show' => true, 'class'=>'column-width-90'],
            'read_status_desc' => ['title' => '是否已读', 'sum_able'=> false, 'show' => true, 'class'=>'column-width-90'],
            'title' => ['title' => '消息标题','sum_able'=> false, 'show' => true, 'class'=>''],
            'content' => ['title' => '消息内容','sum_able'=> false, 'show' => true, 'class'=>''],
            'attachment_down' => ['title' => '附件','sum_able'=> false, 'show' => true, 'class'=>'column-width-90'],
            'create_time' => ['title' => '发布时间', 'sum_able'=> false, 'show' => true, 'class'=>'column-width-170'],
            'op' => ['title' => '操作','sum_able'=> false, 'show' => true,'class'=> 'column-width-90 last'],
        ],
        //title 搜索标题，type
        'filter' => [
            'title' => ['title' => '消息标题', 'type' => 'text','default' => '','id'=> ''],
        ],
        'data_id' => 'inner_notice_id',
    ];
}