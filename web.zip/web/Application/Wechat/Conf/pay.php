<?php

$alipay = [
    'data_tpl_wx'          => [
        'body'             => '支付订单',
        'detail'           => '北京融通天下国际金融信息服务有限公司',
        'total_fee'        => 0,
        'notify_url'       => '',
        'trade_type'       => 'JSAPI',
        'spbill_create_ip' => $_SERVER['REMOTE_ADDR'],
        'input_charset'    => "UTF-8",
        //transaction_id    微信系统交易流水号
    ],
    'timeout'              => 15, // 订单失效时间，单位分钟
    'out_trade_no'         => number_format(microtime($get_as_float = TRUE) * 1000000, 0, '.', ''), // 商户网站唯一订单号.
    
];
if (APOLLO_ENV_STAGE == 'prod') {
    $alipay['notify_host'] = 'http://'.$_SERVER['HTTP_HOST'];
} else {
    $alipay['notify_host'] = 'http://'.$_SERVER['HTTP_HOST'];
}
return ['alipay' => $alipay];
?>