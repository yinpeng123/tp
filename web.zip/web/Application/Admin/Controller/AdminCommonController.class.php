<?php
namespace Admin\Controller;

use Think\Controller;

/**
 * Created by PhpStorm.
 * User: zhongying
 * Date: 2017/6/12
 * Time: 下午3:48
 */
class AdminCommonController extends Controller {

    protected $_refer = NULL;


    public function __construct() {
        parent::__construct();

        // 不需要显示初始化!
        //S(array());

        // 将 session id 在cookie储存的时间设置为0，关闭浏览器即失效
        //ini_set('session.cookie_lifetime', 0);

        // 前一个访问页面地址
        if ( IS_GET ) {
            $this->setRefer();
        }
    }

    // 设置refer
    protected function setRefer() {
        $this->_refer = isset($_REQUEST['refer']) ? $_REQUEST['refer'] : ''; //I('request.refer/s');
        if ( empty($this->_refer) ) {
            $this->_refer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : ''; // I('server.HTTP_REFERER/s');
        }
        //echo $this->_refer."\n";

        // 忽略 /auth/xxx 等地址
        $parts = parse_url($this->_refer);
        if ( !empty($parts['path']) && 0 === stripos($parts['path'], '/auth') ) {
            $this->assign('refer', '');
        } else {
            $this->assign('refer', $this->_refer);
        }
    }

    // 批量赋值模板变量
    protected function assignAll($values) {
        foreach ( $values as $k => $v ) {
            $this->assign($k, $v);
        }
    }


    // 表单令牌验证
    protected function checkFormToken($back_url = '') {
        return;
        if ( !M('')->autoCheckToken($_REQUEST) ) { // 令牌验证错误
            if ( IS_AJAX ) {
                $this->ajaxResponse(-99, 'invalid form token!');
            } else {
                //redirect($back_url ?: I('server.REQUEST_URI'), 3, '表单令牌验证出错，页面刷新中...');
                redirect($back_url ?: $this->_refer, 3, '表单令牌验证出错，页面刷新中...');
            }
            exit;
        }
    }

    /**
     * 为Ajax请求返回json格式字符串
     */
    protected function ajaxResponse($code, $message = '', $extra = '') {
        $this->ajaxReturn(array('code' => $code, 'message' => $message, 'extra' => $extra));
        return;
    }

    /**
     * 为Ajax请求返回json格式字符串，并生成新的表单令牌
     */
    protected function ajaxResponseToken($code, $message = '') {
        $behavior = new \Behavior\TokenBuildBehavior();
        list($token_name, $token_key, $token_value) = $behavior->getToken();
        $this->ajaxReturn(array('code' => $code, 'message' => $message, 'extra' => $token_key.'_'.$token_value));
        return;
    }

    /**
     * 获取返回链接, 默认返回的是之前浏览页面, 如果指定了$to_url则返回该页面并且携带refer参数值
     * @param string $to_url 指定返回的页面地址
     * @return string
     */
    protected function backurl($to_url = NULL) {
        $http_refer = $to_url ?: $_SERVER['HTTP_REFERER'];
        $refer = isset($_REQUEST['refer']) ? urldecode($_REQUEST['refer']) : ''; // I('request.refer/s');
        //echo "http_refer: $http_refer\n refer: $refer\n";

        ///if ( empty($http_refer) ) return $refer;
        if ( empty($refer) ) return $http_refer;

        // 已经包含有refer参数了
        if ( strpos($http_refer, '?refer=') || strpos($http_refer, '&refer=') )
            return $http_refer;

        if ( strpos($http_refer, '?') === FALSE ) {
            return $http_refer."?refer=".urlencode($refer);
        } else {
            return $http_refer."&refer=".urlencode($refer);
        }
    }

    /**
     * 准备查询条件
     */
    protected function prepareSearchCond($fields) {
        $cond = array();
        foreach ( $fields as $f ) {
            $v = I($f, '');
            if ( !empty($v) ) $cond[$f] = $v;
        }
        return $cond;
    }

    /**
     * @param $search_fields
     *获取查询条件
     * @return array
     */
    public function getSearchCond($search_fields) {

        $cond = array();
        foreach ( $search_fields as $key=> $value ) {
            $v = I($key, '');
            if (!empty($v)) {
                if ( $value['type'] == 'like' ) {
                    $cond[$key] = ['like',$v."%"];
                } else if ( $value['type'] == 'eq' ) {
                    $cond[$key] = $v;
                }
            }
        }
        return $cond;
    }
    /**
     * 返回操作成功页面
     */
    protected function admin_success($message, $url = '', $seconds = 3) {
        // 操作成功改为立即跳转
     //   redirect($url == '' ? $this->backurl() : $url);
        $this->assign('admin', session('manager'));
        $this->assign('act_result', 'success');
        $this->assign('message', "操作成功");
        $this->assign('url', $url == '' ? $this->backurl() : $url);
        $this->assign('seconds', $seconds);
        $this->display('Common/succs');
        return TRUE;
    }

    /**
     * 返回操作失败页面
     */
    protected function admin_error($message, $url = '', $seconds = 3) {
        $this->assign('admin', session('manager'));
        $this->assign('act_result', 'error');
        $this->assign('message', $message);
        $this->assign('url', $url == '' ? $this->backurl() : $url);
        $this->assign('seconds', $seconds);
        $this->display('Common/message');
        return TRUE;
    }

    /**
     * 返回操作警告页面
     */
    protected function admin_warn($message, $url = '', $seconds = 3) {
        $this->assign('admin', session('manager'));
        $this->assign('act_result', 'warn');
        $this->assign('message', $message);
        $this->assign('url', $url == '' ? $this->backurl() : $url);
        $this->assign('seconds', $seconds);
        $this->display('Common/message');
        return TRUE;
    }

    public function doResponse($errno = ERRNO::SUCCESS, $errmsg = 'success', $res = []) {
        $resp = [
            "errno" => $errno,
            "errmsg" => $errmsg,
            "res" => $res,
        ];
        header("Content-Type: application/json; charset=utf-8");
        echo json_encode($resp, JSON_UNESCAPED_UNICODE);
        return;
    }

}
