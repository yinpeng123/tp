<?php
namespace Admin\Service;

use Admin\Model\TicketModel;
use Basic\Cnsts\CS_WORK_SHEET;
use Basic\Cnsts\DICT;
use Basic\Cnsts\TICKET;
use Basic\Service\AgentService;
use Basic\Service\CSWorkSheetService;
use Basic\Service\UserService;
use Common\Cnsts\ERRNO;

class TicketService {

    /**
     * 新增开票记录
     */
    public function addTicket($data) {
        $fields = [
            'ticket_no'     => date("YmdHis").sprintf("%03d", mt_rand(1, 999)),
            'fee_type'      => 200, // 费用类型 101运输费 200技术服务费
            'ticket_amount' => $data['ticket_amount'], // 金额
            'order_ids'     => json_encode([$data['work_no']]), // 工单id
            'username'      => $data['username'], // 联系人
            'phone'         => $data['phone'], // 联系人电话
            'work_no'       => $data['work_no'], // 工单id
            'mail_id'       => $data['mail_id'], // 邮寄地址id
            'ticket_info_id'    => $data['ticket_info_id'], // 发票信息id
            'agent_invoice_id'  => $data['agent_invoice_id'], // 渠道发票id
            'ticket_status' => isset($data['ticket_status']) ? $data['ticket_status'] : \Basic\Cnsts\DICT::TICKET_STATUS_APPLYING,
            'ticket_type'   => 0,
            'ext'           => json_encode($data['ext']),
            'create_time'   => datetime(),
        ];

        $ticket_model = D('Ticket');
        return $ticket_model->saveTicket($fields);
    }

    public function getInvoiceInfoClass($data) {
        return '<td title="'.$data['invoice_info'].'" class="nowrap-text-overflow max-column-width-90">'.$data['invoice_info'].'</td>';
    }

    /**
     * 获取发票列表
     */
    public function getTicketList($field, $join, $where, $order=[], $limit=[]) {
        /** @var TicketModel $ticket_m */
        $ticket_m = D('Admin/Ticket', 'Model');
        $list = $ticket_m->getTicketList($field, $join, $where, $order, $limit);
        return $list;
    }

    /**
     * @param $ticket_id
     *根据id 获取信息
     */
    public function getTicketById($ticket_id) {
        /** @var TicketModel $ticket_m */
        $ticket_m = D('Admin/Ticket', 'Model');
        return $ticket_m->getTicketById($ticket_id);
    }

    /**
     * @param $ticket_list
     * 转换开票列表
     */
    public function formatTicketList(&$ticket_list) {
        // 工单、渠道、工单收款来源
        /** @var CSWorkSheetService $cs_work_service */
        $cs_work_service = D('Basic/CSWorkSheet', 'Service');
        /** @var AgentService $agent_service */
        $agent_service = D('Basic/Agent', 'Service');

        /** @var ManagerService $manager_service */
        $manager_service = D('Admin/Manager', 'Service');

//        p($ticket_list);die;
        foreach ( $ticket_list as $i => &$r ) {
            $ticket_id = $r['id'];
            $ticket_type = $r['ticket_type'];
            $ticket_status = $r['ticket_status'];
//            $ticket_info_id = $r['ticket_info_id'];
            $order_ids = json_decode($r['order_ids'],JSON_UNESCAPED_UNICODE);
//            $order_ids = implode(' ', $order_ids);
            $ext = json_decode($r['ext'],JSON_UNESCAPED_UNICODE);
            $r['ticket_id'] = $ticket_id;
            $r['order_ids'] = $order_ids;

            if (strlen(current($r['order_ids'])) == 0) {
                $text = '';
            } else {
                if (strlen(current($r['order_ids'])) != 18) {
                    $text = '工单号：';
                } else {
                    $text = '运单号：';
                }
            }

            $ids = implode('，', $order_ids);
            $r['order_ids_text'] = "<p>$text</p>"."<p>$ids</p>";
            // 字典查询
            $r['fee_type_desc'] = DICT::getDictValue($r['fee_type'], 'fee_type');
            $r['ticket_status_desc'] = DICT::getDictValue($ticket_status, 'ticket_status_crm');
            $ticket_info = $ext['ticket_info'];
            if ($ticket_info['agent_id']) {
                $r['invoice_info'] = $ticket_info['company']. ' '.$ticket_info['bank_name']. ' '
                    .$ticket_info['bank_passport'];
                if ( $ticket_info['type'] == 1 ) {
                    $r['ticket_type_desc'] = '增值税普通发票';
                } else if ( $ticket_info['ticket_type'] == 2 ) {
                    $r['ticket_type_desc'] = '增值税专用发票';
                } else {
                    $r['ticket_type_desc'] = '';
                }
            } else {
                $r['invoice_info'] = $ticket_info['company_name']. ' '.$ticket_info['open_bank']. ' '
                    .$ticket_info['bank_card'];
                if ( $ticket_info['ticket_type'] == 10 ) {
                    $r['ticket_type_desc'] = '增值税普通发票';
                } else if ( $ticket_info['ticket_type'] == 20 ) {
                    $r['ticket_type_desc'] = '增值税专用发票';
                } else {
                    $r['ticket_type_desc'] = '';
                }
            }
            // 所属渠道
            $cs_id = $r['order_ids'];
            $cs_info = $cs_work_service->getWorkSheetInfo(current($cs_id));
            $agent_info = $agent_service->getAgentById($cs_info['agent_id']);

            if ($agent_info['name']) {
                $r['agent_id'] = $agent_info['name'];
            } else {
                $r['agent_id'] = '全国网';
            }
            // 收款来源
            $payment_list = [];
            for ($i=0; $i<count($cs_id); $i++) {
                $cs_detail_info = $cs_work_service->getWorkSheetInfo($cs_id[$i]);
                $pay_json = json_decode($cs_detail_info['charging'], TRUE);
                $detail_info = [];
                for ($j=0; $j<count($pay_json); $j++) {
                    $detail_info['payment']['payment_text'] = CS_WORK_SHEET::WS_CHARGING_ARR[$pay_json[$j]['source']].'：';
                    $detail_info['payment']['amount'] = $pay_json[$j]['amount'];
                    $detail_info['payment']['cs_id'] = $cs_id[$i];

                }

                $payment_list[] = $detail_info;
            }
            $r['payment_list'] = $payment_list;
//            $r['payment_list'] = json_encode($r['payment_list'], JSON_UNESCAPED_UNICODE);

            $payment = '';
            if (strlen(current($r['order_ids'])) == 0) {
                $payment = '';
            } else {
                for ($i=0; $i<count($r['payment_list']); $i++) {
                    $payment .= "<p>工单号：<span>".$r['payment_list'][$i]['payment']['cs_id']."</span></p>"."<p>".$r['payment_list'][$i]['payment']['payment_text']."<span>".'¥'.$r['payment_list'][$i]['payment']['amount']."</span></p>";
                }
            }
            $r['payment_source'] = $payment;
            // 创建人
            $manager_info = $manager_service->get($cs_info['creator'], ['manager_id', 'realname']);
            $r['creator'] = $manager_info['realname'];

            // 网号/账号
            /** @var UserService $user_service */
            $user_service = D('Basic/User','Service');
            $user_info = $user_service->getUserInfoById($r['user_id'],$show_password = FALSE);
            if ( !empty($user_info['net_no']) && !empty($user_info['account'])) {
                $r['net_account'] = $user_info['net_no'].'/'.$user_info['account'];
            } elseif (!empty($user_info['net_no'])) {
                $r['net_account'] = $user_info['net_no'];
            } elseif (!empty($user_info['account'])) {
                $r['net_account'] = $user_info['account'];
            } else {
                $r['net_account'] = '';
            }
            if ( !empty($user_info['telephone'])) {
                $r['app_telephone'] = $user_info['telephone'];
            } else {
                $r['app_telephone'] = '';
            }

            // 新增内容
            $r['confirm_time_ymd'] = substr($r['confirm_time'], 0, 10); // 开票时间
            $r['mail_time_ymd'] = substr($r['mail_time'], 0, 10); // 寄送时间
            $r['owner_company'] = DICT::OWNER_COMPANY_LIST[$r['owner_company']];
            $re_text = '';

            // 寄送方式
            $express_text = '';
            if ($r['express_type'] == 10) {
                $express_text = '到付';
            } elseif ($r['express_type'] == 20) {
                $express_text = '寄付';
            }
            $r['express_type_text'] = $express_text;

            // 是否补开发票
            if ($r['ticket_type'] == 0) {
                $ticket_time = substr($r['create_time'], 0, 10);
                $cs_time = $cs_info['finish_day_real'];
                if ($ticket_time != $cs_time) {
                    $re_text = '是';
                } else{
                    $re_text = '否';
                }
            } else {
                $re_text = '运单发票';
            }

            $r['is_extra_open'] = $re_text;

            // 操作按钮拼接
            if ($ticket_type == 1) {
                $edit = '<a href="javascript:void(0);" onclick="editIndex('.$ticket_id.');">编辑</a>';//编辑运单发票
            } else {
                $edit = '<a href="javascript:void(0);" onclick="editTicket('.$ticket_id.');">编辑</a>';//编辑工单发票
            }
//            $edit = '<a href="javascript:void(0);" onclick="editTicket('.$ticket_id.');">编辑</a>'; //编辑工单发票
            $billing = '<a href="javascript:void(0);" onclick="billing('.$ticket_id.',200);">开票</a>';
            $send = '<a href="javascript:void(0);" onclick="sendTicket('.$ticket_id.',300);">寄送</a>';
            $complete = '<a href="javascript:void(0);" onclick="completeTicket('.$ticket_id.',400);">完成</a>';
            $reset = '<a href="javascript:void(0);" onclick="resetBilling('.$ticket_id.',2000);">重新开票</a>';
            $cancle = '<a href="javascript:void(0);" onclick="cancelTicket('.$ticket_id.')">取消开票</a>';
            $info = '<a href="javascript:void(0);" onclick="ticketInfo('.$ticket_id.');">查看</a>';
            switch ( $ticket_status ) {
                case \Basic\Cnsts\DICT::TICKET_STATUS_APPLYING :
                    $r['op'] = $info;
                    break;
                case \Basic\Cnsts\DICT::TICKET_STATUS_PAYED :
                    $r['op'] = $edit.' '.$billing;
                    break;
                case \Basic\Cnsts\DICT::TICKET_STATUS_OPENED :
                    $r['op'] = $edit.' '.$send;
                    break;
                case \Basic\Cnsts\DICT::TICKET_STATUS_MAILING :
                    $r['op'] = $edit.' '.$complete;
                    break;
                case \Basic\Cnsts\DICT::TICKET_STATUS_COMPLETE :
                    $r['op'] = $info.' '.$reset;
                    break;
                case \Basic\Cnsts\DICT::TICKET_STATUS_CANCEL :
                case \Basic\Cnsts\DICT::TICKET_STATUS_AGAIN :
                    $r['op'] = $info;
                    break;
                default :
                    break;
            }
        }
    }


    //获取工单的费用列表
    public function getCsWorkFormatTicketFee( $ticket_amount ) {
        $format_fee_type_list = [];
        $fee_type_list = TICKET::CS_WORK_FEE_TYPE_LIST;
        $fee_type_rate_list = TICKET::CS_WORK_FEE_TYPE_TAX_LIST;
        foreach ($fee_type_list as $k => $fee_type ) {
            $fee_rate_list = $fee_type_rate_list[$k];
            $total = 0;
            foreach ( $fee_rate_list as &$fee_rate ) {
                if ( $fee_rate['variable'] ) {
                    $fee_rate['amount'] = round($ticket_amount * $fee_rate['rate'], 2);
                }
                $total += $fee_rate['amount'];
            }

            $fee_rate_list[] = ['title' => '总计', 'variable' => FALSE, 'rate' => 0, 'amount' => $total];
            $format_fee_type_list[] =[
                'key' => $k,
                'value' => $fee_type,
                'total_fee' => $total,
                'fee_list' => $fee_rate_list,
            ];
        }
        return $format_fee_type_list;
    }

    public function upTicketById($ticket_id, $up_data) {
        /** @var TicketModel $ticket_m */
        $ticket_m = D('Admin/Ticket', 'Model');
        $up_res = $ticket_m->upTicketById($ticket_id, $up_data);
        if ( $up_res === false ) {
            return [ERRNO::SQL_UPDATE_ERRNO, '更新失败',[]];
        } else {
            return [ERRNO::SUCCESS, ERRNO::e(ERRNO::SUCCESS), []];
        }
    }


    /**
     *获取发票列表
     */
    public function getTicketListTotal($where, $join) {
        /** @var TicketModel $ticket_m */
        $ticket_m = D('Admin/Ticket', 'Model');
        $total = $ticket_m->getTicketListTotal($where, $join);
        return $total;
    }

}