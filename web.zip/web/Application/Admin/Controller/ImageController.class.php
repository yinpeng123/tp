<?php
namespace Admin\Controller;

use Common\Cnsts\ERRNO;
class ImageController extends AdminSessionController {
    public function __construct() {
        parent::__construct();

    }

    // ajax上传图片接口
    public function ajaxUploadImage()
    {
        $key = key($_FILES);
        if (empty($_FILES[$key]) || $_FILES[$key]['size'] == 0) {
            die("{}");
        }

        $root_dir   = C('IMAGE_PATH')['certificate'];
        $sub_dir    = day();
        $image_info = [];
        list($errcode, $errmsg) = uploadImage($key, $root_dir, $sub_dir, $image_info, 'certificate');
        if ($errcode != ERRNO::SUCCESS) {
            echo json_encode(['error' => $errmsg]);
            exit;
        } else {
            // 前端显示为和初始预览框一样的状态: 移动排序图标, 无进度条
            $res = [
                'initialPreview'       => [imageUrl($image_info)],
                'initialPreviewConfig' => [
                    [
                        'type'    => 'image',
                        'caption' => $image_info['name'],
                        'size'    => $_FILES[$key]['size'],
                        'url'     => '/api/ajaxDeleteImage',
                        'key'     => 1,
                    ],
                ]
            ];
            echo json_encode($res);
            exit;
        }
    }

}
