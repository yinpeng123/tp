<?php

namespace Wechat\Controller;

use Basic\ModelU\CenterModel;
use Basic\Service\UuserService;
use Think\Controller;
use Basic\Cnsts\WECHAT;
use Basic\Service\WechatService;
use Basic\ModelU\UserModel;
use Basic\ModelU\ArticleModel;
use Basic\Service\BbsService;
use Basic\Service\PayService;

class PayController extends WechatController
{

    private $debug;
    function __construct()
    {
        parent::__construct();
        $this->debug=I("debug");
    }


    //支付会员/VIP
    public function index()
    {
        $type = I("forType");
        $fee = I("feeType");
        $pays=I("payType","");
        $uid=I("uid");
        $planId=I('planId');
        $payType = ["vip", "member","reward"];
        $feeType = [
            'year' => 88.8,
            "term" => 28.8,
            "month" => 6,
            'reward'=>I("amount"),

        ];
        if (!in_array($type, $payType)) {
            $this->doResponse(-1, "请选择正确的支付类型");
        }
        if (!in_array($fee, ['year','term','month',"reward"])) {
            $this->doResponse(-1, "请选择正确的支付套餐");
        }
        $body = "";
        $amount=0;
        $addTime=0;
        switch ($type) {
            case "vip":
                $body = "支付vip费用";
                break;
            case "member":
                $body = "支付会员费用";
                break;
            case "reward";
                $body = "支付学生赏金";

                if(!$planId){
                    $this->doResponse(-1, "请提交计划ID");
                }
                break;
        }
        switch ($fee){
            case "year":
                $addTime=365;
                break;
            case "term":
                $addTime=120;
                break;
            case "month":
                $addTime=30;
                break;

        }
        if($pays==1){
            $this->payAccount($planId,I("amount"));
        }
        $amount= $feeType[$fee] ;
        if($planId){
            $fee=$planId;
        }

        $this->pay($amount,$body,$addTime,$uid,$type,$fee);

    }

    //获取套餐

    public function getConfig(){
        $data=[
            'uid'=>$this->user->id,
            'vipInfo'=>[
                 ["连续包年","","立省￥30.4","￥266.6"],
                ["连续包学期","","￥100","￥88.8"],
                ["连续包月","6","","￥266.6"],
            ],
            'memberInfo'=>[
                ["连续包年","","立省￥30.4","￥266.6"],
                ["连续包学期","","￥100","￥88.8"],
                ["连续包月","6","","￥266.6"],
            ]
        ];
        $this->doResponse(0,"ok", $data);
    }


    public function recharge()
    {
        $openid = $this->openid;
        $price = I("fee");
        if (empty($price) || $price <= 0) {
            $this->doResponse(-1, "请输入正确的fee参数");
        }
        $url = 'https://api.mch.weixin.qq.com/pay/unifiedorder';
        $param = [
            'appid' => $this->appid,
            'nonce_str' => $this->getRandom(),
            'mch_id' => $this->mch_id,
            'openid' => $openid,
            'body' => WECHAT::PAY_BODY,
            'out_trade_no' => WECHAT::addWechatOrder(['uid' => $this->user->id, 'amount' => $price,"type"=>"recharge"]),
            'total_fee' => $price * 100,
            'spbill_create_ip' => WECHAT::PAY_IP,
            'notify_url' => WECHAT::PAY_URL,
            'trade_type' => 'JSAPI',
        ];
        ksort($param);
        $sign = strtoupper(md5($this->ToUrlParams($param) . "&key=" . $this->key));
        $param['sign'] = $sign;
        $model = $this->xmlHttp($this->arrayToXml($param), $url);
        $res = $this->xmlToArray($model);
        if (isset($res['return_code']) && $res['return_code'] == 'SUCCESS') {
            $param = array(
                'appId' => $this->appid,
                'timeStamp' => (string)time(),
                'nonceStr' => $this->getRandom(),
                'package' => 'prepay_id=' . $res['prepay_id'],
                'signType' => 'MD5'
            );
            ksort($param);
            $sign = strtoupper(md5($this->ToUrlParams($param) . "&key=" . $this->key));
            $param['sign'] = $sign;
            $this->doResponse(0, "获取支付参数成功", $param);
        }
        $this->doResponse(-1, "获取失败请重试",null);

    }

    public function qiyePay()
    {
        $amount=I("amount");
        if(empty($amount) || intval($amount)<1){
            $this->doResponse(-1, "提现金额必须大于等于1元人民币");
        }
        $where=[
            'uid'=>$this->user->id,
            'type'=>'qiye',
            'ctime'=>['gt',day()],
            'status'=>1,
        ];
        $payCount= (new CenterModel("u_finance_log"))->getListTotal($where);
        if($payCount>=2){
            $this->doResponse(-1, "每日可体现两次");
        }
        $openid=$this->openid;
        $model = new UuserService;
        $info= $model->getUserByOpenid($openid);
        if(intval($info['amount'])<intval($amount)){
            $this->doResponse(-1, "余额不足");
        }
        if($amount<=0){
            $this->doResponse(-1, "参数错误");
        }
        $url = 'https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers';
        $param = [
            'mch_appid' => $this->appid,
            'mchid' => $this->mch_id,
            'nonce_str' => (string)time(),
            'partner_trade_no' => date('Ymdhis', time()) . intval(microtime() * 100) . rand(1, 10),
            'openid' => $openid,
            'check_name' => "NO_CHECK",
            'amount' => $amount*100,
            "desc" => "账户提现",
            'spbill_create_ip' => "154.8.139.184"
        ];
        ksort($param);
        $sign = strtoupper(md5($this->ToUrlParams($param) . "&key=" . $this->key));
        $param['sign'] = $sign;
        $model = $this->http_request($url, $this->arrayToXml($param));
        $res = $this->xmlToArray($model);
        $body=[
            'uid'=>$this->user->id,
            'order_id'=>$param['partner_trade_no'],
            'type'=>"qiye",
            'status'=>$res['result_code']=='FAIL'?0:1,
            'amount'=> $amount,
            'body'=>t_json_encode($res),
        ];
        (new CenterModel("u_finance_log"))->add($body);
        if($res['result_code']=='FAIL'){
            $this->doResponse(-1, "提现失败",$res);
        }
        $model= new CenterModel("u_user");
        $data=[
            'amount'=>intval($info['amount'])-intval($amount),
        ];
        $model->update($this->user->id,$data);
        $this->doResponse(0, "提现成功");



    }
//退款
    public function refund(){
        return;
        $url = 'https://api.mch.weixin.qq.com/secapi/pay/refund';
        $param = [
            'appid' => $this->appid,
            'mch_id' => $this->mch_id,
            'nonce_str' => (string)time(),
            'out_trade_no'=>I("order"),
            'out_refund_no'=>date('Ymdhis', time()) . intval(microtime() * 100) . rand(1, 10),
            'total_fee'=>I('fee')*100,
            'refund_fee'=>I('fee')*100,
          //  'spbill_create_ip' => "154.8.139.184"
        ];
        ksort($param);
        $sign = strtoupper(md5($this->ToUrlParams($param) . "&key=" . $this->key));
        $param['sign'] = $sign;
        $model = $this->http_request($url, $this->arrayToXml($param));
        $res = $this->xmlToArray($model);
        p($res);
    }

    //数组转XML
    function arrayToXml($arr)
    {
        $xml = "<xml>";
        foreach ($arr as $key => $val) {
            if (is_numeric($val)) {
                $xml .= "<" . $key . ">" . $val . "</" . $key . ">";
            } else {
                $xml .= "<" . $key . "><![CDATA[" . $val . "]]></" . $key . ">";
            }
        }
        $xml .= "</xml>";
        return $xml;
    }


    //将XML转为array
    function xmlToArray($xml)
    {
        //禁止引用外部xml实体
        libxml_disable_entity_loader(true);
        $values = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
        return $values;
    }

    function xmlHttp($xmldata, $url)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $xmldata);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $return_xml = curl_exec($curl);
        curl_close($curl);
        return $return_xml;

    }

    function xmlHttpCert($xmldata, $url)
    {
        $params = array(
            'SSLCERT' => getcwd() . '/tools/cert/apiclient_cert.pem',
            'SSLKEY' => getcwd() . '/tools/cert/apiclient_key.pem',
            //    'CAINFO' => getcwd().'/tools/cert/apiclient_p12',
        );
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $xmldata);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSLCERTTYPE, 'PEM');
        curl_setopt($curl, CURLOPT_SSLCERT, $params['SSLCERT']);
        curl_setopt($curl, CURLOPT_SSLKEYTYPE, 'PEM');
        curl_setopt($curl, CURLOPT_SSLKEY, $params['SSLKEY']);
        curl_setopt($curl, CURLOPT_CAINFO, 'PEM');
        //  curl_setopt($curl,CURLOPT_CAINFO, $params['CAINFO']);
        $return_xml = curl_exec($curl);
        curl_close($curl);
        return $return_xml;

    }


    function http_request($url, $fields, $method = 'post', $second = 30)
    {

        $params = array(
            'SSLCERT' => getcwd() . '/tools/cert/apiclient_cert.pem',
            'SSLKEY' => getcwd() . '/tools/cert/apiclient_key.pem',
            'CAINFO' => getcwd() . '/tools/cert/rootca.pem',
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_TIMEOUT, $second);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);


        if (isset($params)) {
            curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM');
            curl_setopt($ch, CURLOPT_SSLCERT, $params['SSLCERT']);
            curl_setopt($ch, CURLOPT_SSLKEYTYPE, 'PEM');
            curl_setopt($ch, CURLOPT_SSLKEY, $params['SSLKEY']);
            curl_setopt($ch, CURLOPT_CAINFO, 'PEM');
            curl_setopt($ch, CURLOPT_CAINFO, $params['CAINFO']);
        }

        if ($method == 'post') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        }
        $data = curl_exec($ch);
        if (!$data) {
            $error = curl_errno($ch);
            $data = '<xml><err_code>' . $error . '</err_code><err_code_des>curl' . $error . '</err_code_des></xml>';
        }
        curl_close($ch);
        return $data;
    }

    public function getRandom($param = 32)
    {
        $str = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $key = "";
        for ($i = 0; $i < $param; $i++) {
            $key .= $str{mt_rand(0, 32)};    //生成php随机数
        }
        return $key;
    }

    public function ToUrlParams($params)
    {
        $string = '';
        if (!empty($params)) {
            $array = array();
            foreach ($params as $key => $value) {
                $array[] = $key . '=' . $value;
            }
            $string = implode("&", $array);
        }
        return $string;
    }

    private function pay($price, $body,$addTime=0,$uid=0,$type="",$feeType="")
    {
        $openid=$this->openid;
        $url = 'https://api.mch.weixin.qq.com/pay/unifiedorder';
        $param = [
            'appid' => $this->appid,
            'nonce_str' => $this->getRandom(),
            'mch_id' => $this->mch_id,
            'openid' => $openid,
            'body' => $body,
            'out_trade_no' => WECHAT::addWechatOrder(['uid' => $uid, 'amount' => $price,'addTime'=>$addTime,'type'=>$type,'feeType'=>$feeType]),
            'total_fee' => $price*100,
            'spbill_create_ip' => WECHAT::PAY_IP,
            'notify_url' => WECHAT::PAY_URL,
            'trade_type' => 'JSAPI',
        ];
        if($this->debug=='Y'){
            $param['total_fee']=1;
        }
        ksort($param);
        $sign = strtoupper(md5($this->ToUrlParams($param) . "&key=" . $this->key));
        $param['sign'] = $sign;
        $model = $this->xmlHttp($this->arrayToXml($param), $url);
        $res = $this->xmlToArray($model);
        if (isset($res['return_code']) && $res['return_code'] == 'SUCCESS') {
            $param = array(
                'appId' => $this->appid,
                'timeStamp' => (string)time(),
                'nonceStr' => $this->getRandom(),
                'package' => 'prepay_id=' . $res['prepay_id'],
                'signType' => 'MD5'
            );
            ksort($param);
            $sign = strtoupper(md5($this->ToUrlParams($param) . "&key=" . $this->key));
            $param['sign'] = $sign;
            $this->doResponse(0, "获取支付参数成功", $param);
        }

    }

    private function payAccount($planid,$price){
        if($price<=0){
            $this->doResponse(-1, "金额错误",null);
        }
        if(!$planid){
            $this->doResponse(-1, "计划参数错误",null);
        }
         if($this->user->amount >=$price){
             $model = new CenterModel("u_user");
             $model->update($this->user->id,['amount'=>$this->user->amount-$price]);
             $model = new CenterModel("u_plan");
             $info=[
                 'is_money'=>1,
                 'money'=>$price
             ];
             $model->update($planid,$info);
             $this->doResponse(0, "余额支付成功",null);
        }
        $this->doResponse(-1, "余额不足",null);
    }

}
